# TunIQ v1.3.0-dev.2

Built directly on `v1.3.0-dev.1`. Existing data remains in `%APPDATA%\TunIQ`.

## Changes

- Simplified Command Center with one next-action card and two focused workspace panels.
- Workspace strip now stays in document flow and no longer covers page headings.
- Guided Tune Path shows only three items: previous completed step, current glowing step, and next locked step.
- Operating-system entry is optional and marked automatic.
- Added OS detection from imported XDF titles/filenames and clearly named BIN files.
- Controller selection alone advances Guided Mode; OS detection can occur after a PCM identification or XDF import.
- Tool cards now route to native TunIQ Flash, Calibration, and Patches pages instead of opening separate application windows.
- External program paths are retained only as backend adapter configuration.
- Preserved Garage, projects, BIN/XDF mapping, revision export, scanner demo, diagnostics, and AppData storage.

## Safety status

Native controller writes remain locked. This build improves unified routing and workflow guidance; it does not claim completed direct PCM communication.
