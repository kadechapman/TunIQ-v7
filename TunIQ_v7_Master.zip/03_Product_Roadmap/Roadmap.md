Alpha
- Branding
- UI
- Prototype

Beta
- OBD
- Logging
- AI Analysis

Release
- Desktop
- Mobile
- Website
- Installer
