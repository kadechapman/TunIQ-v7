# TunIQ UI v7

Theme:
- Matte charcoal
- Frosted glass cards
- Subtle translucent hex/airflow background
- Mint accents
- Satin silver branding

Animations:
- Ripple on tap
- Sliding page transitions
- Animated health gauge
- Live tach sweep
- Floating AI button
- Haptic feedback

Navigation:
Dashboard
Live
Garage
Studio
More
