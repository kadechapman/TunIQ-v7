# TunIQ v7

## Brand
TunIQ

Tagline:
Tune Smarter. Drive Faster.

## Logo Direction
- Q is a tachometer
- Needle integrated into Q
- Matte charcoal + mint green
- Premium motorsport style
- Startup animation:
  1. Tach outline appears
  2. Needle sweeps to redline
  3. Returns to idle
  4. Dashboard loads

Products:
- TunIQ Coach
- TunIQ Live
- TunIQ Garage
- TunIQ Studio
- TunIQ Academy
