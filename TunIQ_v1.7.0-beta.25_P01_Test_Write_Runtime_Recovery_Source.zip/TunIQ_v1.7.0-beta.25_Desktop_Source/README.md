# TunIQ v1.7.0-beta.25 — P01 Test Write Runtime Recovery

Beta.25 fixes the first real Test Write failure captured from the Customline P01 project after the beta.24 finalizer completed steps 1–6.

The diagnostic proved that PCM Hammer received the correct `--test-write <file> --device COM3` command, but then reported:

- no `Kernel-*.bin` / `Loader-*.bin` files in TunIQ's project working directory; and
- a timeout while opening Bluetooth serial port COM3.

TunIQ now discovers the kernel directory from the complete PCM Hammer portable installation and passes `--kernel-dir` explicitly. It launches PCM Hammer from the kernel/tool folder instead of the TunIQ project folder.

For Read Properties, full reads, and Test Write, a port-open timeout now triggers a bounded recovery sequence:

1. close TunIQ's persistent serial session and abort stale bridge requests;
2. retry the selected COM port once;
3. inspect Windows-ranked OBDLink ports and PCM Hammer `--list-devices` output;
4. try a recognized outgoing alternate port once; and
5. either complete the operation or stop with the exact code `adapter-open-timeout`.

No endless retry loop is permitted. Destructive write operations do not automatically switch devices.

See `P01_TEST_WRITE_RUNTIME_RECOVERY.md` and `TEST_REPORT_v1.7.0-beta.25.md`.
