@echo off
setlocal
set OLD_CACHE=%APPDATA%\tuniq-desktop
set NEW_CACHE=%APPDATA%\TunIQ\Runtime
if exist "%OLD_CACHE%" rmdir /s /q "%OLD_CACHE%"
if exist "%NEW_CACHE%" rmdir /s /q "%NEW_CACHE%"
echo Electron runtime caches were removed.
echo Vehicles, projects, BINs, XDFs, and settings were not deleted.
pause
endlocal
