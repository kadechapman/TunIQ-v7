# TunIQ v1.2.2-dev.6

## Added
- Active-project BIN import into protected Originals
- SHA-256 fingerprinting
- TunerPro XDF import and common XML XDF parsing
- XDF table and constant mapping into Calibration Lab
- Address-aware 8/16/32-bit little-endian BIN reads/writes
- Basic XDF MATH equation conversion and inverse conversion
- Safe revision BIN export into Revisions (original is never overwritten)
- Active BIN/XDF handoff when launching TunerPro
- Project file status and project folder controls

## Current limitations
- XDF is an open, flexible format. This build supports common XDFTABLE/XDFCONSTANT, EMBEDDEDDATA, XDFAXIS, LABEL and simple arithmetic MATH equations. Advanced flags, bit masks, floating-point storage, lookup equations, checksums, categories and unusual strides may need additional support.
- PCM Hammer and Universal Patcher are integrated as detected/launchable project-aware external apps. Their internal UI state is not controlled yet.
- Before flashing any exported BIN, verify it in TunerPro/Universal Patcher and confirm checksums and the controller/OS match.
