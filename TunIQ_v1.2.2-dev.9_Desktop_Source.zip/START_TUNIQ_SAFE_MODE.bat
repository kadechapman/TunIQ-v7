@echo off
setlocal
cd /d "%~dp0"
echo Starting TunIQ v1.2.2-dev.9 in safe mode...
set ELECTRON_ENABLE_LOGGING=1
set ELECTRON_DISABLE_GPU=1
set ELECTRON_DISABLE_SANDBOX=1
call npm start
echo.
echo TunIQ has closed. Logs are stored at:
echo %APPDATA%\TunIQ\Logs\startup.log
echo %APPDATA%\TunIQ\Logs\desktop-crash.log
pause
endlocal
