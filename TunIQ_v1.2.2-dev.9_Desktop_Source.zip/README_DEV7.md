# TunIQ v1.2.2-dev.7

Calibration Lab layout hotfix built directly on v1.2.2-dev.6.

## Fixed
- Scoped the fixed navigation styles to `.app-sidebar` so nested Calibration Lab sidebars no longer become fixed overlays.
- Calibration groups, editor, toolbar, table, and history now occupy separate layout regions.
- Added horizontal scrolling for wide calibration maps while keeping row/column headers sticky.
- Added a bounded, independently scrolling calibration group list and revision history.
- Improved small-window behavior and toolbar wrapping.
- Preserved all v1.2.2-dev.6 BIN/XDF mapping and external-tool integration.
