@echo off
setlocal
cd /d "%~dp0"
echo Starting TunIQ v1.2.2-dev.9...
if not exist node_modules\electron\dist\electron.exe (
  call INSTALL_AND_RUN_WINDOWS.bat
  exit /b %errorlevel%
)
call npm start
if errorlevel 1 (
  echo.
  echo TunIQ stopped with an error.
  echo Startup log: %APPDATA%\TunIQ\Logs\startup.log
  echo Crash log:   %APPDATA%\TunIQ\Logs\desktop-crash.log
  pause
)
endlocal
