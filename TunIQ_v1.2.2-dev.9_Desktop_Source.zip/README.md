# TunIQ v1.2.2-dev.9

Built directly on the v1.2.2-dev.8 source and preserving `%APPDATA%\TunIQ` data.

## Current working areas

- Persistent Garage vehicles
- Protected Tune Workflow projects
- Per-project Originals, Definitions, Revisions, Logs, and Backups folders
- PCM Hammer, TunerPro, and Universal Patcher detection, verification, browsing, download links, and launching
- Project-aware TunerPro BIN/XDF handoff
- BIN fingerprinting with SHA-256
- Common TunerPro XDF table and constant parsing
- Editable mapped calibration grids
- Undo, redo, multi-cell math, modified-cell tracking, validation, revision snapshots, and revision BIN export
- AppData storage with migration from older Documents installs
- Startup, cache, and malformed-workspace recovery

## Safety limits

TunIQ does not directly flash a PCM in this development build. Exported BIN revisions should be verified in TunerPro or Universal Patcher before using PCM Hammer. Unsupported XDF data types or equations are skipped or blocked from write-back instead of being guessed.

## Windows

1. Extract the complete ZIP into a new local folder.
2. Run `INSTALL_AND_RUN_WINDOWS.bat` once.
3. Use `START_TUNIQ_WINDOWS.bat` afterward.
4. Use `START_TUNIQ_SAFE_MODE.bat` only when diagnosing a startup problem.

See `README_DEV9.md` for the complete dev.9 change list.
