const fs = require('fs');

const MAX_AXIS = 256;
const MAX_TABLE_CELLS = 65536;
const MAX_DEFINITIONS = 5000;

function attrs(source = '') {
  const result = {};
  for (const match of source.matchAll(/([\w:-]+)\s*=\s*"([^"]*)"/g)) {
    result[match[1].toLowerCase()] = match[2];
  }
  return result;
}

function num(value, fallback = 0) {
  if (value == null || value === '') return fallback;
  const text = String(value).trim();
  if (/^0x/i.test(text)) return parseInt(text, 16);
  const parsed = Number(text);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function positiveInt(value, fallback = 1, max = MAX_AXIS) {
  const parsed = Math.floor(num(value, fallback));
  if (!Number.isFinite(parsed) || parsed < 1) return fallback;
  return Math.min(parsed, max);
}

function text(block, tag) {
  const match = block.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, 'i'));
  return match ? match[1].replace(/<[^>]+>/g, '').trim() : '';
}

function tagAttrs(block, tag) {
  const match = block.match(new RegExp(`<${tag}\\b([^>]*)>`, 'i'));
  return match ? attrs(match[1]) : {};
}

function allTagAttrs(block, tag) {
  return [...block.matchAll(new RegExp(`<${tag}\\b([^>]*)>`, 'gi'))].map(match => attrs(match[1]));
}

function equation(block) {
  const match = block.match(/<MATH\b([^>]*)>/i);
  return match ? (attrs(match[1]).equation || 'X') : 'X';
}

function evalEquation(eq, x) {
  if (!eq) return x;
  if (!/^[Xx0-9+\-*/().\s]+$/.test(eq)) return x;
  try {
    return Function('X', `"use strict";return (${eq.replace(/x/g, 'X')})`)(x);
  } catch {
    return x;
  }
}

function inverseEquation(eq, y) {
  if (!eq || /^X$/i.test(eq.trim())) return y;
  const samples = [0, 1, 2, 10, 100, 1000, 65535].map(x => [x, evalEquation(eq, x)]);
  const changed = samples.find(([, value]) => value !== samples[0][1]);
  if (!changed) return y;
  const slope = (changed[1] - samples[0][1]) / (changed[0] - samples[0][0]);
  return slope ? (y - samples[0][1]) / slope : y;
}

function parseAxis(block, id, fallbackCount, warnings) {
  let chosen = null;
  for (const match of block.matchAll(/<XDFAXIS\b([^>]*)>([\s\S]*?)<\/XDFAXIS>/gi)) {
    const axisAttrs = attrs(match[1]);
    if (String(axisAttrs.id || '').toLowerCase() === id.toLowerCase()) {
      chosen = { attrs: axisAttrs, body: match[2] };
      break;
    }
  }

  const safeFallback = positiveInt(fallbackCount, 1);
  if (!chosen) {
    return { count: safeFallback, labels: Array.from({ length: safeFallback }, (_, index) => String(index)) };
  }

  const requested = Math.floor(num(chosen.attrs.indexcount || chosen.attrs.count, safeFallback));
  const count = positiveInt(requested, safeFallback);
  if (requested > MAX_AXIS) warnings.push(`Axis ${id} was limited from ${requested} to ${MAX_AXIS} cells.`);

  const labels = allTagAttrs(chosen.body, 'LABEL')
    .map(item => item.value ?? item.label)
    .filter(value => value != null)
    .slice(0, count);

  while (labels.length < count) labels.push(String(labels.length));
  return { count, labels };
}

function normalizeDefinition(definition, warnings) {
  let rows = positiveInt(definition.rows, 1);
  let cols = positiveInt(definition.cols, 1);
  if (rows * cols > MAX_TABLE_CELLS) {
    const limitedCols = Math.max(1, Math.floor(MAX_TABLE_CELLS / rows));
    warnings.push(`${definition.name} was limited from ${rows * cols} to ${rows * limitedCols} cells.`);
    cols = limitedCols;
  }

  const elementBits = [8, 16, 32].includes(Number(definition.elementBits)) ? Number(definition.elementBits) : 8;
  return {
    ...definition,
    address: Math.max(0, Math.floor(Number(definition.address) || 0)),
    elementBits,
    rows,
    cols,
    rowHeaders: (definition.rowHeaders || []).slice(0, rows),
    colHeaders: (definition.colHeaders || []).slice(0, cols),
    rowStride: Math.max(0, Number(definition.rowStride) || 0),
    colStride: Math.max(0, Number(definition.colStride) || 0)
  };
}

function parseXdf(file) {
  const xml = fs.readFileSync(file, 'utf8');
  const tables = [];
  const warnings = [];

  for (const match of xml.matchAll(/<XDFTABLE\b([^>]*)>([\s\S]*?)<\/XDFTABLE>/gi)) {
    if (tables.length >= MAX_DEFINITIONS) {
      warnings.push(`Definition import stopped at ${MAX_DEFINITIONS} items.`);
      break;
    }
    const tableAttrs = attrs(match[1]);
    const body = match[2];
    const embedded = tagAttrs(body, 'EMBEDDEDDATA');
    const x = parseAxis(body, 'x', num(embedded.colcount, 1), warnings);
    const y = parseAxis(body, 'y', num(embedded.rowcount, 1), warnings);
    tables.push(normalizeDefinition({
      id: tableAttrs.uniqueid || tableAttrs.id || `table-${tables.length}`,
      type: 'table',
      name: tableAttrs.title || text(body, 'TITLE') || `Table ${tables.length + 1}`,
      description: text(body, 'DESCRIPTION'),
      address: num(embedded.mmedaddress || embedded.address),
      elementBits: num(embedded.mmedelementsizebits || embedded.elementsizebits, 8),
      rowStride: num(embedded.mmedrowstridebits, 0) / 8,
      colStride: num(embedded.mmedcolstridebits, 0) / 8,
      rows: y.count,
      cols: x.count,
      rowHeaders: y.labels,
      colHeaders: x.labels,
      equation: equation(body),
      unit: tagAttrs(body, 'MATH').units || '',
      signed: /signed/i.test(embedded.mmedtypeflags || '')
    }, warnings));
  }

  if (tables.length < MAX_DEFINITIONS) {
    for (const match of xml.matchAll(/<XDFCONSTANT\b([^>]*)>([\s\S]*?)<\/XDFCONSTANT>/gi)) {
      if (tables.length >= MAX_DEFINITIONS) {
        warnings.push(`Definition import stopped at ${MAX_DEFINITIONS} items.`);
        break;
      }
      const constantAttrs = attrs(match[1]);
      const body = match[2];
      const embedded = tagAttrs(body, 'EMBEDDEDDATA');
      tables.push(normalizeDefinition({
        id: constantAttrs.uniqueid || constantAttrs.id || `constant-${tables.length}`,
        type: 'constant',
        name: constantAttrs.title || text(body, 'TITLE') || `Constant ${tables.length + 1}`,
        description: text(body, 'DESCRIPTION'),
        address: num(embedded.mmedaddress || embedded.address),
        elementBits: num(embedded.mmedelementsizebits || embedded.elementsizebits, 8),
        rows: 1,
        cols: 1,
        rowHeaders: ['Value'],
        colHeaders: ['Value'],
        equation: equation(body),
        unit: tagAttrs(body, 'MATH').units || '',
        signed: /signed/i.test(embedded.mmedtypeflags || '')
      }, warnings));
    }
  }

  return {
    title: tagAttrs(xml, 'XDFHEADER').deftitle || file.split(/[\\/]/).pop(),
    tables,
    warnings
  };
}

function readRaw(buffer, offset, bits, signed = false) {
  const bytes = bits / 8;
  if (!Number.isInteger(offset) || offset < 0 || offset + bytes > buffer.length) return 0;
  if (bits === 8) return signed ? buffer.readInt8(offset) : buffer.readUInt8(offset);
  if (bits === 16) return signed ? buffer.readInt16LE(offset) : buffer.readUInt16LE(offset);
  if (bits === 32) return signed ? buffer.readInt32LE(offset) : buffer.readUInt32LE(offset);
  return buffer.readUInt8(offset);
}

function writeRaw(buffer, offset, bits, value, signed = false) {
  value = Math.round(Number(value));
  const bytes = bits / 8;
  if (!Number.isInteger(offset) || offset < 0 || offset + bytes > buffer.length) {
    throw new Error(`Address 0x${Math.max(0, Number(offset) || 0).toString(16)} is outside BIN`);
  }
  if (bits === 8) return signed ? buffer.writeInt8(Math.max(-128, Math.min(127, value)), offset) : buffer.writeUInt8(Math.max(0, Math.min(255, value)), offset);
  if (bits === 16) return signed ? buffer.writeInt16LE(Math.max(-32768, Math.min(32767, value)), offset) : buffer.writeUInt16LE(Math.max(0, Math.min(65535, value)), offset);
  if (bits === 32) return signed ? buffer.writeInt32LE(Math.max(-2147483648, Math.min(2147483647, value)), offset) : buffer.writeUInt32LE(Math.max(0, Math.min(4294967295, value)), offset);
  return buffer.writeUInt8(value & 255, offset);
}

function hydrate(definition, bin) {
  const rows = positiveInt(definition.rows, 1);
  const cols = positiveInt(definition.cols, 1);
  const bytes = definition.elementBits / 8;
  const rowStride = definition.rowStride || cols * bytes;
  const colStride = definition.colStride || bytes;
  const values = Array.from({ length: rows }, (_, row) => Array.from({ length: cols }, (_, col) => {
    const offset = definition.address + rowStride * row + colStride * col;
    return Number(evalEquation(definition.equation, readRaw(bin, offset, definition.elementBits, definition.signed)).toFixed(4));
  }));
  return { ...definition, rows, cols, values };
}

function applyTable(buffer, table) {
  if (!table || !Array.isArray(table.values)) return;
  const rows = Math.min(positiveInt(table.rows, table.values.length), table.values.length);
  const cols = Math.min(positiveInt(table.cols, table.values[0]?.length || 1), table.values[0]?.length || 1);
  const bytes = table.elementBits / 8;
  const rowStride = table.rowStride || cols * bytes;
  const colStride = table.colStride || bytes;
  for (let row = 0; row < rows; row += 1) {
    for (let col = 0; col < cols; col += 1) {
      const offset = table.address + rowStride * row + colStride * col;
      writeRaw(buffer, offset, table.elementBits, inverseEquation(table.equation, Number(table.values[row][col])), table.signed);
    }
  }
}

module.exports = { parseXdf, hydrate, applyTable };
