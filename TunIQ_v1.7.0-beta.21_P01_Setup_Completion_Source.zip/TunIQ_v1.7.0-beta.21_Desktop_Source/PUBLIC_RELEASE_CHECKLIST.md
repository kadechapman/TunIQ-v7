# TunIQ Public Release Checklist

## Required before a broad public release
- Select and publish a software license.
- Create the official GitHub organization/repository.
- Replace draft privacy and beta documents with reviewed versions.
- Configure a secure update feed and HTTPS improvement endpoint.
- Obtain a Windows code-signing certificate and protect signing secrets.
- Bench-test identify, read, test-write, calibration-write, full-write, interruption, and recovery paths.
- Publish the exact Verified controller/OS/interface combinations.
- Add verified enhanced PID packs and known-good XDF/BIN fixtures.
- Confirm redistribution terms for PCM Hammer, TunerPro, Universal Patcher, and every bundled component.
- Add server authentication, rate limits, malware scanning, moderation, data deletion, retention controls, and backups.
- Create an incident response and rollback process.

## Release flow
1. Run `npm test` and `npm run check`.
2. Build the installer using GitHub Actions or `BUILD_WINDOWS_INSTALLER.bat`.
3. Sign the installer.
4. Generate and publish SHA-256 checksums.
5. Mark the GitHub release as a prerelease.
6. Publish supported/experimental/unsupported tables and known issues.
7. Start with invited bench testers, then widen access gradually.

## Phone log importer website
- Enable GitHub Pages with **GitHub Actions** as the source.
- Run `Deploy TunIQ OBDLink Log Importer`.
- Test CSV processing on iOS and Android before advertising the site.
- Confirm that the production site remains client-side unless a reviewed privacy-safe backend is deliberately added.
- Publish the required PID checklist for each supported tuning test.
