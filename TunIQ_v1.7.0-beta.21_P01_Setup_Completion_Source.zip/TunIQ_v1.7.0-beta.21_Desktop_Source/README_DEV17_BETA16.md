# TunIQ v1.7.0-beta.16 Developer Notes

- Added `src/com-recovery.js`.
- Added structured Windows bridge timeout classification and tracked process termination.
- Added alternate COM-port recovery to `FlashManager.preparePort`.
- Bumped P01 automation state schema to version 3.
- Added legacy stopped-state normalization, `canResume`, and manual recovery.
- Added IPC: `p01-auto:recover` and `p01-auto:assisted-bypass`.
- Added renderer controls for recovery and assisted bypass.
- Added regression coverage for the exact lock-probe timeout/resume failure.
