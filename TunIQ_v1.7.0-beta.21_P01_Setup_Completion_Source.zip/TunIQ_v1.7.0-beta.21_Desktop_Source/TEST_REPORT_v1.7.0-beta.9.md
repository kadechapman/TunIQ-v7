# TunIQ v1.7.0-beta.9 Test Report

## Release

- Version: `1.7.0-beta.9`
- Name: **Quality of Life**
- Source base: `TunIQ_v1.7.0-beta.8_Connection_Doctor_Offline_Lab_Source.zip`
- Verification type: source checks, automated tests, renderer/IPC contracts, and software simulations
- Real hardware verified: **No**

## Quality-of-life work completed

- Added a searchable **Quick Switch** (`Ctrl+K`) for TunIQ pages, saved projects, Connection Doctor, Garage, BIN/XDF imports, and common actions.
- Added an instant active-project switcher in the header.
- Added Back/Forward navigation with header controls and `Alt+Left` / `Alt+Right`.
- Added a persistent collapsible sidebar with `Ctrl+B`.
- Added restart restoration for the last page, recent pages, Tune Path state, sidebar state, compact density, reduced motion, and per-page scroll positions.
- Added a Dashboard **Recent Work** panel.
- Added compact-density and reduced-motion preferences.
- Added non-blocking toast notifications for ordinary status changes while retaining blocking confirmation for destructive and flash-sensitive actions.
- Added validated UI-preference storage that rejects invalid page identifiers, limits history, removes unsafe scroll keys, clamps scroll values, and normalizes booleans.

## Verification results

| Verification | Result |
|---|---:|
| JavaScript source syntax check | Passed |
| Automated unit/integration and contract suite | **14/14 groups passed** |
| Quality-of-life simulations | **3/3 passed** |
| Connection Doctor simulations | **3/3 passed** |
| Offline P01 Recovery Lab scenarios | **3/3 passed** |
| Clean P01 end-to-end simulation | Passed |
| COM lock/disconnect/restart-resume simulation | Passed |
| Partial/mismatch/repeated block-failure simulation | Passed |
| Combined recovery-labs command | Passed |

### Quality-of-life simulation evidence

1. **Restart restoration:** restored the Device Manager page, persistent collapsed states, and scroll position `864` after a simulated restart.
2. **Rapid navigation:** preserved an ordered recent-page list and separate scroll positions while moving repeatedly between pages.
3. **Corruption and search:** rejected an invalid page path, removed an unsafe scroll key, clamped an extreme scroll value, normalized a malformed boolean, and correctly ranked project and Connection Doctor searches.

### Retained safety and recovery evidence

- PCM Hammer 2.x help-driven command and real-output parsing tests remained green.
- COM release/lock detection remained green.
- Exactly two complete `524,288`-byte reads and matching SHA-256 enforcement remained green.
- Partial reads, mismatched reads, and repeated block failures remained rejected.
- Exact-step restart/resume remained green.
- Exact-OS XDF, checksum, revision, Test Write, and write-gating tests remained green.

## Commands executed

```text
npm run check
npm test
npm run test:qol-sim
npm run test:connection-doctor
npm run test:p01-offline-lab
npm run test:p01-sim:clean
npm run test:p01-sim:recovery
npm run test:p01-sim:failures
npm run test:recovery-labs
```

Detailed logs and JSON results are included under `test-results/`.

## Verification boundary

No real OBDLink MX+, Windows Bluetooth stack, physical COM port, P01 PCM, vehicle, live voltage, real PCM read, Test Write, or flash write was available in this build environment. This release therefore makes **no real-hardware verification claim**. Windows PowerShell serial behavior is covered by source/contract tests and simulated adapters, not physical-device execution.
