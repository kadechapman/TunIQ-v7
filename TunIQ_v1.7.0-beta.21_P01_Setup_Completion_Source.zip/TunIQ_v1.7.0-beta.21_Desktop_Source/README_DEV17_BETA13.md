# TunIQ v1.7.0-beta.13 Developer Notes

## Release theme

Autonomous Tune Agent: complete supported calibration generation and automatic application.

## New source

- `src/autonomous-tune.js`
- `tests/autonomous-tune-simulations.js`
- `AUTONOMOUS_TUNE_AGENT.md`

## Main-process IPC

- `autonomous-tune:status`
- `autonomous-tune:start`
- `autonomous-tune:resume`
- `autonomous-tune:run-log-cycle`
- `autonomous-tune:reset`

## Persistence

Each project stores its current run in `AI/AutonomousTune/state.json`, an audit trail in `AI/AutonomousTune/audit.json`, and previous runs in `AI/AutonomousTune/Archive`.

## Important invariant

Autonomous mode removes per-cell approval but does not remove validation. Every applied item still passes the exact project/BIN/XDF binding check, current-value check, XDF min/max check, and role-specific safety envelope before it is written into a new workspace revision.
