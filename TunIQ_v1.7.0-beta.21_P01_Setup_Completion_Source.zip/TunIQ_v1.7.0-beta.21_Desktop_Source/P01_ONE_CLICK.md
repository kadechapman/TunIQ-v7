# Historical beta.6 note — superseded

The beta.6 “P01 One-Click Commissioning” name and third-read tie-break behavior are retired.

Use **Guided Automatic P01 Setup** in v1.7.0-beta.10 and see:

- `P01_HARDWARE_RECOVERY.md`
- `P01_COMMISSIONING.md`
- `TEST_REPORT_v1.7.0-beta.10.md`

Beta.8 retains exactly two complete 524,288-byte reads with matching SHA-256 hashes and does not claim real-hardware verification.
