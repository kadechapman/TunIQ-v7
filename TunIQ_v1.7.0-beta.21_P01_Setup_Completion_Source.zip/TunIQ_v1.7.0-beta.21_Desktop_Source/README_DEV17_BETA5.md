# TunIQ v1.7.0-beta.5 — P01 Evidence Integration

This release adds a P01 evidence workspace to Live Log. It registers five public log sessions, P01 OS-specific definition references, stock BIN/XDF catalogs, PCM Logger and Universal Patcher resources.

## Added

- Public evidence registry with confidence labels.
- Local evidence import with SHA-256 fingerprints.
- PCM Logger, Torque, OBDLink, Universal Patcher and generic CSV source detection.
- Comma-plus-space and preamble/header detection.
- Expanded P01 channels including both fuel-trim banks, fueling state, O2s, injector pulse width, IAC/idle airflow, wideband voltage and transmission data.
- VIN, GPS, device, account and path stripping.
- Normalized-session deduplication.
- Active-project controller/OS compatibility checks.
- Explicit blockers that prevent public evidence from becoming a tune rule automatically.

## Not included

Third-party raw logs, BINs and XDFs are not redistributed. The source registry opens the original source and accepts a locally downloaded file. No public evidence authorizes a flash or AI tune by itself.
