# TunIQ v1.7.0-beta.10 Test Report

## Release

- Version: `1.7.0-beta.10`
- Name: **Garage & Project Foundation**
- Base: TunIQ v1.7.0-beta.9 Quality of Life
- Verification type: source checks, automated unit/integration tests, renderer/IPC contracts, isolated filesystem simulations, and retained software recovery simulations

## Garage and project work completed

- Replaced name-only project relationships with durable `vehicleId` links and project-safe vehicle snapshots.
- Added migration for legacy name-only project manifests.
- Added rich vehicle fields for engine, transmission, drivetrain, fuel, tire size, rear gear, mileage, controller, OS, PCM hardware ID, service number, modifications, maintenance, VIN, notes, favorites, and managed photos.
- Added local VIN format/check-digit validation while allowing old incomplete VIN records to migrate without blocking startup.
- Added rename propagation across linked project manifests.
- Added linked-project deletion protection with the affected project names in the stop message.
- Added duplicate-vehicle, favorite, search/filter, photo, project-count, and Create Project workflows.
- Added PCM Hammer Read Properties synchronization into the Garage profile linked to the active project.

## Automated suite

`npm test` passed **15 of 15** groups:

1. XDF parse/hydrate/write and checksum correction.
2. Universal Patcher report gating and byte-range comparison.
3. AI log-to-cell proposal and approval execution.
4. PCM Hammer 2.x command discovery, output parsing, COM ownership, strict reads, Test Write, and write gating.
5. Persistent logging, enhanced PIDs, markers, CSV, and analysis.
6. Connection Doctor and Offline P01 Lab foundations.
7. Quality-of-life persistence and Quick Switch ranking.
8. Garage v2 migration, VIN handling, rich profiles, durable links, favorites, duplication, and deletion protection.
9. Public beta privacy and compatibility controls.
10. OBDLink mobile CSV import and privacy removal.
11. Natural-language goal parsing and high-risk gates.
12. P01 commissioning proof requirements.
13. P01 evidence integration.
14. Guided P01 exact-step resume and strict mapping.
15. Renderer DOM, web importer, Garage, preload, and main-process IPC contracts.

## Garage lifecycle simulations

`npm run test:garage-sim` passed all three isolated scenarios:

- **Durable link and rename:** a legacy name-only project was linked to the vehicle ID, then updated when the vehicle name, gear, and tire profile changed.
- **Deletion protection and recovery:** deletion stopped with `vehicle-in-use`; after reassignment, deletion completed without altering the other project.
- **Rich profile persistence:** VIN check digit, PCM identity fields, modifications, maintenance history, favorite state, and duplicate VIN clearing were verified.

## Retained simulations

- Quality-of-life restart/navigation simulations: **3/3 passed**.
- Connection Doctor simulations: **3/3 passed**.
- Offline P01 Recovery Lab scenarios: **3/3 passed**.
- P01 hardware-recovery simulations: **3/3 passed**.
  - Clean success.
  - COM lock, disconnect, and restart/resume.
  - Partial read, hash mismatch, and repeated block-read failures.

## Packaging verification

The source ZIP is built only after this report and the source manifest are finalized. The extracted archive is then checked against `SOURCE_MANIFEST_SHA256.txt` and rerun through the syntax check, automated suite, Garage simulations, and retained simulation chain. Archive-specific results are recorded in the external release report delivered with the ZIP.

## Verification boundary

This release is **not** claimed as real-hardware verified. The build environment did not test:

- A real OBDLink MX+ or Windows Bluetooth COM port.
- A real vehicle, P01/P59 controller, or bench harness.
- Real battery voltage under read/write load.
- Real PCM Hammer Read, Test Write, or Calibration Write operations.
- A Windows Electron GUI launch or installer execution.

The VIN checker validates format and the standard check digit locally; it is not an online vehicle-history or manufacturer database lookup.
