const assert = require('assert');
const fs = require('fs');
const path = require('path');

const APP_FILE = path.join(__dirname, '../src/renderer/app.js');

function sourceBetween(source, start, end) {
  const from = source.indexOf(start);
  const to = source.indexOf(end, from + start.length);
  if (from < 0 || to < 0) throw new Error(`Could not extract renderer source between ${start} and ${end}`);
  return source.slice(from, to);
}

function element() {
  const classes = new Set();
  return {
    textContent: '', innerHTML: '', className: '', disabled: false, placeholder: '', style: {},
    classList: {
      toggle(name, force) { if (force === undefined ? !classes.has(name) : force) classes.add(name); else classes.delete(name); },
      add(name) { classes.add(name); }, remove(name) { classes.delete(name); }, contains(name) { return classes.has(name); }
    }
  };
}

function createRenderHarness() {
  const source = fs.readFileSync(APP_FILE, 'utf8');
  const phaseSource = sourceBetween(source, 'function p01AutoPhaseLabel', 'function renderP01Auto');
  const renderSource = sourceBetween(source, 'function renderP01Auto', 'async function startP01Auto');
  const elements = new Map();
  const ids = ['p01AutoBadge','p01AutoPhase','p01AutoPercent','p01AutoProgressBar','p01AutoSummary','p01AutoMessages','p01AutoStart','p01AutoResume','p01AutoCancel','p01AutoRecover','p01AutoAssistedBypass','p01AutoChooseXdf','p01AutoWriteBox','p01AutoWriteSummary','p01AutoWriteConfirmation'];
  for (const id of ids) elements.set(`#${id}`, element());
  const state = { p01Auto: null, p01: null, workspace: {}, activeProject: { name: 'Customline' } };
  const $ = selector => elements.get(selector) || null;
  const safe = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  let commissioningRenders = 0;
  const factory = new Function('state', '$', 'safe', 'renderP01Commissioning', `${phaseSource}\n${renderSource}\nreturn renderP01Auto;`);
  const render = factory(state, $, safe, () => { commissioningRenders += 1; });
  return { source, state, elements, render, commissioningRenders: () => commissioningRenders };
}

function scenarioExactStartupCrashRegression() {
  const h = createRenderHarness();
  assert(!h.source.includes("String(s.stop?.code||'')"), 'the beta.17 undefined s reference must not return');
  assert.doesNotThrow(() => h.render({
    status: 'paused', phase: 'stopped-integrated-migration', progress: 10,
    stop: { code: 'unsupported-cli' }, blocker: 'Retry the internal PCM Hammer runner.', messages: []
  }));
  assert.equal(h.elements.get('#p01AutoResume').disabled, false, 'paused startup state must remain resumable');
  assert.equal(h.elements.get('#p01AutoAssistedBypass').classList.contains('hidden'), false, 'integrated retry must be visible for CLI recovery');
  assert.equal(h.commissioningRenders(), 1);
  return { name: 'exact-startup-reference-error', passed: true };
}

function scenarioRendererIsolationBoundary() {
  const source = fs.readFileSync(APP_FILE, 'utf8');
  const safeSource = sourceBetween(source, 'function renderSafely', 'function updateNavigationButtons');
  const notifications = [];
  const factory = new Function('appReady', 'notify', `${safeSource}\nreturn renderSafely;`);
  const renderSafely = factory(true, (...args) => notifications.push(args));
  const originalConsoleError = console.error;
  console.error = () => {};
  try {
    assert.equal(renderSafely('Broken card', () => { throw new Error('simulated widget failure'); }), null);
  } finally {
    console.error = originalConsoleError;
  }
  assert.equal(renderSafely('Healthy card', () => 42), 42);
  assert.equal(notifications.length, 1, 'only the failed renderer should notify');
  assert(String(notifications[0][0]).includes('rest of TunIQ is still available'));
  return { name: 'renderer-isolation-boundary', passed: true };
}

function scenarioP01StatesRemainRenderable() {
  const h = createRenderHarness();
  const states = [
    { status: 'running', phase: 'waiting-read-1', progress: 42, messages: [{ at: Date.now(), text: 'Reading block 12', level: 'info' }] },
    { status: 'paused', phase: 'stopped-lock-probe-timeout', progress: 20, stop: { code: 'lock-probe-timeout' }, portRecovery: { device: 'COM3', attempts: [{ port: 'COM3' }, { port: 'COM4' }] }, messages: [] },
    { status: 'complete', phase: 'ready-to-write', progress: 100, activeProject: { name: 'Customline' }, revision: { name: 'Customline-r3.bin' }, messages: [] }
  ];
  for (const value of states) assert.doesNotThrow(() => h.render(value));
  assert(h.elements.get('#p01AutoWriteSummary').textContent.includes('WRITE Customline'));
  assert.equal(h.elements.get('#p01AutoWriteBox').classList.contains('hidden'), false);
  return { name: 'p01-running-paused-ready-states', passed: true };
}

function runStartupRecoverySimulations() {
  return {
    type: 'tuniq-startup-recovery-simulations', version: '1.7.0-beta.21',
    generatedAt: new Date().toISOString(), softwareSimulationOnly: true, realHardwareVerified: false,
    scenarios: [scenarioExactStartupCrashRegression(), scenarioRendererIsolationBoundary(), scenarioP01StatesRemainRenderable()]
  };
}

if (require.main === module) {
  try {
    const report = runStartupRecoverySimulations();
    for (const scenario of report.scenarios) console.log(`✓ beta.18 startup recovery simulation: ${scenario.name}`);
    console.log('All TunIQ beta.21 Startup Recovery simulations passed.');
  } catch (error) {
    console.error(error.stack || error);
    process.exit(1);
  }
}

module.exports = { runStartupRecoverySimulations };
