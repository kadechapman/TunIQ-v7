const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { GarageManager } = require('../src/garage');

function setup(name) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), `tuniq-garage-${name}-`));
  const data = path.join(root, 'TunIQ');
  const projects = path.join(data, 'Projects');
  fs.mkdirSync(path.join(data, 'Vehicles'), { recursive: true });
  fs.mkdirSync(projects, { recursive: true });
  const events = [];
  const manager = new GarageManager({ dataRoot: () => data, projectsRoot: () => projects, appendActivity: (type, details) => events.push({ type, details }) });
  return { root, data, projects, events, manager };
}

function writeProject(projects, id, manifest) {
  const folder = path.join(projects, id);
  fs.mkdirSync(folder, { recursive: true });
  fs.writeFileSync(path.join(folder, 'project.json'), JSON.stringify({ id, name: id, ...manifest }, null, 2));
  return path.join(folder, 'project.json');
}

function scenarioDurableRename() {
  const ctx = setup('rename');
  try {
    const vehicle = ctx.manager.save({ name: 'OBS Truck', year: '1995', make: 'Chevrolet', model: 'K1500', engine: '5.3 LM7', transmission: '4L80E', controller: 'P01' });
    const projectFile = writeProject(ctx.projects, 'obs-tune', { vehicle: 'OBS Truck', controller: 'P01' });
    const renamed = ctx.manager.save({ ...vehicle, name: 'OBS LS Street Truck', rearGear: '4.10', tireSize: '275/40R20' });
    const project = JSON.parse(fs.readFileSync(projectFile, 'utf8'));
    assert.equal(project.vehicleId, renamed.id);
    assert.equal(project.vehicle, 'OBS LS Street Truck');
    assert.equal(project.vehicleSnapshot.rearGear, '4.10');
    return { scenario: 'durable-link-rename', passed: true, vehicleId: renamed.id, projectVehicle: project.vehicle, snapshotGear: project.vehicleSnapshot.rearGear };
  } finally { fs.rmSync(ctx.root, { recursive: true, force: true }); }
}

function scenarioDeletionRecovery() {
  const ctx = setup('delete');
  try {
    const first = ctx.manager.save({ name: 'Tahoe Donor', engine: '5.3 LM7', controller: 'P01' });
    const second = ctx.manager.save({ name: 'Bench P01', engine: '5.3 LM7', controller: 'P01' });
    const projectFile = writeProject(ctx.projects, 'donor-read', { vehicleId: first.id, vehicle: first.name });
    let stop = '';
    try { ctx.manager.delete(first.id); } catch (error) { stop = error.code; }
    assert.equal(stop, 'vehicle-in-use');
    const project = JSON.parse(fs.readFileSync(projectFile, 'utf8'));
    fs.writeFileSync(projectFile, JSON.stringify({ ...project, vehicleId: second.id, vehicle: second.name }, null, 2));
    assert.equal(ctx.manager.delete(first.id), true);
    assert(!ctx.manager.list().some(item => item.id === first.id));
    return { scenario: 'linked-delete-protection', passed: true, stop, reassignedTo: second.name };
  } finally { fs.rmSync(ctx.root, { recursive: true, force: true }); }
}

function scenarioRichProfile() {
  const ctx = setup('rich');
  try {
    const vehicle = ctx.manager.save({
      name: 'P01 Bench Truck', vin: '1M8GDM9AXKP042788', controller: 'P01', os: '12212156', hardwareId: '9386530', serviceNumber: '12200411',
      modifications: 'camshaft\nlong-tube headers\n36 lb injectors', maintenance: '2026-07-19 | 120000 | Verified grounds\n2026-07-20 | 120010 | Read PCM properties'
    });
    assert.equal(vehicle.vinStatus.checkDigitValid, true);
    assert.equal(vehicle.maintenance.length, 2);
    const copy = ctx.manager.duplicate(vehicle.id);
    assert.equal(copy.vin, '');
    const favorite = ctx.manager.favorite(vehicle.id);
    assert.equal(favorite.favorite, true);
    return { scenario: 'rich-profile-vin-history', passed: true, vinStatus: vehicle.vinStatus.status, modifications: vehicle.modifications.length, maintenance: vehicle.maintenance.length, duplicateVinCleared: copy.vin === '', favorite: favorite.favorite };
  } finally { fs.rmSync(ctx.root, { recursive: true, force: true }); }
}

const report = {
  type: 'tuniq-garage-project-simulations',
  version: '1.7.0-beta.21',
  generatedAt: new Date().toISOString(),
  scenarios: [scenarioDurableRename(), scenarioDeletionRecovery(), scenarioRichProfile()]
};
report.passed = report.scenarios.every(item => item.passed);
console.log(JSON.stringify(report, null, 2));
if (!report.passed) process.exit(1);
