# TunIQ v1.7.0-beta.10 — Garage & Project Foundation

Beta.10 makes the Garage a dependable source of project context rather than a small list of disconnected names.

## Added

- Durable `vehicleId` links between Garage profiles and project manifests.
- Automatic migration of legacy name-only project links.
- Safe vehicle rename propagation across linked projects.
- Deletion protection that identifies linked projects and requires reassignment first.
- Engine, transmission, drivetrain, fuel, tire, gear, mileage, controller, OS, hardware ID, and service-number fields.
- Modification lists and structured maintenance history.
- Local VIN format/check-digit validation.
- AppData-managed vehicle photos.
- Favorites, Garage search/filtering, project counts, duplication, and Create Project shortcuts.
- PCM Hammer identity synchronization into the linked Garage profile.

## Retained

Beta.9 Quick Switch and workspace restoration, beta.8 Connection Doctor and Offline P01 Lab, and beta.7 P01 hardware-recovery gates remain enabled.

## Verification boundary

The Garage/project data model and UI contracts are tested with isolated filesystem simulations. No real vehicle, VIN database, OBDLink adapter, COM port, PCM, or flash operation is claimed as verified.
