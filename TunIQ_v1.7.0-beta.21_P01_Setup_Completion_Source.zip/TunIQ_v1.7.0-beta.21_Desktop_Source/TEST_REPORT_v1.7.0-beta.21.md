# TunIQ v1.7.0-beta.21 Test Report

## Release

**P01 Setup Completion**

Generated: 2026-07-21 UTC

## Problem addressed

The verified Customline P01 project reached OS 9379910 definition binding with Read Properties and two matching 524,288-byte reads complete, but no trustworthy writable exact-OS XDF or explicit Universal Patcher tuner XML was available. Beta.20 correctly refused to guess addresses but could not finish the hardware-commissioning workflow.

## Implemented completion path

Beta.21 adds a read-only exact-OS commissioning fallback:

- Generates a marked exact-OS XDF with zero writable calibration tables.
- Records OS, controller, BIN size, original SHA-256, and limitations in provenance metadata.
- Creates a revision that is a byte-for-byte clone of the verified protected original.
- Requires equal size, matching SHA-256, compatible layout, and zero changed bytes.
- Records the clone as `valid-stock-clone` only after those checks pass.
- Allows PCM Hammer Test Write for that exact unchanged clone.
- Completes Guided P01 Setup at `commissioning-complete` after successful Test Write.
- Keeps AI tuning, manual calibration editing, Calibration Write, Full Write, and OS conversion locked.
- Separates commissioning-only XDFs from writable Definition Center candidates so a trustworthy writable source can replace the fallback later.

## Automated verification

- Source syntax validation: **PASS**
- Automated suite: **26/26 groups passed**
- Focused recovery and subsystem simulations: **45/45 passed**
- New P01 Setup Completion scenarios: **3/3 passed**

### New scenarios

1. Commissioning-only exact-OS XDF generation and provenance
2. Unchanged stock-clone validation and Test Write authorization while tuning/writes remain locked
3. Writable exact-OS definition discovery separated from the commissioning fallback

## Retained verification

The release also passed the retained PCM Hammer, real CLI command recovery, COM recovery, startup recovery, Definition Center, Universal Patcher conversion, TunerPro contracts, Garage, workspace, Tune Engine, Autonomous Tune, Closed-Loop Tune, Connection Doctor, offline P01 lab, and P01 failure/recovery simulations.

## Safety assertions

- No calibration addresses are guessed.
- The commissioning fallback exposes zero writable tables.
- A changed clone cannot receive `valid-stock-clone` status.
- Test Write is allowed only for the exact validated clone.
- Controller writing remains blocked in commissioning-only mode, including after Test Write succeeds.
- A real writable exact-OS definition can replace the fallback later.

## Hardware boundary

This release is software and simulation verified only. Real Windows startup, COM3, OBDLink MX+, P01 PCM communication, and PCM Hammer Test Write must still be confirmed on the user's hardware. No physical write or real-vehicle tuning is claimed.
