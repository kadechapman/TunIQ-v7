# TunIQ v1.7.0-beta.11 Test Report

## Release

**Tune Workspace & Revision Control**

## Major verification targets

- Calibration workspaces are isolated by project.
- XDF workspaces are bound to the exact project, protected BIN SHA-256, and XDF SHA-256.
- A BIN/XDF fingerprint change archives stale workspaces instead of continuing silently.
- Workspace saves retain a recoverable previous copy.
- Corrupt workspace JSON recovers from the valid project backup without crashing.
- Snapshots remain isolated by project and record notes, binding, table count, and modified-cell count.
- Snapshot compare reports cell-level differences.
- Snapshot restore updates only the editable workspace and refuses a changed BIN/XDF fingerprint.
- AI goal and AI log proposals save through the project-scoped workspace manager.
- Existing Garage, QoL, Connection Doctor, Offline P01 Lab, and P01 hardware-recovery behavior remains intact.

## Commands executed

- `npm run check`
- `npm test`
- `npm run test:workspace-sim`
- `npm run test:garage-sim`
- `npm run test:qol-sim`
- `npm run test:connection-doctor`
- `npm run test:p01-offline-lab`
- `npm run test:p01-sim:clean`
- `npm run test:p01-sim:recovery`
- `npm run test:p01-sim:failures`

## Results

- Source syntax validation: **passed**
- Automated suite: **16/16 groups passed**
- Tune Workspace simulations: **3/3 passed**
- Garage lifecycle simulations: **3/3 passed**
- QoL simulations: **3/3 passed**
- Connection Doctor simulations: **3/3 passed**
- Offline P01 Lab scenarios: **3/3 passed**
- Retained P01 recovery simulations: **3/3 passed**

## New workspace simulations

1. **Project isolation and restart** — separate projects retained separate calibration values and histories after reload.
2. **Corrupt workspace recovery** — a damaged primary JSON file recovered the previous valid project backup.
3. **Compare, restore, and fingerprint stop** — cell differences were reported, a known-good snapshot restored correctly, and restoration stopped after the original BIN fingerprint changed.

## Hardware boundary

Testing was performed through source-level automated tests and software simulations. No claim is made that beta.11 was verified with a physical OBDLink MX+, Windows Bluetooth COM port, vehicle, bench harness, or PCM.
