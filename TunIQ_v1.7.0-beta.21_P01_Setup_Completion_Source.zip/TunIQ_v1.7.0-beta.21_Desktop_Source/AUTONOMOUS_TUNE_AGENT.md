# TunIQ Autonomous Tune Agent

TunIQ v1.7.0-beta.13 changes Full AI from a proposal-only guide into an autonomous calibration executor for supported, exactly mapped tables.

## What Autopilot does

After the active project has a protected original BIN, matching XDF, confirmed controller/OS identity, build profile, and a usable baseline log, Autopilot can:

1. Build the project-specific tuning plan.
2. Classify exact XDF tables by calibration role.
3. Derive conservative targets when the build profile provides enough information.
4. Apply every supported stage without per-cell approval.
5. Create a recovery snapshot before each stage.
6. Enforce table limits and TunIQ safety envelopes for every cell.
7. Save the project workspace after every completed stage.
8. Export checksum-corrected revision BINs.
9. Create after-stage snapshots and a full audit trail.
10. Produce a final handoff package and mark the revision ready for Flash Center confirmation.
11. Resume from the exact completed stage after an interruption.
12. Run later correction cycles from the newest imported or recorded log.

## Automatic stages

- Drivability, idle, thermal settings, and explicit limits
- MAF, VE, and idle-airflow corrections from repeatable log evidence
- Power-enrichment targets from explicit AFR/lambda or conservative profile-derived lambda
- Knock-based spark reductions mapped to exact cells
- WOT shift-RPM movement within bounded per-stage limits

Unsupported or ambiguous tables are skipped. TunIQ does not invent an address, equation, axis, injector characterization, or controller strategy.

## Required facts

Autopilot may require confirmed facts that software cannot discover safely, including mechanical health, fuel pressure, wideband calibration, injector data, valvetrain capability, driveline capability, and controlled-test availability. These are facts supplied once at run start, not per-cell approvals.

## Flash boundary

Autopilot creates the complete supported calibration and final revision automatically. It does not silently write the PCM. Flash Center remains a separate operation requiring controller compatibility, recovery proof, voltage checks, and explicit confirmation.

## Verification boundary

The included tests use simulated projects, mapped XDF tables, generated logs, revision exports, interruption/restart, and fingerprint failures. They do not claim physical vehicle, dyno, OBDLink, PCM, or live-flash verification.
