# Integrated Definitions & Patch Pipeline

## Purpose

Beta.20 removes the assumption that a new TunIQ user already owns an XDF. It adds a project-scoped Definition Center and managed compatibility pipelines for TunerPro and Universal Patcher.

## Definition Center

Definition Center scans bounded local sources for `.xdf` and Universal Patcher Tuner `.xml` files. Every candidate is parsed before it can be selected.

Acceptance requires:

- The exact active OS identifier
- Explicit table addresses
- Supported data widths and byte order
- Safe conversion equations
- At least one usable table
- A clean BIN/XDF mapping before Guided Setup continues

Rejected files remain visible with their reason. Approximate OS matches are never promoted.

## Universal Patcher XML conversion

The converter supports explicit 8-, 16-, and 32-bit signed/unsigned table data, rows, columns, row-major/column-major layout, labels, units, bit masks, minimums, maximums, decimal places, and safe math expressions. Platform byte order is resolved only for known controller families.

Nonzero extra offsets, unsupported equations, missing addresses, unknown multi-byte platform order, or out-of-range tables are blocked rather than guessed.

Generated definitions include a provenance JSON file containing the source and output SHA-256 hashes.

## Managed TunerPro roundtrip

TunIQ creates an isolated compatibility folder containing:

- A working copy of the latest revision or protected original
- The exact bound XDF
- A roundtrip manifest with project, OS, and SHA-256 binding

TunerPro may be opened against those files. TunIQ watches the folder and accepts exactly one changed same-layout BIN. The result is copied into Revisions; the protected original is never overwritten.

## Managed Universal Patcher validation

TunIQ creates separate Input, Output, and Reports folders for the target revision. Universal Patcher operates on the managed working copy. TunIQ accepts exactly one compatible changed BIN, imports a valid report when present, and runs TunIQ's own comparison and checksum analysis again.

## External-tool boundary

TunerPro and Universal Patcher are managed external engines. Their Windows interfaces are not embedded in Electron, and no dependable general-purpose headless API is assumed. TunIQ remains the source of truth for project identity, fingerprints, protected originals, revisions, validation, and flash gates.
