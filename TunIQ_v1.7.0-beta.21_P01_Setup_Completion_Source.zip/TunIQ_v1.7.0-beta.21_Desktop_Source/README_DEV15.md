# TunIQ 1.5 dev.1 implementation notes

1. Physical serial communication uses Windows PowerShell and `.NET System.IO.Ports.SerialPort`, avoiding a native Node serial dependency during the first connection milestone.
2. Windows device discovery uses CIM/WMI and the serial-device registry map. A paired Bluetooth adapter must expose a COM port.
3. Device probing tries 115200, 38400, and 9600 baud and performs an ELM/STN-compatible initialization sequence.
4. Physical samples currently use a short-lived serial session per polling request. This is intentionally conservative for dev.1; a persistent high-rate session transport is planned for the next logger milestone.
5. The virtual adapter exercises the complete connection → logging → marker → CSV → AI-analysis path without touching a vehicle.
6. Logs are stored only inside the active project's `Logs` directory and cannot be analyzed through a path outside that project.
7. AI findings use repeatable aggregate patterns rather than a single sensor spike.
8. Wide-open-throttle decisions are blocked when wideband AFR and enhanced knock data are unavailable.
9. OBDLink MX+ is treated as a diagnostics/logging device until a specific controller/write backend combination is separately verified.
10. Live logging does not activate calibration or flashing actions and controller writing remains locked.
