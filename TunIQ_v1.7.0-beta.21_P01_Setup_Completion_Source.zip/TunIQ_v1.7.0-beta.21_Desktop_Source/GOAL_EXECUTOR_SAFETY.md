# Natural-Language Tune Goal Executor

The goal executor converts plain-language requests into a visible, approval-gated action sheet. It is not permission for an AI model to edit arbitrary bytes or flash a controller.

Example request:

> Ghost cam tune, raise max rev to 6000, and raise max speed to 190.

## Execution rules

1. Parse the requested outcomes.
2. Match each outcome to exact, writable parameters in the active BIN/XDF workspace.
3. Show the current value, proposed value, table, cell, reason, and any blocking requirement.
4. Require the user to select the actions to apply.
5. Write only the approved cells into a new revision.
6. Run the existing layout/checksum validation.
7. Keep flashing as a separate Flash Center operation with its own confirmations.

## RPM limiter changes

TunIQ searches for applicable cutoff and restore/resume parameters. Requests above the conservative threshold require confirmation that the valvetrain is suitable. TunIQ refuses to guess a limiter location when no exact mapped parameter exists.

## Speed limiter changes

High-speed requests are treated as high risk. A request above 130 mph requires:

- tire speed rating at or above the request
- verified driveline suitability
- verified brakes, suspension, and stability
- closed-course confirmation

Changing a limiter does not prove that the vehicle can safely reach that speed.

## Ghost-cam behavior

Ghost-cam calibration is controller- and operating-system-specific. TunIQ recognizes the request but will not apply a generic recipe. It requires a verified rule pack that identifies the exact tables, operating regions, limits, and rollback behavior for the active controller/OS.

A template exists under `src/rules`, but it is deliberately not marked verified and cannot authorize changes.

## Safety boundary

- No unsupported table guessing
- No silent calibration edits
- No automatic flash
- No bypass of checksum, compatibility, voltage, or typed-write confirmation
- Original BIN remains protected
