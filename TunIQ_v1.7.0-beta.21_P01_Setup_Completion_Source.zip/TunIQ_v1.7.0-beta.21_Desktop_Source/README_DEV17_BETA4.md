# TunIQ v1.7.0-beta.4 — P01 Live Commissioning

This release closes the software-side P01 commissioning gaps found in the beta.3 audit.

## Changes

- Added service-number identity proof and imported Read Properties support.
- Added two/three full-read import with 2-of-3 majority resolution.
- Added official PCM Hammer 2.x backend identity and executable hash binding.
- Added typed exact-OS definition confirmation bound to XDF and original hashes.
- Added per-action P01 parameter commissioning and required commissioned-map enforcement before Full AI goal execution.
- Added commissioned mild ghost-idle support when exact idle parameters are verified.
- Added imported PCM Hammer GUI Test Write proof bound to exact revision SHA.
- Added beginner-facing P01 controls and checklist.
- Updated test coverage for majority reads, backend proof, definition confirmation, parameter maps, revision validation, and Test Write.

## Remaining physical validation

The code cannot certify a physical setup without running it. The first real P01 workflow is the acceptance test for the exact PCM, interface, power, CLI build, BIN, and XDF.
