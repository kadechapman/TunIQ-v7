# TunIQ v1.7.0-beta.15 Developer Notes

Beta.15 is a hardware-validation hotfix focused on Electron IPC serialization and PCM Hammer assisted fallback. The new `src/ipc-safe.js` module is the mandatory boundary for workspace summary IPC results.

No physical PCM, vehicle, OBDLink MX+, or live flash verification is claimed.
