# TunIQ v1.7.0-beta.11 Developer Notes

## Release focus

Beta.11 replaces the global calibration workspace with project-local tuning state and adds a recoverable snapshot timeline.

## Data layout

Each project now owns:

- `Workspace/calibration-workspace.json`
- `Workspace/calibration-workspace.backup.json`
- `Workspace/history.json`
- `Workspace/Snapshots/*.json`
- `Workspace/Recovery/*.json`

Snapshot records include the project ID and exact BIN/XDF fingerprints. A snapshot cannot be restored after those fingerprints change.

## Migration

The old global `Calibration/workspace.json` is migrated only when its `projectId` matches the active project. Unrelated global state is not attached to another vehicle.

## Verification

Run `npm run check`, `npm test`, `npm run test:workspace-sim`, and `npm run test:recovery-labs`.
