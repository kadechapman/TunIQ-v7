# Developer Notes — v1.7.0-beta.20

## New module

`src/definition-pipeline.js` implements bounded scanning, exact-OS XDF inspection, Universal Patcher installation checks, safe Tuner XML parsing, XML-to-XDF generation, provenance hashing, and managed definition jobs.

## Main-process integration

New IPC groups:

- `definition:scan`, `definition:resolve`, `definition:import-sources`
- `definition:create-job`, `definition:inspect-job`, `definition:open-job`
- `definition:bind-candidate`
- `definition:launch-universal-patcher`
- `definition:launch-tunerpro`, `definition:inspect-tunerpro`, `definition:import-tunerpro`
- `patch:launch-universal-managed`, `patch:inspect-universal-managed`, `patch:import-universal-managed`

The Guided P01 definition phase now resolves an already-bound exact XDF, one unambiguous exact XDF, or one unambiguous exact Universal Patcher XML source. Otherwise it pauses with a managed definition job.

## Safety invariants

- Never generate addresses from pattern matching or BIN similarity.
- Never use another OS definition.
- Never overwrite the protected original.
- TunerPro and Universal Patcher outputs must preserve BIN layout.
- More than one changed output is ambiguous and blocks import.
- Every generated or imported source is fingerprinted.
