# TunIQ Improvement API Contract — Foundation

The desktop submits only after explicit user action to a configured HTTPS endpoint.

## Request
`POST /v1/improvement-packages`

Content type: `application/json`

Body fields:
- `schemaVersion`: currently `1`
- `installation`: one-way 16-character installation pseudonym
- `items`: validated anonymized outcomes

## Required server behavior
- Reject oversized bodies and unsupported schema versions.
- Rate-limit by pseudonym and IP without exposing either publicly.
- Validate every field against the JSON schema.
- Re-run VIN, email, credential, path, GPS, and free-text redaction server-side.
- Quarantine sensor data and attachments before review.
- Never feed submissions directly into calibration rules or model training.
- Record consent version, retention class, deletion token, validation score, and reviewer state.
- Return a receipt ID without revealing internal database identifiers.
- Support deletion and export requests.

## Response example
```json
{
  "accepted": 2,
  "rejected": 0,
  "receipt": "public-random-receipt"
}
```

No production endpoint is included in this source build.
