# TunIQ v1.7.0-beta.21 — P01 Setup Completion

Beta.21 removes the exact-XDF dead end from Guided Automatic P01 Setup.

When TunIQ finds a trustworthy writable definition for the exact operating system, it continues with the normal mapped tuning workflow. When no trustworthy writable definition exists, it now creates an exact-OS **commissioning-only definition** that contains no writable calibration maps and no guessed calibration addresses.

## What the fallback completes

For a verified P01 project, TunIQ can now continue through:

1. PCM Hammer Read Properties
2. Two independent matching 524,288-byte reads
3. Protected verified original
4. Exact-OS read-only commissioning binding
5. Byte-for-byte stock-clone revision
6. Proof that the clone is unchanged
7. PCM Hammer Test Write
8. A completed P01 hardware-commissioning state

## What remains locked

The commissioning-only definition does not authorize:

- AI or manual calibration changes
- TunerPro calibration editing
- Calibration Write
- Full Write
- Operating-system conversion

A trustworthy writable definition for the exact OS must replace it before tuning. TunIQ keeps searching Definition Center and separates writable candidates from its own commissioning fallback.

## Existing beta.20 integration

Definition Center still searches project folders, TunIQ libraries, TunerPro folders, Universal Patcher XML/Tuner folders, Downloads, Desktop, and Documents. Exact Universal Patcher table XML can still be converted into a writable XDF with provenance when it contains explicit safe addresses.

TunerPro and Universal Patcher managed working folders, revision fingerprints, checksum validation, PCM Hammer integration, two-read verification, and protected-original rules remain in place.

## Windows

Extract the ZIP into a new folder and run `INSTALL_AND_RUN_WINDOWS.bat`. Existing projects remain in TunIQ AppData.

## Verification boundary

Beta.21 was verified with automated tests and software simulations. Real Windows, COM3, OBDLink MX+, P01 PCM, and Test Write operation still require confirmation on the user's hardware.
