# Contributing to TunIQ Public Beta

Do not submit raw BINs, VINs, credentials, personal information, proprietary definitions, or third-party binaries without clear permission.

Useful contributions include reproducible bugs, sanitized `.tuniqreport` packages, known-good open/licensed test fixtures, controller/OS/interface test results, enhanced PID documentation, UI fixes, automated tests, and beginner-focused documentation.

Every hardware result must state the exact controller, operating system, interface, power setup, operation, software version, and recovery outcome. A successful single write remains Experimental until repeated and reviewed.

Code contributions should run:

```text
npm run check
npm test
```

The project license and contributor terms must be selected before outside code contributions are accepted.
