# TunIQ v1.6.0-dev.1 engineering notes

This milestone connects the five major systems requested after v1.5:

1. Managed PCM Hammer CLI read/write/recovery orchestration
2. BIN checksum, segment, patch-preview, and external-report validation
3. Expanded XDF decoding and write-back
4. Persistent serial logging with imported enhanced PID profiles
5. Approval-gated AI calibration proposals and repeatable revision cycles

## Deliberate limitations

- PCM Hammer CLI command syntax is capability-probed because different releases/builds may expose different command names and options. Advanced templates are available, but the user must verify them.
- Native checksum correction is limited to explicit checksum definitions using algorithms TunIQ implements. All other algorithms require a Universal Patcher report tied to the exact BIN hash.
- Universal Patcher's internal patch database is not copied into TunIQ. TunIQ previews/imports its output BIN and parses its reports.
- Enhanced PID commands are not fabricated. Controller/OS-specific PID libraries must come from verified definitions.
- AI execution is limited to supported airflow/idle evidence with explicit per-cell approval. Spark, boost, transmission pressure, and high-load fueling remain recommendation-only unless a future controller-specific rule pack is validated.
- No write operation is silently started. Calibration, full, and recovery writes retain typed authorization and safety confirmation.

## Storage additions

- `%APPDATA%\TunIQ\Logs\Flash\history.json`
- `%APPDATA%\TunIQ\Logs\Flash\*.log`
- Project `Reports\validation-*.json`
- Project `Reports\patch-preview-*.json`
- Project `Checksums\universal-patcher-*.json`
- Project `AI\Proposals\*.json`
- Project `AI\CalibrationCycles\*.json`
