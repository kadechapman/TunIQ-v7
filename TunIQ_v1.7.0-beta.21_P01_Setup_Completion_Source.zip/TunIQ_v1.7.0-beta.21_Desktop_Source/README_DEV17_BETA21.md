# Developer Notes — v1.7.0-beta.21

## Main additions

- `buildCommissioningOnlyXdf()` and marker detection in `src/definition-pipeline.js`.
- Writable and commissioning-only XDF candidates are separated during scans.
- Definition Center can replace a commissioning fallback when a real writable exact-OS source appears.
- Guided P01 Setup automatically creates the fallback only when there is no trustworthy unambiguous writable source.
- Calibration workspace marks every fallback item read-only and reports `writableTables: 0`.
- A byte-identical stock clone receives `valid-stock-clone` validation.
- Test Write accepts the stock clone; all PCM writes remain blocked.
- Successful Test Write ends in `commissioning-complete`, not `ready-to-write`.

## Non-goals

- No table-address inference.
- No automatic OS conversion.
- No tuning through the fallback XDF.
- No Calibration Write or Full Write through the fallback path.
