# TunIQ Public Beta Privacy Draft

This is a working product draft, not a substitute for review by a qualified privacy professional before public launch.

## Local-first operation
TunIQ stores profiles, vehicles, projects, BIN metadata, revisions, logs, settings, and beta feedback under the current Windows user's AppData\TunIQ folder. Public-beta improvement sharing is disabled by default.

## What is never uploaded automatically
TunIQ does not automatically upload VINs, email addresses, raw BIN files, exact local file paths, Bluetooth identifiers, API credentials, community private messages, or location data.

## Optional improvement data
A user may enable **Help improve TunIQ**. This only permits the user to add anonymized outcomes to a local queue. Nothing is sent until the user presses Submit. If no secure improvement endpoint is configured, TunIQ only offers an exportable `.tuniqfeedback` package.

Optional records may include controller family, operating system, engine description, tune goal, log fingerprint, user-rated outcome, DTC changes, repair notes, and—only when separately enabled—sanitized sensor rows.

## Redaction
Diagnostic and improvement packages remove or pseudonymize email addresses, VINs, user-folder names, passwords, tokens, secrets, API keys, GPS/location fields, and absolute timestamps. Raw BIN bytes are excluded.

## User controls
Users can inspect queue counts, export queued data, delete the queue, disable improvement sharing, and reset beta consent from the Public Beta Center. Uninstalling TunIQ does not delete AppData by default so projects are not accidentally lost.

## Server-side work still required
Before public data collection begins, TunIQ needs a published privacy policy, secure HTTPS endpoint, retention schedule, deletion-request process, access controls, abuse monitoring, and documentation of any third-party processors.
