# Offline P01 Recovery Lab — retained in TunIQ v1.7.0-beta.10

The Offline P01 Recovery Lab lets TunIQ exercise recovery logic without an adapter or vehicle.

It runs three scenarios using the production PCM Hammer result parser and strict P01 BIN validator:

1. Clean Read Properties plus two matching 524,288-byte reads.
2. Adapter-lock stop followed by exact-step restart/resume and a valid matching pair.
3. Partial read rejection, complete-read SHA-256 mismatch, repeated block-read failure, and a fresh valid pair.

The lab writes reports under `%APPDATA%\TunIQ\Labs\P01Recovery` and never opens a COM port. Passing the lab is software verification only and is not real-hardware verification.
