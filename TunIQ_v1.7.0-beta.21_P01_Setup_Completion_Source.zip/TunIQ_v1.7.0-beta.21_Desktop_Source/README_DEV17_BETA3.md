# TunIQ v1.7.0-beta.3 — P01 Commissioning

This milestone replaces the generic P01 AI/write path with an evidence-gated workflow.

## Added

- P01 identity record bound to controller, OS, hardware ID, and VIN when available
- Two independent matching 512 KB full-read requirement
- SHA-256 canonical original protection
- Exact OS number requirement in the XDF title or filename
- Calibration workspace binding to the verified original and XDF hashes
- Exact-revision checksum/layout proof
- Exact-revision Test Write proof before Calibration Write
- Automatic proof invalidation when controller identity changes
- Beginner-facing P01 commissioning panel
- Full AI and log-proposal lock until the P01 AI gates pass
- Per-project commissioning report in `Reports/p01-commissioning.json`

## Deliberately not claimed

- No physical P01 was flashed in the automated test environment.
- No universal ghost-cam rule was added.
- Exact OS naming is not treated as proof that an unknown XDF is accurate.
- Full Write is not automatically unlocked by normal P01 calibration commissioning.
