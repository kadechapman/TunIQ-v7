# TunIQ Public Beta Agreement — Draft 1.0

This is a working product draft and should receive legal review before broad public distribution.

TunIQ Public Beta is pre-release automotive calibration software. Some features interact with vehicle controllers and can cause a no-start condition, controller damage, engine or transmission damage, emissions noncompliance, unsafe drivability, or loss of vehicle functions when used incorrectly or with unsupported hardware.

By accepting in the application, the tester acknowledges:

1. Compatibility labels matter. **Verified** means a specific workflow passed TunIQ's documented testing. **Experimental** means the software path exists but real hardware combinations remain under evaluation. **Unsupported** operations are blocked.
2. A protected original BIN, stable power supply, correct controller/OS definition, validated checksum, and recovery plan are required before controller writing.
3. Experimental writing is hidden in Beginner View and requires an explicit Advanced setting. This does not make it safe or verified.
4. AI and community recommendations are proposals, not guarantees. The tester must inspect every change and confirm that the vehicle is mechanically sound.
5. Road logging must be performed legally and safely. A passenger should operate the computer when attention would otherwise be diverted from driving.
6. Improvement sharing is optional. Nothing uploads automatically. Diagnostic and feedback packages are designed to redact personal identifiers but should still be reviewed before submission.
7. Public Beta should first be used on spare/bench controllers or vehicles the tester can recover.
