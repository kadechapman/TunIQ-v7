# TunIQ v1.7.0-beta.16 Test Report

## Release

- Version: `1.7.0-beta.16`
- Name: **COM Recovery & Resume Fix**
- Base: TunIQ v1.7.0-beta.15 Hardware Validation Hotfix
- Verification boundary: software tests and simulations only
- Real vehicle/OBDLink/PCM/flash verified: **No**

## Reported failure reproduced in regression state

The beta.15 Guided Automatic P01 workflow could stop after a Windows `LockProbe` timeout while retaining stale runtime or persisted state. This could make **Resume** unavailable or allow the old timed-out bridge request to race with a later recovery attempt.

## Implemented fixes

- Structured `lock-probe-timeout`, `bridge-timeout`, and `adapter-locked` error codes.
- Tracked PowerShell serial-bridge requests with one-settlement guards.
- Timeout and manual recovery terminate the PowerShell process tree.
- Manual recovery settles the old bridge promise immediately so it cannot overwrite a resumed workflow later.
- Lock probing now returns structured timeout information rather than throwing an unclassified generic error.
- Selected COM port is shown in recovery state and diagnostics.
- Recognized alternate OBDLink COM ports are tried before stopping.
- Guided P01 state schema bumped to version 3.
- Legacy beta.15 stopped/running states normalize to a resumable paused state.
- Resume force-clears stale bridge state and retries the exact ledger step.
- Added **Clear Stuck COM State**.
- Added **Use Assisted PCM Hammer** for Read Properties, full read, and Test Write.
- Lock-probe timeout automatically falls back to normal PCM Hammer when the GUI is available.
- Existing protected-original, exact-two-read, exact-XDF, checksum, voltage, Test Write, and final write-confirmation safety gates remain unchanged.

## Automated verification

- Source syntax check: **PASS**
- Automated suite: **21/21 groups passed**
- Focused simulations: **30/30 passed**
- New COM Recovery simulations: **3/3 passed**
  - selected COM timeout with automatic alternate-port recovery
  - all candidate lock probes time out and stop cleanly
  - beta.15 stuck state migrates, clears, and resumes the exact failed step
- Closed-loop simulations: **3/3 passed**
- Autonomous Tune simulations: **3/3 passed**
- Unified Tune Engine simulations: **3/3 passed**
- Garage simulations: **3/3 passed**
- Project workspace simulations: **3/3 passed**
- QoL simulations: **3/3 passed**
- Connection Doctor simulations: **3/3 passed**
- Offline P01 Lab simulations: **3/3 passed**
- P01 hardware-recovery simulations: **3/3 passed**

## Safety and hardware boundary

This release has not been tested here with the user's physical OBDLink MX+, Windows Bluetooth COM ports, vehicle, P01 PCM, bench harness, Test Write, or live calibration write. The next meaningful verification is to open the existing Customline project in beta.16, clear the migrated stuck state, and retry Read Properties on the real Windows system.

## Test logs

- `test-results/01-source-check.txt`
- `test-results/02-automated-suite.txt`
- `test-results/03-recovery-labs.txt`
- `test-results/com-recovery-simulations.json`
- Retained simulation JSON reports in `test-results/`
