# Integrated PCM Hammer Pipeline

Beta.17 replaces Guided Setup's external assisted workflow with a single internal operation coordinator.

## Port ownership

Only one process may own the OBDLink serial port at a time. TunIQ disconnects and aborts its own bridge request, waits for Windows to release the handle, and then grants PCM Hammer a direct lease. A second lock-probe open is deliberately not performed because that probe can race with the operation it is supposed to protect.

The current owner, port, operation, and lease ID are exposed in Flash Center and diagnostic status. Ownership returns to `idle` after completion, failure, cancellation, or recovery cleanup.

## CLI profile discovery

PCM Hammer 2.x CLI builds may expose different command-line option forms. TunIQ first uses help-derived syntax or a previously proven profile. When help/version output is blank, TunIQ may test known profiles only for non-destructive Read Properties and full-read operations.

A different profile is tried only when all of these are true:

- The failure is clearly a command-line syntax error.
- No adapter, serial, voltage, controller, read-block, erase, write, or verification activity appeared.
- No output file was created.
- The operation is Read Properties or full read.

Test Write and write operations never use speculative profile retries. They require a profile already proven by a non-destructive operation.

## Internal evidence path

The integrated runner automatically parses and imports:

- Controller, OSID, Hardware ID, service number, VIN, and voltage from Read Properties.
- Full-read output only when it is exactly 524,288 bytes and PCM Hammer proves success.
- Test Write only when the output explicitly proves a passed Test Write.
- Write verification and the complete session log.

The two-read matching-hash requirement, exact-XDF requirement, checksum gates, stable-power gates, and final write confirmation remain unchanged.

## Advanced fallback

Normal PCM Hammer can still be launched manually from advanced tools for emergency diagnostics. It is not part of Guided Automatic P01 Setup and is not required for a normal beta.17 flow.
