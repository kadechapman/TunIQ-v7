# TunIQ P01 Public Evidence Registry

TunIQ beta.5 includes a **source registry**, not copied third-party calibration or log files. The user downloads files from their original public source and imports them locally. TunIQ then fingerprints the original, removes private columns from logs, normalizes supported channels, checks controller/OS compatibility, and records blockers.

## Five public log sessions

1. **1123.csv** — explicitly identified as P01, OS 12225074, paired with `0105.bin`.
2. **0105c.csv** — follow-up session from the same P01/12225074 thread.
3. **exportedPIDs (3).csv** — Torque phone log; uploader explicitly says P01 and uses an EGR-voltage wideband channel.
4. **20210810_1908_FuelTrims.csv** — PCM Logger 018 session showing comma-plus-space delimiter, Clock Time and Elapsed Time. Controller is not stated; kept as P01/P59-family evidence.
5. **20210814_1700_0002.RAM.csv** — PCM Logger RAM-profile session. Controller is not stated; kept as P01/P59-family evidence.

The two PCM Logger family examples are useful parser evidence, but TunIQ does not treat them as P01 tune evidence until controller identity and OS are supplied.

## Calibration definitions and tables

The registry links P01 XDF references for OS 12202088, 12208322, 12209203, 12212156 and 12225074, a stock BIN/XDF catalog, Universal Patcher table/checksum definitions, and an OS 12202088 map-validation discussion.

A public XDF is never automatically trusted. TunIQ requires:

- exact controller and operating system;
- two matching original reads;
- BIN and XDF fingerprints;
- definition warnings resolved;
- exact parameter cells commissioned;
- checksum validation and Test Write before Calibration Write.

## Training boundary

An imported item is always `trainingEligible: false`. Promotion requires verified before/after calibration relationship, matching controller/OS, known vehicle hardware, meaningful logs, outcome feedback, and independent review. Duplicate sessions are detected using a normalized-session fingerprint.

## Redistribution

Raw public attachments are not bundled because the forum posts and community repository do not provide clear permission for TunIQ to redistribute every file. Source links remain attached to each registry record.
