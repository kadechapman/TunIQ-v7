# TunIQ 1.3 dev.2 implementation notes

This milestone focuses on usability and the unified-window contract.

1. The floating Tune Path is intentionally limited to three visible states.
2. OS numbers are not required during project creation. Detection currently uses trustworthy metadata available locally: XDF title, XDF filename, and BIN filename. PCM-reported OS identification will replace filename heuristics when the native PCM Hammer adapter is enabled.
3. Standard tool-card actions no longer call `bridge:launch-tool`. They navigate to TunIQ-native workspaces. The legacy IPC remains temporarily for migration/testing but is not exposed in the normal UI.
4. Flash writes and checksum write-back remain locked.
