# TunIQ v1.3.0-dev.1 — Unified Workspace Foundation

This is the first 1.3 milestone. It changes TunIQ from a collection of separate pages and launch buttons into a shared project workspace.

## Unified workspace

The header now shows the active project, controller/OS, protected original BIN, and XDF at all times. Flash, Calibration, Patches, Scanner, Logs & Revisions, and AI Coach use the same project state.

## Guided Tune Path

Guided Mode displays a corner Tune Path panel. Each step has a state:

- Check mark: complete
- Glowing star: current step
- Plain star: waiting
- Lock: not yet available

Clicking a step opens the correct page, scrolls to its control, and highlights it.

Current steps cover:

1. Project selection
2. Controller and operating system
3. Protected original BIN
4. Matching XDF
5. Calibration mapping
6. Revision export
7. Checksum/change review
8. Controlled flash preparation

## Native integration foundations

### Flash Center

- Shares the active project and controller context.
- Shows original BIN and PCM Hammer adapter readiness.
- Records controller-identification and original-read preflight plans.
- Keeps direct reads/writes locked until command behavior, progress parsing, voltage checks, cancellation, and recovery are verified.

### Calibration

- Continues using TunIQ's native XDF/BIN editor.
- Shares revisions and Tune Path state with the rest of the workspace.

### Patches & Checksums

- Shows the active BIN fingerprint and Universal Patcher adapter readiness.
- Records a safe analysis preflight.
- Does not modify BIN bytes in dev.1.

### Logs & Revisions

- Lists exported revision files from the active project.
- Lists recent project-aware TunIQ activity.
- Opens the active project's Revisions and Logs folders.

### AI Coach

- Receives active project, vehicle, controller, OS, BIN, XDF, revision count, and Tune Path context.
- Can explain the current required step offline.

## Compatibility Mode

Tool Setup still detects and launches PCM Hammer, TunerPro, and Universal Patcher for unsupported features. Those buttons are clearly treated as fallback compatibility mode rather than the primary workflow.
