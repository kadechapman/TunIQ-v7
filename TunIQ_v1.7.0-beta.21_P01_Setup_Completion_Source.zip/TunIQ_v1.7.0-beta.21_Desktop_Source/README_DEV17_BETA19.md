# Developer Notes — v1.7.0-beta.19

## Release purpose

Beta.19 fixes the real PCM Hammer CLI command mismatch and incorrect P01 resume point shown by the user's beta.18 diagnostic report.

## Diagnostic root cause

TunIQ launched `read-properties --port COM3`. The installed CLI requires `--get-properties --device COM3`. It returned `No operation specified` followed by help text. The old communication detector matched generic words inside that help text and refused a safe non-destructive retry.

The same diagnostic showed valid P01 identity and multiple matching 524,288-byte reads on disk, but a missing `readPair` object and incomplete automation ledger caused Resume to repeat Read Properties.

## Important implementation points

- `src/pcmhammer.js`: exact flag-based help parsing.
- `src/pcmhammer-integrated.js`: observed real-CLI profile and usage-only classification.
- `src/flash.js`: saved command-schema migration and technical execution details.
- `src/p01-commissioning.js`: strict saved read-pair repair.
- `src/p01-auto.js`: completed evidence reconciliation.
- `src/main.js`: repair and reconcile before choosing the next Guided P01 step.
- Renderer: Copy Technical Details button for stopped PCM Hammer operations.

## Test commands

```bash
npm run check
npm test
npm run test:real-cli-recovery
npm run test:recovery-labs
```

The release preserves the separate final write authorization and does not reinterpret the CLI's Full Write command as Calibration Write.
