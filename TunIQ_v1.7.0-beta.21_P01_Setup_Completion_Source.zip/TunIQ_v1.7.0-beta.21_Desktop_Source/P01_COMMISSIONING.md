# P01 Commissioning Guide — beta.7

TunIQ does not expose a P01 calibration write from unverified evidence.

## Controller properties

Use **Read Properties** through the supported PCM Hammer 2.x CLI operation, or use the assisted normal PCM Hammer app and import its result. TunIQ records:

- controller family;
- OSID;
- Hardware ID;
- service number;
- VIN when present;
- reported voltage when present.

A CLI command literally named `identify` is not required.

## Exactly two matching full reads

Every accepted P01 image must be exactly **524,288 bytes**. TunIQ requires exactly two independent reads with identical SHA-256 hashes. The reads must come from separate completed sessions.

A partial, missing, oversized, failed, or mismatched read is rejected. A mismatch stops the workflow and clears the read pair; start a fresh two-read pair after correcting power, wiring, interface, or connection problems. TunIQ does not use a third-read majority.

## Exact definition and revision

The XDF must explicitly match the detected OS and load without unresolved address or parser warnings. The generated revision remains bound to the controller identity, original-read hash, XDF hash, and requested cell map.

## Test Write

TunIQ requires an explicit successful PCM Hammer Test Write result for the exact revision. An exit code alone is not proof. Assisted GUI logs can be imported automatically or manually.

## COM-port ownership

Before PCM Hammer starts, TunIQ closes its persistent OBD session and probes the selected port without issuing vehicle commands. A port held by PCM Hammer or another application produces an `adapter-locked` stop. Close the locking application, then resume the same step.

## Recovery behavior

Progress is persisted after every completed step. A restart during an operation pauses at that exact step and requires a deliberate resume. Disconnects, repeated block-read failures, read-size failures, and hash mismatches are distinct stop reasons; none are silently looped.

## Hardware-verification status

The beta.7 test report covers software tests and simulations only. It is not real-hardware verification.
