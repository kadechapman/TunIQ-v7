param(
  [string]$PortName,
  [int]$Baud = 115200
)
$ErrorActionPreference = 'Stop'
$port = $null

function Write-Result($Value) {
  [Console]::Out.WriteLine(($Value | ConvertTo-Json -Compress -Depth 10))
  [Console]::Out.Flush()
}
function Open-Port([string]$Name, [int]$Speed) {
  $p = New-Object System.IO.Ports.SerialPort
  $p.PortName = $Name
  $p.BaudRate = $Speed
  $p.Parity = [System.IO.Ports.Parity]::None
  $p.DataBits = 8
  $p.StopBits = [System.IO.Ports.StopBits]::One
  $p.Handshake = [System.IO.Ports.Handshake]::None
  $p.ReadTimeout = 250
  $p.WriteTimeout = 1200
  $p.NewLine = "`r"
  $p.Encoding = [System.Text.Encoding]::ASCII
  $p.DtrEnable = $false
  $p.RtsEnable = $false
  $p.Open()
  Start-Sleep -Milliseconds 180
  return $p
}
function Send-Command($p, [string]$Command, [int]$TimeoutMs = 1000) {
  try { $p.DiscardInBuffer() } catch {}
  $p.Write("$Command`r")
  $deadline = [DateTime]::UtcNow.AddMilliseconds($TimeoutMs)
  $text = ''
  while ([DateTime]::UtcNow -lt $deadline) {
    Start-Sleep -Milliseconds 8
    try { $text += $p.ReadExisting() } catch {}
    if ($text.Contains('>')) { break }
  }
  return $text.Trim()
}
function Initialize-Adapter($p) {
  $responses = @{}
  $responses.ATE0 = Send-Command $p 'ATE0' 900
  $responses.ATL0 = Send-Command $p 'ATL0' 900
  $responses.ATS0 = Send-Command $p 'ATS0' 900
  $responses.ATH0 = Send-Command $p 'ATH0' 900
  $responses.ATSP0 = Send-Command $p 'ATSP0' 1100
  return $responses
}
try {
  if ([string]::IsNullOrWhiteSpace($PortName)) { throw 'A COM port is required.' }
  $port = Open-Port $PortName $Baud
  $init = Initialize-Adapter $port
  $identity = Send-Command $port 'ATI' 1200
  Write-Result ([pscustomobject]@{ id = 'ready'; success = $true; port = $PortName; baud = $Baud; adapter = $identity; init = $init })

  while (($line = [Console]::In.ReadLine()) -ne $null) {
    if ([string]::IsNullOrWhiteSpace($line)) { continue }
    $request = $null
    try { $request = $line | ConvertFrom-Json -ErrorAction Stop } catch {
      Write-Result ([pscustomobject]@{ id = ''; success = $false; error = 'Invalid JSON request.' })
      continue
    }
    $id = [string]$request.id
    try {
      switch ([string]$request.action) {
        'sample' {
          $responses = @{}
          $commands = @($request.commands)
          $timeout = if ([int]$request.timeoutMs -gt 0) { [int]$request.timeoutMs } else { 900 }
          foreach ($command in $commands) {
            $cmd = [string]$command
            if (-not [string]::IsNullOrWhiteSpace($cmd)) { $responses[$cmd] = Send-Command $port $cmd $timeout }
          }
          if ($request.includeVoltage -ne $false) { $responses['ATRV'] = Send-Command $port 'ATRV' 800 }
          if ($request.includeProtocol -eq $true) { $responses['ATDP'] = Send-Command $port 'ATDP' 800 }
          Write-Result ([pscustomobject]@{ id = $id; success = $true; responses = $responses; at = [DateTime]::UtcNow.ToString('o') })
        }
        'command' {
          $command = [string]$request.command
          $timeout = if ([int]$request.timeoutMs -gt 0) { [int]$request.timeoutMs } else { 1200 }
          $response = Send-Command $port $command $timeout
          Write-Result ([pscustomobject]@{ id = $id; success = $true; command = $command; response = $response })
        }
        'ping' { Write-Result ([pscustomobject]@{ id = $id; success = $true; at = [DateTime]::UtcNow.ToString('o') }) }
        'close' { Write-Result ([pscustomobject]@{ id = $id; success = $true; closing = $true }); break }
        default { throw "Unknown session action: $($request.action)" }
      }
      if ([string]$request.action -eq 'close') { break }
    } catch {
      Write-Result ([pscustomobject]@{ id = $id; success = $false; error = $_.Exception.Message })
    }
  }
} catch {
  Write-Result ([pscustomobject]@{ id = 'ready'; success = $false; error = $_.Exception.Message; port = $PortName; baud = $Baud })
  exit 1
} finally {
  if ($port -and $port.IsOpen) { try { $port.Close() } catch {} }
  if ($port) { try { $port.Dispose() } catch {} }
}
