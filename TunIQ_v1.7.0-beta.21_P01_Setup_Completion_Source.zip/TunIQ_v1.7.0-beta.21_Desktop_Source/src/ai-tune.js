const fs = require('fs');
const path = require('path');

function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, value) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function finite(value) { const n = Number(value); return Number.isFinite(n) ? n : null; }
function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
function round(value, digits = 3) { return Number.isFinite(value) ? Number(value.toFixed(digits)) : null; }
function mean(values) { const valid = values.filter(Number.isFinite); return valid.length ? valid.reduce((a,b)=>a+b,0) / valid.length : null; }
function median(values) { const valid = values.filter(Number.isFinite).sort((a,b)=>a-b); if (!valid.length) return null; const m = Math.floor(valid.length/2); return valid.length%2 ? valid[m] : (valid[m-1]+valid[m])/2; }
function stddev(values) { const avg = mean(values); if (!Number.isFinite(avg)) return null; return Math.sqrt(mean(values.filter(Number.isFinite).map(value => (value - avg) ** 2))); }
function safe(value, max = 500) { return String(value ?? '').trim().slice(0, max); }

function parseCsvLine(line) {
  const output = []; let current = ''; let quote = false;
  for (let index = 0; index < line.length; index += 1) {
    const char = line[index];
    if (quote) {
      if (char === '"' && line[index + 1] === '"') { current += '"'; index += 1; }
      else if (char === '"') quote = false;
      else current += char;
    } else if (char === '"') quote = true;
    else if (char === ',') { output.push(current); current = ''; }
    else current += char;
  }
  output.push(current); return output;
}

function parseLog(csvPath) {
  const text = fs.readFileSync(csvPath, 'utf8');
  const lines = text.split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) return [];
  const headers = parseCsvLine(lines[0]);
  return lines.slice(1).map(line => {
    const values = parseCsvLine(line); const row = {};
    headers.forEach((header, index) => {
      const raw = values[index] ?? '';
      row[header] = ['timestamp','marker'].includes(header) ? raw : (raw === '' ? null : finite(raw));
    });
    return row;
  });
}

function numericLabels(labels = []) {
  return labels.map((label, index) => ({ index, value: finite(String(label).replace(/[^0-9+-.]/g, '')) })).filter(item => item.value != null);
}
function nearestLabel(labels, value) {
  const parsed = numericLabels(labels);
  if (!parsed.length || !Number.isFinite(value)) return null;
  return parsed.reduce((best, item) => Math.abs(item.value - value) < Math.abs(best.value - value) ? item : best, parsed[0]);
}
function tableText(table) { return `${table?.name || ''} ${table?.description || ''} ${table?.category || ''} ${table?.unit || ''}`.toLowerCase(); }
function findTables(workspace, patterns) {
  return Object.entries(workspace.tables || {}).filter(([,table]) => patterns.some(pattern => pattern.test(tableText(table))));
}
function getStock(workspace, tableKey, row, col) {
  const stock = workspace.stock?.[tableKey]?.values?.[row]?.[col];
  return Number.isFinite(Number(stock)) ? Number(stock) : Number(workspace.tables?.[tableKey]?.values?.[row]?.[col]);
}
function groupBy(items, keyFn) {
  const result = new Map();
  for (const item of items) { const key = keyFn(item); if (key == null) continue; if (!result.has(key)) result.set(key, []); result.get(key).push(item); }
  return result;
}
function proposalId(prefix, tableKey, row, col) { return `${prefix}:${tableKey}:${row}:${col}`; }

function proposeMaf(rows, workspace, proposals, evidence) {
  const tables = findTables(workspace, [/maf/, /mass air/]).filter(([,table]) => Array.isArray(table.values) && table.values.length * (table.values[0]?.length || 0) > 1);
  if (!tables.length) return;
  const usable = rows.filter(row => finite(row.rpm) > 650 && finite(row.tps) != null && finite(row.tps) < 65 && finite(row.stft1) != null && finite(row.ltft1) != null && (finite(row.mafFrequency) != null || finite(row.maf) != null));
  if (usable.length < 30) return;
  const [tableKey, table] = tables[0];
  const isRowVector = table.values.length === 1;
  const labels = isRowVector ? table.colHeaders : table.rowHeaders;
  const groups = groupBy(usable, row => {
    const x = finite(row.mafFrequency) ?? finite(row.maf);
    return nearestLabel(labels, x)?.index;
  });
  for (const [index, samples] of groups.entries()) {
    if (samples.length < 8) continue;
    const corrections = samples.map(row => finite(row.stft1) + finite(row.ltft1)).filter(Number.isFinite);
    const correction = median(corrections); const spread = stddev(corrections);
    if (!Number.isFinite(correction) || Math.abs(correction) < 2.5 || (Number.isFinite(spread) && spread > 7.5)) continue;
    const row = isRowVector ? 0 : index, col = isRowVector ? index : 0;
    const current = Number(table.values[row]?.[col]); if (!Number.isFinite(current)) continue;
    const percent = clamp(correction, -8, 8);
    const proposed = current * (1 + percent / 100);
    proposals.push({
      id: proposalId('maf', tableKey, row, col), tableKey, tableName: table.name, row, col,
      rowLabel: table.rowHeaders?.[row] ?? String(row), colLabel: table.colHeaders?.[col] ?? String(col),
      current: round(current, 6), proposed: round(proposed, 6), delta: round(proposed-current, 6), percent: round(percent, 2),
      reason: `Median combined fuel correction was ${correction >= 0 ? '+' : ''}${round(correction,1)}% in this MAF region across ${samples.length} repeatable samples.`,
      evidence: { samples: samples.length, medianTrim: round(correction,2), trimSpread: round(spread,2), source: finite(samples[0].mafFrequency) != null ? 'MAF frequency' : 'MAF airflow' },
      confidence: samples.length >= 20 && (!Number.isFinite(spread) || spread < 4) ? 'high' : 'medium', risk: 'moderate', approvalRequired: true
    });
  }
  evidence.push({ type: 'maf', table: table.name, usableSamples: usable.length });
}

function proposeVe(rows, workspace, proposals, evidence) {
  const tables = findTables(workspace, [/\bve\b/, /volumetric efficiency/]);
  if (!tables.length) return;
  const usable = rows.filter(row => finite(row.rpm) > 650 && finite(row.map) != null && finite(row.stft1) != null && finite(row.ltft1) != null && finite(row.tps) < 75);
  if (usable.length < 40) return;
  const [tableKey, table] = tables[0];
  if (table.values.length < 2 || (table.values[0]?.length || 0) < 2) return;
  const groups = groupBy(usable, row => {
    const r = nearestLabel(table.rowHeaders, finite(row.rpm));
    const c = nearestLabel(table.colHeaders, finite(row.map));
    return r && c ? `${r.index}:${c.index}` : null;
  });
  for (const [key, samples] of groups.entries()) {
    if (samples.length < 8) continue;
    const [row, col] = key.split(':').map(Number);
    const correctionValues = samples.map(sample => finite(sample.stft1) + finite(sample.ltft1)).filter(Number.isFinite);
    const correction = median(correctionValues), spread = stddev(correctionValues);
    if (!Number.isFinite(correction) || Math.abs(correction) < 3 || (Number.isFinite(spread) && spread > 8)) continue;
    const current = Number(table.values[row]?.[col]); if (!Number.isFinite(current)) continue;
    const percent = clamp(correction, -8, 8), proposed = current * (1 + percent/100);
    proposals.push({
      id: proposalId('ve', tableKey, row, col), tableKey, tableName: table.name, row, col,
      rowLabel: table.rowHeaders?.[row] ?? String(row), colLabel: table.colHeaders?.[col] ?? String(col),
      current: round(current, 6), proposed: round(proposed, 6), delta: round(proposed-current, 6), percent: round(percent,2),
      reason: `Median combined fuel correction was ${correction >= 0 ? '+' : ''}${round(correction,1)}% near ${table.rowHeaders?.[row] || row} RPM / ${table.colHeaders?.[col] || col} MAP-load.`,
      evidence: { samples: samples.length, medianTrim: round(correction,2), trimSpread: round(spread,2) },
      confidence: samples.length >= 20 && (!Number.isFinite(spread) || spread < 4) ? 'high' : 'medium', risk: 'moderate', approvalRequired: true
    });
  }
  evidence.push({ type: 've', table: table.name, usableSamples: usable.length });
}

function proposeIdle(rows, workspace, proposals, evidence) {
  const tables = findTables(workspace, [/base.*air/, /running.*air/, /idle.*air/]);
  if (!tables.length) return;
  const idleRows = rows.filter(row => finite(row.rpm) > 450 && finite(row.speed) <= 1 && finite(row.tps) <= 3 && (finite(row.desiredIdle) != null || finite(row.rpm) != null));
  if (idleRows.length < 25) return;
  const desiredValues = idleRows.map(row => finite(row.desiredIdle)).filter(Number.isFinite);
  if (!desiredValues.length) return;
  const actual = mean(idleRows.map(row => finite(row.rpm)).filter(Number.isFinite));
  const desired = mean(desiredValues); const error = desired - actual;
  if (!Number.isFinite(error) || Math.abs(error) < 75) return;
  const [tableKey, table] = tables[0];
  const temp = mean(idleRows.map(row => finite(row.ect)).filter(Number.isFinite));
  const rowMatch = nearestLabel(table.rowHeaders, temp) || { index: 0 };
  const col = Math.min((table.values[0]?.length || 1)-1, 0);
  const row = rowMatch.index; const current = Number(table.values[row]?.[col]);
  if (!Number.isFinite(current)) return;
  const delta = clamp(error / 300, -0.75, 0.75), proposed = Math.max(0, current + delta);
  proposals.push({
    id: proposalId('idle-airflow', tableKey, row, col), tableKey, tableName: table.name, row, col,
    rowLabel: table.rowHeaders?.[row] ?? String(row), colLabel: table.colHeaders?.[col] ?? String(col),
    current: round(current,6), proposed: round(proposed,6), delta: round(proposed-current,6), percent: current ? round((proposed/current-1)*100,2) : null,
    reason: `Warm idle averaged ${round(actual,0)} RPM against ${round(desired,0)} RPM desired (${error >= 0 ? '+' : ''}${round(error,0)} RPM error).`,
    evidence: { samples: idleRows.length, actualRpm: round(actual,1), desiredRpm: round(desired,1), coolantF: round(temp,1) },
    confidence: idleRows.length >= 60 ? 'medium' : 'low', risk: 'moderate', approvalRequired: true
  });
  evidence.push({ type: 'idle-airflow', table: table.name, usableSamples: idleRows.length });
}

function buildSafetyFindings(rows) {
  const findings = [];
  const voltage = rows.filter(row => finite(row.rpm) > 450).map(row => finite(row.voltage)).filter(Number.isFinite);
  if (voltage.length && Math.min(...voltage) < 12.4) findings.push({ severity: 'block', title: 'Low running voltage', detail: `Voltage reached ${round(Math.min(...voltage),2)} V. Repair power/charging before flashing.` });
  const knock = rows.map(row => finite(row.knockRetard)).filter(Number.isFinite);
  if (knock.length && Math.max(...knock) > 4) findings.push({ severity: 'warning', title: 'Knock retard recorded', detail: `Maximum recorded knock retard was ${round(Math.max(...knock),1)}°. TunIQ will not automatically add spark.` });
  const ect = rows.map(row => finite(row.ect)).filter(Number.isFinite);
  if (ect.length && Math.max(...ect) > 230) findings.push({ severity: 'block', title: 'Excessive coolant temperature', detail: `Coolant reached ${round(Math.max(...ect),1)} °F. Resolve cooling before tuning.` });
  const wot = rows.filter(row => finite(row.tps) >= 70);
  const hasWideband = wot.filter(row => finite(row.widebandAfr) != null || finite(row.commandedEqRatio) != null).length >= 10;
  if (wot.length && !hasWideband) findings.push({ severity: 'block', title: 'Power data is incomplete', detail: 'High-throttle samples exist without a trustworthy wideband/commanded equivalence-ratio channel. No power enrichment or spark proposal was generated.' });
  return findings;
}

function generateProposal({ csvPath, workspace, activeProject, analysis = null }) {
  if (!csvPath || !fs.existsSync(csvPath)) throw new Error('Select an existing project CSV log.');
  if (!workspace || workspace.mode !== 'xdf' || !workspace.tables) throw new Error('Load the active project BIN/XDF mapping before generating calibration proposals.');
  if (!activeProject?.id || workspace.projectId !== activeProject.id) throw new Error('The calibration workspace does not match the active project.');
  const rows = parseLog(csvPath);
  if (rows.length < 30) throw new Error('The log needs at least 30 usable samples before TunIQ can propose calibration changes.');
  const proposals = [], evidence = [];
  proposeMaf(rows, workspace, proposals, evidence);
  proposeVe(rows, workspace, proposals, evidence);
  proposeIdle(rows, workspace, proposals, evidence);
  const safetyFindings = buildSafetyFindings(rows);
  const blockers = safetyFindings.filter(item => item.severity === 'block');
  const deduped = [];
  const seen = new Set();
  for (const item of proposals) { if (!seen.has(item.id)) { seen.add(item.id); deduped.push(item); } }
  const result = {
    id: `${Date.now()}-proposal`, projectId: activeProject.id, projectName: activeProject.name,
    sourceLog: csvPath, sourceLogName: path.basename(csvPath), generatedAt: new Date().toISOString(), sampleCount: rows.length,
    analysis, evidence, safetyFindings, blocked: blockers.length > 0,
    proposals: blockers.length ? deduped.map(item => ({ ...item, blocked: true })) : deduped,
    summary: {
      proposedCells: deduped.length,
      highConfidence: deduped.filter(item => item.confidence === 'high').length,
      tables: [...new Set(deduped.map(item => item.tableName))],
      approvalRequired: true,
      automaticSparkIncrease: false,
      automaticFlash: false
    },
    warnings: [
      'Each proposed cell requires explicit approval.',
      'Mechanical faults and unsafe data block application.',
      'TunIQ never automatically adds spark from a single log.',
      'Applying a proposal changes the calibration workspace only; exporting and flashing are separate confirmation-gated actions.'
    ]
  };
  return result;
}

function applyApproved(workspace, proposal, approvedIds = []) {
  if (!workspace || workspace.mode !== 'xdf') throw new Error('Load an XDF calibration workspace first.');
  if (!proposal || proposal.projectId !== workspace.projectId) throw new Error('The proposal does not match this calibration workspace.');
  if (proposal.blocked) throw new Error('This proposal is blocked by safety findings. Resolve them and record a new log.');
  const approved = new Set(approvedIds.map(String));
  if (!approved.size) throw new Error('Select at least one proposed calibration change.');
  const applied = [];
  for (const item of proposal.proposals || []) {
    if (!approved.has(String(item.id))) continue;
    const table = workspace.tables?.[item.tableKey];
    if (!table?.values?.[item.row] || !Number.isFinite(Number(item.proposed))) continue;
    const current = Number(table.values[item.row][item.col]);
    if (Math.abs(current - Number(item.current)) > 1e-5) throw new Error(`${item.tableName} cell ${item.rowLabel}/${item.colLabel} changed after the proposal was generated. Generate a fresh proposal.`);
    table.values[item.row][item.col] = Number(item.proposed);
    workspace.modified = workspace.modified && typeof workspace.modified === 'object' ? workspace.modified : {};
    workspace.modified[`${item.tableKey}:${item.row}:${item.col}`] = true;
    applied.push({ ...item, appliedAt: new Date().toISOString() });
  }
  if (!applied.length) throw new Error('None of the selected proposals could be applied.');
  workspace.updatedAt = new Date().toISOString();
  workspace.aiApplied = { proposalId: proposal.id, sourceLog: proposal.sourceLog, applied, at: workspace.updatedAt };
  return { workspace, applied };
}

function proposalRoot(active) { return ensureDir(path.join(active.folder, 'AI', 'Proposals')); }
function saveProposal(active, proposal) { const file = path.join(proposalRoot(active), `${proposal.id}.json`); writeJson(file, proposal); return { ...proposal, file }; }
function listProposals(active) {
  const folder = proposalRoot(active);
  return fs.readdirSync(folder).filter(name => name.endsWith('.json')).map(name => {
    const file = path.join(folder, name), item = readJson(file, null); return item ? { ...item, file } : null;
  }).filter(Boolean).sort((a,b)=>String(b.generatedAt).localeCompare(String(a.generatedAt))).slice(0,100);
}
function getProposal(active, id) { return listProposals(active).find(item => item.id === id) || null; }

module.exports = { parseLog, generateProposal, applyApproved, saveProposal, listProposals, getProposal };
