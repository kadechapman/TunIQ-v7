const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const MAX_SCAN_FILES = 30000;
const MAX_SCAN_DEPTH = 6;
const MAX_TABLES = 12000;
const SUPPORTED_EXTENSIONS = new Set(['.xdf', '.xml']);
const COMMISSIONING_MARKER = 'TUNIQ_COMMISSIONING_ONLY';

function sha256File(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}
function xmlDecode(value = '') {
  return String(value)
    .replace(/&#x([0-9a-f]+);/gi, (_m, hex) => String.fromCodePoint(parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_m, dec) => String.fromCodePoint(parseInt(dec, 10)))
    .replace(/&quot;/gi, '"').replace(/&apos;/gi, "'").replace(/&lt;/gi, '<').replace(/&gt;/gi, '>').replace(/&amp;/gi, '&');
}
function xmlEscape(value = '') {
  return String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
}
function elementText(block, name) {
  const match = String(block).match(new RegExp(`<${name}\\b[^>]*>([\\s\\S]*?)<\\/${name}>`, 'i'));
  return match ? xmlDecode(match[1].replace(/<[^>]+>/g, '').trim()) : '';
}
function firstText(block, names) {
  for (const name of names) {
    const value = elementText(block, name);
    if (value !== '') return value;
  }
  return '';
}
function parseNumber(value, fallback = NaN) {
  if (value == null || value === '') return fallback;
  const text = String(value).trim();
  if (/^0x[0-9a-f]+$/i.test(text)) return parseInt(text, 16);
  if (/^\$[0-9a-f]+$/i.test(text)) return parseInt(text.slice(1), 16);
  const numeric = Number(text);
  return Number.isFinite(numeric) ? numeric : fallback;
}
function osCandidatesFromText(value) {
  const matches = [...String(value || '').matchAll(/(?:^|\D)(\d{7,9})(?!\d)/g)].map(match => match[1]);
  return [...new Set(matches)].filter(value => Number(value) > 1000000 && Number(value) < 999999999);
}
function equationIsSafe(equation = 'X') {
  const text = String(equation || 'X').trim().replace(/\^/g, '**');
  if (!text || text.length > 500 || /(constructor|prototype|process|require|function|=>|window|document|eval)/i.test(text)) return false;
  return /^[A-Za-z0-9_+\-*/().,\s%?:<>=!&|]+$/.test(text);
}
function listFilesRecursive(roots, { extensions = SUPPORTED_EXTENSIONS, maxDepth = MAX_SCAN_DEPTH, maxFiles = MAX_SCAN_FILES } = {}) {
  const output = [];
  const seen = new Set();
  const skip = new Set(['node_modules', '.git', '$recycle.bin', 'windows', 'winsxs', 'packages', 'cache']);
  const queue = (roots || []).filter(Boolean).map(root => ({ folder: path.resolve(root), depth: 0 }));
  while (queue.length && output.length < maxFiles) {
    const item = queue.shift();
    if (seen.has(item.folder) || !fs.existsSync(item.folder)) continue;
    seen.add(item.folder);
    let entries;
    try { entries = fs.readdirSync(item.folder, { withFileTypes: true }); } catch { continue; }
    for (const entry of entries) {
      if (output.length >= maxFiles) break;
      const full = path.join(item.folder, entry.name);
      if (entry.isFile() && extensions.has(path.extname(entry.name).toLowerCase())) output.push(full);
      else if (entry.isDirectory() && item.depth < maxDepth && !skip.has(entry.name.toLowerCase())) queue.push({ folder: full, depth: item.depth + 1 });
    }
  }
  return output;
}

function analyzeXdf(file, parseXdf) {
  try {
    const parsed = parseXdf(file);
    const osCandidates = osCandidatesFromText(`${path.basename(file)} ${parsed.title || ''}`);
    return {
      kind: 'xdf', path: path.resolve(file), name: path.basename(file), sha256: sha256File(file),
      title: parsed.title || path.basename(file), osCandidates, tableCount: parsed.tables?.length || 0,
      checksumCount: parsed.checksums?.length || 0, warnings: parsed.warnings || [], commissioningOnly: isCommissioningOnlyXdf(file), error: null
    };
  } catch (error) {
    return { kind: 'xdf', path: path.resolve(file), name: path.basename(file), osCandidates: osCandidatesFromText(path.basename(file)), tableCount: 0, warnings: [], error: error.message };
  }
}

function universalPatcherLayout(exe) {
  if (!exe || !fs.existsSync(exe)) return { installed: false, exe: exe || null, root: null, complete: false, issues: ['Universal Patcher executable was not found.'] };
  const root = path.dirname(path.resolve(exe));
  const xmlFolder = path.join(root, 'XML');
  const tunerFolder = path.join(root, 'Tuner');
  const p01Xml = path.join(xmlFolder, 'P01-P59.xml');
  const issues = [];
  if (!fs.existsSync(xmlFolder)) issues.push('The XML folder is missing. Universal Patcher must be extracted as a complete folder.');
  if (!fs.existsSync(tunerFolder)) issues.push('The Tuner definition folder is missing.');
  if (!fs.existsSync(p01Xml)) issues.push('XML/P01-P59.xml is missing.');
  return { installed: true, exe: path.resolve(exe), root, xmlFolder, tunerFolder, p01Xml, complete: issues.length === 0, issues };
}

function parseUpTableBlocks(xml) {
  const output = [];
  for (const tag of ['TableData', 'Table']) {
    for (const match of String(xml).matchAll(new RegExp(`<${tag}\\b[^>]*>([\\s\\S]*?)<\\/${tag}>`, 'gi'))) output.push(match[1]);
  }
  return output;
}
function normalizeDataType(value) {
  const lower = String(value || '').toLowerCase().replace(/[\s_-]/g, '');
  const map = {
    uint8: { bits: 8, signed: false, float: false }, ubyte: { bits: 8, signed: false, float: false }, byte: { bits: 8, signed: false, float: false },
    int8: { bits: 8, signed: true, float: false }, sbyte: { bits: 8, signed: true, float: false },
    uint16: { bits: 16, signed: false, float: false }, ushort: { bits: 16, signed: false, float: false }, uword: { bits: 16, signed: false, float: false }, word: { bits: 16, signed: false, float: false },
    int16: { bits: 16, signed: true, float: false }, short: { bits: 16, signed: true, float: false }, sword: { bits: 16, signed: true, float: false },
    uint32: { bits: 32, signed: false, float: false }, ulong: { bits: 32, signed: false, float: false }, udword: { bits: 32, signed: false, float: false }, dword: { bits: 32, signed: false, float: false },
    int32: { bits: 32, signed: true, float: false }, long: { bits: 32, signed: true, float: false }, sdword: { bits: 32, signed: true, float: false },
    float: { bits: 32, signed: true, float: true }, single: { bits: 32, signed: true, float: true }
  };
  if (map[lower]) return map[lower];
  const bits = parseInt((lower.match(/(8|16|32)/) || [])[1], 10);
  if (bits) return { bits, signed: /(^|[^u])int|signed/.test(lower), float: /float|single/.test(lower) };
  return null;
}
function splitLabels(value, count) {
  const values = String(value || '').split(/[;,|\r\n]+/).map(item => item.trim()).filter(Boolean);
  return Array.from({ length: count }, (_v, index) => values[index] ?? String(index));
}
function platformByteOrder(controller = '') {
  const normalized = String(controller || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (['P01','P59','P04','P08','P10','P11','P12'].includes(normalized)) return 'big';
  return null;
}
function parseUniversalTunerXml(file, { controller = '' } = {}) {
  const xml = fs.readFileSync(file, 'utf8');
  const rootOs = firstText(xml, ['OS', 'OSID', 'OperatingSystem', 'OperatingSystemId']) || path.basename(file, path.extname(file));
  const rootCandidates = osCandidatesFromText(`${rootOs} ${path.basename(file)}`);
  const tables = [];
  const warnings = [];
  for (const block of parseUpTableBlocks(xml).slice(0, MAX_TABLES)) {
    const tableOs = firstText(block, ['OS', 'OSID', 'OperatingSystem', 'OperatingSystemId']) || rootOs;
    const osCandidates = osCandidatesFromText(tableOs);
    const name = firstText(block, ['TableName', 'Name', 'Title']) || `Universal Patcher item ${tables.length + 1}`;
    const category = firstText(block, ['Category', 'Group']);
    const addressText = firstText(block, ['Address', 'addrInt', 'AddrInt']);
    const address = parseNumber(addressText);
    const offset = parseNumber(firstText(block, ['Offset']), 0);
    const extraOffset = parseNumber(firstText(block, ['ExtraOffset']), 0);
    const dataTypeText = firstText(block, ['DataType', 'Type', 'ElementType']);
    const dataType = normalizeDataType(dataTypeText);
    const rows = Math.max(1, Math.floor(parseNumber(firstText(block, ['Rows', 'RowCount', 'NumRows']), 1)));
    const cols = Math.max(1, Math.floor(parseNumber(firstText(block, ['Columns', 'ColumnCount', 'Cols', 'NumColumns']), 1)));
    const equation = firstText(block, ['Math', 'Equation', 'Conversion']) || 'X';
    const units = firstText(block, ['Units', 'Unit']);
    const byteOrderText = firstText(block, ['ByteOrder', 'LittleEndian', 'LSBFirst', 'Endian']);
    const platformOrder = platformByteOrder(controller);
    let littleEndian = null;
    if (/little|lohi|lsb|true|^1$/i.test(byteOrderText)) littleEndian = true;
    else if (/big|hilo|msb|false|^0$/i.test(byteOrderText)) littleEndian = false;
    else if (/platformorder/i.test(byteOrderText)) littleEndian = platformOrder === 'little' ? true : platformOrder === 'big' ? false : null;
    else if (!byteOrderText && dataType?.bits === 8) littleEndian = true;
    const rowLabels = splitLabels(firstText(block, ['RowHeaders', 'RowLabels', 'YAxisLabels']), rows);
    const colLabels = splitLabels(firstText(block, ['ColumnHeaders', 'ColumnLabels', 'XAxisLabels']), cols);
    const rowMajorText = firstText(block, ['RowMajor']);
    const rowMajor = !/false|0/i.test(rowMajorText || 'true');
    const bitMaskText = firstText(block, ['BitMask', 'Mask']);
    const bitMask = bitMaskText ? parseNumber(bitMaskText) : 0;
    const min = parseNumber(firstText(block, ['Min', 'Minimum']), NaN);
    const max = parseNumber(firstText(block, ['Max', 'Maximum']), NaN);
    const decimals = parseNumber(firstText(block, ['Decimals', 'DecimalPlaces']), NaN);
    const issues = [];
    if (!Number.isInteger(address) || address < 0) issues.push('missing or invalid address');
    if (offset !== 0 || extraOffset !== 0) issues.push(`nonzero address offset (${offset} + ${extraOffset}) requires manual review`);
    if (!dataType) issues.push(`unsupported data type ${dataTypeText || '(blank)'}`);
    if (dataType && dataType.bits > 8 && littleEndian == null) issues.push(`unresolved byte order ${byteOrderText || '(blank)'}`);
    if (bitMaskText && (!Number.isInteger(bitMask) || bitMask <= 0)) issues.push(`invalid bit mask ${bitMaskText}`);
    if (!equationIsSafe(equation)) issues.push(`unsafe equation ${equation}`);
    if (rows * cols > 131072) issues.push('table exceeds 131,072 cells');
    const table = { name, category, address, dataType, rows, cols, equation, units, littleEndian: littleEndian ?? true, rowMajor, bitMask: Number.isInteger(bitMask) ? bitMask >>> 0 : 0, min: Number.isFinite(min) ? min : null, max: Number.isFinite(max) ? max : null, decimals: Number.isFinite(decimals) ? Math.max(0, Math.floor(decimals)) : null, rowLabels, colLabels, osCandidates, issues };
    if (issues.length) warnings.push(`${name}: ${issues.join(', ')}`);
    tables.push(table);
  }
  return {
    kind: 'universal-patcher-tuner-xml', path: path.resolve(file), name: path.basename(file), sha256: sha256File(file),
    osCandidates: rootCandidates, tables, usableTables: tables.filter(table => !table.issues.length), warnings
  };
}

function buildXdfFromUniversalTunerXml(sourceFile, destination, { os, binSize = 524288, controller = '' } = {}) {
  const parsed = parseUniversalTunerXml(sourceFile, { controller });
  const exactOs = String(os || '');
  if (!exactOs || !parsed.osCandidates.includes(exactOs)) throw new Error(`Universal Patcher definition ${parsed.name} does not explicitly declare OS ${exactOs}.`);
  const usable = parsed.usableTables.filter(table => !table.osCandidates.length || table.osCandidates.includes(exactOs));
  if (!usable.length) throw new Error(`Universal Patcher definition ${parsed.name} has no safe, explicitly addressed tables for OS ${exactOs}.`);
  const items = [];
  usable.forEach((table, index) => {
    const bytes = table.dataType.bits / 8;
    const lastAddress = table.address + Math.max(0, table.rows * table.cols - 1) * bytes + bytes;
    if (Number.isFinite(binSize) && lastAddress > binSize) throw new Error(`${table.name} extends beyond the ${binSize}-byte BIN.`);
    const id = `up_${index + 1}_${crypto.createHash('sha1').update(`${table.name}:${table.address}`).digest('hex').slice(0, 10)}`;
    const flags = (table.dataType.signed ? 0x01 : 0) | (!table.littleEndian ? 0x02 : 0) | (!table.rowMajor ? 0x04 : 0);
    const embedded = `<EMBEDDEDDATA mmedaddress="0x${table.address.toString(16).toUpperCase()}" mmedelementsizebits="${table.dataType.bits}" mmedrowcount="${table.rows}" mmedcolcount="${table.cols}" mmedtypeflags="${flags}" lsbfirst="${table.littleEndian ? 1 : 0}"${table.bitMask ? ` mmedbitmask="0x${table.bitMask.toString(16).toUpperCase()}"` : ''}${table.dataType.float ? ' float="1"' : ''}/>`;
    const limits = `${table.min != null ? `<min>${table.min}</min>` : ''}${table.max != null ? `<max>${table.max}</max>` : ''}${table.decimals != null ? `<decimalpl>${table.decimals}</decimalpl>` : ''}`;
    const math = `<MATH equation="${xmlEscape(table.equation || 'X')}" units="${xmlEscape(table.units || '')}"/>${limits}`;
    if (table.rows === 1 && table.cols === 1) {
      items.push(`<XDFCONSTANT uniqueid="${id}" title="${xmlEscape(table.name)}"><description>${xmlEscape(`Generated from Universal Patcher ${parsed.name}${table.category ? ` · ${table.category}` : ''}`)}</description>${embedded}${math}</XDFCONSTANT>`);
      return;
    }
    const labels = (axis, values) => `<XDFAXIS id="${axis}"><indexcount>${values.length}</indexcount>${values.map((label, labelIndex) => `<LABEL index="${labelIndex}" value="${xmlEscape(label)}"/>`).join('')}</XDFAXIS>`;
    items.push(`<XDFTABLE uniqueid="${id}" title="${xmlEscape(table.name)}"><description>${xmlEscape(`Generated from Universal Patcher ${parsed.name}${table.category ? ` · ${table.category}` : ''}`)}</description>${labels('x', table.colLabels)}${labels('y', table.rowLabels)}<XDFAXIS id="z">${embedded}${math}</XDFAXIS></XDFTABLE>`);
  });
  const xdf = `<?xml version="1.0" encoding="utf-8"?>\n<XDF>\n<XDFHEADER>\n<deftitle>TunIQ / Universal Patcher exact definition OS ${xmlEscape(exactOs)}</deftitle>\n<description>Generated only from explicit addresses in ${xmlEscape(parsed.name)}. Source SHA-256 ${parsed.sha256}.</description>\n<baseoffset>0</baseoffset>\n<DEFAULTS datasizeinbits="8" signed="0" lsbfirst="0"/>\n</XDFHEADER>\n${items.join('\n')}\n</XDF>\n`;
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  fs.writeFileSync(destination, xdf, 'utf8');
  const provenance = {
    schemaVersion: 1, generatedAt: new Date().toISOString(), generator: 'TunIQ Integrated Definitions & Patch Pipeline',
    os: exactOs, sourceFile: path.resolve(sourceFile), sourceSha256: parsed.sha256, outputFile: path.resolve(destination), outputSha256: sha256File(destination),
    tableCount: usable.length, warnings: parsed.warnings
  };
  fs.writeFileSync(`${destination}.provenance.json`, JSON.stringify(provenance, null, 2), 'utf8');
  return { path: destination, provenance, parsed };
}


function isCommissioningOnlyXdf(file) {
  try { return Boolean(file && fs.existsSync(file) && fs.readFileSync(file, 'utf8').includes(COMMISSIONING_MARKER)); }
  catch { return false; }
}

function buildCommissioningOnlyXdf(destination, { os, binSize = 524288, controller = 'P01', originalSha256 = '' } = {}) {
  const exactOs = String(os || '').trim();
  if (!/^\d{7,9}$/.test(exactOs)) throw new Error('A confirmed 7–9 digit operating-system number is required for commissioning-only setup.');
  const size = Number(binSize);
  if (!Number.isFinite(size) || size <= 0) throw new Error('A verified BIN size is required for commissioning-only setup.');
  const title = `TunIQ Commissioning Only — ${String(controller || 'P01').toUpperCase()} OS ${exactOs}`;
  const description = `${COMMISSIONING_MARKER}; exact OS ${exactOs}; read-only hardware commissioning definition; zero writable calibration tables; no calibration addresses were guessed.`;
  const xdf = `<?xml version="1.0" encoding="utf-8"?>\n<XDF>\n<XDFHEADER>\n<deftitle>${xmlEscape(title)}</deftitle>\n<description>${xmlEscape(description)}</description>\n<baseoffset>0</baseoffset>\n<DEFAULTS datasizeinbits="8" signed="0" lsbfirst="1"/>\n</XDFHEADER>\n<XDFCONSTANT uniqueid="tuniq_commissioning_identity" title="Commissioning identity byte (read-only)">\n<description>${xmlEscape(description)}</description>\n<EMBEDDEDDATA mmedaddress="0x0" mmedelementsizebits="8" mmedrowcount="1" mmedcolcount="1" mmedtypeflags="0" lsbfirst="1"/>\n<MATH equation="X" units="raw"/>\n</XDFCONSTANT>\n</XDF>\n`;
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  fs.writeFileSync(destination, xdf, 'utf8');
  const provenance = {
    schemaVersion: 1,
    generatedAt: new Date().toISOString(),
    generator: 'TunIQ P01 Setup Completion',
    mode: 'commissioning-only-read-only',
    marker: COMMISSIONING_MARKER,
    os: exactOs,
    controller: String(controller || 'P01').toUpperCase(),
    binSize: size,
    originalSha256: String(originalSha256 || ''),
    outputFile: path.resolve(destination),
    outputSha256: sha256File(destination),
    writableCalibrationTables: 0,
    guessedCalibrationAddresses: false,
    limitations: [
      'Permits exact-OS project binding, unchanged-stock revision validation, and PCM Hammer Test Write.',
      'Does not permit AI tuning, manual calibration editing, calibration write, full write, or OS conversion.',
      'Replace with a trustworthy writable exact-OS definition before changing calibration data.'
    ]
  };
  fs.writeFileSync(`${destination}.provenance.json`, JSON.stringify(provenance, null, 2), 'utf8');
  return { path: destination, provenance };
}

function scoreCandidate(candidate, os) {
  let score = 0;
  if (candidate.osCandidates?.includes(String(os))) score += 100;
  if (candidate.kind === 'xdf') score += 20;
  if (!candidate.error) score += 10;
  score += Math.min(25, Math.floor((candidate.tableCount || candidate.usableTables?.length || 0) / 20));
  score -= Math.min(30, (candidate.warnings || []).length * 2);
  return score;
}
function scanDefinitionSources({ os, roots = [], parseXdf, universalPatcherExe = null, controller = '' } = {}) {
  const exactOs = String(os || '');
  const layout = universalPatcherLayout(universalPatcherExe);
  const allRoots = [...roots];
  if (layout.complete) allRoots.push(layout.tunerFolder, layout.xmlFolder);
  const files = listFilesRecursive(allRoots);
  const xdfs = [];
  const commissioningXdfs = [];
  const universalXml = [];
  for (const file of files) {
    const extension = path.extname(file).toLowerCase();
    if (extension === '.xdf') {
      const candidate = analyzeXdf(file, parseXdf);
      if (candidate.osCandidates.includes(exactOs)) {
        const scored = { ...candidate, score: scoreCandidate(candidate, exactOs) };
        if (candidate.commissioningOnly) commissioningXdfs.push(scored); else xdfs.push(scored);
      }
    } else if (extension === '.xml' && /(?:^|\D)\d{7,9}(?:\D|$)/.test(path.basename(file))) {
      try {
        const candidate = parseUniversalTunerXml(file, { controller });
        if (candidate.osCandidates.includes(exactOs)) universalXml.push({ ...candidate, score: scoreCandidate(candidate, exactOs) });
      } catch {}
    }
  }
  xdfs.sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
  universalXml.sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
  commissioningXdfs.sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
  return { os: exactOs, scannedFiles: files.length, xdfs, commissioningXdfs, universalXml, universalPatcher: layout };
}

function createDefinitionJob({ projectFolder, projectId, projectName, os, bin, binSha256, tools = {} }) {
  if (!projectFolder || !bin || !fs.existsSync(bin)) throw new Error('A verified project BIN is required for a managed definition job.');
  const folder = path.join(projectFolder, 'Compatibility', 'Definition-Jobs', `${Date.now()}-os-${String(os)}`);
  const input = path.join(folder, 'Input');
  const output = path.join(folder, 'Output');
  fs.mkdirSync(input, { recursive: true });
  fs.mkdirSync(output, { recursive: true });
  const copiedBin = path.join(input, path.basename(bin));
  fs.copyFileSync(bin, copiedBin);
  const manifest = {
    schemaVersion: 1, id: path.basename(folder), createdAt: new Date().toISOString(), status: 'awaiting-definition-output',
    projectId, projectName, os: String(os || ''), bin: copiedBin, binSha256: binSha256 || sha256File(bin), output,
    tunerPro: tools.tunerPro || null, universalPatcher: tools.universalPatcher || null,
    acceptedOutputs: ['Exact-OS .xdf', `Universal Patcher Tuner/${String(os)}.xml`],
    safety: 'TunIQ will not generate guessed table addresses. Only exact-OS files with explicit addresses are accepted.'
  };
  fs.writeFileSync(path.join(folder, 'definition-job.json'), JSON.stringify(manifest, null, 2), 'utf8');
  fs.writeFileSync(path.join(folder, 'README.txt'), [
    `TunIQ definition job for OS ${manifest.os}`,
    '',
    'TunIQ watches Output for an exact-OS XDF or an exact Universal Patcher Tuner XML file.',
    'The protected original BIN in Input must never be overwritten.',
    'Approximate definitions and files for another OS are rejected.'
  ].join('\r\n'), 'utf8');
  return { folder, input, output, manifest };
}

function inspectDefinitionJob(jobFolder, { parseXdf, os, binSize, controller = '' } = {}) {
  const manifestFile = path.join(jobFolder, 'definition-job.json');
  const manifest = JSON.parse(fs.readFileSync(manifestFile, 'utf8'));
  const exactOs = String(os || manifest.os || '');
  const output = manifest.output || path.join(jobFolder, 'Output');
  const files = listFilesRecursive([output], { maxDepth: 3, maxFiles: 1000 });
  const accepted = [];
  const rejected = [];
  for (const file of files) {
    if (path.extname(file).toLowerCase() === '.xdf') {
      const candidate = analyzeXdf(file, parseXdf);
      if (candidate.osCandidates.includes(exactOs) && candidate.tableCount > 0 && !candidate.error) accepted.push(candidate);
      else rejected.push({ path: file, reason: candidate.error || `does not declare OS ${exactOs}` });
    } else if (path.extname(file).toLowerCase() === '.xml') {
      try {
        const candidate = parseUniversalTunerXml(file, { controller });
        if (candidate.osCandidates.includes(exactOs) && candidate.usableTables.length) accepted.push(candidate);
        else rejected.push({ path: file, reason: `does not contain safe exact-OS ${exactOs} table data` });
      } catch (error) { rejected.push({ path: file, reason: error.message }); }
    }
  }
  return { manifest, files, accepted, rejected, os: exactOs, binSize };
}

module.exports = {
  sha256File, osCandidatesFromText, listFilesRecursive, analyzeXdf, universalPatcherLayout,
  parseUniversalTunerXml, buildXdfFromUniversalTunerXml, scanDefinitionSources,
  createDefinitionJob, inspectDefinitionJob, equationIsSafe, normalizeDataType,
  COMMISSIONING_MARKER, isCommissioningOnlyXdf, buildCommissioningOnlyXdf
};
