const fs = require('fs');
const path = require('path');

const DOCTOR_VERSION = 1;
const DEFAULT_BAUDS = [115200, 38400, 9600];

function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, value) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function clean(value, max = 2000) { return String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max); }
function unique(values) { return [...new Set(values.filter(value => value !== '' && value != null))]; }
function now() { return new Date().toISOString(); }

function classifyConnectionError(input) {
  const message = clean(input?.message || input || 'Unknown connection error.', 2000);
  const lower = message.toLowerCase();
  if (/access.*denied|unauthorized|being used|in use|busy|cannot open.*because|permission denied/.test(lower)) {
    return {
      code: 'adapter-locked', severity: 'blocked', title: 'Another program has the COM port open', message,
      actions: ['Close PCM Hammer, OBDLink, OBDwiz, FORScan, serial terminals, and any other scanner app.', 'Wait five seconds, then rerun Connection Doctor.'], retryable: true
    };
  }
  if (/does not exist|could not find.*port|port.*not found|file not found|device.*not connected|specified port/.test(lower)) {
    return {
      code: 'stale-com-port', severity: 'blocked', title: 'The saved COM port no longer exists', message,
      actions: ['Remove the old OBDLink Bluetooth pairing in Windows.', 'Pair the MX+ again, wait for Windows to create its serial port, then rescan.'], retryable: true
    };
  }
  if (/timed out|timeout/.test(lower)) {
    return {
      code: 'adapter-timeout', severity: 'blocked', title: 'The adapter did not answer before timeout', message,
      actions: ['Confirm the MX+ is powered and paired to this PC.', 'Disconnect the phone from the MX+ while testing the PC connection.', 'Retry the alternate COM port if Windows created more than one.'], retryable: true
    };
  }
  if (/no adapter response|could not communicate|unable to connect|empty response|did not answer/.test(lower)) {
    return {
      code: 'adapter-no-response', severity: 'blocked', title: 'Windows opened the port, but no adapter answered', message,
      actions: ['Make sure the MX+ is not connected to a phone or another PC.', 'Try the other Bluetooth COM port and let TunIQ test 115200, 38400, and 9600 baud.', 'Unplug/replug vehicle power or cycle the MX+ pairing if the LEDs do not respond.'], retryable: true
    };
  }
  if (/bluetooth|pair/.test(lower)) {
    return {
      code: 'bluetooth-pairing', severity: 'blocked', title: 'Bluetooth pairing is incomplete', message,
      actions: ['Pair OBDLink MX+ in Windows Bluetooth settings first.', 'Wait for a COM port to appear, then scan again.'], retryable: true
    };
  }
  return {
    code: 'serial-probe-failed', severity: 'blocked', title: 'Serial probe failed', message,
    actions: ['Review the saved Connection Doctor report for the exact port and baud attempt.', 'Close other scanner software and rerun the test.'], retryable: true
  };
}

function scoreDevice(device, preferredPort = '') {
  const text = `${device?.name || ''} ${device?.manufacturer || ''} ${device?.hardwareId || ''} ${device?.transport || ''}`.toLowerCase();
  let score = 0;
  if (device?.port && device.port === preferredPort) score += 100;
  if (/obdlink|scantool/.test(text)) score += 80;
  if (/stn11|stn21|stn22/.test(text)) score += 55;
  if (/bluetooth|bthenum|spp|standard serial over bluetooth/.test(text)) score += 25;
  if (device?.recommended) score += 20;
  if (device?.recognized) score += 10;
  if (/incoming/.test(text)) score -= 20;
  if (/outgoing/.test(text)) score += 8;
  if (/unknown|error|disabled/.test(String(device?.status || '').toLowerCase())) score -= 15;
  return score;
}

function rankAdapterCandidates(devices = [], preferredPort = '') {
  return devices.filter(item => item && !item.demo && item.port).map(item => ({ ...item, doctorScore: scoreDevice(item, preferredPort) }))
    .sort((a, b) => b.doctorScore - a.doctorScore || String(a.port).localeCompare(String(b.port), undefined, { numeric: true }));
}

function doctorStage(id, title, status, message, details = {}) {
  return { id, title, status, message: clean(message, 3000), ...details, at: now() };
}

class ConnectionDoctor {
  constructor(options) {
    this.dataRoot = options.dataRoot;
    this.listDevices = options.listDevices;
    this.releasePort = options.releasePort;
    this.probePortLock = options.probePortLock;
    this.probeAdapter = options.probeAdapter;
    this.getPreferred = options.getPreferred || (() => ({}));
    this.savePreferred = options.savePreferred || (() => ({}));
    this.normalizeProbe = options.normalizeProbe || (value => value);
    this.appendActivity = options.appendActivity || (() => {});
  }
  root() { return ensureDir(path.join(this.dataRoot(), 'Devices', 'ConnectionDoctor')); }
  latestFile() { return path.join(this.root(), 'latest.json'); }
  history() {
    const folder = this.root();
    return fs.readdirSync(folder).filter(name => /^connection-doctor-.*\.json$/i.test(name)).sort().reverse().slice(0, 20)
      .map(name => readJson(path.join(folder, name), null)).filter(Boolean);
  }
  status() { return { latest: readJson(this.latestFile(), null), history: this.history() }; }
  save(report) {
    const stamp = report.finishedAt.replace(/[:.]/g, '-');
    const file = path.join(this.root(), `connection-doctor-${stamp}.json`);
    report.reportFile = file;
    writeJson(file, report); writeJson(this.latestFile(), report);
    return file;
  }
  async run(payload = {}) {
    const preferred = this.getPreferred() || {};
    const requestedPort = clean(payload.port || '', 40);
    const report = {
      type: 'tuniq-connection-doctor', version: DOCTOR_VERSION, status: 'running', startedAt: now(), finishedAt: null,
      requestedPort: requestedPort || null, preferredPort: preferred.port || null, devices: [], stages: [], attempts: [], issues: [], recommendedConnection: null
    };
    let devices;
    try {
      devices = await this.listDevices();
      report.devices = rankAdapterCandidates(devices, requestedPort || preferred.port || '');
      const physicalCount = report.devices.length;
      report.stages.push(doctorStage('windows-scan', 'Windows serial-device scan', physicalCount ? 'passed' : 'blocked', physicalCount ? `Windows returned ${physicalCount} physical serial port${physicalCount === 1 ? '' : 's'}.` : 'Windows did not return a physical serial port for the adapter.'));
      if (!physicalCount) {
        report.issues.push({ code: 'no-serial-port', severity: 'blocked', title: 'No Bluetooth or USB COM port was found', message: 'The MX+ must be paired in Windows before TunIQ can test it.', actions: ['Open Windows Bluetooth settings and pair OBDLink MX+.', 'Disconnect the phone from the adapter, then press Find My Adapter again.'], retryable: true });
        report.status = 'blocked'; report.finishedAt = now(); report.reportFile = this.save(report); return report;
      }
    } catch (error) {
      const issue = classifyConnectionError(error); report.issues.push(issue);
      report.stages.push(doctorStage('windows-scan', 'Windows serial-device scan', 'blocked', issue.message));
      report.status = 'blocked'; report.finishedAt = now(); report.reportFile = this.save(report); return report;
    }

    let candidates = report.devices;
    if (requestedPort) {
      const exact = candidates.find(item => item.port === requestedPort);
      candidates = exact ? [exact, ...candidates.filter(item => item.port !== requestedPort)] : candidates;
    }
    if (payload.tryAlternates === false) candidates = candidates.slice(0, 1);
    const baudRates = unique([Number(payload.baud) || 0, Number(preferred.baud) || 0, ...DEFAULT_BAUDS]).filter(value => value > 0);

    for (const candidate of candidates) {
      try {
        const release = await this.releasePort({ port: candidate.port, reason: 'connection-doctor' });
        if (release?.released) report.stages.push(doctorStage(`release-${candidate.port}`, `Release ${candidate.port} from TunIQ`, 'passed', `TunIQ closed its own ${candidate.port} session before testing.`));
      } catch (error) {
        report.stages.push(doctorStage(`release-${candidate.port}`, `Release ${candidate.port} from TunIQ`, 'warning', error.message));
      }

      let lock;
      try {
        lock = await this.probePortLock({ port: candidate.port, baud: baudRates[0] || 115200 });
      } catch (error) {
        const issue = classifyConnectionError(error); lock = { locked: issue.code === 'adapter-locked', available: false, message: issue.message };
      }
      if (lock?.locked || lock?.available === false) {
        const issue = classifyConnectionError(lock?.message || `${candidate.port} could not be opened.`);
        report.attempts.push({ port: candidate.port, stage: 'lock-probe', status: 'blocked', code: issue.code, message: issue.message });
        report.issues.push({ ...issue, port: candidate.port });
        report.stages.push(doctorStage(`lock-${candidate.port}`, `Exclusive access to ${candidate.port}`, 'blocked', issue.title));
        continue;
      }
      report.stages.push(doctorStage(`lock-${candidate.port}`, `Exclusive access to ${candidate.port}`, 'passed', `${candidate.port} opened and closed successfully; no other program held the port during this test.`));

      for (const baud of baudRates) {
        try {
          const raw = await this.probeAdapter({ port: candidate.port, baud });
          const connection = this.normalizeProbe(raw, candidate);
          report.attempts.push({ port: candidate.port, baud, status: 'passed', adapter: connection.adapter, protocol: connection.protocol, voltage: connection.voltage });
          report.stages.push(doctorStage('adapter-handshake', 'MX+ adapter handshake', 'passed', `${connection.adapter || 'The adapter'} answered on ${candidate.port} at ${baud} baud.`));
          const identityText = `${connection.adapter || ''} ${connection.description || ''} ${connection.firmware || ''}`;
          const obdLink = /obdlink|stn/i.test(identityText);
          report.stages.push(doctorStage('adapter-identity', 'Adapter identity', obdLink ? 'passed' : 'warning', obdLink ? 'OBDLink/STN identity was detected.' : 'A serial OBD adapter answered, but an OBDLink/STN identity was not confirmed.'));
          if (!obdLink) report.issues.push({ code: 'adapter-not-confirmed-obdlink', severity: 'warning', title: 'Adapter identity needs review', message: identityText || 'The adapter did not return a recognizable identity.', actions: ['Confirm the selected COM port belongs to the OBDLink MX+ before using PCM operations.'], retryable: false });
          if (Number.isFinite(Number(connection.voltage))) {
            const voltage = Number(connection.voltage);
            const status = voltage < 11.8 ? 'blocked' : voltage < 12.2 ? 'warning' : 'passed';
            report.stages.push(doctorStage('vehicle-power', 'Vehicle/bench power', status, `The adapter reported ${voltage.toFixed(2)} V.`));
            if (voltage < 11.8) report.issues.push({ code: 'unsafe-voltage', severity: 'warning', blocksPcm: true, title: 'Voltage is too low for PCM work', message: `${voltage.toFixed(2)} V was reported.`, actions: ['Charge the battery or use a regulated power supply before reading or flashing.'], retryable: true });
            else if (voltage < 12.2) report.issues.push({ code: 'marginal-voltage', severity: 'warning', title: 'Voltage is marginal', message: `${voltage.toFixed(2)} V was reported.`, actions: ['Stabilize power before long reads or any write operation.'], retryable: true });
          } else {
            report.stages.push(doctorStage('vehicle-power', 'Vehicle/bench power', 'warning', 'The adapter answered, but ATRV did not return a usable voltage.'));
            report.issues.push({ code: 'voltage-unavailable', severity: 'warning', title: 'Vehicle voltage was not proven', message: 'The PC-to-adapter link works, but vehicle/bench power was not confirmed.', actions: ['Turn the ignition on and confirm the MX+ is fully seated.', 'Verify voltage again before reading or flashing.'], retryable: true });
          }
          const protocolObserved = connection.protocolObserved != null ? Boolean(connection.protocolObserved) : Boolean(connection.protocol && !/^automatic protocol detection$/i.test(connection.protocol));
          report.stages.push(doctorStage('vehicle-protocol', 'Vehicle protocol/VIN', protocolObserved || connection.vin ? 'passed' : 'warning', protocolObserved || connection.vin ? `${protocolObserved ? connection.protocol : 'Protocol not observed'}${connection.vin ? ` · VIN ${connection.vin}` : ''}` : 'The adapter link works, but the vehicle did not return protocol or VIN evidence during this pass.'));
          report.recommendedConnection = { port: candidate.port, baud, adapter: connection.adapter || '', description: connection.description || '', firmware: connection.firmware || '', protocol: connection.protocol || '', voltage: Number.isFinite(Number(connection.voltage)) ? Number(connection.voltage) : null, vin: connection.vin || '', transport: candidate.transport || 'Bluetooth / Serial' };
          for (const issue of report.issues) {
            if (issue.port && issue.port !== candidate.port && issue.severity === 'blocked') { issue.severity = 'info'; issue.resolvedByAlternate = true; }
          }
          this.savePreferred(report.recommendedConnection);
          report.status = report.issues.some(item => item.severity === 'blocked') ? 'blocked' : report.issues.some(item => item.severity === 'warning') ? 'warning' : 'ready';
          report.finishedAt = now(); report.summary = report.status === 'ready' ? `Use ${candidate.port} at ${baud} baud. The PC-to-MX+ route passed.` : `Use ${candidate.port} at ${baud} baud after reviewing the warning${report.issues.length === 1 ? '' : 's'}.`;
          report.reportFile = this.save(report);
          this.appendActivity('connection-doctor-complete', { status: report.status, port: candidate.port, baud, adapter: connection.adapter, reportFile: report.reportFile });
          return report;
        } catch (error) {
          const issue = classifyConnectionError(error);
          report.attempts.push({ port: candidate.port, baud, status: 'failed', code: issue.code, message: issue.message });
        }
      }
      const failed = report.attempts.filter(item => item.port === candidate.port && item.status === 'failed');
      if (failed.length) {
        const issue = classifyConnectionError(failed[failed.length - 1].message);
        report.issues.push({ ...issue, port: candidate.port, testedBauds: baudRates });
        report.stages.push(doctorStage(`probe-${candidate.port}`, `Adapter handshake on ${candidate.port}`, 'blocked', `No valid adapter response at ${baudRates.join(', ')} baud.`));
      }
    }

    report.status = 'blocked'; report.finishedAt = now(); report.summary = 'TunIQ could not prove a working PC-to-adapter route on the detected ports.';
    report.reportFile = this.save(report);
    this.appendActivity('connection-doctor-complete', { status: report.status, reportFile: report.reportFile, issueCodes: report.issues.map(item => item.code) });
    return report;
  }
}

module.exports = { ConnectionDoctor, classifyConnectionError, rankAdapterCandidates, scoreDevice, DEFAULT_BAUDS };
