const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { parseLog, generateProposal } = require('./ai-tune');
const { sameBinding } = require('./tune-workspace');

const TUNE_ENGINE_SCHEMA_VERSION = 1;
const MAX_AUDIT = 500;
const MAX_PROPOSALS = 200;

function clone(value) { return JSON.parse(JSON.stringify(value)); }
function finite(value) { const number = Number(value); return Number.isFinite(number) ? number : null; }
function clamp(value, minimum, maximum) { return Math.max(minimum, Math.min(maximum, value)); }
function round(value, digits = 4) { return Number.isFinite(Number(value)) ? Number(Number(value).toFixed(digits)) : null; }
function safe(value, maximum = 500) { return String(value ?? '').trim().slice(0, maximum); }
function safeName(value, fallback = 'item') { return (safe(value, 100) || fallback).replace(/[<>:"/\\|?*\x00-\x1F]+/g, '-').replace(/\s+/g, ' '); }
function now() { return new Date().toISOString(); }
function id(prefix) { return `${prefix}-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`; }
function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function atomicWriteJson(file, value) {
  ensureDir(path.dirname(file));
  const temporary = `${file}.tmp-${process.pid}-${Date.now()}`;
  fs.writeFileSync(temporary, JSON.stringify(value, null, 2), 'utf8');
  try { fs.renameSync(temporary, file); }
  catch (error) {
    if (!['EEXIST', 'EPERM', 'EACCES'].includes(error?.code)) { try { fs.unlinkSync(temporary); } catch {} throw error; }
    try { fs.unlinkSync(file); } catch {}
    fs.renameSync(temporary, file);
  }
}
function sha256File(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function median(values) {
  const items = values.map(finite).filter(Number.isFinite).sort((a, b) => a - b);
  if (!items.length) return null;
  const middle = Math.floor(items.length / 2);
  return items.length % 2 ? items[middle] : (items[middle - 1] + items[middle]) / 2;
}
function mean(values) {
  const items = values.map(finite).filter(Number.isFinite);
  return items.length ? items.reduce((sum, value) => sum + value, 0) / items.length : null;
}
function numericLabels(labels = []) {
  return labels.map((label, index) => ({ index, value: finite(String(label).replace(/[^0-9+-.]/g, '')) })).filter(item => item.value != null);
}
function nearestLabel(labels, value) {
  const parsed = numericLabels(labels);
  if (!parsed.length || !Number.isFinite(value)) return null;
  return parsed.reduce((best, item) => Math.abs(item.value - value) < Math.abs(best.value - value) ? item : best, parsed[0]);
}
function tableText(table) { return `${table?.name || ''} ${table?.description || ''} ${table?.category || ''} ${table?.unit || ''}`.toLowerCase(); }
function tableCells(table) {
  const cells = [];
  for (let row = 0; row < (table?.values?.length || 0); row += 1) {
    for (let column = 0; column < (table.values[row]?.length || 0); column += 1) {
      const value = finite(table.values[row][column]);
      if (value == null) continue;
      cells.push({ row, column, value, rowLabel: table.rowHeaders?.[row] ?? String(row), columnLabel: table.colHeaders?.[column] ?? String(column) });
    }
  }
  return cells;
}

const ROLE_DEFINITIONS = [
  { role: 'desired-idle', title: 'Desired Idle Speed', group: 'Drivability', patterns: [/desired.*idle/, /idle.*speed/, /target.*idle/, /idle.*rpm/], excludes: [/air/, /spark/] },
  { role: 'idle-airflow', title: 'Idle Airflow', group: 'Drivability', patterns: [/base.*running.*air/, /idle.*air(flow)?/, /airflow.*idle/] },
  { role: 'maf', title: 'MAF Airflow', group: 'Airflow', patterns: [/\bmaf\b/, /mass.*air/] },
  { role: 've', title: 'Volumetric Efficiency', group: 'Airflow', patterns: [/\bve\b/, /volumetric.*efficiency/] },
  { role: 'power-enrichment', title: 'Power Enrichment', group: 'Fueling', patterns: [/power.*enrich/, /commanded.*(fuel|eq|lambda|afr)/, /\bpe\b.*(fuel|eq|lambda|afr)/] },
  { role: 'stoich', title: 'Stoichiometric Ratio', group: 'Fueling', patterns: [/stoich/, /stoichiometric/] },
  { role: 'injector-flow', title: 'Injector Flow Rate', group: 'Fueling', patterns: [/injector.*flow/, /flow.*injector/, /injector.*rate/] },
  { role: 'injector-offset', title: 'Injector Offset', group: 'Fueling', patterns: [/injector.*offset/, /offset.*voltage/, /injector.*voltage/] },
  { role: 'cranking-fuel', title: 'Cranking Fuel', group: 'Fueling', patterns: [/crank.*fuel/, /crank.*pulse/, /startup.*fuel/] },
  { role: 'high-spark', title: 'High-Octane Spark', group: 'Spark', patterns: [/high.*octane.*spark/, /spark.*high.*octane/, /main.*spark/, /optimal.*spark/] },
  { role: 'low-spark', title: 'Low-Octane Spark', group: 'Spark', patterns: [/low.*octane.*spark/, /spark.*low.*octane/] },
  { role: 'rev-limit', title: 'Engine RPM Limit', group: 'Limits', patterns: [/rev.*limit/, /rpm.*limit/, /fuel.*cut.*rpm/, /engine.*speed.*limit/] },
  { role: 'speed-limit', title: 'Vehicle Speed Limit', group: 'Limits', patterns: [/speed.*limit/, /vehicle.*speed.*limit/, /vss.*limit/] },
  { role: 'fan-temperature', title: 'Cooling Fan Temperatures', group: 'Thermal', patterns: [/fan.*temp/, /fan.*on/, /coolant.*fan/, /electric.*fan/] },
  { role: 'shift-rpm', title: 'Shift RPM', group: 'Transmission', patterns: [/shift.*rpm/, /wot.*shift/, /shift.*speed.*rpm/] },
  { role: 'shift-pressure', title: 'Shift Pressure', group: 'Transmission', patterns: [/shift.*pressure/, /line.*pressure/] },
  { role: 'torque-management', title: 'Torque Management', group: 'Transmission', patterns: [/torque.*management/, /torque.*reduction/] },
  { role: 'gear-ratio', title: 'Final Drive / Gear Ratio', group: 'Speedometer', patterns: [/gear.*ratio/, /final.*drive/] },
  { role: 'tire-revs', title: 'Tire Revolutions', group: 'Speedometer', patterns: [/tire.*rev/, /revs.*mile/, /tire.*diameter/] }
];

function scoreRole(table, definition) {
  const text = tableText(table);
  if (definition.excludes?.some(pattern => pattern.test(text))) return 0;
  let score = 0;
  definition.patterns.forEach((pattern, index) => { if (pattern.test(text)) score += index === 0 ? 75 : 50; });
  if (!score) return 0;
  if (table.unsupportedReason) score -= 45;
  if (table.address != null) score += 10;
  if (table.equationSupported !== false) score += 5;
  if ((table.values?.length || 0) * (table.values?.[0]?.length || 0) > 1) score += 3;
  return Math.max(1, score);
}

function buildCoverageMap(workspace) {
  const entries = Object.entries(workspace?.tables || {});
  const roles = {};
  for (const definition of ROLE_DEFINITIONS) {
    const candidates = entries.map(([tableKey, table]) => ({
      tableKey,
      tableName: table.name || tableKey,
      score: scoreRole(table, definition),
      address: table.address ?? null,
      cells: (table.values?.length || 0) * (table.values?.[0]?.length || 0),
      unsupportedReason: table.unsupportedReason || null
    })).filter(candidate => candidate.score > 0).sort((a, b) => b.score - a.score || a.tableName.localeCompare(b.tableName));
    const primary = candidates[0] || null;
    const ambiguous = Boolean(primary && candidates[1] && candidates[1].score >= primary.score - 10);
    roles[definition.role] = { ...definition, available: Boolean(primary && !primary.unsupportedReason), primary, candidates: candidates.slice(0, 8), ambiguous };
  }
  const available = Object.values(roles).filter(item => item.available).length;
  return {
    generatedAt: now(),
    tableCount: entries.length,
    availableRoles: available,
    totalRoles: ROLE_DEFINITIONS.length,
    percent: Math.round((available / ROLE_DEFINITIONS.length) * 100),
    roles,
    groups: [...new Set(ROLE_DEFINITIONS.map(item => item.group))].map(group => ({
      group,
      roles: ROLE_DEFINITIONS.filter(item => item.group === group).map(item => item.role),
      available: ROLE_DEFINITIONS.filter(item => item.group === group && roles[item.role].available).length
    }))
  };
}

function normalizeTargets(payload = {}, intake = {}) {
  const allowedProfiles = new Set(['stock-plus', 'street', 'tow', 'performance', 'cam', 'economy', 'forced-induction', 'custom']);
  const profile = allowedProfiles.has(String(payload.profile)) ? String(payload.profile) : 'street';
  const desiredIdle = finite(payload.desiredIdle ?? intake.desiredIdle);
  const revLimit = finite(payload.revLimit);
  const speedLimit = finite(payload.speedLimit);
  const fan1On = finite(payload.fan1On);
  const fan1Off = finite(payload.fan1Off);
  const fan2On = finite(payload.fan2On);
  const fan2Off = finite(payload.fan2Off);
  const targetAfr = finite(payload.targetAfr);
  const targetLambda = finite(payload.targetLambda);
  const shiftRpm = finite(payload.shiftRpm);
  return {
    profile,
    aggressiveness: clamp(Math.round(finite(payload.aggressiveness) || 2), 1, 5),
    desiredIdle: desiredIdle == null ? null : clamp(Math.round(desiredIdle), 500, 1400),
    revLimit: revLimit == null ? null : clamp(Math.round(revLimit), 3500, 8500),
    speedLimit: speedLimit == null ? null : clamp(Math.round(speedLimit), 25, 250),
    fan1On: fan1On == null ? null : clamp(Math.round(fan1On), 130, 240),
    fan1Off: fan1Off == null ? null : clamp(Math.round(fan1Off), 120, 235),
    fan2On: fan2On == null ? null : clamp(Math.round(fan2On), 135, 245),
    fan2Off: fan2Off == null ? null : clamp(Math.round(fan2Off), 125, 240),
    targetAfr: targetAfr == null ? null : clamp(targetAfr, 8, 18),
    targetLambda: targetLambda == null ? null : clamp(targetLambda, 0.55, 1.2),
    shiftRpm: shiftRpm == null ? null : clamp(Math.round(shiftRpm), 2500, 8000),
    octane: safe(payload.octane || intake.fuel, 60),
    fuelType: safe(payload.fuelType || intake.fuel, 60),
    selectedLog: safe(payload.selectedLog, 2000),
    confirmations: {
      protectedOriginal: Boolean(payload.confirmations?.protectedOriginal),
      mechanicalHealth: Boolean(payload.confirmations?.mechanicalHealth),
      injectorData: Boolean(payload.confirmations?.injectorData),
      fuelPressure: Boolean(payload.confirmations?.fuelPressure),
      wideband: Boolean(payload.confirmations?.wideband),
      valvetrain: Boolean(payload.confirmations?.valvetrain),
      driveline: Boolean(payload.confirmations?.driveline),
      controlledTest: Boolean(payload.confirmations?.controlledTest)
    }
  };
}

function analyzeLogHealth(csvPath) {
  if (!csvPath || !fs.existsSync(csvPath)) return { available: false, csvPath: csvPath || null, blockers: ['A baseline CSV log has not been selected.'], warnings: [], metrics: {} };
  const rows = parseLog(csvPath);
  const running = rows.filter(row => finite(row.rpm) > 450);
  const voltage = running.map(row => finite(row.voltage)).filter(Number.isFinite);
  const ect = rows.map(row => finite(row.ect)).filter(Number.isFinite);
  const knock = rows.map(row => finite(row.knockRetard)).filter(Number.isFinite);
  const misfire = rows.map(row => finite(row.misfireTotal)).filter(Number.isFinite);
  const wot = rows.filter(row => finite(row.tps) >= 70);
  const widebandSamples = wot.filter(row => finite(row.widebandAfr) != null || finite(row.commandedEqRatio) != null).length;
  const trims = rows.map(row => {
    const stft = finite(row.stft1), ltft = finite(row.ltft1);
    return stft != null && ltft != null ? stft + ltft : null;
  }).filter(Number.isFinite);
  const blockers = [], warnings = [];
  const minimumVoltage = voltage.length ? Math.min(...voltage) : null;
  const maximumEct = ect.length ? Math.max(...ect) : null;
  const maximumKnock = knock.length ? Math.max(...knock) : null;
  const maximumMisfire = misfire.length ? Math.max(...misfire) : null;
  if (rows.length < 30) blockers.push('The selected log has fewer than 30 usable samples.');
  if (minimumVoltage != null && minimumVoltage < 12.2) blockers.push(`Running voltage fell to ${round(minimumVoltage, 2)} V.`);
  if (maximumEct != null && maximumEct > 235) blockers.push(`Coolant temperature reached ${round(maximumEct, 1)} °F.`);
  if (maximumMisfire != null && maximumMisfire > 50) blockers.push(`The misfire counter reached ${Math.round(maximumMisfire)}.`);
  if (maximumKnock != null && maximumKnock > 4) warnings.push(`Knock retard reached ${round(maximumKnock, 1)}°. Spark increases are disabled.`);
  if (wot.length >= 10 && widebandSamples < 10) warnings.push('High-throttle data does not contain enough wideband or commanded-EQ samples for power fueling work.');
  if (trims.length && Math.abs(median(trims)) > 12) warnings.push(`Median combined fuel trim is ${round(median(trims), 1)}%; diagnose airflow or fuel delivery before aggressive changes.`);
  return {
    available: true,
    csvPath,
    sourceLogName: path.basename(csvPath),
    samples: rows.length,
    rows,
    blockers,
    warnings,
    healthy: blockers.length === 0,
    metrics: {
      minimumVoltage: round(minimumVoltage, 2), maximumEct: round(maximumEct, 1), maximumKnock: round(maximumKnock, 1), maximumMisfire: round(maximumMisfire, 0),
      wotSamples: wot.length, widebandSamples, medianCombinedTrim: round(median(trims), 2), averageRpm: round(mean(running.map(row => row.rpm)), 0)
    }
  };
}

function hasModification(intake, patterns) {
  const text = `${(intake?.modifications || []).join(' ')} ${intake?.aspiration || ''} ${intake?.tuneGoal || ''}`.toLowerCase();
  return patterns.some(pattern => pattern.test(text));
}

function stageStatus(blockers, available = true, complete = false) {
  if (complete) return 'complete';
  if (!available || blockers.length) return 'blocked';
  return 'ready';
}

function buildTunePlan({ activeProject, intake = {}, workspace, targets = {}, selectedLog = null }) {
  if (!activeProject?.id) throw new Error('Create or activate a project before building a tune plan.');
  if (!workspace || workspace.mode !== 'xdf' || workspace.projectId !== activeProject.id) throw new Error('Load the active project BIN and XDF mapping before building the tune-engine plan.');
  const normalizedTargets = normalizeTargets({ ...targets, selectedLog: selectedLog || targets.selectedLog }, intake);
  const coverage = buildCoverageMap(workspace);
  const health = analyzeLogHealth(normalizedTargets.selectedLog);
  const mappingWarnings = Array.isArray(workspace.mappingSummary?.warnings) ? workspace.mappingSummary.warnings : [];
  const boosted = hasModification(intake, [/turbo/, /supercharg/, /boost/, /forced induction/]) || normalizedTargets.profile === 'forced-induction';
  const cammed = hasModification(intake, [/camshaft/, /\bcam\b/, /ghost.?cam/]) || normalizedTargets.profile === 'cam';
  const injectorChanged = hasModification(intake, [/injector/]);
  const projectBlockers = [];
  if (!activeProject.controller || !activeProject.os) projectBlockers.push('Controller and operating system identity are incomplete.');
  if (!activeProject.bin || !workspace.sourceBinSha256) projectBlockers.push('A fingerprinted protected original BIN is required.');
  if (mappingWarnings.length) projectBlockers.push(`The XDF mapping contains ${mappingWarnings.length} warning(s).`);
  if (!normalizedTargets.confirmations.protectedOriginal) projectBlockers.push('Confirm that the protected original and recovery path are available.');

  const drivabilityTargets = [normalizedTargets.desiredIdle, normalizedTargets.revLimit, normalizedTargets.speedLimit, normalizedTargets.fan1On, normalizedTargets.fan2On].filter(value => value != null).length;
  const drivabilityRoles = ['desired-idle', 'rev-limit', 'speed-limit', 'fan-temperature'].filter(role => coverage.roles[role]?.available).length;
  const airflowAvailable = coverage.roles.maf.available || coverage.roles.ve.available || coverage.roles['idle-airflow'].available;
  const fuelAvailable = coverage.roles['power-enrichment'].available;
  const sparkAvailable = coverage.roles['high-spark'].available;
  const transmissionAvailable = coverage.roles['shift-rpm'].available || coverage.roles['shift-pressure'].available;

  const stages = [];
  const recoveryBlockers = [...projectBlockers];
  stages.push({ id: 'recovery', order: 1, title: 'Recovery & Identity', group: 'Foundation', status: stageStatus(recoveryBlockers, true, recoveryBlockers.length === 0), blockers: recoveryBlockers, summary: 'Fingerprint the original, controller, OS, and recovery path before any calibration change.', proposalSupported: false });

  const baselineBlockers = [...health.blockers];
  if (!health.available) baselineBlockers.push('Record or select a baseline log.');
  if (!normalizedTargets.confirmations.mechanicalHealth) baselineBlockers.push('Confirm mechanical health, fluid levels, fuel pressure, and sensor plausibility.');
  stages.push({ id: 'baseline', order: 2, title: 'Baseline Health Gate', group: 'Foundation', status: stageStatus(baselineBlockers, health.available), blockers: [...new Set(baselineBlockers)], warnings: health.warnings, summary: health.available ? `${health.samples} samples analyzed from ${health.sourceLogName}.` : 'No baseline log selected.', evidence: health.metrics, proposalSupported: false });

  const driveBlockers = [];
  if (!drivabilityTargets) driveBlockers.push('Enter at least one exact target: idle, fan, RPM limit, or speed limit.');
  if (!drivabilityRoles) driveBlockers.push('No exact drivability/limit tables were identified in the loaded XDF.');
  if (cammed && normalizedTargets.desiredIdle == null) driveBlockers.push('A cammed profile needs an explicit desired idle target.');
  if (normalizedTargets.revLimit != null && !normalizedTargets.confirmations.valvetrain) driveBlockers.push('Confirm the valvetrain and rotating assembly before changing the RPM limit.');
  if (normalizedTargets.speedLimit != null && !normalizedTargets.confirmations.driveline) driveBlockers.push('Confirm tire rating, driveshaft, brakes, bearings, and suspension before changing the speed limit.');
  stages.push({ id: 'drivability', order: 3, title: 'Drivability, Thermal & Limits', group: 'Calibration', status: stageStatus(driveBlockers, drivabilityRoles > 0), blockers: driveBlockers, summary: `${drivabilityTargets} target(s), ${drivabilityRoles} mapped role(s).`, roles: ['desired-idle', 'fan-temperature', 'rev-limit', 'speed-limit'], proposalSupported: true });

  const airflowBlockers = [];
  if (!airflowAvailable) airflowBlockers.push('No MAF, VE, or idle-airflow table was identified.');
  if (!health.available || !health.healthy) airflowBlockers.push('A healthy baseline log is required.');
  stages.push({ id: 'airflow', order: 4, title: 'Airflow Calibration', group: 'Calibration', status: stageStatus(airflowBlockers, airflowAvailable), blockers: airflowBlockers, summary: 'Uses repeatable fuel trims and idle error to propose bounded MAF, VE, and idle-airflow corrections.', roles: ['maf', 've', 'idle-airflow'], proposalSupported: true });

  const fuelBlockers = [];
  if (!fuelAvailable) fuelBlockers.push('No exact power-enrichment table was identified.');
  if (normalizedTargets.targetAfr == null && normalizedTargets.targetLambda == null) fuelBlockers.push('Enter an explicit target AFR or lambda.');
  if (!normalizedTargets.confirmations.wideband) fuelBlockers.push('Confirm a calibrated wideband is present.');
  if (!normalizedTargets.confirmations.fuelPressure) fuelBlockers.push('Confirm fuel pressure under load.');
  if (injectorChanged && !normalizedTargets.confirmations.injectorData) fuelBlockers.push('Changed injectors require verified injector characterization data.');
  if (boosted && !normalizedTargets.confirmations.controlledTest) fuelBlockers.push('Forced-induction power fueling requires a controlled test environment.');
  if (health.metrics?.wotSamples >= 10 && health.metrics?.widebandSamples < 10) fuelBlockers.push('The selected log does not contain enough trustworthy WOT wideband samples.');
  stages.push({ id: 'fueling', order: 5, title: 'Power Fueling', group: 'Calibration', status: stageStatus(fuelBlockers, fuelAvailable), blockers: fuelBlockers, summary: 'Creates bounded high-load commanded-fuel changes only from explicit targets and verified instrumentation.', roles: ['power-enrichment', 'stoich', 'injector-flow', 'injector-offset'], proposalSupported: true, highRisk: true });

  const sparkBlockers = [];
  if (!sparkAvailable) sparkBlockers.push('No exact high-octane spark table was identified.');
  if (!health.available || !health.healthy) sparkBlockers.push('A healthy log is required for spark work.');
  if (!normalizedTargets.confirmations.controlledTest) sparkBlockers.push('Spark work requires a controlled test environment.');
  stages.push({ id: 'spark', order: 6, title: 'Spark Safety & Optimization', group: 'Calibration', status: stageStatus(sparkBlockers, sparkAvailable), blockers: sparkBlockers, warnings: ['Beta.13 can automatically apply bounded spark reductions from repeatable knock evidence. It never automatically adds spark.'], summary: 'Maps knock events to exact cells and proposes conservative reductions only.', roles: ['high-spark', 'low-spark'], proposalSupported: true, highRisk: true });

  const transmissionBlockers = [];
  if (!transmissionAvailable) transmissionBlockers.push('No supported shift RPM or shift-pressure table was identified.');
  if (!intake.transmission) transmissionBlockers.push('Transmission identity is missing from the build profile.');
  if (normalizedTargets.shiftRpm == null) transmissionBlockers.push('Enter an explicit WOT shift RPM to create an automatic proposal.');
  if (normalizedTargets.shiftRpm != null && !normalizedTargets.confirmations.driveline) transmissionBlockers.push('Confirm the transmission, converter, driveshaft, tires, and rear axle before changing WOT shifts.');
  stages.push({ id: 'transmission', order: 7, title: 'Transmission Strategy', group: 'Calibration', status: stageStatus(transmissionBlockers, transmissionAvailable), blockers: transmissionBlockers, summary: 'Creates bounded WOT shift-RPM changes; pressure and torque-management changes remain review-only.', roles: ['shift-rpm', 'shift-pressure', 'torque-management'], proposalSupported: true });

  stages.push({ id: 'validation', order: 8, title: 'Validate, Compare & Package', group: 'Release', status: projectBlockers.length ? 'blocked' : 'ready', blockers: projectBlockers, summary: 'Exports a new revision, validates checksums/layout, records the full change set, and creates a handoff bundle.', proposalSupported: false });
  stages.push({ id: 'flash', order: 9, title: 'Controlled Flash & Verification', group: 'Release', status: 'locked', blockers: ['Flash Center requires a compatible validated revision, stable voltage, recovery proof, and a separate typed confirmation.'], summary: 'Tune Engine never silently writes a controller.', proposalSupported: false });

  const completed = stages.filter(stage => stage.status === 'complete').length;
  const ready = stages.filter(stage => stage.status === 'ready').length;
  let readiness = 10;
  if (activeProject.controller && activeProject.os) readiness += 15;
  if (activeProject.bin && workspace.sourceBinSha256) readiness += 15;
  if (!mappingWarnings.length) readiness += 10;
  readiness += Math.min(20, Math.round(coverage.percent * 0.2));
  if (health.available) readiness += 10;
  if (health.healthy) readiness += 10;
  if (normalizedTargets.confirmations.protectedOriginal) readiness += 5;
  if (normalizedTargets.confirmations.mechanicalHealth) readiness += 5;
  readiness = clamp(readiness, 0, 100);
  const nextStage = stages.find(stage => stage.status === 'ready') || stages.find(stage => stage.status === 'blocked') || stages[stages.length - 1];
  return {
    schemaVersion: TUNE_ENGINE_SCHEMA_VERSION,
    id: id('tune-plan'),
    projectId: activeProject.id,
    projectName: activeProject.name,
    binding: clone(workspace.binding || {}),
    controller: activeProject.controller || '',
    operatingSystem: activeProject.os || '',
    profile: normalizedTargets.profile,
    aggressiveness: normalizedTargets.aggressiveness,
    targets: normalizedTargets,
    build: clone(intake || {}),
    generatedAt: now(),
    updatedAt: now(),
    readiness: { score: readiness, label: readiness >= 85 ? 'ready-for-staged-work' : readiness >= 60 ? 'foundation-ready' : readiness >= 35 ? 'setup-incomplete' : 'blocked', completedStages: completed, readyStages: ready, totalStages: stages.length, projectBlockers },
    coverage,
    health: { ...health, rows: undefined },
    stages,
    nextStageId: nextStage?.id || null,
    appliedStages: [],
    warnings: [
      'Tune Engine changes only exact mapped cells and always creates reviewable project history.',
      'Unknown or ambiguous tables remain blocked instead of being guessed.',
      'Spark increases, injector characterization guesses, automatic emissions-disable changes, and silent PCM writes are not permitted.'
    ]
  };
}

function assertPlan(plan, activeProject, workspace) {
  if (!plan || plan.schemaVersion !== TUNE_ENGINE_SCHEMA_VERSION) throw new Error('Build a current Tune Engine plan first.');
  if (String(plan.projectId) !== String(activeProject?.id) || String(workspace?.projectId) !== String(activeProject?.id)) throw new Error('The Tune Engine plan, workspace, and active project do not match.');
  if (!sameBinding(plan.binding, workspace.binding)) {
    const error = new Error('The BIN/XDF fingerprint changed after this Tune Engine plan was built. Rebuild the plan before generating or applying changes.');
    error.code = 'tune-engine-binding-mismatch'; throw error;
  }
}

function selectPrimaryTable(workspace, coverage, role) {
  const key = coverage.roles?.[role]?.primary?.tableKey;
  return key && workspace.tables?.[key] ? [key, workspace.tables[key]] : null;
}
function proposalItem(prefix, role, tableKey, table, cell, proposed, reason, risk = 'moderate', evidence = {}) {
  const current = Number(cell.value), next = Number(proposed);
  return {
    id: `${prefix}:${tableKey}:${cell.row}:${cell.column}`,
    role, tableKey, tableName: table.name || tableKey, row: cell.row, col: cell.column,
    rowLabel: cell.rowLabel, colLabel: cell.columnLabel,
    current: round(current, 6), proposed: round(next, 6), delta: round(next - current, 6), percent: current ? round((next / current - 1) * 100, 2) : null,
    reason, risk, evidence, approvalRequired: true, blocked: false
  };
}
function targetCells(table, predicate, maximum = 12) {
  const matching = tableCells(table).filter(predicate);
  return (matching.length ? matching : tableCells(table)).slice(0, maximum);
}
function labelNumeric(value) { return finite(String(value).replace(/[^0-9+-.]/g, '')); }

function buildDrivabilityProposal(plan, workspace) {
  const coverage = buildCoverageMap(workspace), items = [], blockers = [];
  const targets = plan.targets;
  if (targets.desiredIdle != null) {
    const match = selectPrimaryTable(workspace, coverage, 'desired-idle');
    if (!match) blockers.push('Desired idle target was entered, but no desired-idle table is mapped.');
    else {
      const [tableKey, table] = match;
      const cells = targetCells(table, cell => {
        const row = labelNumeric(cell.rowLabel), column = String(cell.columnLabel).toLowerCase();
        return (row == null || row >= 150 || /warm|hot|normal/.test(String(cell.rowLabel).toLowerCase())) && !/startup|crank/.test(column);
      }, 16);
      for (const cell of cells) items.push(proposalItem('idle-target', 'desired-idle', tableKey, table, cell, targets.desiredIdle, `Set the mapped warm desired-idle cell to the explicit ${targets.desiredIdle} RPM target.`, 'moderate', { targetRpm: targets.desiredIdle }));
    }
  }
  const fanTargets = [
    { value: targets.fan1On, patterns: [/fan\s*1.*on/i, /low.*fan.*on/i], label: 'Fan 1 On' },
    { value: targets.fan1Off, patterns: [/fan\s*1.*off/i, /low.*fan.*off/i], label: 'Fan 1 Off' },
    { value: targets.fan2On, patterns: [/fan\s*2.*on/i, /high.*fan.*on/i], label: 'Fan 2 On' },
    { value: targets.fan2Off, patterns: [/fan\s*2.*off/i, /high.*fan.*off/i], label: 'Fan 2 Off' }
  ].filter(item => item.value != null);
  if (fanTargets.length) {
    const match = selectPrimaryTable(workspace, coverage, 'fan-temperature');
    if (!match) blockers.push('Fan targets were entered, but no cooling-fan table is mapped.');
    else {
      const [tableKey, table] = match;
      const cells = tableCells(table);
      for (const target of fanTargets) {
        const cell = cells.find(candidate => target.patterns.some(pattern => pattern.test(`${candidate.rowLabel} ${candidate.columnLabel}`))) || (cells.length === 1 && fanTargets.length === 1 ? cells[0] : null);
        if (!cell) blockers.push(`${target.label} could not be isolated in ${table.name}.`);
        else items.push(proposalItem(`fan-${target.label.toLowerCase().replace(/\s+/g, '-')}`, 'fan-temperature', tableKey, table, cell, target.value, `Set ${target.label} to the explicit ${target.value} °F target.`, 'moderate'));
      }
    }
  }
  if (targets.revLimit != null) {
    const match = selectPrimaryTable(workspace, coverage, 'rev-limit');
    if (!match) blockers.push('RPM limit target was entered, but no RPM-limit table is mapped.');
    else {
      const [tableKey, table] = match; const cells = tableCells(table);
      let cut = cells.find(cell => /cut|max|limit|fuel/.test(`${cell.rowLabel} ${cell.columnLabel}`.toLowerCase())) || cells[0];
      let resume = cells.find(cell => /resume|re.?enable|hyster/.test(`${cell.rowLabel} ${cell.columnLabel}`.toLowerCase()));
      if (cut) items.push(proposalItem('rev-cut', 'rev-limit', tableKey, table, cut, targets.revLimit, `Set the mapped engine-speed cut to ${targets.revLimit} RPM after valvetrain confirmation.`, 'high'));
      if (resume && (resume.row !== cut.row || resume.column !== cut.column)) items.push(proposalItem('rev-resume', 'rev-limit', tableKey, table, resume, Math.max(3000, targets.revLimit - 100), `Keep the RPM-limit resume point 100 RPM below the requested cut.`, 'high'));
    }
  }
  if (targets.speedLimit != null) {
    const match = selectPrimaryTable(workspace, coverage, 'speed-limit');
    if (!match) blockers.push('Speed-limit target was entered, but no speed-limit table is mapped.');
    else {
      const [tableKey, table] = match; const cells = tableCells(table);
      const speedCells = cells.filter(cell => /speed|mph|vss/i.test(`${cell.rowLabel} ${cell.columnLabel}`));
      const selected = speedCells.length ? speedCells : (cells.length === 1 ? cells : []);
      if (!selected.length) blockers.push(`The speed-limit role matched ${table.name}, but a speed-specific cell could not be isolated.`);
      for (const cell of selected.slice(0, 4)) items.push(proposalItem('speed-limit', 'speed-limit', tableKey, table, cell, targets.speedLimit, `Set the mapped vehicle-speed limit to the explicit ${targets.speedLimit} MPH target after driveline confirmation.`, 'high'));
    }
  }
  return { items, blockers };
}

function buildAirflowProposal(plan, workspace, activeProject, csvPath) {
  const source = csvPath || plan.targets.selectedLog;
  if (!source) return { items: [], blockers: ['Select a healthy baseline log for airflow calibration.'], sourceLog: null };
  try {
    const generated = generateProposal({ csvPath: source, workspace: clone(workspace), activeProject, analysis: { source: 'tune-engine-airflow-stage', planId: plan.id } });
    const items = (generated.proposals || []).filter(item => /^(maf|ve|idle-airflow):/.test(item.id)).map(item => ({ ...item, role: item.id.split(':')[0], sourceProposalId: generated.id }));
    const blockers = [];
    if (generated.blocked) blockers.push(...(generated.safetyFindings || []).filter(item => item.severity === 'block').map(item => item.detail || item.title));
    if (!items.length) blockers.push('The log did not produce a repeatable bounded MAF, VE, or idle-airflow correction.');
    return { items, blockers, sourceLog: source, evidence: generated.evidence, safetyFindings: generated.safetyFindings };
  } catch (error) { return { items: [], blockers: [error.message], sourceLog: source }; }
}

function powerCells(table) {
  const rowNumbers = numericLabels(table.rowHeaders), columnNumbers = numericLabels(table.colHeaders);
  const maxRow = rowNumbers.length ? Math.max(...rowNumbers.map(item => item.value)) : null;
  const maxColumn = columnNumbers.length ? Math.max(...columnNumbers.map(item => item.value)) : null;
  return tableCells(table).filter(cell => {
    const row = labelNumeric(cell.rowLabel), column = labelNumeric(cell.columnLabel);
    const highRpm = row == null || maxRow == null || maxRow < 1000 || row >= Math.max(1800, maxRow * 0.45);
    const highLoad = column == null || maxColumn == null || (maxColumn <= 2 ? column >= maxColumn * 0.7 : column >= maxColumn * 0.7);
    return highRpm && highLoad;
  }).slice(0, 48);
}
function fuelTargetValue(table, targets) {
  const text = tableText(table), stoich = /e85|ethanol/i.test(targets.fuelType) ? 9.8 : 14.68;
  const lambda = targets.targetLambda != null ? targets.targetLambda : targets.targetAfr != null ? targets.targetAfr / stoich : null;
  if (lambda == null) return null;
  if (/\beq\b|equivalence/.test(text)) return 1 / lambda;
  if (/lambda/.test(text)) return lambda;
  if (/afr|air.*fuel/.test(text)) return lambda * stoich;
  const current = mean(tableCells(table).map(cell => cell.value));
  if (current != null && current > 0.6 && current < 1.8) return current >= 1 ? 1 / lambda : lambda;
  return null;
}
function buildFuelingProposal(plan, workspace) {
  const coverage = buildCoverageMap(workspace), match = selectPrimaryTable(workspace, coverage, 'power-enrichment');
  if (!match) return { items: [], blockers: ['No exact power-enrichment table is mapped.'] };
  const [tableKey, table] = match, target = fuelTargetValue(table, plan.targets);
  if (target == null) return { items: [], blockers: ['TunIQ could not determine whether the mapped power-fueling table uses EQ, lambda, or AFR. Review the XDF units before continuing.'] };
  const items = powerCells(table).map(cell => {
    const maximumStep = Math.abs(cell.value) * 0.05;
    const bounded = clamp(target, cell.value - maximumStep, cell.value + maximumStep);
    return proposalItem('power-fuel', 'power-enrichment', tableKey, table, cell, bounded, `Move this high-load cell one bounded step toward the explicit ${plan.targets.targetLambda != null ? `${plan.targets.targetLambda} lambda` : `${plan.targets.targetAfr} AFR`} target.`, 'high', { finalTarget: round(target, 5), stageLimitPercent: 5 });
  }).filter(item => Math.abs(item.delta) > 1e-6);
  return { items, blockers: items.length ? [] : ['The mapped power-fueling cells already match the requested target within the beta.14 stage limit.'] };
}

function identifySparkAxes(table) {
  const rows = numericLabels(table.rowHeaders), columns = numericLabels(table.colHeaders);
  const rowMax = rows.length ? Math.max(...rows.map(item => item.value)) : null;
  const colMax = columns.length ? Math.max(...columns.map(item => item.value)) : null;
  if (rowMax != null && rowMax > 1000) return { rpmAxis: 'row', loadAxis: 'column' };
  if (colMax != null && colMax > 1000) return { rpmAxis: 'column', loadAxis: 'row' };
  return { rpmAxis: 'row', loadAxis: 'column' };
}
function buildSparkProposal(plan, workspace, csvPath) {
  const coverage = buildCoverageMap(workspace), match = selectPrimaryTable(workspace, coverage, 'high-spark');
  if (!match) return { items: [], blockers: ['No exact high-octane spark table is mapped.'] };
  const source = csvPath || plan.targets.selectedLog;
  if (!source || !fs.existsSync(source)) return { items: [], blockers: ['Select a log containing RPM, load, and knock-retard data.'] };
  const rows = parseLog(source).filter(row => finite(row.rpm) > 700 && finite(row.knockRetard) >= 1.5);
  if (rows.length < 4) return { items: [], blockers: ['The selected log does not contain enough repeatable knock evidence for an automatic spark-reduction proposal.'] };
  const [tableKey, table] = match, axes = identifySparkAxes(table), groups = new Map();
  for (const sample of rows) {
    const load = finite(sample.load) ?? finite(sample.map) ?? finite(sample.maf);
    if (load == null) continue;
    const rpmMatch = nearestLabel(axes.rpmAxis === 'row' ? table.rowHeaders : table.colHeaders, finite(sample.rpm));
    const loadMatch = nearestLabel(axes.loadAxis === 'row' ? table.rowHeaders : table.colHeaders, load);
    if (!rpmMatch || !loadMatch) continue;
    const row = axes.rpmAxis === 'row' ? rpmMatch.index : loadMatch.index;
    const column = axes.rpmAxis === 'column' ? rpmMatch.index : loadMatch.index;
    const key = `${row}:${column}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(sample);
  }
  const items = [];
  for (const [key, samples] of groups.entries()) {
    if (samples.length < 4) continue;
    const [row, column] = key.split(':').map(Number), current = finite(table.values?.[row]?.[column]);
    if (current == null) continue;
    const knock = median(samples.map(sample => sample.knockRetard));
    const reduction = clamp(knock, 1, 4);
    const cell = { row, column, value: current, rowLabel: table.rowHeaders?.[row] ?? String(row), columnLabel: table.colHeaders?.[column] ?? String(column) };
    items.push(proposalItem('spark-knock-reduction', 'high-spark', tableKey, table, cell, current - reduction, `Reduce timing because median knock retard was ${round(knock, 1)}° across ${samples.length} mapped samples. Beta.13 never automatically adds spark.`, 'high', { samples: samples.length, medianKnock: round(knock, 2), maximumReduction: 4 }));
  }
  return { items, blockers: items.length ? [] : ['Knock events could not be mapped to a repeatable exact spark cell.'], sourceLog: source };
}

function buildTransmissionProposal(plan, workspace) {
  const coverage = buildCoverageMap(workspace), match = selectPrimaryTable(workspace, coverage, 'shift-rpm');
  if (!match) return { items: [], blockers: ['No exact WOT shift-RPM table is mapped.'] };
  if (plan.targets.shiftRpm == null) return { items: [], blockers: ['Enter an explicit WOT shift RPM.'] };
  const [tableKey, table] = match;
  const ceiling = plan.targets.revLimit != null ? plan.targets.revLimit - 200 : plan.targets.shiftRpm;
  const target = Math.min(plan.targets.shiftRpm, ceiling);
  const cells = targetCells(table, cell => /wot|performance|sport|normal|1-2|2-3|3-4/i.test(`${cell.rowLabel} ${cell.columnLabel}`), 12);
  const items = cells.map(cell => {
    const boundedTarget = clamp(target, cell.value - ENVELOPES['shift-rpm'].maxAbs, cell.value + ENVELOPES['shift-rpm'].maxAbs);
    return proposalItem('wot-shift-rpm', 'shift-rpm', tableKey, table, cell, boundedTarget, `Move the mapped WOT shift cell toward ${target} RPM while limiting this autonomous stage to ${ENVELOPES['shift-rpm'].maxAbs} RPM per cell and maintaining at least 200 RPM below the requested rev limit when available.`, 'high', { requestedTarget: target, stageBoundedTarget: boundedTarget });
  }).filter(item => Math.abs(item.delta) > 1e-6);
  return { items, blockers: items.length ? [] : ['No WOT shift cells could be isolated.'] };
}

function buildStageProposal({ plan, stageId, workspace, activeProject, csvPath = null }) {
  assertPlan(plan, activeProject, workspace);
  const stage = plan.stages.find(item => item.id === String(stageId));
  if (!stage) throw new Error('The requested Tune Engine stage does not exist.');
  if (!stage.proposalSupported) throw new Error(`${stage.title} does not generate calibration cells.`);
  if (stage.status === 'blocked') throw new Error(`${stage.title} is blocked: ${(stage.blockers || []).join(' ')}`);
  let result;
  if (stage.id === 'drivability') result = buildDrivabilityProposal(plan, workspace);
  else if (stage.id === 'airflow') result = buildAirflowProposal(plan, workspace, activeProject, csvPath);
  else if (stage.id === 'fueling') result = buildFuelingProposal(plan, workspace);
  else if (stage.id === 'spark') result = buildSparkProposal(plan, workspace, csvPath);
  else if (stage.id === 'transmission') result = buildTransmissionProposal(plan, workspace);
  else throw new Error(`Automatic proposal generation is not available for ${stage.title}.`);
  const blocked = Boolean(result.blockers?.length || !result.items?.length);
  return {
    schemaVersion: TUNE_ENGINE_SCHEMA_VERSION,
    id: id(`stage-${stage.id}`),
    kind: 'tune-engine-stage-proposal',
    planId: plan.id,
    projectId: activeProject.id,
    binding: clone(workspace.binding),
    stageId: stage.id,
    stageTitle: stage.title,
    generatedAt: now(),
    sourceLog: result.sourceLog || csvPath || plan.targets.selectedLog || null,
    blocked,
    blockers: result.blockers || [],
    warnings: stage.warnings || [],
    evidence: result.evidence || null,
    safetyFindings: result.safetyFindings || [],
    proposals: result.items || [],
    summary: { proposedCells: result.items?.length || 0, approvalRequired: true, automaticFlash: false, risk: stage.highRisk ? 'high' : 'moderate' }
  };
}

const ENVELOPES = {
  'desired-idle': { maxAbs: 150 },
  'fan-temperature': { maxAbs: 20 },
  'rev-limit': { maxAbs: 500 },
  'speed-limit': { maxAbs: 80 },
  maf: { maxPercent: 8 },
  ve: { maxPercent: 8 },
  'idle-airflow': { maxPercent: 12, maxAbs: 1.5 },
  'power-enrichment': { maxPercent: 5 },
  'high-spark': { maxAbs: 4, decreaseOnly: true },
  'shift-rpm': { maxAbs: 300 }
};
function enforceEnvelope(item, table) {
  const current = finite(item.current), proposed = finite(item.proposed), envelope = ENVELOPES[item.role];
  if (current == null || proposed == null) throw new Error(`${item.tableName} contains an invalid proposal value.`);
  if (!envelope) throw new Error(`${item.role} is not enabled for automatic Tune Engine application.`);
  const delta = proposed - current;
  const percent = current ? Math.abs(delta / current * 100) : null;
  if (envelope.decreaseOnly && delta > 1e-9) throw new Error(`${item.tableName} attempted an automatic spark increase, which is prohibited.`);
  if (envelope.maxAbs != null && Math.abs(delta) > envelope.maxAbs + 1e-6) throw new Error(`${item.tableName} exceeds the ${envelope.maxAbs} ${item.role} stage limit.`);
  if (envelope.maxPercent != null && percent != null && percent > envelope.maxPercent + 0.01) throw new Error(`${item.tableName} exceeds the ${envelope.maxPercent}% ${item.role} stage limit.`);
  if (table.min != null && proposed < Number(table.min) - 1e-9) throw new Error(`${item.tableName} would fall below the XDF minimum.`);
  if (table.max != null && proposed > Number(table.max) + 1e-9) throw new Error(`${item.tableName} would exceed the XDF maximum.`);
}

function applyStageProposal(workspace, proposal, approvedIds = []) {
  if (!workspace || workspace.mode !== 'xdf') throw new Error('Load an XDF calibration workspace first.');
  if (!proposal || proposal.kind !== 'tune-engine-stage-proposal' || String(proposal.projectId) !== String(workspace.projectId)) throw new Error('The Tune Engine proposal does not match this workspace.');
  if (!sameBinding(proposal.binding, workspace.binding)) throw new Error('The BIN/XDF fingerprint changed after this stage proposal was generated.');
  if (proposal.blocked) throw new Error(`This stage proposal is blocked: ${(proposal.blockers || []).join(' ')}`);
  const approved = new Set((approvedIds || []).map(String));
  if (!approved.size) throw new Error('Approve at least one Tune Engine cell.');
  const applied = [];
  for (const item of proposal.proposals || []) {
    if (!approved.has(String(item.id))) continue;
    const table = workspace.tables?.[item.tableKey];
    if (!table?.values?.[item.row]) throw new Error(`${item.tableName} is no longer present in the workspace.`);
    const current = finite(table.values[item.row][item.col]);
    if (current == null || Math.abs(current - Number(item.current)) > 1e-5) throw new Error(`${item.tableName} changed after the stage proposal was generated. Build a fresh proposal.`);
    enforceEnvelope(item, table);
    table.values[item.row][item.col] = Number(item.proposed);
    workspace.modified = workspace.modified && typeof workspace.modified === 'object' ? workspace.modified : {};
    workspace.modified[`${item.tableKey}:${item.row}:${item.col}`] = true;
    applied.push({ ...item, appliedAt: now() });
  }
  if (!applied.length) throw new Error('None of the approved Tune Engine cells were applied.');
  workspace.updatedAt = now();
  workspace.tuneEngineApplied = { proposalId: proposal.id, planId: proposal.planId, stageId: proposal.stageId, applied, at: workspace.updatedAt };
  return { workspace, applied };
}

class TuneEngineManager {
  constructor(options = {}) { this.appendActivity = options.appendActivity || (() => {}); }
  root(active) { return ensureDir(path.join(active.folder, 'AI', 'TuneEngine')); }
  planFile(active) { return path.join(this.root(active), 'plan.json'); }
  auditFile(active) { return path.join(this.root(active), 'audit.json'); }
  proposalsRoot(active) { return ensureDir(path.join(this.root(active), 'Proposals')); }
  handoffRoot(active) { return ensureDir(path.join(active.folder, 'Handoff')); }
  loadPlan(active) { const plan = readJson(this.planFile(active), null); return plan?.projectId === active.id ? plan : null; }
  savePlan(active, plan) { atomicWriteJson(this.planFile(active), plan); return plan; }
  createPlan(active, intake, workspace, targets) {
    const plan = buildTunePlan({ activeProject: active, intake, workspace, targets, selectedLog: targets?.selectedLog });
    this.savePlan(active, plan);
    this.audit(active, 'plan-created', { planId: plan.id, readiness: plan.readiness.score, profile: plan.profile, nextStageId: plan.nextStageId });
    this.appendActivity('tune-engine-plan-created', { projectId: active.id, planId: plan.id, readiness: plan.readiness.score, profile: plan.profile });
    return plan;
  }
  saveProposal(active, proposal) {
    const file = path.join(this.proposalsRoot(active), `${proposal.id}.json`);
    atomicWriteJson(file, proposal);
    this.audit(active, 'stage-proposal-created', { proposalId: proposal.id, planId: proposal.planId, stageId: proposal.stageId, proposedCells: proposal.summary.proposedCells, blocked: proposal.blocked });
    return { ...proposal, file };
  }
  listProposals(active) {
    return fs.readdirSync(this.proposalsRoot(active)).filter(name => name.endsWith('.json')).map(name => {
      const file = path.join(this.proposalsRoot(active), name), proposal = readJson(file, null);
      return proposal ? { ...proposal, file } : null;
    }).filter(Boolean).sort((left, right) => String(right.generatedAt).localeCompare(String(left.generatedAt))).slice(0, MAX_PROPOSALS);
  }
  getProposal(active, proposalId) { return this.listProposals(active).find(item => item.id === String(proposalId)) || null; }
  audit(active, type, details = {}) {
    const existing = readJson(this.auditFile(active), []);
    const items = Array.isArray(existing) ? existing : [];
    items.unshift({ id: id('audit'), type, details, at: now() });
    atomicWriteJson(this.auditFile(active), items.slice(0, MAX_AUDIT));
  }
  recordApplied(active, plan, proposal, applied, revision = null) {
    const at = now();
    const stage = plan.stages.find(item => item.id === proposal.stageId);
    if (stage) { stage.status = 'complete'; stage.completedAt = at; stage.appliedCells = applied.length; stage.revision = revision ? { name: revision.name, path: revision.path, sha256: revision.sha256 } : null; }
    plan.appliedStages = [...(plan.appliedStages || []), { stageId: proposal.stageId, proposalId: proposal.id, appliedCells: applied.length, at, revision: revision ? { name: revision.name, path: revision.path, sha256: revision.sha256 } : null }];
    plan.updatedAt = at;
    const next = plan.stages.find(item => item.status === 'ready') || plan.stages.find(item => item.status === 'blocked');
    plan.nextStageId = next?.id || 'validation';
    this.savePlan(active, plan);
    this.audit(active, 'stage-applied', { stageId: proposal.stageId, proposalId: proposal.id, appliedCells: applied.length, revision: revision?.name || null });
    this.appendActivity('tune-engine-stage-applied', { projectId: active.id, planId: plan.id, stageId: proposal.stageId, appliedCells: applied.length, revision: revision?.name || null });
    return plan;
  }
  status(active, workspace = null) {
    if (!active) return { active: false, plan: null, proposals: [], audit: [] };
    const plan = this.loadPlan(active);
    const audit = readJson(this.auditFile(active), []);
    let stale = false, staleReason = null;
    if (plan && workspace) {
      try { assertPlan(plan, active, workspace); } catch (error) { stale = true; staleReason = error.message; }
    }
    return { active: true, plan, proposals: this.listProposals(active), audit: Array.isArray(audit) ? audit.slice(0, 100) : [], stale, staleReason };
  }
  createHandoff(active, plan, workspace, revision = null) {
    assertPlan(plan, active, workspace);
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const folder = ensureDir(path.join(this.handoffRoot(active), `${stamp}-${safeName(plan.profile, 'tune')}`));
    const revisionInfo = revision && revision.path && fs.existsSync(revision.path) ? {
      name: path.basename(revision.path), sha256: sha256File(revision.path), size: fs.statSync(revision.path).size
    } : null;
    if (revisionInfo) fs.copyFileSync(revision.path, path.join(folder, revisionInfo.name));
    const payload = {
      schemaVersion: TUNE_ENGINE_SCHEMA_VERSION, createdAt: now(), appFeature: 'TunIQ Unified Tune Engine',
      project: { id: active.id, name: active.name, vehicleId: active.vehicleId || null, controller: active.controller || '', os: active.os || '' },
      binding: clone(workspace.binding), plan: clone(plan), revision: revisionInfo,
      modifiedCells: Object.keys(workspace.modified || {}).length,
      warnings: ['This bundle does not authorize a controller write. Validate the revision and use Flash Center with explicit confirmation.']
    };
    atomicWriteJson(path.join(folder, 'handoff.json'), payload);
    const markdown = [
      '# TunIQ Tune Engine Handoff', '', `- Project: ${active.name}`, `- Controller / OS: ${active.controller || 'Unknown'} / ${active.os || 'Unknown'}`,
      `- Tune profile: ${plan.profile}`, `- Readiness: ${plan.readiness.score}% (${plan.readiness.label})`, `- Modified cells: ${payload.modifiedCells}`,
      `- Revision: ${revisionInfo?.name || 'No revision copied'}`, '', '## Applied stages',
      ...(plan.appliedStages?.length ? plan.appliedStages.map(item => `- ${item.stageId}: ${item.appliedCells} cells${item.revision?.name ? ` → ${item.revision.name}` : ''}`) : ['- None']),
      '', '## Safety boundary', '- Revalidate checksums, layout, controller/OS, voltage, backup, and recovery before any write.', '- This bundle never bypasses Flash Center confirmation.'
    ].join('\n');
    fs.writeFileSync(path.join(folder, 'CHANGE_SUMMARY.md'), markdown, 'utf8');
    this.audit(active, 'handoff-created', { folder, revision: revisionInfo?.name || null, modifiedCells: payload.modifiedCells });
    this.appendActivity('tune-engine-handoff-created', { projectId: active.id, folder, revision: revisionInfo?.name || null });
    return { folder, manifest: path.join(folder, 'handoff.json'), summary: path.join(folder, 'CHANGE_SUMMARY.md'), revision: revisionInfo };
  }
  reset(active) {
    const root = this.root(active), stamp = new Date().toISOString().replace(/[:.]/g, '-');
    if (fs.existsSync(root)) {
      const archive = `${root}-Archived-${stamp}`;
      fs.renameSync(root, archive);
      this.appendActivity('tune-engine-reset', { projectId: active.id, archive });
      return { reset: true, archive };
    }
    return { reset: false, archive: null };
  }
}

module.exports = {
  TuneEngineManager,
  TUNE_ENGINE_SCHEMA_VERSION,
  ROLE_DEFINITIONS,
  ENVELOPES,
  buildCoverageMap,
  normalizeTargets,
  analyzeLogHealth,
  buildTunePlan,
  buildStageProposal,
  applyStageProposal,
  assertPlan
};
