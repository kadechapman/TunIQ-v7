const UI_PREFERENCE_DEFAULTS = Object.freeze({
  sidebarCollapsed: false,
  tunePathCollapsed: false,
  compactDensity: false,
  reduceMotion: false,
  restoreLastPage: true,
  lastPage: 'dashboard',
  recentPages: ['dashboard'],
  scrollPositions: {}
});

const BOOLEAN_KEYS = ['sidebarCollapsed','tunePathCollapsed','compactDensity','reduceMotion','restoreLastPage'];
const PAGE_RE = /^[a-z][a-z0-9-]{0,39}$/;

function cleanPage(value, fallback = 'dashboard') {
  const page = String(value || '').trim().toLowerCase();
  return PAGE_RE.test(page) ? page : fallback;
}

function cleanRecentPages(value, lastPage = 'dashboard') {
  const source = Array.isArray(value) ? value : [];
  const unique = [];
  for (const item of [lastPage, ...source]) {
    const page = cleanPage(item, '');
    if (page && !unique.includes(page)) unique.push(page);
    if (unique.length >= 8) break;
  }
  return unique.length ? unique : ['dashboard'];
}

function cleanScrollPositions(value) {
  const result = {};
  if (!value || typeof value !== 'object' || Array.isArray(value)) return result;
  for (const [rawPage, rawPosition] of Object.entries(value)) {
    const page = cleanPage(rawPage, '');
    const position = Math.max(0, Math.min(1000000, Math.round(Number(rawPosition) || 0)));
    if (page) result[page] = position;
  }
  return result;
}

function normalizeUiPreferences(value = {}) {
  const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const result = { ...UI_PREFERENCE_DEFAULTS };
  for (const key of BOOLEAN_KEYS) result[key] = typeof source[key] === 'boolean' ? source[key] : UI_PREFERENCE_DEFAULTS[key];
  result.lastPage = cleanPage(source.lastPage, UI_PREFERENCE_DEFAULTS.lastPage);
  result.recentPages = cleanRecentPages(source.recentPages, result.lastPage);
  result.scrollPositions = cleanScrollPositions(source.scrollPositions);
  return result;
}

function mergeUiPreferences(settings = {}, patch = {}) {
  const previous = normalizeUiPreferences(settings.uiPreferences);
  const next = normalizeUiPreferences({ ...previous, ...(patch && typeof patch === 'object' ? patch : {}) });
  return { ...settings, uiPreferences: next, updatedAt: new Date().toISOString() };
}

function tokenize(value) {
  return String(value || '').toLowerCase().trim().split(/\s+/).filter(Boolean);
}

function rankQuickActions(actions, query, limit = 12) {
  const terms = tokenize(query);
  return (Array.isArray(actions) ? actions : [])
    .map((action, index) => {
      const haystack = [action.title, action.subtitle, action.keywords, action.group].filter(Boolean).join(' ').toLowerCase();
      let score = Number(action.priority || 0);
      if (!terms.length) score += Math.max(0, 100 - index);
      for (const term of terms) {
        if (!haystack.includes(term)) return null;
        if (String(action.title || '').toLowerCase().startsWith(term)) score += 120;
        else if (String(action.title || '').toLowerCase().includes(term)) score += 70;
        else score += 30;
      }
      return { ...action, _score: score, _index: index };
    })
    .filter(Boolean)
    .sort((a, b) => b._score - a._score || a._index - b._index)
    .slice(0, Math.max(1, Math.min(50, Number(limit) || 12)))
    .map(({ _score, _index, ...action }) => action);
}

module.exports = { UI_PREFERENCE_DEFAULTS, normalizeUiPreferences, mergeUiPreferences, rankQuickActions, cleanPage };
