const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const WORKSPACE_SCHEMA_VERSION = 2;
const MAX_HISTORY = 100;
const MAX_COMPARE_DETAILS = 500;

function clone(value) { return JSON.parse(JSON.stringify(value)); }
function fileSha256(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function safeReadJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function atomicWriteJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const temp = `${file}.tmp-${process.pid}-${Date.now()}`;
  fs.writeFileSync(temp, JSON.stringify(value, null, 2), 'utf8');
  try { fs.renameSync(temp, file); }
  catch (error) {
    if (!['EEXIST','EPERM','EACCES'].includes(error?.code)) { try { fs.unlinkSync(temp); } catch {} throw error; }
    try { fs.unlinkSync(file); } catch {}
    fs.renameSync(temp, file);
  }
}
function sanitizeName(value, fallback = 'snapshot') {
  const name = String(value || fallback).trim().replace(/[<>:"/\\|?*\x00-\x1F]+/g, '-').replace(/\s+/g, ' ').slice(0, 80);
  return name || fallback;
}
function bindingFor(active) {
  return {
    projectId: active?.id || '',
    binPath: active?.bin || null,
    binSha256: active?.bin && fs.existsSync(active.bin) ? (active.binInfo?.sha256 || fileSha256(active.bin)) : null,
    binSize: active?.bin && fs.existsSync(active.bin) ? fs.statSync(active.bin).size : null,
    xdfPath: active?.xdf || null,
    xdfSha256: active?.xdf && fs.existsSync(active.xdf) ? fileSha256(active.xdf) : null,
    xdfName: active?.xdf ? path.basename(active.xdf) : null,
    controller: active?.controller || '',
    os: active?.os || ''
  };
}
function sameBinding(left, right) {
  if (!left || !right) return false;
  return String(left.projectId || '') === String(right.projectId || '')
    && String(left.binSha256 || '') === String(right.binSha256 || '')
    && String(left.xdfSha256 || '') === String(right.xdfSha256 || '');
}
function modifiedCount(workspace) { return Object.keys(workspace?.modified && typeof workspace.modified === 'object' ? workspace.modified : {}).length; }
function tableCount(workspace) { return Object.keys(workspace?.tables && typeof workspace.tables === 'object' ? workspace.tables : {}).length; }

class TuneWorkspaceManager {
  constructor(options = {}) {
    this.legacyWorkspaceFile = options.legacyWorkspaceFile || (() => null);
    this.legacyHistoryFile = options.legacyHistoryFile || (() => null);
    this.appendActivity = options.appendActivity || (() => {});
  }
  root(active) {
    if (!active?.id || !active?.folder) throw new Error('Create or activate a project first.');
    const folder = path.join(active.folder, 'Workspace');
    fs.mkdirSync(folder, { recursive: true });
    return folder;
  }
  workspaceFile(active) { return path.join(this.root(active), 'calibration-workspace.json'); }
  backupFile(active) { return path.join(this.root(active), 'calibration-workspace.backup.json'); }
  recoveryRoot(active) { const folder = path.join(this.root(active), 'Recovery'); fs.mkdirSync(folder, { recursive: true }); return folder; }
  snapshotsRoot(active) { const folder = path.join(this.root(active), 'Snapshots'); fs.mkdirSync(folder, { recursive: true }); return folder; }
  historyFile(active) { return path.join(this.root(active), 'history.json'); }
  binding(active) { return bindingFor(active); }
  bind(workspace, active) {
    const now = new Date().toISOString();
    return {
      ...workspace,
      schemaVersion: WORKSPACE_SCHEMA_VERSION,
      projectId: active.id,
      binding: this.binding(active),
      updatedAt: now
    };
  }
  assertBinding(workspace, active, options = {}) {
    if (!workspace || typeof workspace !== 'object') throw new Error('Calibration workspace is missing.');
    if (String(workspace.projectId || '') !== String(active.id || '')) {
      const error = new Error('This calibration workspace belongs to a different project. Reload the active BIN and XDF.');
      error.code = 'workspace-project-mismatch'; throw error;
    }
    if (workspace.mode === 'xdf' && !sameBinding(workspace.binding || {
      projectId: workspace.projectId, binSha256: workspace.sourceBinSha256, xdfSha256: workspace.sourceXdfSha256
    }, this.binding(active))) {
      const error = new Error('The active BIN/XDF fingerprint changed after this workspace was created. Reload the mapping before editing or exporting.');
      error.code = 'workspace-binding-mismatch'; throw error;
    }
    if (options.requireXdf && workspace.mode !== 'xdf') throw new Error('Load the active BIN and XDF mapping first.');
    return true;
  }
  migrateLegacy(active, validate) {
    const target = this.workspaceFile(active);
    if (fs.existsSync(target)) return null;
    const legacy = this.legacyWorkspaceFile();
    const legacyWorkspace = legacy && fs.existsSync(legacy) ? safeReadJson(legacy, null) : null;
    if (legacyWorkspace && String(legacyWorkspace.projectId || '') === String(active.id)) {
      const migrated = this.bind(legacyWorkspace, active);
      validate(migrated); atomicWriteJson(target, migrated);
      const legacyHistory = this.legacyHistoryFile();
      const items = legacyHistory && fs.existsSync(legacyHistory) ? safeReadJson(legacyHistory, []) : [];
      if (Array.isArray(items) && items.length) {
        for (const item of items.slice().reverse().slice(0, MAX_HISTORY)) {
          if (!item?.workspace || String(item.workspace.projectId || active.id) !== String(active.id)) continue;
          try { this.createSnapshot(active, this.bind(item.workspace, active), { name: item.name, note: item.note, at: item.at, migrated: true }, validate); } catch {}
        }
      }
      this.appendActivity('workspace-migrated', { projectId: active.id, from: legacy });
      return migrated;
    }
    return null;
  }
  load(active, defaultFactory, validate) {
    this.migrateLegacy(active, validate);
    const file = this.workspaceFile(active), backup = this.backupFile(active);
    let workspace = safeReadJson(file, null), recovered = false;
    try {
      if (workspace) {
        validate(workspace);
        if (workspace.mode === 'xdf') this.assertBinding(workspace, active);
      }
    } catch (error) {
      if (workspace && error?.code === 'workspace-binding-mismatch') this.invalidate(active, error.message);
      workspace = null;
    }
    if (!workspace) {
      const candidate = safeReadJson(backup, null);
      try {
        if (candidate) {
          validate(candidate);
          if (candidate.mode === 'xdf') this.assertBinding(candidate, active);
          workspace = candidate; recovered = true;
        }
      } catch (error) {
        if (candidate && error?.code === 'workspace-binding-mismatch') this.invalidate(active, error.message);
        workspace = null;
      }
    }
    if (!workspace) workspace = this.bind(defaultFactory(active), active);
    else workspace = { ...workspace, schemaVersion: WORKSPACE_SCHEMA_VERSION, projectId: active.id };
    validate(workspace);
    if (recovered) {
      workspace.recovery = { restoredFromBackupAt: new Date().toISOString() };
      this.appendActivity('workspace-recovered', { projectId: active.id, source: backup });
    }
    atomicWriteJson(file, workspace);
    return workspace;
  }
  save(active, workspace, validate) {
    if (workspace?.mode === 'xdf') this.assertBinding(workspace, active);
    const bound = this.bind(workspace, active);
    validate(bound);
    const file = this.workspaceFile(active), backup = this.backupFile(active);
    if (fs.existsSync(file)) fs.copyFileSync(file, backup);
    atomicWriteJson(file, bound);
    return bound;
  }
  invalidate(active, reason = 'Project file fingerprints changed.') {
    const file = this.workspaceFile(active), backup = this.backupFile(active);
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const archived = [];
    for (const source of [file, backup]) {
      if (!fs.existsSync(source)) continue;
      const destination = path.join(this.recoveryRoot(active), `${path.basename(source, '.json')}-${stamp}.json`);
      fs.renameSync(source, destination); archived.push(destination);
    }
    atomicWriteJson(path.join(this.recoveryRoot(active), `invalidated-${stamp}.json`), { at: new Date().toISOString(), projectId: active.id, reason, archived });
    this.appendActivity('workspace-invalidated', { projectId: active.id, reason, archived: archived.map(item => path.basename(item)) });
    return { invalidated: archived.length > 0, archived };
  }
  history(active) {
    const items = safeReadJson(this.historyFile(active), []);
    return Array.isArray(items) ? items.filter(item => item && item.id && item.snapshotFile && fs.existsSync(item.snapshotFile)) : [];
  }
  createSnapshot(active, workspace, payload = {}, validate) {
    if (workspace?.mode === 'xdf') this.assertBinding(workspace, active);
    const bound = this.bind(workspace, active); validate(bound);
    const at = payload.at || new Date().toISOString();
    const id = `${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const name = sanitizeName(payload.name, `Revision ${this.history(active).length + 1}`);
    const snapshotFile = path.join(this.snapshotsRoot(active), `${id}-${sanitizeName(name).replace(/\s+/g, '-')}.json`);
    const snapshot = { id, name, note: String(payload.note || '').slice(0, 2000), at, projectId: active.id, binding: this.binding(active), workspace: bound, migrated: Boolean(payload.migrated) };
    atomicWriteJson(snapshotFile, snapshot);
    const item = { id, name, note: snapshot.note, at, projectId: active.id, binding: snapshot.binding, modifiedCells: modifiedCount(bound), tableCount: tableCount(bound), activeTable: bound.activeTable || '', snapshotFile };
    const history = [item, ...this.history(active).filter(existing => existing.id !== id)];
    for (const old of history.slice(MAX_HISTORY)) { try { fs.unlinkSync(old.snapshotFile); } catch {} }
    atomicWriteJson(this.historyFile(active), history.slice(0, MAX_HISTORY));
    this.appendActivity('calibration-revision', { id, name, projectId: active.id, modifiedCells: item.modifiedCells });
    return item;
  }
  snapshot(active, id) {
    const item = this.history(active).find(entry => entry.id === String(id));
    if (!item) throw new Error('The selected calibration snapshot no longer exists.');
    const snapshot = safeReadJson(item.snapshotFile, null);
    if (!snapshot?.workspace) throw new Error('The selected calibration snapshot is unreadable.');
    return snapshot;
  }
  compare(active, currentWorkspace, id) {
    this.assertBinding(currentWorkspace, active);
    const snapshot = this.snapshot(active, id);
    const before = snapshot.workspace, after = currentWorkspace;
    const details = [];
    let changedCells = 0, addedTables = 0, removedTables = 0;
    const keys = new Set([...Object.keys(before.tables || {}), ...Object.keys(after.tables || {})]);
    for (const key of keys) {
      const a = before.tables?.[key], b = after.tables?.[key];
      if (!a) { addedTables += 1; continue; }
      if (!b) { removedTables += 1; continue; }
      const rows = Math.max(a.values?.length || 0, b.values?.length || 0);
      for (let r = 0; r < rows; r += 1) {
        const cols = Math.max(a.values?.[r]?.length || 0, b.values?.[r]?.length || 0);
        for (let c = 0; c < cols; c += 1) {
          const from = a.values?.[r]?.[c], to = b.values?.[r]?.[c];
          if (Number(from) === Number(to)) continue;
          changedCells += 1;
          if (details.length < MAX_COMPARE_DETAILS) details.push({ tableKey: key, table: b.name || a.name || key, row: r, column: c, rowLabel: b.rowHeaders?.[r] ?? a.rowHeaders?.[r] ?? String(r), columnLabel: b.colHeaders?.[c] ?? a.colHeaders?.[c] ?? String(c), from, to, delta: Number.isFinite(Number(from)) && Number.isFinite(Number(to)) ? Number(to) - Number(from) : null });
        }
      }
    }
    return { snapshot: this.history(active).find(item => item.id === String(id)), changedCells, addedTables, removedTables, details, truncated: changedCells > details.length };
  }
  restore(active, id, validate) {
    const snapshot = this.snapshot(active, id);
    if (!sameBinding(snapshot.binding, this.binding(active))) {
      const error = new Error('This snapshot was created from a different BIN/XDF fingerprint and cannot be restored into the current mapping.');
      error.code = 'snapshot-binding-mismatch'; throw error;
    }
    const restored = this.bind(clone(snapshot.workspace), active);
    restored.restoredFrom = { id: snapshot.id, name: snapshot.name, at: new Date().toISOString() };
    const saved = this.save(active, restored, validate);
    this.appendActivity('calibration-snapshot-restored', { projectId: active.id, snapshotId: snapshot.id, name: snapshot.name });
    return saved;
  }
}

module.exports = { TuneWorkspaceManager, WORKSPACE_SCHEMA_VERSION, bindingFor, sameBinding, atomicWriteJson };
