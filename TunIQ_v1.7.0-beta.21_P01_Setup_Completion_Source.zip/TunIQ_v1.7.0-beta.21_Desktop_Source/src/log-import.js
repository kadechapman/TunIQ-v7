const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const CANONICAL_COLUMNS = [
  'timestamp','rpm','speed','ect','iat','tps','map','maf','stft1','stft2','ltft1','ltft2','spark','voltage','load','fuelPressure',
  'knockRetard','commandedEqRatio','commandedAfr','widebandAfr','widebandVoltage','fuelingMode','closedLoop','o2B1S1','o2B2S1',
  'injectorPulseWidth','misfireTotal','mafFrequency','injectorDuty','desiredIdle','iacPosition','idleAirflow','parkNeutral','acRequest',
  'commandedGear','actualGear','inputShaftSpeed','outputShaftSpeed','transSlip','shiftTime','tccSlip','torqueManagement','engineTorque','marker'
];

const PRIVATE_HEADER_PATTERNS = [
  /\bvin\b/i,/vehicle\s*identification/i,/latitude/i,/longitude/i,/\bgps\b/i,/geo(?:graphical)?\s*location/i,
  /street\s*address/i,/email/i,/device\s*(?:id|identifier)/i,/bluetooth/i,/adapter\s*serial/i,/serial\s*number/i,
  /phone\s*name/i,/computer\s*name/i,/user\s*name/i,/file\s*path/i
];

const FIELD_ALIASES = {
  timestamp: [/^time$/i,/clock\s*time/i,/time.*stamp/i,/elapsed.*time/i,/seconds.*start/i,/date.*time/i,/frame.*time/i,/^date$/i],
  rpm: [/engine.*rpm/i,/engine.*speed/i,/^rpm(?:\s*\(.*\))?$/i],
  speed: [/vehicle.*speed/i,/road.*speed/i,/speed.*mph/i,/speed.*km/i,/^kph$/i,/^mph$/i],
  ect: [/coolant/i,/engine.*temp/i,/^ect$/i],
  iat: [/intake.*air.*temp/i,/^iat$/i],
  tps: [/throttle.*position/i,/absolute.*throttle/i,/^tps$/i,/throttle.*angle/i],
  map: [/manifold.*absolute.*pressure/i,/intake.*manifold.*pressure/i,/^map$/i],
  maf: [/mass.*air.*flow(?!.*freq)/i,/air.*flow.*rate/i,/^maf(?:\s*\(.*\))?$/i],
  mafFrequency: [/maf.*freq/i,/mass.*air.*flow.*freq/i],
  stft2: [/short.*term.*fuel.*trim.*(?:bank|b)\s*2/i,/^stft\s*(?:bank|b)?\s*2/i,/stft.*b2/i],
  ltft2: [/long.*term.*fuel.*trim.*(?:bank|b)\s*2/i,/^ltft\s*(?:bank|b)?\s*2/i,/ltft.*b2/i],
  stft1: [/short.*term.*fuel.*trim.*(?:bank|b)?\s*1/i,/^stft\s*(?:bank|b)?\s*1/i,/stft.*b1/i,/^short.*fuel.*trim$/i],
  ltft1: [/long.*term.*fuel.*trim.*(?:bank|b)?\s*1/i,/^ltft\s*(?:bank|b)?\s*1/i,/ltft.*b1/i,/^long.*fuel.*trim$/i],
  spark: [/spark.*advance/i,/ignition.*advance/i,/timing.*advance/i,/final.*spark/i],
  voltage: [/control.*module.*voltage/i,/battery.*voltage/i,/system.*voltage/i,/adapter.*voltage/i,/ignition.*voltage/i,/^voltage$/i],
  load: [/calculated.*load/i,/engine.*load/i,/absolute.*load/i,/cylinder.*air/i],
  fuelPressure: [/fuel.*rail.*pressure/i,/fuel.*pressure/i],
  knockRetard: [/knock.*retard/i,/^kr$/i,/retard.*knock/i],
  commandedEqRatio: [/commanded.*equivalence/i,/commanded.*eq/i,/target.*lambda/i,/commanded.*lambda/i],
  commandedAfr: [/commanded.*afr/i,/target.*afr/i,/desired.*afr/i],
  widebandAfr: [/wideband.*afr/i,/measured.*afr/i,/actual.*afr/i,/air.*fuel.*ratio/i,/wideband(?!.*volt)/i],
  widebandVoltage: [/wideband.*volt/i,/egr.*volt/i,/analog.*volt/i],
  fuelingMode: [/fueling.*mode/i,/fuel.*mode/i,/power.*enrichment.*status/i],
  closedLoop: [/closed.*loop/i,/fuel.*system.*status/i,/loop.*status/i],
  o2B1S1: [/(?:o2|oxygen).*bank\s*1.*sensor\s*1/i,/b1s1.*o2/i,/o2s11/i],
  o2B2S1: [/(?:o2|oxygen).*bank\s*2.*sensor\s*1/i,/b2s1.*o2/i,/o2s21/i],
  injectorPulseWidth: [/injector.*pulse.*width/i,/inj.*pulse/i,/pulse.*width/i],
  misfireTotal: [/misfire.*total/i,/total.*misfire/i,/misfire.*count/i],
  injectorDuty: [/injector.*duty/i,/duty.*cycle/i],
  desiredIdle: [/desired.*idle/i,/target.*idle/i,/commanded.*idle/i],
  iacPosition: [/iac.*position/i,/idle.*air.*control.*position/i,/iac.*counts/i],
  idleAirflow: [/idle.*airflow/i,/base.*running.*airflow/i,/throttle.*cracker.*airflow/i,/throttle.*follower.*airflow/i],
  parkNeutral: [/park.*neutral/i,/p\/?n.*status/i,/trans.*range.*park/i],
  acRequest: [/a\/?c.*request/i,/air.*condition.*request/i,/compressor.*request/i],
  commandedGear: [/commanded.*gear/i,/target.*gear/i],
  actualGear: [/actual.*gear/i,/current.*gear/i,/transmission.*gear/i],
  inputShaftSpeed: [/input.*shaft.*speed/i,/turbine.*speed/i],
  outputShaftSpeed: [/output.*shaft.*speed/i],
  transSlip: [/transmission.*slip/i,/gear.*slip/i],
  shiftTime: [/shift.*time/i],
  tccSlip: [/tcc.*slip/i,/converter.*slip/i],
  torqueManagement: [/torque.*management/i,/torque.*reduction/i],
  engineTorque: [/engine.*torque/i,/delivered.*torque/i,/calculated.*torque/i],
  marker: [/marker/i,/note/i,/event/i]
};

function cleanText(value, max = 200) { return String(value ?? '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max); }
function safeFileName(value) { return cleanText(value, 100).replace(/[<>:"/\\|?*]+/g, '-').replace(/\s+/g, '-').replace(/^-+|-+$/g, '') || 'P01-Log-Import'; }
function csvValue(value) { const text = value == null ? '' : String(value); return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text; }
function sha256(file) { const hash = crypto.createHash('sha256'); hash.update(fs.readFileSync(file)); return hash.digest('hex'); }
function sha256Text(text) { return crypto.createHash('sha256').update(String(text)).digest('hex'); }
function round(value, digits = 3) { return Number.isFinite(value) ? Number(value.toFixed(digits)) : null; }

function splitDelimited(line, delimiter = ',') {
  const output = []; let current = ''; let quote = false;
  for (let index = 0; index < line.length; index += 1) {
    const char = line[index];
    if (quote) {
      if (char === '"' && line[index + 1] === '"') { current += '"'; index += 1; }
      else if (char === '"') quote = false;
      else current += char;
    } else if (char === '"') quote = true;
    else if (char === delimiter) { output.push(current); current = ''; }
    else current += char;
  }
  output.push(current); return output;
}

function detectDelimiter(line) {
  const candidates = [',',';','\t'];
  return candidates.map(delimiter => ({ delimiter, count: splitDelimited(line, delimiter).length })).sort((a,b) => b.count - a.count)[0].delimiter;
}

function headerText(value) { return String(value || '').replace(/^\uFEFF/, '').replace(/[_-]+/g, ' ').replace(/\s+/g, ' ').trim(); }
function compactHeader(value) { return headerText(value).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(); }

function mapHeader(header) {
  const text = compactHeader(header);
  if (!text || PRIVATE_HEADER_PATTERNS.some(pattern => pattern.test(text))) return { key: null, private: true };
  for (const [key, patterns] of Object.entries(FIELD_ALIASES)) if (patterns.some(pattern => pattern.test(text))) return { key, private: false };
  return { key: null, private: false };
}

function numberFrom(raw) {
  if (raw == null || raw === '') return null;
  const text = String(raw).trim().replace(/,/g, '');
  const match = text.match(/-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/);
  return match ? Number(match[0]) : null;
}

function truthValue(raw) {
  const text = compactHeader(raw);
  if (['true','yes','on','closed loop','closed','active','enabled','park','neutral','p n'].includes(text)) return 1;
  if (['false','no','off','open loop','open','inactive','disabled','drive','gear'].includes(text)) return 0;
  return numberFrom(raw);
}

function convertValue(key, raw, header) {
  if (key === 'timestamp' || key === 'marker' || key === 'fuelingMode') return cleanText(raw, 240);
  if (key === 'closedLoop' || key === 'parkNeutral' || key === 'acRequest') return truthValue(raw);
  const value = numberFrom(raw); if (!Number.isFinite(value)) return null;
  const text = compactHeader(header);
  if (key === 'speed' && /(km h|km\/h|kph|kilomet)/i.test(String(header))) return round(value * 0.621371, 3);
  if ((key === 'ect' || key === 'iat') && /(deg c|°c|celsius|degrees c)/i.test(String(header))) return round((value * 9 / 5) + 32, 3);
  if (key === 'widebandAfr' && /lambda/i.test(text) && !/afr/i.test(text)) return round(value * 14.7, 4);
  if (key === 'commandedAfr' && /lambda/i.test(text) && !/afr/i.test(text)) return round(value * 14.7, 4);
  return value;
}

function parseDurationSeconds(raw) {
  const text = String(raw ?? '').trim();
  if (!text) return null;
  if (/^-?\d+(?:\.\d+)?$/.test(text)) return Number(text);
  const match = text.match(/^(?:(\d+)\s+days?\s+)?(\d{1,2}):(\d{2}):(\d{2}(?:\.\d+)?)$/i);
  if (match) return (Number(match[1] || 0) * 86400) + (Number(match[2]) * 3600) + (Number(match[3]) * 60) + Number(match[4]);
  const short = text.match(/^(\d{1,2}):(\d{2}(?:\.\d+)?)$/);
  if (short) return (Number(short[1]) * 60) + Number(short[2]);
  return null;
}

function parseTimeSeconds(raw, index) {
  const duration = parseDurationSeconds(raw); if (Number.isFinite(duration)) return duration;
  const parsed = Date.parse(raw); return Number.isFinite(parsed) ? parsed / 1000 : index;
}

function recommendedFields(profile = 'baseline') {
  const common = ['timestamp','rpm','speed','ect','tps','map','maf','stft1','stft2','ltft1','ltft2','voltage'];
  const sets = {
    baseline: common,
    fuelTrims: [...common,'load','closedLoop'],
    camIdle: [...common,'spark','desiredIdle','idleAirflow','parkNeutral'],
    mafVe: [...common,'mafFrequency','load','commandedEqRatio'],
    power: [...common,'spark','knockRetard','commandedEqRatio','widebandAfr','injectorDuty'],
    transmission: [...common,'commandedGear','actualGear','inputShaftSpeed','outputShaftSpeed','tccSlip']
  };
  return sets[profile] || common;
}

function detectLogSource(headers, text = '') {
  const joined = headers.map(compactHeader).join(' | ');
  const body = String(text || '').slice(0, 16000).toLowerCase();
  const scores = [
    { key: 'pcm-logger', label: 'PCM Logger CSV', score: 0 },
    { key: 'torque', label: 'Torque CSV', score: 0 },
    { key: 'obdlink', label: 'OBDLink CSV', score: 0 },
    { key: 'universal-patcher', label: 'Universal Patcher Logger CSV', score: 0 },
    { key: 'flow-csv', label: 'Flow CSV / generic LS1 export', score: 0 }
  ];
  const by = key => scores.find(item => item.key === key);
  if (/clock time/.test(joined) && /elapsed time/.test(joined)) by('pcm-logger').score += 5;
  if (/fueling mode|query time|ram throttle|logprofile/.test(joined + body)) by('pcm-logger').score += 3;
  if (/latitude|longitude|gps bearing|gps speed|device time/.test(joined)) by('torque').score += 4;
  if (/kff|obd header|egr.*volt|torque pro/.test(joined + body)) by('torque').score += 3;
  if (/obdlink|trip id|enhanced diagnostics|trigger on pid/.test(joined + body)) by('obdlink').score += 5;
  if (/universal patcher|j console|pid 1141|log-\d{4}-\d{2}-\d{2}/.test(joined + body)) by('universal-patcher').score += 5;
  if (/1123|0105c|flow csv/.test(body)) by('flow-csv').score += 2;
  const best = scores.sort((a,b) => b.score - a.score)[0];
  return best.score > 0 ? { format: best.key, label: best.label, confidence: best.score >= 5 ? 'high' : 'medium' } : { format: 'generic-csv', label: 'Generic CSV', confidence: 'limited' };
}

function headerCandidateScore(line) {
  if (!line || line.length > 50000) return -1;
  const delimiter = detectDelimiter(line); const fields = splitDelimited(line, delimiter);
  if (fields.length < 2) return -1;
  const mapped = fields.map(mapHeader).filter(item => item.key).length;
  const alpha = fields.filter(item => /[A-Za-z]/.test(item)).length;
  return (mapped * 10) + alpha + Math.min(fields.length, 20);
}

function findHeaderLineIndex(lines) {
  let best = { index: 0, score: -1 };
  for (let index = 0; index < Math.min(lines.length, 25); index += 1) {
    const score = headerCandidateScore(lines[index]);
    if (score > best.score) best = { index, score };
  }
  return best.index;
}

function normalizedFingerprint(rows, available) {
  const keys = available.filter(key => key !== 'timestamp' && key !== 'marker').slice(0, 16);
  const picks = rows.length <= 20 ? rows : [rows[0], ...rows.slice(Math.floor(rows.length / 2) - 4, Math.floor(rows.length / 2) + 5), rows[rows.length - 1]];
  const compact = picks.map(row => keys.map(key => row[key] ?? '').join('|')).join('\n');
  return sha256Text(`${rows.length}|${keys.join(',')}|${compact}`);
}

function normalizeRows(headers, rawRows, options = {}, sourceText = '') {
  const mappings = headers.map((header, index) => ({ index, header: headerText(header), ...mapHeader(header) }));
  const selected = new Map();
  for (const mapping of mappings) if (mapping.key && !selected.has(mapping.key)) selected.set(mapping.key, mapping);
  const rows = [];
  for (let rowIndex = 0; rowIndex < rawRows.length; rowIndex += 1) {
    const raw = rawRows[rowIndex]; const row = {};
    for (const column of CANONICAL_COLUMNS) row[column] = null;
    for (const [key, mapping] of selected.entries()) row[key] = convertValue(key, raw[mapping.index], mapping.header);
    if (!row.timestamp) row.timestamp = String(rowIndex);
    const useful = CANONICAL_COLUMNS.some(key => !['timestamp','marker','fuelingMode'].includes(key) && Number.isFinite(Number(row[key])));
    if (useful) rows.push(row);
  }
  const profile = options.profile || 'baseline';
  const required = recommendedFields(profile);
  const available = CANONICAL_COLUMNS.filter(key => rows.some(row => row[key] !== null && row[key] !== ''));
  const missing = required.filter(key => !available.includes(key));
  const privateRemoved = mappings.filter(item => item.private).map(item => item.header);
  const unmapped = mappings.filter(item => !item.key && !item.private).map(item => item.header).filter(Boolean);
  const times = rows.map((row,index) => parseTimeSeconds(row.timestamp,index));
  const durationSeconds = times.length > 1 ? Math.max(0, Math.max(...times) - Math.min(...times)) : 0;
  const sampleRateHz = durationSeconds > 0 ? rows.length / durationSeconds : null;
  const source = detectLogSource(headers, sourceText);
  const fingerprint = normalizedFingerprint(rows, available);
  return {
    rows,
    mapping: mappings.filter(item => item.key).map(item => ({ source: item.header, canonical: item.key })),
    available, missing, privateRemoved, unmapped, source, normalizedFingerprint: fingerprint,
    quality: {
      rowCount: rows.length,
      durationSeconds: round(durationSeconds, 2),
      sampleRateHz: round(sampleRateHz, 2),
      status: rows.length < 20 ? 'insufficient' : missing.length > Math.ceil(required.length / 2) ? 'limited' : 'usable',
      warnings: [
        ...(rows.length < 20 ? ['Fewer than 20 usable rows were found.'] : []),
        ...(missing.length ? [`Missing recommended channels: ${missing.join(', ')}`] : []),
        ...(privateRemoved.length ? [`Removed private/location columns: ${privateRemoved.join(', ')}`] : []),
        ...(sampleRateHz != null && sampleRateHz < 1 ? ['Sampling rate is below 1 Hz; transient events may not be captured clearly.'] : [])
      ]
    }
  };
}

function parseCsvText(text, options = {}) {
  const allLines = String(text || '').replace(/^\uFEFF/, '').split(/\r?\n/).filter(line => line.trim() !== '');
  if (allLines.length < 2) throw new Error('The selected log does not contain a header and data rows.');
  const headerIndex = findHeaderLineIndex(allLines);
  const lines = allLines.slice(headerIndex);
  const delimiter = detectDelimiter(lines[0]);
  const headers = splitDelimited(lines[0], delimiter);
  const rawRows = lines.slice(1).map(line => splitDelimited(line, delimiter));
  const normalized = normalizeRows(headers, rawRows, options, allLines.slice(0, Math.min(15, allLines.length)).join('\n'));
  return { ...normalized, delimiter: delimiter === '\t' ? 'tab' : delimiter, headerLine: headerIndex + 1, preambleLinesSkipped: headerIndex };
}

function parseTuniqLog(file) {
  const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (raw?.format !== 'TunIQ Web Log Package' || !Array.isArray(raw.rows)) throw new Error('This .tuniqlog package is not recognized.');
  const headers = Array.isArray(raw.columns) && raw.columns.length ? raw.columns : CANONICAL_COLUMNS;
  const rows = raw.rows.map(item => headers.map(key => item?.[key] ?? ''));
  return { ...normalizeRows(headers, rows, { profile: raw.profile || 'baseline' }, JSON.stringify(raw).slice(0, 12000)), package: raw };
}

function normalizeFile(sourceFile, options = {}) {
  if (!sourceFile || !fs.existsSync(sourceFile)) throw new Error('Select an existing CSV, TXT, LOG, or TunIQ web-log package.');
  const extension = path.extname(sourceFile).toLowerCase();
  if (extension === '.tuniqlog' || extension === '.json') return parseTuniqLog(sourceFile);
  if (!['.csv','.txt','.log'].includes(extension)) throw new Error('Supported log formats are CSV, TXT, LOG, JSON, and .tuniqlog. Export TunerPro XDL files to CSV first.');
  return parseCsvText(fs.readFileSync(sourceFile, 'utf8'), options);
}

function writeNormalizedCsv(file, rows) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const output = [CANONICAL_COLUMNS.join(',')];
  for (const row of rows) output.push(CANONICAL_COLUMNS.map(key => csvValue(row[key])).join(','));
  fs.writeFileSync(file, `${output.join('\n')}\n`, 'utf8');
  return file;
}

function importPhoneLog({ sourceFile, activeProject, profile = 'baseline', name = '', provenance = null }) {
  if (!activeProject?.folder) throw new Error('Create or activate a TunIQ project before importing a phone log.');
  const normalized = normalizeFile(sourceFile, { profile });
  if (!normalized.rows.length) throw new Error('No usable sensor rows could be mapped from this file.');
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const base = safeFileName(name || path.basename(sourceFile, path.extname(sourceFile)) || 'Phone-Log');
  const logsFolder = path.join(activeProject.folder, 'Logs');
  const csvPath = path.join(logsFolder, `${base}-Imported-${stamp}.csv`);
  const metaPath = csvPath.replace(/\.csv$/i, '.meta.json');
  writeNormalizedCsv(csvPath, normalized.rows);
  const startedAt = new Date().toISOString();
  const metadata = {
    id: `${Date.now()}-imported-log`, projectId: activeProject.id, projectName: activeProject.name,
    vehicle: activeProject.vehicle || '', controller: activeProject.controller || '', os: activeProject.os || '', bin: activeProject.binInfo?.name || '',
    profileKey: profile, profileName: `${normalized.source.label} Import`, csvPath, metaPath, startedAt, stoppedAt: startedAt,
    durationSeconds: normalized.quality.durationSeconds, samples: normalized.rows.length, status: 'complete',
    adapter: `${normalized.source.label} / imported file`, port: 'file-import', protocol: 'Imported CSV', sourceFileName: path.basename(sourceFile),
    sourceFileSha256: sha256(sourceFile), normalizedFingerprint: normalized.normalizedFingerprint, sourceFormat: normalized.source,
    importQuality: normalized.quality, columnMapping: normalized.mapping, privateColumnsRemoved: normalized.privateRemoved,
    unmappedColumns: normalized.unmapped, preambleLinesSkipped: normalized.preambleLinesSkipped || 0, provenance: provenance || null
  };
  fs.writeFileSync(metaPath, JSON.stringify(metadata, null, 2), 'utf8');
  const reportPath = csvPath.replace(/\.csv$/i, '.import.json');
  fs.writeFileSync(reportPath, JSON.stringify({ ...metadata, availableChannels: normalized.available, missingRecommendedChannels: normalized.missing }, null, 2), 'utf8');
  return { ...metadata, reportPath, availableChannels: normalized.available, missingRecommendedChannels: normalized.missing };
}

function buildWebPackage(csvText, options = {}) {
  const parsed = parseCsvText(csvText, options);
  return {
    format: 'TunIQ Web Log Package', schemaVersion: 2, createdAt: new Date().toISOString(), source: parsed.source.label,
    sourceFormat: parsed.source, normalizedFingerprint: parsed.normalizedFingerprint,
    profile: options.profile || 'baseline', name: cleanText(options.name || 'Phone Log', 120), columns: CANONICAL_COLUMNS,
    rows: parsed.rows, mapping: parsed.mapping, quality: parsed.quality, availableChannels: parsed.available,
    missingRecommendedChannels: parsed.missing, privateColumnsRemoved: parsed.privateRemoved, unmappedColumns: parsed.unmapped
  };
}

module.exports = {
  CANONICAL_COLUMNS, FIELD_ALIASES, PRIVATE_HEADER_PATTERNS, detectDelimiter, splitDelimited, mapHeader, parseCsvText, normalizeFile,
  writeNormalizedCsv, importPhoneLog, buildWebPackage, recommendedFields, detectLogSource, parseDurationSeconds, normalizedFingerprint
};
