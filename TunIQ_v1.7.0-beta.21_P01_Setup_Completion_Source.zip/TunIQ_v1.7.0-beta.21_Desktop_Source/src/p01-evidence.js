const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { normalizeFile, writeNormalizedCsv } = require('./log-import');

const PUBLIC_EVIDENCE_REGISTRY = Object.freeze([
  {
    id: 'log-p01-12225074-1123', type: 'live-log', title: 'P01 OS 12225074 — 1123.csv road log',
    attachmentName: '1123.csv', format: 'Flow CSV / generic CSV', controller: 'P01', os: '12225074',
    controllerEvidence: 'The uploader identifies the original BIN as P01 OS 12225074 in the same thread.', confidence: 'explicit-p01',
    sourceUrl: 'https://pcmhacking.net/forums/viewtopic.php?t=8433', redistribution: 'reference-only',
    notes: 'Large road log paired with a 512 KiB BIN. Useful for importer coverage and MAF/VE/fuel-trim analysis after local download.'
  },
  {
    id: 'log-p01-12225074-0105c', type: 'live-log', title: 'P01 OS 12225074 — 0105c.csv follow-up log',
    attachmentName: '0105c.csv', format: 'Flow CSV / generic CSV', controller: 'P01', os: '12225074',
    controllerEvidence: 'Follow-up session from the same P01 OS 12225074 vehicle after returning to the original and retuning.', confidence: 'explicit-p01',
    sourceUrl: 'https://pcmhacking.net/forums/viewtopic.php?t=8433', redistribution: 'reference-only',
    notes: 'Before/after-style evidence when paired with 1123.csv, 0105.bin and 0105c.bin. It is not accepted as a verified tuning rule without outcome review.'
  },
  {
    id: 'log-p01-torque-egr-wideband', type: 'live-log', title: 'P01 Torque CSV with EGR wideband channel',
    attachmentName: 'exportedPIDs (3).csv', format: 'Torque CSV', controller: 'P01', os: null,
    controllerEvidence: 'Uploader explicitly states “I’m using a P01.”', confidence: 'explicit-p01',
    sourceUrl: 'https://pcmhacking.net/forums/viewtopic.php?t=8769', redistribution: 'reference-only',
    notes: 'Useful for phone-log aliases, custom GM Mode 22 fields, EGR-voltage wideband handling and GPS/privacy removal.'
  },
  {
    id: 'log-p01-family-fueltrims-20210810', type: 'live-log', title: 'PCM Logger 018 FuelTrims CSV session',
    attachmentName: '20210810_1908_FuelTrims.csv', format: 'PCM Logger CSV', controller: 'P01/P59 family', os: null,
    controllerEvidence: 'Posted in the GM LS1 512 KiB/1 MiB controller forum; the exact controller and OS are not stated.', confidence: 'family-unverified',
    sourceUrl: 'https://pcmhacking.net/forums/viewtopic.php?t=7519', redistribution: 'reference-only',
    notes: 'Documents PCM Logger comma-plus-space formatting, Clock Time and Elapsed Time fields. The resaved “FuelTrims2” file is the same session and is deduplicated.'
  },
  {
    id: 'log-p01-family-ram-20210814', type: 'live-log', title: 'PCM Logger RAM-profile CSV session',
    attachmentName: '20210814_1700_0002.RAM.csv', format: 'PCM Logger RAM CSV', controller: 'P01/P59 family', os: null,
    controllerEvidence: 'Posted in the GM LS1 controller forum; exact controller identity is not included in the post.', confidence: 'family-unverified',
    sourceUrl: 'https://pcmhacking.net/forums/viewtopic.php?start=10&t=7519', redistribution: 'reference-only',
    notes: 'Useful for RAM-parameter profile parsing and detecting sparse/short logs. It must not be used as OS-specific tuning evidence until identity is supplied.'
  },
  {
    id: 'definition-p01-12202088', type: 'definition', title: 'P01 OS 12202088 XDF reference',
    attachmentName: '12202088 - 2001 512k.xdf', format: 'TunerPro XDF', controller: 'P01', os: '12202088',
    controllerEvidence: 'Repository sorts XDFs by PCM type and operating system.', confidence: 'community-reference',
    sourceUrl: 'https://github.com/BoredTruckOwner/LS_Based_Engine_Repository/tree/master/.XDF%20Files/P01_512Kb', redistribution: 'reference-only',
    notes: 'Candidate definition only. TunIQ still requires exact-OS binding, mapping review, fingerprinting and commissioning.'
  },
  {
    id: 'definition-p01-12208322', type: 'definition', title: 'P01 OS 12208322 XDF reference',
    attachmentName: '12208322 - 2001 512k.xdf', format: 'TunerPro XDF', controller: 'P01', os: '12208322',
    controllerEvidence: 'Repository sorts XDFs by PCM type and operating system.', confidence: 'community-reference',
    sourceUrl: 'https://github.com/BoredTruckOwner/LS_Based_Engine_Repository/tree/master/.XDF%20Files/P01_512Kb', redistribution: 'reference-only',
    notes: 'Candidate definition only; not bundled because the repository does not expose a standard software license.'
  },
  {
    id: 'definition-p01-12209203', type: 'definition', title: 'P01 OS 12209203 XDF reference',
    attachmentName: '12209203 - 2002 512k V1.xdf', format: 'TunerPro XDF', controller: 'P01', os: '12209203',
    controllerEvidence: 'Repository sorts XDFs by PCM type and operating system.', confidence: 'community-reference',
    sourceUrl: 'https://github.com/BoredTruckOwner/LS_Based_Engine_Repository/tree/master/.XDF%20Files/P01_512Kb', redistribution: 'reference-only',
    notes: 'Candidate definition only. Table names are not enough to authorize AI writes.'
  },
  {
    id: 'definition-p01-12212156', type: 'definition', title: 'P01 OS 12212156 XDF reference',
    attachmentName: '12212156 - 2002 512k V1.xdf', format: 'TunerPro XDF', controller: 'P01', os: '12212156',
    controllerEvidence: 'Repository sorts XDFs by PCM type and operating system.', confidence: 'community-reference',
    sourceUrl: 'https://github.com/BoredTruckOwner/LS_Based_Engine_Repository/tree/master/.XDF%20Files/P01_512Kb', redistribution: 'reference-only',
    notes: 'Candidate definition only. TunIQ requires the loaded PCM identity and XDF title/filename to match the exact OS.'
  },

  {
    id: 'definition-p01-12225074-complete', type: 'definition', title: 'P01 OS 12225074 Complete XDF reference',
    attachmentName: '12225074_Complete.zip', format: 'TunerPro XDF + checksum plugin', controller: 'P01', os: '12225074',
    controllerEvidence: 'The author explicitly documents differences between OS 12202088 and 12225074 and provides both definitions.', confidence: 'community-tested',
    sourceUrl: 'https://pcmhacking.net/forums/viewtopic.php?t=8494', redistribution: 'reference-only',
    notes: 'Candidate definition with 800+ entries; the author says not every entry was tested. TunIQ therefore requires exact-OS fingerprinting and per-action commissioning.'
  },
  {
    id: 'collection-p01-stock-bins-xdfs', type: 'calibration-library', title: 'P01/P59 stock BIN and XDF reference collection',
    attachmentName: null, format: 'GitHub BIN/XDF repository', controller: 'P01/P59', os: null,
    controllerEvidence: 'Repository organizes BINs by PCM type, stock/modified status, vehicle and OS, and XDFs by PCM type and OS.', confidence: 'community-reference',
    sourceUrl: 'https://github.com/BoredTruckOwner/LS_Based_Engine_Repository', redistribution: 'link-only',
    notes: 'Reference catalog only. TunIQ does not auto-download or trust a file from this collection; the user imports it locally and TunIQ fingerprints and validates it.'
  },
  {
    id: 'tool-universal-patcher', type: 'tool-reference', title: 'Universal Patcher LS1 table and checksum definitions',
    attachmentName: null, format: 'Open-source GM calibration tool', controller: 'P01/P59', os: null,
    controllerEvidence: 'Project includes LS1 TableSeek, DTC and checksum definitions for P01/P59-family files.', confidence: 'primary-source',
    sourceUrl: 'https://github.com/joukoy/UniversalPatcher', redistribution: 'link-only',
    notes: 'TunIQ uses Universal Patcher reports as independent checksum/table evidence. Auto-discovered tables remain read-only until address, shape and equation are commissioned.'
  },
  {
    id: 'tool-pcm-logger-profiles', type: 'logger-reference', title: 'PCM Logger parameters and profiles',
    attachmentName: null, format: 'Official source/profile definitions', controller: 'P01/P59 family', os: null,
    controllerEvidence: 'PCM Logger is distributed with PCM Hammer and supports P01 logging.', confidence: 'primary-source',
    sourceUrl: 'https://github.com/PcmHammer/PcmHammer', redistribution: 'link-only',
    notes: 'Used to expand alias mapping and future controller-specific PID packs. A profile is not considered verified until the expected values are checked on real hardware.'
  },
  {
    id: 'calibration-map-p01-12202088-validation', type: 'calibration-research', title: 'P01 OS 12202088 map-validation thread',
    attachmentName: '12202088 OS MAP.zip', format: 'BIN/XDF/map comparison', controller: 'P01', os: '12202088',
    controllerEvidence: 'Thread explicitly targets P01 OSID 12202088.', confidence: 'negative-validation',
    sourceUrl: 'https://pcmhacking.net/forums/viewtopic.php?t=7884', redistribution: 'reference-only',
    notes: 'Important negative evidence: a reviewer found only a small fraction of automatically detected maps had the correct address and size. TunIQ uses this to keep auto-discovered tables read-only until commissioned.'
  },
  {
    id: 'tool-pcm-hammer-current', type: 'tool-reference', title: 'Official PCM Hammer P01 read/write/logger support',
    attachmentName: null, format: 'Official documentation/source', controller: 'P01', os: null,
    controllerEvidence: 'Official project support matrix.', confidence: 'primary-source',
    sourceUrl: 'https://github.com/PcmHammer/PcmHammer', redistribution: 'link-only',
    notes: 'Used for controller support, CLI integration, safe read/write sequence and logger/profile compatibility.'
  }
]);

function sha256(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function clean(value, max = 300) { return String(value ?? '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max); }
function safeName(value) { return clean(value, 120).replace(/[<>:"/\\|?*]+/g, '-').replace(/\s+/g, '-').replace(/^-+|-+$/g, '') || 'P01-Evidence'; }
function readJson(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, value) { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function detectOs(text) { const matches = String(text || '').match(/\b(?:12\d{6}|\d{7,8})\b/g) || []; return matches.find(item => /^12\d{6}$/.test(item)) || null; }

class P01EvidenceManager {
  constructor({ dataRoot, getActiveProject, appendActivity = () => {} }) {
    this.dataRoot = dataRoot;
    this.getActiveProject = getActiveProject;
    this.appendActivity = appendActivity;
  }
  root() { const folder = path.join(this.dataRoot(), 'P01Evidence'); fs.mkdirSync(folder, { recursive: true }); return folder; }
  indexFile() { return path.join(this.root(), 'imported.json'); }
  imports() { const value = readJson(this.indexFile(), []); return Array.isArray(value) ? value : []; }
  registry() { return PUBLIC_EVIDENCE_REGISTRY.map(item => ({ ...item })); }
  list() {
    const imported = this.imports();
    const publicLogs = PUBLIC_EVIDENCE_REGISTRY.filter(item => item.type === 'live-log');
    const explicitP01 = publicLogs.filter(item => item.confidence === 'explicit-p01');
    return {
      registryVersion: 1,
      updatedAt: '2026-07-18',
      registry: this.registry(), imported,
      summary: {
        publicLogSessions: publicLogs.length,
        explicitP01Logs: explicitP01.length,
        familyFormatLogs: publicLogs.length - explicitP01.length,
        definitionReferences: PUBLIC_EVIDENCE_REGISTRY.filter(item => item.type === 'definition').length,
        importedItems: imported.length,
        normalizedLogs: imported.filter(item => item.kind === 'live-log' && item.normalizedPath).length,
        uniqueNormalizedSessions: new Set(imported.filter(item => item.normalizedFingerprint).map(item => item.normalizedFingerprint)).size
      },
      warning: 'Public files are evidence candidates, not trusted tune rules. Exact PCM identity, OS, BIN/XDF fingerprints, before/after logs and outcomes are required before a rule can be promoted.'
    };
  }
  findSource(sourceId) { return PUBLIC_EVIDENCE_REGISTRY.find(item => item.id === sourceId) || null; }
  importFile(sourceFile, payload = {}) {
    if (!sourceFile || !fs.existsSync(sourceFile)) throw new Error('Select an existing evidence file.');
    const stat = fs.statSync(sourceFile); if (!stat.isFile()) throw new Error('The selected evidence item is not a file.');
    if (stat.size > 100 * 1024 * 1024) throw new Error('Evidence files are limited to 100 MB in this beta.');
    const source = this.findSource(payload.sourceId);
    const extension = path.extname(sourceFile).toLowerCase();
    const sourceKind = ['live-log','definition','bin'].includes(source?.type) ? source.type : null;
    const kind = payload.kind || sourceKind || (['.csv','.txt','.log','.json','.tuniqlog'].includes(extension) ? 'live-log' : extension === '.xdf' ? 'definition' : extension === '.bin' ? 'bin' : 'other');
    const active = this.getActiveProject?.() || null;
    const fileHash = sha256(sourceFile);
    const existing = this.imports();
    const duplicateRaw = existing.find(item => item.sourceFileSha256 === fileHash);
    if (duplicateRaw) return { ...duplicateRaw, duplicate: true, duplicateReason: 'identical-file-hash' };
    const now = new Date().toISOString();
    const id = `${Date.now()}-${safeName(path.basename(sourceFile, extension)).toLowerCase()}`;
    const folder = path.join(this.root(), 'Imported', id); fs.mkdirSync(folder, { recursive: true });
    let normalized = null; let normalizedPath = null; let detectedOs = source?.os || null; let xdfTitle = null;
    if (kind === 'live-log') {
      normalized = normalizeFile(sourceFile, { profile: payload.profile || 'baseline' });
      if (!normalized.rows.length) throw new Error('No usable rows were found in the selected log.');
      normalizedPath = path.join(folder, `${safeName(path.basename(sourceFile, extension))}-sanitized.csv`);
      writeNormalizedCsv(normalizedPath, normalized.rows);
    } else if (kind === 'definition') {
      const text = fs.readFileSync(sourceFile, 'utf8');
      detectedOs = detectedOs || detectOs(`${path.basename(sourceFile)} ${text.slice(0, 20000)}`);
      xdfTitle = (text.match(/<deftitle>([^<]+)<\/deftitle>/i) || text.match(/title=["']([^"']+)["']/i) || [])[1] || null;
    } else if (kind === 'bin') {
      detectedOs = detectedOs || detectOs(path.basename(sourceFile));
    }
    const compatibility = {
      activeProjectId: active?.id || null,
      activeController: active?.controller || null,
      activeOs: active?.os || null,
      controllerMatch: !active?.controller || !source?.controller || /P01/i.test(active.controller) && /P01/i.test(source.controller),
      osMatch: !active?.os || !detectedOs || String(active.os) === String(detectedOs)
    };
    const item = {
      id, kind, importedAt: now, sourceId: source?.id || null, sourceTitle: source?.title || clean(payload.title || path.basename(sourceFile), 180),
      sourceUrl: source?.sourceUrl || clean(payload.sourceUrl || '', 500) || null, sourceFileName: path.basename(sourceFile), sourceFileSha256: fileHash,
      sourceFileSize: stat.size, redistribution: source?.redistribution || 'user-supplied-local', confidence: source?.confidence || clean(payload.confidence || '', 50) || 'user-supplied', controller: source?.controller || clean(payload.controller || '', 50) || null,
      os: detectedOs || clean(payload.os || '', 20) || null, xdfTitle, notes: clean(payload.notes || source?.notes || '', 1000),
      normalizedPath, normalizedFingerprint: normalized?.normalizedFingerprint || null, sourceFormat: normalized?.source || null,
      rowCount: normalized?.quality?.rowCount || null, durationSeconds: normalized?.quality?.durationSeconds || null,
      quality: normalized?.quality || null, availableChannels: normalized?.available || [], missingChannels: normalized?.missing || [],
      privateColumnsRemoved: normalized?.privateRemoved || [], unmappedColumns: normalized?.unmapped || [], compatibility,
      trainingEligible: false,
      trainingBlockers: [
        ...(!compatibility.controllerMatch ? ['controller does not match active project'] : []),
        ...(!compatibility.osMatch ? ['operating system does not match active project'] : []),
        ...(source?.confidence === 'family-unverified' ? ['public source does not state whether the controller is P01 or P59'] : []),
        ...(kind === 'live-log' && !detectedOs ? ['log is not bound to an exact operating system'] : []),
        ...(kind === 'live-log' ? ['before/after calibration relationship and real outcome are not verified'] : []),
        ...(kind === 'definition' ? ['definition has not been commissioned against matching dual reads'] : [])
      ]
    };
    const duplicateNormalized = item.normalizedFingerprint && existing.find(entry => entry.normalizedFingerprint === item.normalizedFingerprint);
    if (duplicateNormalized) {
      item.duplicateOf = duplicateNormalized.id;
      item.trainingBlockers.push('normalized session duplicates an existing import');
    }
    existing.unshift(item); writeJson(this.indexFile(), existing.slice(0, 1000));
    writeJson(path.join(folder, 'evidence.json'), item);
    this.appendActivity('p01-evidence-imported', { id, kind, sourceId: item.sourceId, file: item.sourceFileName, format: item.sourceFormat?.label, rows: item.rowCount, os: item.os, duplicateOf: item.duplicateOf || null });
    return item;
  }
  deleteImport(id) {
    const items = this.imports(); const target = items.find(item => item.id === id); if (!target) return this.list();
    const folder = target.normalizedPath ? path.dirname(target.normalizedPath) : path.join(this.root(), 'Imported', target.id);
    try { fs.rmSync(folder, { recursive: true, force: true }); } catch {}
    writeJson(this.indexFile(), items.filter(item => item.id !== id));
    this.appendActivity('p01-evidence-deleted', { id });
    return this.list();
  }
}

module.exports = { P01EvidenceManager, PUBLIC_EVIDENCE_REGISTRY, detectOs };
