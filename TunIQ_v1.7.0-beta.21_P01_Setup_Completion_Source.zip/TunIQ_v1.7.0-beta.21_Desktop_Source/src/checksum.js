const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function sha256Buffer(buffer) { return crypto.createHash('sha256').update(buffer).digest('hex'); }
function sha256File(file) { return sha256Buffer(fs.readFileSync(file)); }
function clampInt(value, fallback = 0) { const n = Number(value); return Number.isFinite(n) ? Math.max(0, Math.floor(n)) : fallback; }

const CRC32_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i += 1) {
    let c = i;
    for (let j = 0; j < 8; j += 1) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(buffer, start = 0, end = buffer.length) {
  let crc = 0xFFFFFFFF;
  const from = Math.max(0, clampInt(start));
  const to = Math.min(buffer.length, Math.max(from, clampInt(end, buffer.length)));
  for (let index = from; index < to; index += 1) crc = CRC32_TABLE[(crc ^ buffer[index]) & 0xFF] ^ (crc >>> 8);
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function normalizedRanges(definition, length) {
  const ranges = Array.isArray(definition?.ranges) && definition.ranges.length
    ? definition.ranges
    : [{ start: definition?.start ?? 0, end: definition?.end ?? length }];
  return ranges.map(range => {
    const start = Math.min(length, clampInt(range.start, 0));
    let end = range.end == null ? length : clampInt(range.end, length);
    if (range.length != null) end = start + clampInt(range.length, 0);
    end = Math.min(length, Math.max(start, end));
    return { start, end };
  }).filter(range => range.end > range.start);
}

function checksumValue(buffer, definition) {
  const algorithm = String(definition?.algorithm || definition?.method || 'sum32').toLowerCase().replace(/[^a-z0-9]/g, '');
  const ranges = normalizedRanges(definition, buffer.length);
  let value = 0;
  if (algorithm === 'crc32') {
    let aggregate = Buffer.alloc(0);
    if (ranges.length === 1) value = crc32(buffer, ranges[0].start, ranges[0].end);
    else {
      aggregate = Buffer.concat(ranges.map(range => buffer.subarray(range.start, range.end)));
      value = crc32(aggregate);
    }
  } else if (algorithm === 'xor8' || algorithm === 'xor') {
    for (const range of ranges) for (let index = range.start; index < range.end; index += 1) value ^= buffer[index];
    value &= 0xFF;
  } else {
    const bits = algorithm.includes('8') ? 8 : algorithm.includes('16') ? 16 : 32;
    const mask = bits === 32 ? 0xFFFFFFFF : (2 ** bits) - 1;
    for (const range of ranges) for (let index = range.start; index < range.end; index += 1) value = (value + buffer[index]) >>> 0;
    value &= mask;
  }
  if (definition?.onesComplement || definition?.complement === 'ones') value = (~value) >>> 0;
  if (definition?.twosComplement || definition?.complement === 'twos') value = ((~value) + 1) >>> 0;
  if (definition?.xor != null) value = (value ^ Number(definition.xor)) >>> 0;
  if (definition?.add != null) value = (value + Number(definition.add)) >>> 0;
  const bits = Number(definition?.bits || definition?.sizeBits || 32);
  if (bits < 32) value &= (2 ** bits) - 1;
  return value >>> 0;
}

function readStored(buffer, definition) {
  if (definition?.address == null || definition.address === '') return null;
  const address = clampInt(definition.address, 0);
  const bits = Number(definition?.bits || definition?.sizeBits || 32);
  const little = definition?.littleEndian !== false;
  if (address < 0 || address + bits / 8 > buffer.length) return null;
  if (bits === 8) return buffer.readUInt8(address);
  if (bits === 16) return little ? buffer.readUInt16LE(address) : buffer.readUInt16BE(address);
  if (bits === 32) return little ? buffer.readUInt32LE(address) : buffer.readUInt32BE(address);
  return null;
}

function writeStored(buffer, definition, value) {
  if (definition?.address == null || definition.address === '') throw new Error('Checksum definition does not include a writable storage address.');
  const address = clampInt(definition.address, 0);
  const bits = Number(definition?.bits || definition?.sizeBits || 32);
  const little = definition?.littleEndian !== false;
  if (address < 0 || address + bits / 8 > buffer.length) throw new Error(`Checksum target 0x${Math.max(0, address).toString(16)} is outside the BIN.`);
  if (bits === 8) buffer.writeUInt8(value & 0xFF, address);
  else if (bits === 16) little ? buffer.writeUInt16LE(value & 0xFFFF, address) : buffer.writeUInt16BE(value & 0xFFFF, address);
  else if (bits === 32) little ? buffer.writeUInt32LE(value >>> 0, address) : buffer.writeUInt32BE(value >>> 0, address);
  else throw new Error(`Unsupported checksum storage width: ${bits} bits.`);
}

function verifyDefinitions(buffer, definitions = []) {
  return definitions.map((definition, index) => {
    const calculated = checksumValue(buffer, definition);
    const stored = readStored(buffer, definition);
    return {
      id: definition.id || `checksum-${index + 1}`,
      name: definition.name || definition.title || `Checksum ${index + 1}`,
      algorithm: definition.algorithm || definition.method || 'sum32',
      address: definition.address ?? null,
      stored,
      calculated,
      valid: stored == null ? null : Number(stored) === Number(calculated),
      writable: stored != null,
      ranges: normalizedRanges(definition, buffer.length)
    };
  });
}

function correctDefinitions(buffer, definitions = []) {
  const output = Buffer.from(buffer);
  const results = [];
  for (let index = 0; index < definitions.length; index += 1) {
    const definition = definitions[index];
    const value = checksumValue(output, definition);
    writeStored(output, definition, value);
    results.push({ id: definition.id || `checksum-${index + 1}`, value, address: definition.address, algorithm: definition.algorithm || definition.method || 'sum32' });
  }
  return { buffer: output, results };
}

function segmentMap(buffer, segmentSize = 0x10000) {
  const size = Math.max(0x1000, clampInt(segmentSize, 0x10000));
  const segments = [];
  for (let start = 0; start < buffer.length; start += size) {
    const end = Math.min(buffer.length, start + size);
    const chunk = buffer.subarray(start, end);
    segments.push({
      index: segments.length,
      start,
      end,
      size: end - start,
      sha256: sha256Buffer(chunk),
      blankFF: chunk.every(byte => byte === 0xFF),
      blank00: chunk.every(byte => byte === 0x00)
    });
  }
  return segments;
}

function diffBuffers(original, revised, maxRanges = 5000) {
  const sameSize = original.length === revised.length;
  const length = Math.min(original.length, revised.length);
  const ranges = [];
  let changedBytes = Math.abs(original.length - revised.length);
  let start = -1;
  for (let index = 0; index < length; index += 1) {
    const changed = original[index] !== revised[index];
    if (changed) {
      changedBytes += 1;
      if (start < 0) start = index;
    } else if (start >= 0) {
      if (ranges.length < maxRanges) ranges.push({ start, end: index, length: index - start });
      start = -1;
    }
  }
  if (start >= 0 && ranges.length < maxRanges) ranges.push({ start, end: length, length: length - start });
  if (!sameSize && ranges.length < maxRanges) ranges.push({ start: length, end: Math.max(original.length, revised.length), length: Math.abs(original.length - revised.length), sizeMismatch: true });
  return { sameSize, changedBytes, changedPercent: Math.max(original.length, revised.length) ? changedBytes * 100 / Math.max(original.length, revised.length) : 0, ranges, truncated: ranges.length >= maxRanges };
}

function compareFiles(originalFile, revisedFile) {
  const original = fs.readFileSync(originalFile);
  const revised = fs.readFileSync(revisedFile);
  const diff = diffBuffers(original, revised);
  const originalSegments = segmentMap(original);
  const revisedSegments = segmentMap(revised);
  const segmentChanges = [];
  const count = Math.max(originalSegments.length, revisedSegments.length);
  for (let index = 0; index < count; index += 1) {
    const a = originalSegments[index]; const b = revisedSegments[index];
    segmentChanges.push({ index, start: a?.start ?? b?.start ?? 0, end: a?.end ?? b?.end ?? 0, originalSha256: a?.sha256 || null, revisedSha256: b?.sha256 || null, changed: a?.sha256 !== b?.sha256 });
  }
  return {
    original: { path: originalFile, name: path.basename(originalFile), size: original.length, sha256: sha256Buffer(original) },
    revised: { path: revisedFile, name: path.basename(revisedFile), size: revised.length, sha256: sha256Buffer(revised) },
    ...diff,
    segmentChanges,
    compatibleLayout: diff.sameSize
  };
}

function parseUniversalPatcherReport(file) {
  const raw = fs.readFileSync(file, 'utf8');
  let json = null;
  try { json = JSON.parse(raw); } catch {}
  const lines = raw.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  const entries = [];
  const scanLine = line => {
    const lower = line.toLowerCase();
    let severity = 'info';
    if (/\b(error|failed|invalid|incorrect|bad checksum|mismatch)\b/.test(lower)) severity = 'error';
    else if (/\b(warn|unknown|unsupported)\b/.test(lower)) severity = 'warning';
    else if (/\b(ok|valid|correct|passed|success)\b/.test(lower)) severity = 'ok';
    const type = /checksum/.test(lower) ? 'checksum' : /segment/.test(lower) ? 'segment' : /patch/.test(lower) ? 'patch' : /\bos\b|operating system/.test(lower) ? 'os' : 'message';
    entries.push({ type, severity, text: line.slice(0, 1000) });
  };
  if (json && typeof json === 'object') {
    const walk = (value, key = '') => {
      if (value == null) return;
      if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') scanLine(`${key}: ${value}`);
      else if (Array.isArray(value)) value.forEach((item, index) => walk(item, `${key}[${index}]`));
      else Object.entries(value).forEach(([childKey, child]) => walk(child, key ? `${key}.${childKey}` : childKey));
    };
    walk(json);
  } else lines.forEach(scanLine);
  const errors = entries.filter(entry => entry.severity === 'error');
  const warnings = entries.filter(entry => entry.severity === 'warning');
  const passes = entries.filter(entry => entry.severity === 'ok');
  const checksumEntries = entries.filter(entry => entry.type === 'checksum');
  const checksumPasses = checksumEntries.filter(entry => entry.severity === 'ok');
  const checksumProblems = checksumEntries.filter(entry => entry.severity === 'error' || entry.severity === 'warning');
  return {
    file,
    name: path.basename(file),
    parsedAt: new Date().toISOString(),
    format: json ? 'json' : /<[^>]+>/.test(raw) ? 'xml/text' : 'text',
    valid: errors.length === 0 && checksumPasses.length > 0 && checksumProblems.length === 0,
    errors: errors.length,
    warnings: warnings.length,
    passes: passes.length,
    checksumPasses: checksumPasses.length,
    entries: entries.slice(0, 1000)
  };
}

function analyzeBin(file, { referenceFile = null, checksumDefinitions = [] } = {}) {
  const buffer = fs.readFileSync(file);
  const nativeChecksums = verifyDefinitions(buffer, checksumDefinitions);
  return {
    file,
    name: path.basename(file),
    size: buffer.length,
    sha256: sha256Buffer(buffer),
    segments: segmentMap(buffer),
    nativeChecksums,
    nativeChecksumStatus: nativeChecksums.length ? (nativeChecksums.every(item => item.valid === true) ? 'valid' : nativeChecksums.some(item => item.valid === false) ? 'invalid' : 'unknown') : 'not-defined',
    comparison: referenceFile && fs.existsSync(referenceFile) ? compareFiles(referenceFile, file) : null,
    analyzedAt: new Date().toISOString()
  };
}

module.exports = {
  sha256File,
  crc32,
  checksumValue,
  verifyDefinitions,
  correctDefinitions,
  segmentMap,
  diffBuffers,
  compareFiles,
  parseUniversalPatcherReport,
  analyzeBin
};
