const fs = require('fs');
const path = require('path');

const MAX_AXIS = 512;
const MAX_TABLE_CELLS = 131072;
const MAX_DEFINITIONS = 8000;

function decodeXml(value = '') {
  return String(value)
    .replace(/&#x([0-9a-f]+);/gi, (_m, hex) => String.fromCodePoint(parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_m, decimal) => String.fromCodePoint(parseInt(decimal, 10)))
    .replace(/&quot;/gi, '"').replace(/&apos;/gi, "'").replace(/&lt;/gi, '<').replace(/&gt;/gi, '>').replace(/&amp;/gi, '&');
}
function attrs(source = '') {
  const result = {};
  for (const match of source.matchAll(/([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g)) result[match[1].toLowerCase()] = decodeXml(match[2] ?? match[3] ?? '');
  return result;
}
function num(value, fallback = 0) {
  if (value == null || value === '') return fallback;
  const text = decodeXml(String(value)).trim();
  if (/^[-+]?0x/i.test(text)) return parseInt(text, 16);
  if (/^[-+]?\$[0-9a-f]+$/i.test(text)) return parseInt(text.replace('$', ''), 16);
  const parsed = Number(text); return Number.isFinite(parsed) ? parsed : fallback;
}
function positiveInt(value, fallback = 1, max = MAX_AXIS) { const parsed = Math.floor(num(value, fallback)); return !Number.isFinite(parsed) || parsed < 1 ? fallback : Math.min(parsed, max); }
function text(block, tag) { const match = String(block).match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, 'i')); return match ? decodeXml(match[1].replace(/<[^>]+>/g, '').trim()) : ''; }
function tagAttrs(block, tag) { const match = String(block).match(new RegExp(`<${tag}\\b([^>]*)>`, 'i')); return match ? attrs(match[1]) : {}; }
function allTagAttrs(block, tag) { return [...String(block).matchAll(new RegExp(`<${tag}\\b([^>]*)>`, 'gi'))].map(match => attrs(match[1])); }
function blocks(xml, tag) { return [...String(xml).matchAll(new RegExp(`<${tag}\\b([^>]*)>([\\s\\S]*?)<\\/${tag}>`, 'gi'))].map(match => ({ attrs: attrs(match[1]), body: match[2], raw: match[0] })); }
function axisBlock(block, id) { return blocks(block, 'XDFAXIS').find(item => String(item.attrs.id || '').toLowerCase() === id.toLowerCase()) || null; }

function normalizeFormula(eq) {
  let formula = decodeXml(eq || 'X').trim() || 'X';
  formula = formula.replace(/\^/g, '**');
  formula = formula.replace(/\b(ABS|MIN|MAX|POW|SQRT|LOG10|LOG|LN|EXP|ROUND|FLOOR|CEIL|SIN|COS|TAN|ASIN|ACOS|ATAN)\b/gi, token => {
    const lower = token.toLowerCase(); return `Math.${lower === 'ln' ? 'log' : lower}`;
  });
  return formula;
}
function equation(block) { const match = String(block).match(/<MATH\b([^>]*)>/i); return normalizeFormula(match ? attrs(match[1]).equation || 'X' : 'X'); }
function equationIsSafe(eq) {
  const formula = normalizeFormula(eq);
  if (!formula || formula.length > 500 || /(constructor|prototype|global|process|require|function|=>|this|window|document|eval)/i.test(formula)) return false;
  if (!/^[A-Za-z0-9_+\-*/().,\s%?:<>=!&|]+$/.test(formula)) return false;
  const allowed = new Set(['X','x','Math','PI','E','abs','min','max','pow','sqrt','log10','log','exp','round','floor','ceil','sin','cos','tan','asin','acos','atan']);
  return (formula.match(/[A-Za-z_][A-Za-z0-9_]*/g) || []).every(identifier => allowed.has(identifier));
}
function evalEquation(eq, x) {
  const formula = normalizeFormula(eq);
  if (!formula || /^X$/i.test(formula)) return Number(x);
  if (!equationIsSafe(formula)) return Number(x);
  try { const result = Function('X', `"use strict";return (${formula.replace(/\bx\b/gi, 'X')});`)(Number(x)); return Number.isFinite(Number(result)) ? Number(result) : Number(x); } catch { return Number(x); }
}
function rawRange(bits, signed, float) {
  if (float) return [-3.402823466e38, 3.402823466e38];
  if (signed) return [-(2 ** (bits - 1)), (2 ** (bits - 1)) - 1];
  return [0, bits === 32 ? 0xFFFFFFFF : (2 ** bits) - 1];
}
function inverseEquation(eq, y, bits, signed, float = false) {
  const target = Number(y); if (!Number.isFinite(target)) throw new Error('Calibration value is not numeric.');
  const formula = normalizeFormula(eq);
  if (!formula || /^X$/i.test(formula)) return target;
  if (!equationIsSafe(formula)) throw new Error(`Unsupported XDF equation: ${eq}`);
  const f0 = evalEquation(formula, 0), f1 = evalEquation(formula, 1), slope = f1 - f0, check = evalEquation(formula, 10);
  if (Number.isFinite(slope) && Math.abs(slope) > 1e-14 && Math.abs(check - (f0 + slope * 10)) < 1e-7 * Math.max(1, Math.abs(check))) return (target - f0) / slope;
  if (float) throw new Error(`TunIQ cannot safely invert this nonlinear floating-point equation: ${eq}`);
  let [low, high] = rawRange(bits, signed, false); let lowValue = evalEquation(formula, low), highValue = evalEquation(formula, high);
  if (!Number.isFinite(lowValue) || !Number.isFinite(highValue) || lowValue === highValue) throw new Error(`TunIQ cannot safely invert XDF equation: ${eq}`);
  const increasing = highValue > lowValue, minValue = Math.min(lowValue, highValue), maxValue = Math.max(lowValue, highValue);
  if (target < minValue || target > maxValue) throw new Error(`Value ${target} is outside the invertible range for equation ${eq}.`);
  for (let iteration = 0; iteration < 72 && high - low > 1; iteration += 1) {
    const middle = Math.floor((low + high) / 2), middleValue = evalEquation(formula, middle);
    if ((increasing && middleValue < target) || (!increasing && middleValue > target)) low = middle; else high = middle;
  }
  return [low, high].sort((a, b) => Math.abs(evalEquation(formula, a) - target) - Math.abs(evalEquation(formula, b) - target))[0];
}

function lowestBit(mask) { if (!mask) return 0; let shift = 0; let value = mask >>> 0; while (shift < 32 && (value & 1) === 0) { value >>>= 1; shift += 1; } return shift; }
function dataSettings(embedded, defaults) {
  const flags = Math.max(0, Math.floor(num(embedded.mmedtypeflags, 0)));
  const explicitSigned = embedded.signed;
  const signed = explicitSigned != null ? num(explicitSigned, 0) === 1 : Boolean(flags & 0x01) || defaults.signed;
  let littleEndian = defaults.littleEndian;
  if (flags & 0x02) littleEndian = false;
  if (embedded.lsbfirst != null) littleEndian = num(embedded.lsbfirst, 1) === 1;
  const bitMask = num(embedded.mmedbitmask ?? embedded.bitmask ?? embedded.mask, 0) >>> 0;
  return { flags, signed, littleEndian, columnMajor: Boolean(flags & 0x04), float: defaults.float || num(embedded.float, 0) === 1 || /float/i.test(embedded.datatype || ''), bitMask, bitShift: lowestBit(bitMask) };
}

function parseCategories(xml) {
  const categories = {};
  for (const item of blocks(xml, 'CATEGORY')) {
    const id = item.attrs.index || item.attrs.id || item.attrs.uniqueid || String(Object.keys(categories).length);
    categories[String(id)] = item.attrs.name || item.attrs.title || text(item.body, 'name') || text(item.body, 'title') || `Category ${id}`;
  }
  for (const attributes of allTagAttrs(xml, 'CATEGORY')) {
    const id = attributes.index || attributes.id || attributes.uniqueid;
    if (id == null || categories[String(id)]) continue;
    categories[String(id)] = attributes.name || attributes.title || `Category ${id}`;
  }
  return categories;
}
function categoryFor(body, categories) {
  const mem = tagAttrs(body, 'CATEGORYMEM'); const id = mem.index || mem.category || mem.id;
  return id != null ? categories[String(id)] || String(id) : '';
}

function parseAxis(block, id, fallbackCount, warnings, baseOffset, defaults) {
  const chosen = axisBlock(block, id); const safeFallback = positiveInt(fallbackCount, 1);
  if (!chosen) return { id, count: safeFallback, labels: Array.from({ length: safeFallback }, (_, index) => String(index)), dynamic: false };
  const requested = Math.floor(num(text(chosen.body, 'indexcount') || chosen.attrs.indexcount || chosen.attrs.count, safeFallback));
  const count = positiveInt(requested, safeFallback); if (requested > MAX_AXIS) warnings.push(`Axis ${id} was limited from ${requested} to ${MAX_AXIS} cells.`);
  const indexedLabels = allTagAttrs(chosen.body, 'LABEL').map((item, order) => ({ index: Math.max(0, Math.floor(num(item.index, order))), value: item.value ?? item.label })).filter(item => item.value != null).sort((a, b) => a.index - b.index);
  const labels = Array.from({ length: count }, (_, index) => String(index)); for (const item of indexedLabels) if (item.index < count) labels[item.index] = String(item.value);
  const embedded = tagAttrs(chosen.body, 'EMBEDDEDDATA'); const settings = dataSettings(embedded, defaults); const math = equation(chosen.body);
  const addressRaw = embedded.mmedaddress ?? embedded.address;
  return {
    id, count, labels, dynamic: addressRaw != null, linkId: chosen.attrs.linkobjid || chosen.attrs.linkid || tagAttrs(chosen.body, 'LINKOBJ').uniqueid || null,
    address: addressRaw == null ? null : baseOffset + num(addressRaw), elementBits: num(embedded.mmedelementsizebits || embedded.elementsizebits, defaults.elementBits),
    stride: Math.max(1, num(embedded.mmedminorstridebits || embedded.mmedcolstridebits, 0) / 8 || num(embedded.stride, 0) || num(embedded.mmedelementsizebits || embedded.elementsizebits, defaults.elementBits) / 8),
    equation: math, unit: text(chosen.body, 'units') || tagAttrs(chosen.body, 'MATH').units || '', ...settings
  };
}

function normalizeDefinition(definition, warnings) {
  let rows = positiveInt(definition.rows, 1), cols = positiveInt(definition.cols, 1);
  if (rows * cols > MAX_TABLE_CELLS) { const limitedCols = Math.max(1, Math.floor(MAX_TABLE_CELLS / rows)); warnings.push(`${definition.name} was limited from ${rows * cols} to ${rows * limitedCols} cells.`); cols = limitedCols; }
  const elementBits = [8,16,32,64].includes(Number(definition.elementBits)) ? Number(definition.elementBits) : 8;
  const bytes = elementBits / 8, majorStride = Math.max(0, Number(definition.majorStride) || 0), minorStride = Math.max(0, Number(definition.minorStride) || 0), columnMajor = Boolean(definition.columnMajor);
  const rowStride = columnMajor ? (minorStride || bytes) : (majorStride || cols * bytes), colStride = columnMajor ? (majorStride || rows * bytes) : (minorStride || bytes);
  let unsupportedReason = null;
  if (elementBits === 64 && !definition.float) unsupportedReason = '64-bit integer XDF data is not writable.';
  else if (definition.float && ![32,64].includes(elementBits)) unsupportedReason = `Unsupported ${elementBits}-bit floating-point storage.`;
  else if (!equationIsSafe(definition.equation || 'X')) unsupportedReason = `Unsupported conversion equation: ${definition.equation}`;
  if (unsupportedReason) warnings.push(`${definition.name}: ${unsupportedReason}`);
  return { ...definition, address: Math.max(0, Math.floor(Number(definition.address) || 0)), elementBits, rows, cols, rowHeaders: (definition.rowHeaders || []).slice(0, rows), colHeaders: (definition.colHeaders || []).slice(0, cols), rowStride, colStride, columnMajor, unsupportedReason };
}

function parseChecksumDefinitions(xml, baseOffset) {
  const definitions = [];
  for (const tag of ['XDFCHECKSUM','CHECKSUM']) {
    for (const item of blocks(xml, tag)) {
      const embedded = tagAttrs(item.body, 'EMBEDDEDDATA'); const a = item.attrs;
      const ranges = [];
      for (const range of allTagAttrs(item.body, 'RANGE')) ranges.push({ start: baseOffset + num(range.start || range.address), end: range.end != null ? baseOffset + num(range.end) : null, length: range.length != null ? num(range.length) : null });
      const addressRaw = embedded.mmedaddress ?? embedded.address ?? a.address;
      definitions.push({
        id: a.uniqueid || a.id || `checksum-${definitions.length + 1}`, name: a.title || text(item.body, 'title') || `Checksum ${definitions.length + 1}`,
        algorithm: a.algorithm || a.method || text(item.body, 'algorithm') || 'sum32', address: addressRaw == null || addressRaw === '' ? null : baseOffset + num(addressRaw),
        bits: num(embedded.mmedelementsizebits || embedded.elementsizebits || a.bits, 32), littleEndian: a.lsbfirst == null ? true : num(a.lsbfirst, 1) === 1,
        ranges, complement: a.complement || '', xor: a.xor == null ? null : num(a.xor), add: a.add == null ? null : num(a.add)
      });
    }
  }
  return definitions;
}

function parseXdf(file) {
  const xml = fs.readFileSync(file, 'utf8'), tables = [], warnings = [], categories = parseCategories(xml);
  const defaultAttributes = tagAttrs(xml, 'DEFAULTS');
  const defaults = { elementBits: num(defaultAttributes.datasizeinbits, 8), signed: num(defaultAttributes.signed, 0) === 1, littleEndian: defaultAttributes.lsbfirst == null ? true : num(defaultAttributes.lsbfirst, 1) === 1, float: num(defaultAttributes.float, 0) === 1 };
  const baseOffset = num(text(xml, 'baseoffset'), 0);
  const addDefinition = (attributes, body, type) => {
    if (tables.length >= MAX_DEFINITIONS) return;
    const z = type === 'table' ? axisBlock(body, 'z') : null, dataBody = z?.body || body, embedded = tagAttrs(dataBody, 'EMBEDDEDDATA'), settings = dataSettings(embedded, defaults), math = equation(dataBody);
    const x = parseAxis(body, 'x', num(embedded.mmedcolcount || embedded.colcount, 1), warnings, baseOffset, defaults), y = parseAxis(body, 'y', num(embedded.mmedrowcount || embedded.rowcount, 1), warnings, baseOffset, defaults);
    tables.push(normalizeDefinition({
      id: attributes.uniqueid || attributes.id || `${type}-${tables.length}`, type,
      name: attributes.title || text(body, 'title') || `${type === 'table' ? 'Table' : 'Constant'} ${tables.length + 1}`, description: text(body, 'description'), category: categoryFor(body, categories),
      address: baseOffset + num(embedded.mmedaddress || embedded.address), elementBits: num(embedded.mmedelementsizebits || embedded.elementsizebits, defaults.elementBits),
      majorStride: num(embedded.mmedmajorstridebits || embedded.mmedrowstridebits, 0) / 8, minorStride: num(embedded.mmedminorstridebits || embedded.mmedcolstridebits, 0) / 8,
      rows: type === 'table' ? num(embedded.mmedrowcount || embedded.rowcount, y.count) : 1, cols: type === 'table' ? num(embedded.mmedcolcount || embedded.colcount, x.count) : 1,
      rowHeaders: type === 'table' ? y.labels : ['Value'], colHeaders: type === 'table' ? x.labels : ['Value'], xAxis: type === 'table' ? x : null, yAxis: type === 'table' ? y : null,
      equation: math, equationSupported: equationIsSafe(math), unit: text(dataBody, 'units') || tagAttrs(dataBody, 'MATH').units || '',
      min: text(dataBody, 'min') === '' ? null : num(text(dataBody, 'min')), max: text(dataBody, 'max') === '' ? null : num(text(dataBody, 'max')),
      enumLabels: allTagAttrs(dataBody, 'LABEL').map(item => ({ index: num(item.index), value: item.value ?? item.label })).filter(item => item.value != null), ...settings
    }, warnings));
  };
  for (const item of blocks(xml, 'XDFTABLE')) addDefinition(item.attrs, item.body, 'table');
  for (const item of blocks(xml, 'XDFCONSTANT')) addDefinition(item.attrs, item.body, 'constant');
  if (tables.length >= MAX_DEFINITIONS) warnings.push(`Definition import stopped at ${MAX_DEFINITIONS} items.`);
  const byId = new Map(tables.map(table => [String(table.id), table]));
  for (const table of tables) for (const axisName of ['xAxis','yAxis']) { const axis = table[axisName]; if (axis?.linkId && byId.has(String(axis.linkId))) axis.linkedDefinition = String(axis.linkId); }
  return { title: text(xml, 'deftitle') || tagAttrs(xml, 'XDFHEADER').deftitle || path.basename(file), baseOffset, tables, categories, checksums: parseChecksumDefinitions(xml, baseOffset), warnings };
}

function readRaw(buffer, offset, bits, signed = false, littleEndian = true, float = false) {
  const bytes = bits / 8; if (!Number.isInteger(offset) || offset < 0 || offset + bytes > buffer.length) return 0;
  if (float) { if (bits === 32) return littleEndian ? buffer.readFloatLE(offset) : buffer.readFloatBE(offset); if (bits === 64) return littleEndian ? buffer.readDoubleLE(offset) : buffer.readDoubleBE(offset); }
  if (bits === 8) return signed ? buffer.readInt8(offset) : buffer.readUInt8(offset);
  if (bits === 16) return signed ? (littleEndian ? buffer.readInt16LE(offset) : buffer.readInt16BE(offset)) : (littleEndian ? buffer.readUInt16LE(offset) : buffer.readUInt16BE(offset));
  if (bits === 32) return signed ? (littleEndian ? buffer.readInt32LE(offset) : buffer.readInt32BE(offset)) : (littleEndian ? buffer.readUInt32LE(offset) : buffer.readUInt32BE(offset));
  return 0;
}
function writeRaw(buffer, offset, bits, value, signed = false, littleEndian = true, float = false) {
  value = Number(value); const bytes = bits / 8; if (!Number.isInteger(offset) || offset < 0 || offset + bytes > buffer.length) throw new Error(`Address 0x${Math.max(0, Number(offset) || 0).toString(16)} is outside BIN`);
  if (float) { if (bits === 32) return littleEndian ? buffer.writeFloatLE(value, offset) : buffer.writeFloatBE(value, offset); if (bits === 64) return littleEndian ? buffer.writeDoubleLE(value, offset) : buffer.writeDoubleBE(value, offset); }
  value = Math.round(value);
  if (bits === 8) return signed ? buffer.writeInt8(Math.max(-128, Math.min(127, value)), offset) : buffer.writeUInt8(Math.max(0, Math.min(255, value)), offset);
  if (bits === 16) return signed ? (littleEndian ? buffer.writeInt16LE(Math.max(-32768, Math.min(32767, value)), offset) : buffer.writeInt16BE(Math.max(-32768, Math.min(32767, value)), offset)) : (littleEndian ? buffer.writeUInt16LE(Math.max(0, Math.min(65535, value)), offset) : buffer.writeUInt16BE(Math.max(0, Math.min(65535, value)), offset));
  if (bits === 32) { if (signed) return littleEndian ? buffer.writeInt32LE(Math.max(-2147483648, Math.min(2147483647, value)), offset) : buffer.writeInt32BE(Math.max(-2147483648, Math.min(2147483647, value)), offset); const clamped = Math.max(0, Math.min(4294967295, value)); return littleEndian ? buffer.writeUInt32LE(clamped, offset) : buffer.writeUInt32BE(clamped, offset); }
  throw new Error(`Unsupported raw storage width: ${bits}`);
}
function extractMasked(raw, mask, shift) { return mask ? ((raw >>> shift) & (mask >>> shift)) >>> 0 : raw; }
function mergeMasked(original, value, mask, shift) { if (!mask) return value; return (((original >>> 0) & (~mask >>> 0)) | ((Number(value) << shift) & mask)) >>> 0; }
function hydrateAxis(axis, bin) {
  if (!axis?.dynamic || axis.address == null) return axis?.labels || [];
  const labels = [];
  for (let index = 0; index < axis.count; index += 1) {
    const offset = axis.address + axis.stride * index, rawStorage = readRaw(bin, offset, axis.elementBits, axis.signed, axis.littleEndian, axis.float), raw = extractMasked(rawStorage, axis.bitMask, axis.bitShift);
    labels.push(String(Number(evalEquation(axis.equation, raw).toFixed(6))));
  }
  return labels;
}
function hydrate(definition, bin) {
  const rows = positiveInt(definition.rows, 1), cols = positiveInt(definition.cols, 1);
  const values = Array.from({ length: rows }, (_, row) => Array.from({ length: cols }, (_, col) => {
    const offset = definition.address + definition.rowStride * row + definition.colStride * col;
    const stored = readRaw(bin, offset, definition.elementBits, definition.signed, definition.littleEndian, definition.float), raw = extractMasked(stored, definition.bitMask, definition.bitShift);
    return Number(evalEquation(definition.equation, raw).toFixed(6));
  }));
  const rowHeaders = definition.yAxis ? hydrateAxis(definition.yAxis, bin) : definition.rowHeaders, colHeaders = definition.xAxis ? hydrateAxis(definition.xAxis, bin) : definition.colHeaders;
  return { ...definition, rows, cols, rowHeaders: rowHeaders.slice(0, rows), colHeaders: colHeaders.slice(0, cols), values };
}
function applyTable(buffer, table, changedCells = null) {
  if (!table || !Array.isArray(table.values)) return; if (table.unsupportedReason) throw new Error(`${table.name}: ${table.unsupportedReason}`);
  const rows = Math.min(positiveInt(table.rows, table.values.length), table.values.length), cols = Math.min(positiveInt(table.cols, table.values[0]?.length || 1), table.values[0]?.length || 1);
  for (let row = 0; row < rows; row += 1) for (let col = 0; col < cols; col += 1) {
    if (changedCells && !changedCells.has(`${row}:${col}`)) continue;
    const offset = table.address + table.rowStride * row + table.colStride * col;
    const inverse = inverseEquation(table.equation, Number(table.values[row][col]), table.elementBits, table.signed, table.float);
    let raw = inverse;
    if (table.bitMask) {
      const original = readRaw(buffer, offset, table.elementBits, false, table.littleEndian, false);
      raw = mergeMasked(original, Math.round(inverse), table.bitMask, table.bitShift);
      writeRaw(buffer, offset, table.elementBits, raw, false, table.littleEndian, false);
    } else writeRaw(buffer, offset, table.elementBits, raw, table.signed, table.littleEndian, table.float);
  }
}

module.exports = { parseXdf, hydrate, applyTable, evalEquation, inverseEquation, readRaw, writeRaw, equationIsSafe };
