const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const VEHICLE_SCHEMA_VERSION = 2;
const VIN_TRANSLITERATION = Object.freeze({
  A: 1, B: 2, C: 3, D: 4, E: 5, F: 6, G: 7, H: 8,
  J: 1, K: 2, L: 3, M: 4, N: 5, P: 7, R: 9,
  S: 2, T: 3, U: 4, V: 5, W: 6, X: 7, Y: 8, Z: 9
});
const VIN_WEIGHTS = Object.freeze([8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2]);
const VIN_YEAR_CODES = 'ABCDEFGHJKLMNPRSTVWXY123456789';

function cleanText(value, max = 5000) {
  return String(value ?? '').replace(/\0/g, '').trim().slice(0, max);
}

function slug(value) {
  return cleanText(value, 120).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'vehicle';
}

function stableId(prefix = 'vehicle') {
  if (typeof crypto.randomUUID === 'function') return `${prefix}-${crypto.randomUUID()}`;
  return `${prefix}-${Date.now()}-${crypto.randomBytes(6).toString('hex')}`;
}

function normalizeStringList(value, maxItems = 100, maxLength = 160) {
  const values = Array.isArray(value) ? value : cleanText(value, 20000).split(/[\n,;]+/);
  const result = [];
  const seen = new Set();
  for (const raw of values) {
    const item = cleanText(typeof raw === 'object' ? raw?.name || raw?.description : raw, maxLength);
    const key = item.toLowerCase();
    if (!item || seen.has(key)) continue;
    seen.add(key);
    result.push(item);
    if (result.length >= maxItems) break;
  }
  return result;
}

function normalizeMaintenance(value) {
  const source = Array.isArray(value) ? value : cleanText(value, 30000).split(/\r?\n/).filter(Boolean).map(line => {
    const parts = line.split('|').map(part => part.trim());
    return { date: parts[0] || '', mileage: parts[1] || '', description: parts.slice(2).join(' | ') || parts[1] || parts[0] || '' };
  });
  return source.slice(0, 250).map((entry, index) => {
    const description = cleanText(entry?.description || entry?.service || entry?.notes, 500);
    if (!description) return null;
    return {
      id: cleanText(entry?.id, 120) || `service-${Date.now()}-${index}-${crypto.randomBytes(3).toString('hex')}`,
      date: /^\d{4}-\d{2}-\d{2}$/.test(cleanText(entry?.date, 10)) ? cleanText(entry.date, 10) : '',
      mileage: cleanText(entry?.mileage, 30),
      description
    };
  }).filter(Boolean);
}

function vinValue(character) {
  if (/\d/.test(character)) return Number(character);
  return VIN_TRANSLITERATION[character] ?? -1;
}

function vinYearCandidates(code, currentYear = new Date().getFullYear()) {
  const index = VIN_YEAR_CODES.indexOf(code);
  if (index < 0) return [];
  const base = 1980 + index;
  const years = [];
  for (let year = base; year <= currentYear + 2; year += 30) years.push(year);
  return years.reverse();
}

function validateVin(value, currentYear = new Date().getFullYear()) {
  const vin = cleanText(value, 32).toUpperCase().replace(/\s+/g, '');
  if (!vin) return { vin: '', status: 'empty', validFormat: true, checkDigitValid: null, message: 'VIN not entered.', yearCandidates: [] };
  if (!/^[A-HJ-NPR-Z0-9]{17}$/.test(vin)) {
    return { vin, status: 'invalid-format', validFormat: false, checkDigitValid: false, message: 'VIN must contain exactly 17 characters and cannot contain I, O, or Q.', yearCandidates: [] };
  }
  let total = 0;
  for (let index = 0; index < vin.length; index += 1) {
    const numeric = vinValue(vin[index]);
    if (numeric < 0) return { vin, status: 'invalid-format', validFormat: false, checkDigitValid: false, message: `VIN contains an unsupported character at position ${index + 1}.`, yearCandidates: [] };
    total += numeric * VIN_WEIGHTS[index];
  }
  const remainder = total % 11;
  const expected = remainder === 10 ? 'X' : String(remainder);
  const checkDigitValid = vin[8] === expected;
  const yearCandidates = vinYearCandidates(vin[9], currentYear);
  return {
    vin,
    status: checkDigitValid ? 'valid' : 'check-digit-mismatch',
    validFormat: true,
    checkDigitValid,
    expectedCheckDigit: expected,
    actualCheckDigit: vin[8],
    modelYearCode: vin[9],
    yearCandidates,
    message: checkDigitValid ? 'VIN format and check digit are valid.' : `VIN format is valid, but the check digit should be ${expected}. Review the entered VIN.`
  };
}

function normalizeVehicle(payload = {}, existing = {}, options = {}) {
  const name = cleanText(payload.name ?? existing.name, 120);
  if (!name) throw new Error('Vehicle name is required.');
  const vinResult = validateVin(payload.vin ?? existing.vin);
  if (vinResult.status === 'invalid-format' && !options.allowInvalidVin) throw new Error(vinResult.message);
  const now = new Date().toISOString();
  const id = cleanText(existing.id || payload.id, 160) || stableId(slug(name));
  const favorite = typeof payload.favorite === 'boolean' ? payload.favorite : Boolean(existing.favorite);
  return {
    schemaVersion: VEHICLE_SCHEMA_VERSION,
    ...existing,
    id,
    name,
    favorite,
    year: cleanText(payload.year ?? existing.year, 12),
    make: cleanText(payload.make ?? existing.make, 80),
    model: cleanText(payload.model ?? existing.model, 80),
    trim: cleanText(payload.trim ?? existing.trim, 80),
    engine: cleanText(payload.engine ?? existing.engine, 120),
    transmission: cleanText(payload.transmission ?? existing.transmission, 120),
    drivetrain: cleanText(payload.drivetrain ?? existing.drivetrain, 80),
    fuel: cleanText(payload.fuel ?? existing.fuel, 80),
    controller: cleanText(payload.controller ?? existing.controller, 80),
    os: cleanText(payload.os ?? existing.os, 80),
    hardwareId: cleanText(payload.hardwareId ?? existing.hardwareId, 120),
    serviceNumber: cleanText(payload.serviceNumber ?? existing.serviceNumber, 120),
    vin: vinResult.vin,
    vinStatus: vinResult,
    mileage: cleanText(payload.mileage ?? existing.mileage, 30),
    tireSize: cleanText(payload.tireSize ?? existing.tireSize, 80),
    rearGear: cleanText(payload.rearGear ?? existing.rearGear, 40),
    modifications: normalizeStringList(payload.modifications ?? existing.modifications),
    maintenance: normalizeMaintenance(payload.maintenance ?? existing.maintenance),
    notes: cleanText(payload.notes ?? existing.notes, 8000),
    photoPath: cleanText(payload.photoPath ?? existing.photoPath, 1000),
    createdAt: existing.createdAt || cleanText(payload.createdAt, 50) || now,
    updatedAt: options.touch === false ? (existing.updatedAt || cleanText(payload.updatedAt, 50) || now) : now
  };
}

function vehicleSnapshot(vehicle) {
  if (!vehicle) return null;
  return {
    id: vehicle.id,
    name: vehicle.name,
    year: vehicle.year || '',
    make: vehicle.make || '',
    model: vehicle.model || '',
    trim: vehicle.trim || '',
    engine: vehicle.engine || '',
    transmission: vehicle.transmission || '',
    drivetrain: vehicle.drivetrain || '',
    fuel: vehicle.fuel || '',
    controller: vehicle.controller || '',
    os: vehicle.os || '',
    hardwareId: vehicle.hardwareId || '',
    serviceNumber: vehicle.serviceNumber || '',
    tireSize: vehicle.tireSize || '',
    rearGear: vehicle.rearGear || '',
    modifications: Array.isArray(vehicle.modifications) ? [...vehicle.modifications] : []
  };
}

function resolveVehicle(vehicles, payload = {}) {
  const byId = cleanText(payload.vehicleId, 160);
  if (byId) {
    const exact = vehicles.find(vehicle => vehicle.id === byId);
    if (exact) return exact;
  }
  const legacyName = cleanText(payload.vehicle, 120).toLowerCase();
  return legacyName ? vehicles.find(vehicle => vehicle.name.toLowerCase() === legacyName) || null : null;
}

function projectVehicleFields(payload, vehicles) {
  const vehicle = resolveVehicle(vehicles, payload);
  if (!vehicle) return { vehicleId: '', vehicle: cleanText(payload.vehicle, 120), vehicleSnapshot: null };
  return { vehicleId: vehicle.id, vehicle: vehicle.name, vehicleSnapshot: vehicleSnapshot(vehicle) };
}

class GarageManager {
  constructor(options = {}) {
    this.dataRoot = options.dataRoot;
    this.projectsRoot = options.projectsRoot;
    this.readJson = options.readJson || ((file, fallback = null) => { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } });
    this.writeJson = options.writeJson || ((file, value) => { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); });
    this.appendActivity = options.appendActivity || (() => {});
  }

  vehiclesFile() { return path.join(this.dataRoot(), 'Vehicles', 'vehicles.json'); }
  photosRoot() { const folder = path.join(this.dataRoot(), 'Vehicles', 'Photos'); fs.mkdirSync(folder, { recursive: true }); return folder; }

  list() {
    const raw = this.readJson(this.vehiclesFile(), []);
    const source = Array.isArray(raw) ? raw : [];
    const vehicles = source.map(item => normalizeVehicle(item, item, { touch: false, allowInvalidVin: true }));
    const changed = JSON.stringify(source) !== JSON.stringify(vehicles);
    if (changed) this.writeJson(this.vehiclesFile(), vehicles);
    return vehicles.sort((a, b) => Number(Boolean(b.favorite)) - Number(Boolean(a.favorite)) || String(b.updatedAt || '').localeCompare(String(a.updatedAt || '')));
  }

  projectEntries() {
    const root = this.projectsRoot();
    if (!fs.existsSync(root)) return [];
    return fs.readdirSync(root, { withFileTypes: true }).filter(entry => entry.isDirectory()).map(entry => {
      const folder = path.join(root, entry.name);
      const file = path.join(folder, 'project.json');
      return { folder, file, manifest: this.readJson(file, null) };
    }).filter(entry => entry.manifest?.id);
  }

  usage(vehicle, previousName = '') {
    const names = new Set([vehicle?.name, previousName].map(value => cleanText(value, 120).toLowerCase()).filter(Boolean));
    return this.projectEntries().filter(entry => entry.manifest.vehicleId === vehicle.id || (!entry.manifest.vehicleId && names.has(cleanText(entry.manifest.vehicle, 120).toLowerCase()))).map(entry => ({ id: entry.manifest.id, name: entry.manifest.name, folder: entry.folder }));
  }

  listWithUsage() {
    const vehicles = this.list();
    const entries = this.projectEntries();
    return vehicles.map(vehicle => {
      const names = new Set([vehicle.name.toLowerCase()]);
      const projects = entries.filter(entry => entry.manifest.vehicleId === vehicle.id || (!entry.manifest.vehicleId && names.has(cleanText(entry.manifest.vehicle, 120).toLowerCase())));
      return { ...vehicle, projectCount: projects.length, projectNames: projects.map(entry => entry.manifest.name) };
    });
  }

  syncProjects(vehicle, previousName = '') {
    const refs = this.usage(vehicle, previousName);
    const snapshot = vehicleSnapshot(vehicle);
    for (const ref of refs) {
      const file = path.join(ref.folder, 'project.json');
      const manifest = this.readJson(file, null);
      if (!manifest) continue;
      this.writeJson(file, { ...manifest, vehicleId: vehicle.id, vehicle: vehicle.name, vehicleSnapshot: snapshot, updatedAt: new Date().toISOString() });
    }
    return refs;
  }

  save(payload = {}) {
    const vehicles = this.list();
    const index = payload.id ? vehicles.findIndex(vehicle => vehicle.id === payload.id) : -1;
    const existing = index >= 0 ? vehicles[index] : {};
    const vehicle = normalizeVehicle(payload, existing);
    if (vehicle.vin) {
      const duplicate = vehicles.find(item => item.id !== vehicle.id && item.vin && item.vin === vehicle.vin);
      if (duplicate) throw new Error(`That VIN is already assigned to ${duplicate.name}.`);
    }
    if (index >= 0) vehicles[index] = vehicle; else vehicles.unshift(vehicle);
    this.writeJson(this.vehiclesFile(), vehicles);
    const projects = this.syncProjects(vehicle, existing.name || '');
    this.appendActivity(index >= 0 ? 'vehicle-updated' : 'vehicle-created', { id: vehicle.id, name: vehicle.name, linkedProjects: projects.length });
    return { ...vehicle, projectCount: projects.length, projectNames: projects.map(item => item.name) };
  }

  favorite(id) {
    const vehicle = this.list().find(item => item.id === id);
    if (!vehicle) throw new Error('Vehicle not found.');
    return this.save({ ...vehicle, favorite: !vehicle.favorite });
  }

  duplicate(id) {
    const vehicle = this.list().find(item => item.id === id);
    if (!vehicle) throw new Error('Vehicle not found.');
    const copy = { ...vehicle, id: null, name: `${vehicle.name} Copy`, favorite: false, vin: '', vinStatus: null, photoPath: '', maintenance: vehicle.maintenance.map(entry => ({ ...entry, id: null })) };
    return this.save(copy);
  }

  delete(id) {
    const vehicles = this.list();
    const vehicle = vehicles.find(item => item.id === id);
    if (!vehicle) return true;
    const refs = this.usage(vehicle);
    if (refs.length) {
      const error = new Error(`${vehicle.name} is linked to ${refs.length} project${refs.length === 1 ? '' : 's'}: ${refs.map(item => item.name).join(', ')}. Reassign those projects before deleting the vehicle.`);
      error.code = 'vehicle-in-use';
      error.projects = refs;
      throw error;
    }
    this.writeJson(this.vehiclesFile(), vehicles.filter(item => item.id !== id));
    if (vehicle.photoPath && path.resolve(vehicle.photoPath).startsWith(path.resolve(this.photosRoot()) + path.sep)) {
      try { fs.unlinkSync(vehicle.photoPath); } catch {}
    }
    this.appendActivity('vehicle-deleted', { id: vehicle.id, name: vehicle.name });
    return true;
  }

  importPhoto(id, sourceFile) {
    const vehicles = this.list();
    const vehicle = vehicles.find(item => item.id === id);
    if (!vehicle) throw new Error('Save the vehicle before adding a photo.');
    if (!sourceFile || !fs.existsSync(sourceFile)) throw new Error('Choose an existing image file.');
    const extension = path.extname(sourceFile).toLowerCase();
    if (!['.jpg', '.jpeg', '.png', '.webp'].includes(extension)) throw new Error('Vehicle photos must be JPG, PNG, or WebP files.');
    const stat = fs.statSync(sourceFile);
    if (stat.size > 15 * 1024 * 1024) throw new Error('Vehicle photos must be smaller than 15 MB.');
    const destination = path.join(this.photosRoot(), `${vehicle.id}${extension === '.jpeg' ? '.jpg' : extension}`);
    fs.copyFileSync(sourceFile, destination);
    if (vehicle.photoPath && path.resolve(vehicle.photoPath) !== path.resolve(destination) && path.resolve(vehicle.photoPath).startsWith(path.resolve(this.photosRoot()) + path.sep)) {
      try { fs.unlinkSync(vehicle.photoPath); } catch {}
    }
    return this.save({ ...vehicle, photoPath: destination });
  }

  removePhoto(id) {
    const vehicle = this.list().find(item => item.id === id);
    if (!vehicle) throw new Error('Vehicle not found.');
    if (vehicle.photoPath && path.resolve(vehicle.photoPath).startsWith(path.resolve(this.photosRoot()) + path.sep)) {
      try { fs.unlinkSync(vehicle.photoPath); } catch {}
    }
    return this.save({ ...vehicle, photoPath: '' });
  }
}

module.exports = {
  VEHICLE_SCHEMA_VERSION,
  cleanText,
  normalizeStringList,
  normalizeMaintenance,
  validateVin,
  normalizeVehicle,
  vehicleSnapshot,
  resolveVehicle,
  projectVehicleFields,
  GarageManager
};
