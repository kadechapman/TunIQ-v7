# TunIQ v1.6.0-dev.2

Beginner-first interface pass.

- Beginner View is the default and hides expert-only controls.
- Advanced View restores raw CLI templates, full-write/recovery buttons, byte comparison, checksum correction, enhanced PID setup, and calibration math tools.
- Added plain-language Start Here cards to Flash, Project Files, Calibration, Checksums, Device Manager, Live Log, and Full AI.
- Added a persistent Interface Detail Level setting.
- No safety gates, file protections, validation requirements, or confirmation requirements were removed.
