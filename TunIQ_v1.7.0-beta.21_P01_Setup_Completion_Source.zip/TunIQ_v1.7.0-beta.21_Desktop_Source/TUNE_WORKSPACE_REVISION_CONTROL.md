# Tune Workspace & Revision Control

## Project isolation

Calibration edits, autosave state, recovery backups, and snapshots live inside the active project. Switching projects loads a different workspace and history.

## Fingerprint binding

An XDF-mapped workspace records:

- project ID
- protected original BIN SHA-256 and size
- XDF SHA-256 and filename
- controller and operating system context

TunIQ stops stale editing or restoration when the current BIN/XDF pair no longer matches.

## Recovery behavior

Before replacing a saved workspace, TunIQ keeps the previous valid copy as `calibration-workspace.backup.json`. If the main JSON becomes unreadable, the backup is restored. When a BIN or XDF fingerprint changes, the old workspace and backup are moved into `Workspace/Recovery` with a reason record.

## Snapshots

Snapshots are project-local JSON records with a name, optional note, timestamp, binding, table count, and modified-cell count. Compare shows cell-level changes. Restore updates the editable workspace only and does not export a BIN or authorize a flash.
