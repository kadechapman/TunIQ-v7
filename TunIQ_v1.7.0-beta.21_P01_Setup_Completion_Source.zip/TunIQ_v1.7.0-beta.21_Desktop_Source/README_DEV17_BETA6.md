# TunIQ v1.7.0-beta.6 — P01 One-Click Commissioning

> Historical release notes. Superseded by v1.7.0-beta.9 Quality of Life; do not use this file as the current workflow.


This release automates the time-consuming P01 commissioning path from controller identification through a successful Test Write.

## Added

- Persistent One-Click session with progress, pause, resume, and recovery state.
- Automatic Identify and complete P01 identity checks.
- Two full reads plus an automatic third tie-breaker read when needed.
- SHA-256 matching and protected-original promotion.
- Exact-OS local XDF discovery and strict unambiguous selection.
- Clean-mapping requirement and OS/XDF/original fingerprint binding.
- Strict automatic parameter commissioning for RPM limit, vehicle-speed limit, and conservative ghost-idle roles.
- Automatic revision creation, supported checksum correction, exact-file validation, and Test Write.
- One separate typed confirmation before the real Calibration Write.

## Deliberate stops

One-Click pauses for missing identity fields, read disagreement, missing or ambiguous XDFs, parser warnings, ambiguous calibration roles, unsupported checksum validation, failed Test Write, or missing power proof. Those stops are safety behavior, not incomplete progress dialogs.

See `P01_ONE_CLICK.md` for the full sequence and limits.
