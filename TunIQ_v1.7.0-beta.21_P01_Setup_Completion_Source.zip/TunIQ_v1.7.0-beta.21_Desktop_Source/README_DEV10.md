# TunIQ v1.2.2-dev.10

## Tune Workflow fixes

- Added a real edit/save path for existing projects.
- Project name, vehicle association, controller, operating system, and notes now save back to `project.json`.
- Editing a project preserves its Originals, Definitions, Revisions, Logs, Backups, BIN, XDF, and revision history.
- Added Edit buttons to saved projects and the active-project card.
- Added clear create/edit states and a Cancel Editing control.
- Selecting a Garage vehicle can fill its saved controller.

## Controller catalog

- Replaced the small fixed controller list with a searchable catalog of 125+ common controllers.
- Includes GM legacy, Gen III, gas ECM, diesel ECM, TCM, marine, Holley, FuelTech, Haltech, MegaSquirt, AEM, Ford, Mopar, Bosch/European, and other standalone systems.
- Controller fields accept custom typed values, so the catalog never blocks an unsupported or uncommon controller.
