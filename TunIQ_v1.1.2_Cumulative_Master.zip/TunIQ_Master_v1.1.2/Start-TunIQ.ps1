$ErrorActionPreference='Continue'
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
$DataDir=Join-Path $Root 'Data'; New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
$LauncherLog=Join-Path $DataDir 'launcher.log'
function L([string]$m){$line="$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff') $m"; Add-Content -LiteralPath $LauncherLog -Value $line -Encoding UTF8; Write-Host $m}
Remove-Item -LiteralPath $LauncherLog -Force -ErrorAction SilentlyContinue
Clear-Host
Write-Host 'TunIQ v1.1.2' -ForegroundColor Green
Write-Host 'Starting the Windows Bridge...' -ForegroundColor Cyan
L "Root: $Root"
$bridge=Join-Path $Root 'bridge\TunIQ-Bridge.ps1'; $offline=Join-Path $Root 'TunIQ_Open_Me.html'
if(-not (Test-Path $bridge)){L 'ERROR: Bridge script is missing.'; if(Test-Path $offline){Start-Process $offline}; Read-Host 'Press Enter to close'; exit 1}
$chosen=$null; $proc=$null
foreach($port in 8788..8797){
  try {
    $busy=Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
    if($busy){L "Port $port is already in use; trying the next port."; continue}
  } catch {}
  L "Trying local port $port..."
  $args=@('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File',$bridge,'-Port',"$port")
  try {$proc=Start-Process powershell.exe -ArgumentList $args -WindowStyle Hidden -PassThru} catch {L "Could not start PowerShell bridge: $($_.Exception.Message)"; break}
  $ok=$false
  foreach($i in 1..40){
    Start-Sleep -Milliseconds 250
    if($proc.HasExited){L "Bridge process exited early with code $($proc.ExitCode)."; break}
    try {$r=Invoke-RestMethod -Uri "http://127.0.0.1:$port/api/bridge/health" -TimeoutSec 1; if($r.ok){$ok=$true;break}} catch {}
  }
  if($ok){$chosen=$port;break}
  if($proc -and -not $proc.HasExited){try {Stop-Process -Id $proc.Id -Force}catch{}}
}
if($chosen){
  L "SUCCESS: Bridge connected on port $chosen."
  Write-Host 'Opening TunIQ...' -ForegroundColor Green
  Start-Process "http://127.0.0.1:$chosen/"
  Start-Sleep -Seconds 2
  exit 0
}
L 'ERROR: The local bridge could not start.'
Write-Host ''
Write-Host 'TunIQ can still open in offline mode, but PC scanning and tool launching will be unavailable.' -ForegroundColor Yellow
Write-Host '[1] Open Offline   [2] Open Logs Folder   [3] Exit'
$choice=Read-Host 'Choose 1, 2, or 3'
switch($choice){
  '1' {if(Test-Path $offline){Start-Process $offline}else{L 'Offline HTML file is missing.'}}
  '2' {Start-Process explorer.exe -ArgumentList @($DataDir)}
  default {}
}
Read-Host 'Press Enter to close'
exit 1
