# TunIQ changelog

## v1.1.0
- Reliable bridge scan/demo/launch feedback and timeout handling
- Official tool download buttons and missing-tools modal
- Bridge launch-mode banner and improved Windows startup readiness check
- All previous cumulative features retained

# TunIQ Changelog

## v1.0.0
- Added functional Guided, Manual, and Full AI modes.
- Added mode-aware AI context and deliberate response pacing.
- Added polished startup timing and animation.
- Retained cumulative v0.9.1 functionality and safety locks.

# TunIQ changelog

## v0.9.1 — Startup Recovery Hotfix
- Prevented the logo splash from permanently covering the app.
- Added an always-available Continue to Dashboard control.
- Added startup module isolation and readable diagnostics.
- Added a structuredClone fallback for older browsers.
- Added an independent load watchdog in both normal and standalone builds.
- Preserved all v0.9 integration proof-of-concept features and safety locks.

# Changelog

## v0.9.0
- Added a Windows PowerShell bridge that avoids a normal-use Node.js dependency.
- Added early PCM Hammer, TunerPro/TunerPro RT, and Universal Patcher installation discovery.
- Added custom executable-path persistence and validation.
- Added controlled desktop-tool launch requests with PID/error logging.
- Added Windows COM-port inventory.
- Added project and Tools folder shortcuts.
- Added integration-report export.
- Kept PCM read/write/flash and automated calibration changes hard locked.

## 0.9.0
- Added read-only tune-file workspace.
- Added SHA-256 fingerprints and raw byte comparison.
- Added changed-region map and local file register.
- Preserved one-file offline launcher and previous cumulative features.
- Kept all controller write/flash functions locked.

# v0.7.0
- Added safe calibration table practice sandbox.
- Added editable example Spark, VE, and fan-command tables.
- Added undo, baseline comparison, local snapshots, guided explanations, and practice JSON export.
- Preserved hardware write and flash locks.

# Changelog

## 0.6.0
- Added one-click Windows offline launcher.
- Added START_HERE guide and no-install opening instructions.
- Clarified optional Node.js backend and bridge launchers.
- Preserved all cumulative features and write locks through Wave 5.


## 0.5.0
- Added cumulative Wave 5 bridge foundation.
- Added local-agent health endpoint with hard write lock.
- Added bridge UI, demo, preflight checklist, logs, and report export.
- Added one-file offline launcher.

# Changelog

## v0.4.0 — Wave 4 cumulative master

Contains all implemented functionality from Waves 1–4 in one project.

### Wave 4 additions
- Scanner workspace with simulated live data
- CSV replay and recording export
- DTC workspace and local explanations
- Experimental read-only ELM327 Web Serial path
- Session logging and scanner safety boundaries

### Included from Wave 3
- Multiple vehicle profiles and active-build memory
- Persistent AI conversations and answer modes
- Build planner, compatibility review, task and cost tracking
- Searchable knowledge base and data backup/restore

### Included from Wave 2
- Guided onboarding and vehicle profile editor
- CSV datalog analysis and sample log
- Optional secure Node.js AI backend
- Readiness and safety checks

### Included from Wave 1
- Dashboard and responsive navigation
- Garage, AI, Tune Studio, and Settings foundations
- TunIQ visual identity and GitHub-ready structure

### Locked for safety
- PCM Hammer control
- BIN reading or writing
- Calibration editing and checksums
- Code clearing and controller flashing
- Automatic tuning


## v1.1.2
- Fixed malformed embedded logo markup.
- Fixed bridge UI being stuck on launch-mode checking.
- Serve the standalone app from the local PowerShell bridge for same-origin communication.
- Updated the launcher to open the local app URL only after health verification.
- Preserved browser-only fallback and all write locks.

## v1.1.2
- Replaced the fragile HttpListener bridge with a loopback TcpListener implementation.
- Added automatic fallback across ports 8788-8797.
- Added launcher and bridge logs in the Data folder.
- Added an offline recovery menu when the bridge cannot start.
- Added OPEN_TUNIQ_DEBUG.bat so startup errors remain visible.
- Preserved all PCM write and flash locks.
