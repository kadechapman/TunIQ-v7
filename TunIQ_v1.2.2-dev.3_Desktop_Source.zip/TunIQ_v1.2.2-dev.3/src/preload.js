const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('tuniq', {
  getBootstrap: () => ipcRenderer.invoke('app:get-bootstrap'),
  saveProfile: (payload) => ipcRenderer.invoke('profile:save', payload),
  setAiMode: (mode) => ipcRenderer.invoke('settings:set-ai-mode', mode),
  scanTools: () => ipcRenderer.invoke('bridge:scan-tools'),
  chooseTool: (key) => ipcRenderer.invoke('bridge:choose-tool', key),
  launchTool: (key) => ipcRenderer.invoke('bridge:launch-tool', key),
  openDataFolder: () => ipcRenderer.invoke('system:open-data-folder'),
  createProject: (payload) => ipcRenderer.invoke('project:create', payload),
  listProjects: () => ipcRenderer.invoke('project:list'),
  exportDiagnostics: () => ipcRenderer.invoke('diagnostics:export'),
  openExternal: (url) => ipcRenderer.invoke('system:open-external', url),
  listVehicles: () => ipcRenderer.invoke('vehicle:list'),
  saveVehicle: (payload) => ipcRenderer.invoke('vehicle:save', payload),
  deleteVehicle: (id) => ipcRenderer.invoke('vehicle:delete', id),
  setActiveProject: (id) => ipcRenderer.invoke('project:set-active', id),
  listActivity: () => ipcRenderer.invoke('activity:list')
});
