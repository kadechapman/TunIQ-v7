# TunIQ v1.2.2-dev.2

A visual and functional rebuild of the Electron desktop prototype.

## Windows
1. Extract the ZIP fully.
2. Double-click `INSTALL_AND_RUN_WINDOWS.bat` the first time.
3. Use `START_TUNIQ_WINDOWS.bat` afterward.

## Added in dev.2
- Rich icon-based navigation and dashboard
- Garage, Tune Files, Calibration Sandbox, and Diagnostics pages
- Official download buttons for PCM Hammer, TunerPro, and Universal Patcher
- Tool status cards with Configure, Download, and Launch actions
- Scanner demo status strip and animated gauges
- Expanded project workflow with controller and operating-system fields
- Guided/manual/full-AI mode descriptions
- More inviting empty states, badges, progress indicators, and quick actions

## Safety
PCM write/flash controls remain disabled until controller and file validation are implemented.
