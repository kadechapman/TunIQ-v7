let state={profile:null,settings:{},tools:{},vehicles:[],projects:[],activity:[],activeProject:null,editingProjectId:null,calibration:null,calHistory:[],workspace:null,aiIntake:null,aiPlan:null,tuneLibrary:[],communityPosts:[],devices:[],device:null,liveLogs:[],logSession:null,logAnalysis:null,sensorProfiles:{},flash:null,validation:null,patchPreview:null,aiProposals:[],currentProposal:null,goalRequests:[],goalProposal:null,p01:null,p01Auto:null,p01Evidence:null,beta:null,updates:null,lastCompletedLog:null};let livePollTimer=null;let livePolling=false;const livePoints=[];
const $=s=>document.querySelector(s);const $$=s=>[...document.querySelectorAll(s)];
const CONTROLLER_CATALOG=[
  ['GM OBD-I / Legacy',['1227747','1228746','16168625','16197427','16196395','16188051 LT1','16214399 LT1']],
  ['GM Gen III PCM',['P01','P59','P04','P06','P08','P10','P11','P12']],
  ['GM Gas ECM',['E37','E38','E39','E39A','E40','E55','E60','E67','E69','E77','E78','E80','E82','E84','E88','E90','E92','E92A','E99']],
  ['GM Diesel ECM',['E35A','E35B','E41','E46','E54','E86','E93']],
  ['GM Transmission',['T42','T43','T76','T77','T87','T87A','T93','T93A']],
  ['GM Marine / Industrial',['MEFI-1','MEFI-2','MEFI-3','MEFI-4','MEFI-4B','MEFI-5','MEFI-6','Delphi E67 Marine']],
  ['Holley EFI',['Terminator X','Terminator X Max','Holley HP EFI','Holley Dominator EFI','Sniper EFI','Sniper 2 EFI']],
  ['FuelTech',['FT450','FT550','FT550LITE','FT600','FT700','FT700PLUS']],
  ['Haltech',['Elite 550','Elite 750','Elite 1500','Elite 2000','Elite 2500','Nexus R3','Nexus R5','Nexus VCU']],
  ['MegaSquirt',['MS1','MS2','MS3','MS3X','MS3Pro Mini','MS3Pro EVO','MS3Pro Ultimate','Gold Box']],
  ['AEM',['EMS Series 1','EMS Series 2','Infinity 506','Infinity 508','Infinity 710']],
  ['Ford',['EEC-IV','EEC-V','Spanish Oak','Black Oak','PowerPC','Copperhead','Continental EMS24xx','Bosch MG1 Ford']],
  ['Mopar',['SBEC','JTEC','JTEC+','NGC3','NGC4','GPEC2','GPEC2A','GPEC3','GPEC4','GPEC5']],
  ['Bosch / European',['ME7','MED9','MED17','EDC15','EDC16','EDC17','MG1','MD1','MSD80','MSD81','MEVD17']],
  ['Other / Custom',['Motec M1','Motec M4','Motec M8','Link G4+','Link G4X','ECUMaster EMU Black','MaxxECU Street','MaxxECU Race','Speeduino','Custom / Unknown']]
];
function populateControllerCatalog(){const list=$('#controllerOptions');if(!list)return;list.innerHTML=CONTROLLER_CATALOG.flatMap(([family,items])=>items.map(value=>`<option value="${safe(value)}" label="${safe(family)}"></option>`)).join('')}
const safe=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
function showPage(id){$$('.page').forEach(x=>x.classList.toggle('active',x.id===id));$$('.app-sidebar button').forEach(x=>x.classList.toggle('active',x.dataset.page===id));if(id==='sandbox')ensureCalibrationInitialized().catch(showCalibrationFailure);if(['flash','patches','revisions','ai','files','fullai','devices','scanner'].includes(id))refreshWorkspace(true).catch(()=>{});if(id==='fullai')loadAiWorkspace().catch(error=>showFullAiError(error));if(id==='tunes')loadTuneLibrary().catch(error=>alert(error.message));if(id==='community')loadCommunityPosts().catch(error=>alert(error.message));if(id==='devices')loadDeviceManager().catch(error=>showDeviceMessage(error.message,true));if(id==='scanner')loadLiveWorkspace().catch(error=>showLogMessage(error.message,true));if(id==='beta')loadBetaCenter().catch(error=>showBetaMessage(error.message,true));if(id!=='scanner'&&!state.logSession)stopLivePolling();}
function modeName(v){return v==='full-ai'?'Full AI':v==='manual'?'Manual':'Guided'}
function detailName(v){return v==='advanced'?'Advanced':'Beginner'}
function supportLabel(status){return status==='verified'?'Verified':status==='experimental'?'Experimental':'Unsupported'}
function supportClass(status){return status==='verified'?'verified':status==='experimental'?'experimental':'unsupported'}
function updateHeader(){const m=state.settings.aiMode||'guided',detail=state.settings.detailLevel||'beginner';$('#modeBtn').textContent=modeName(m).toUpperCase();$('#modeSelect').value=m;if($('#detailSelect'))$('#detailSelect').value=detail;if($('#detailBadge'))$('#detailBadge').textContent=`${detailName(detail).toUpperCase()} VIEW`;$('#settingsProfile').textContent=state.profile?`${state.profile.name} — ${state.profile.email}`:'No profile configured';document.body.classList.remove('mode-guided','mode-manual','mode-full-ai','detail-beginner','detail-advanced');document.body.classList.add(`mode-${m}`,`detail-${detail}`);updateModeDescription();updateDetailDescription();updateActiveProject();renderTunePath();}
function updateModeDescription(){const m=$('#modeSelect').value;$('#modeDescription').textContent={guided:'Guided mode explains each step, shows safety checks, and recommends the next action.',manual:'Manual mode keeps prompts minimal and leaves workflow choices to you.','full-ai':'Full AI mode collects the complete build, creates a project-specific diagnostic and tuning plan, and executes only changes you approve. Controller writing always requires confirmation.'}[m]||''}
function updateDetailDescription(){const el=$('#detailDescription');if(!el)return;const d=$('#detailSelect')?.value||state.settings.detailLevel||'beginner';el.textContent=d==='advanced'?'Shows backend commands, raw validation data, checksum tools, enhanced PID setup, and expert controls.':'Recommended. Uses plain language, hides expert-only controls, and keeps the next safe action visible.'}
function updateActiveProject(){const text=state.activeProject?`Active project: ${state.activeProject.name}`:'No active project selected';$('#activeProjectBridge').textContent=text;$('#activeProjectCard').innerHTML=state.activeProject?`<b>● ACTIVE: ${safe(state.activeProject.name)}</b><small>${safe(state.activeProject.vehicle||'No vehicle')} • ${safe(state.activeProject.controller||'Unknown controller')}${state.activeProject.os?` • OS ${safe(state.activeProject.os)}`:''}</small>${state.activeProject.notes?`<p>${safe(state.activeProject.notes)}</p>`:''}<button id="editActiveProject" class="ghost">Edit Active Project</button>`:'No active project';const edit=$('#editActiveProject');if(edit)edit.onclick=()=>beginProjectEdit(state.activeProject);renderWorkspaceStrip();}
const toolsMeta={pcmHammer:{name:'PCM Hammer',icon:'🔨',desc:'Backend connection for controller identification, reads, and future controlled writes',url:'https://github.com/PcmHammer/PcmHammer/releases',page:'flash',openLabel:'Open TunIQ Flash'},tunerPro:{name:'TunerPro / XDF',icon:'📊',desc:'XDF-compatible definitions and calibration editing inside TunIQ',url:'https://www.tunerpro.net/downloadApp.htm',page:'sandbox',openLabel:'Open TunIQ Calibration'},universalPatcher:{name:'Universal Patcher',icon:'🧩',desc:'Checksum and patch analysis routed through TunIQ Patches',url:'https://universalpatcher.net/download/',page:'patches',openLabel:'Open TunIQ Patches'}};
function renderTools(){
  const container=$('#toolCards');
  container.innerHTML='';
  for(const key of Object.keys(toolsMeta)){
    const meta=toolsMeta[key],toolPath=typeof state.tools[key]==='string'&&state.tools[key].trim()?state.tools[key]:null;
    const card=document.createElement('article');
    card.className=`tool-card ${toolPath?'found':''}`;
    card.innerHTML=`<div class="tool-icon">${meta.icon}</div><h3>${meta.name}</h3><div class="tool-status ${toolPath?'ok':'bad'}">${toolPath?'● ADAPTER READY':'○ ADAPTER NOT FOUND'}</div><p>${meta.desc}</p><div class="tool-path">${safe(toolPath||'No valid executable path detected')}</div><div class="tool-actions"><button class="download" data-download="${key}">⇩ Download</button><button class="ghost" data-browse="${key}">Browse</button><button class="ghost" data-verify="${key}">Verify</button><button class="launch native-open" data-open-native="${key}">${meta.openLabel}</button></div><small class="native-route-note">Stays inside the TunIQ window.</small>`;
    container.appendChild(card);
  }
  $$('[data-download]').forEach(button=>button.onclick=async()=>{
    try{await window.tuniq.openExternal(toolsMeta[button.dataset.download].url)}catch(error){status(error.message,true)}
  });
  $$('[data-browse]').forEach(button=>button.onclick=async()=>{
    try{
      const selected=await window.tuniq.chooseTool(button.dataset.browse);
      if(selected){state.tools[button.dataset.browse]=selected;renderTools();await refreshWorkspace(true);status(`${toolsMeta[button.dataset.browse].name} verified and configured.`)}
    }catch(error){status(error.message,true)}
  });
  $$('[data-verify]').forEach(button=>button.onclick=async()=>{
    const key=button.dataset.verify;
    try{
      const result=await window.tuniq.verifyTool(key);
      state.tools[key]=result.path;
      renderTools();
      await refreshWorkspace(true);
      status(result.valid?`${toolsMeta[key].name} path verified.`:`${toolsMeta[key].name} was not found at the saved path. Use Scan or Browse.`,!result.valid);
    }catch(error){status(error.message,true)}
  });
  $$('[data-open-native]').forEach(button=>button.onclick=()=>{
    const key=button.dataset.openNative;
    const meta=toolsMeta[key];
    showPage(meta.page);
    status(`${meta.name} routed to ${meta.openLabel.replace('Open ','')}. No external application window was opened.`);
  });
}
function status(t,bad=false){$('#bridgeStatus').textContent=t;$('#bridgeStatus').className=bad?'bad':''}

function formatBytes(value){const n=Number(value)||0;if(n<1024)return `${n} B`;if(n<1024*1024)return `${(n/1024).toFixed(1)} KB`;return `${(n/1024/1024).toFixed(1)} MB`}
function renderWorkspaceStrip(){
  const active=state.workspace?.activeProject||state.activeProject;
  $('#workspaceProject').textContent=active?.name||'No project selected';
  $('#workspaceController').textContent=active?.controller?`${active.controller}${active.os?` / OS ${active.os}`:' / OS auto-detect'}`:'Not configured';
  $('#workspaceBin').textContent=active?.binInfo?.name||'Not loaded';
  $('#workspaceXdf').textContent=active?.xdfInfo?.name||'Not loaded';
  const support=state.beta?.support?.flashing;const supportEl=$('#workspaceSupport');if(supportEl){supportEl.textContent=support?supportLabel(support.status):'Not evaluated';supportEl.className=support?`support-${supportClass(support.status)}`:'';}
}
function compactTunePathSteps(steps){
  if(!steps.length)return [];
  let currentIndex=steps.findIndex(step=>step.status==='current');
  if(currentIndex<0){
    const firstIncomplete=steps.findIndex(step=>step.status!=='complete');
    currentIndex=firstIncomplete>=0?firstIncomplete:steps.length-1;
  }
  const previous=[...steps.slice(0,currentIndex)].reverse().find(step=>step.status==='complete')||{id:'desktop-ready',title:'TunIQ workspace ready',description:'Desktop core and project storage are online',page:'dashboard',target:'#dashboard',status:'complete',synthetic:true};
  const current={...steps[currentIndex],status:'current'};
  const nextSource=steps.slice(currentIndex+1).find(step=>step.status!=='complete')||steps[Math.min(steps.length-1,currentIndex+1)];
  const next=nextSource&&nextSource.id!==current.id?{...nextSource,status:'locked'}:{id:'safety-lock',title:'Verify the result and record a follow-up log',description:'After a confirmed flash, re-identify the controller and record the same test conditions',page:'flash',target:'#flashWriteCalibration',status:'locked',synthetic:true};
  return [previous,current,next];
}
function renderDashboard(){
  const workspace=state.workspace||{},active=workspace.activeProject||state.activeProject;
  const current=workspace.tunePath?.steps?.find(step=>step.status==='current')||workspace.tunePath?.steps?.find(step=>step.status!=='complete');
  $('#dashProjectTitle').textContent=active?.name||'No active project';
  $('#dashProjectSummary').textContent=active?`${active.vehicle||'Unassigned vehicle'} · ${active.controller||'Controller pending'}${active.os?` · OS ${active.os}`:' · OS will auto-detect'}`:'Create or activate a tune project to begin.';
  $('#dashVehicle').textContent=active?.vehicle||'Not assigned';
  $('#dashController').textContent=active?.controller?`${active.controller}${active.os?` / OS ${active.os}`:' / OS auto-detect'}`:'Not selected';
  const hasBin=Boolean(active?.binInfo),hasXdf=Boolean(active?.xdfInfo&&!active.xdfInfo.error);
  $('#dashFiles').textContent=hasBin&&hasXdf?'BIN + XDF ready':hasBin?'BIN ready · XDF needed':hasXdf?'XDF ready · BIN needed':'BIN and XDF not loaded';
  $('#dashReadiness').textContent=active?`${workspace.tunePath?.progress||0}% complete`:'Waiting for project';
  $('#dashNextTitle').textContent=current?.title||'Review the active workspace';
  $('#dashNextDescription').textContent=current?.description||'TunIQ will keep your next required action here.';
  const continueButton=$('#dashContinue');
  continueButton.onclick=()=>current?goToTuneStep(current):showPage('workflow');
}
function renderTunePath(){
  const panel=$('#tunePathPanel'),steps=state.workspace?.tunePath?.steps||[];
  if(!panel)return;
  const compact=compactTunePathSteps(steps);
  const current=steps.find(step=>step.status==='current');
  const currentIndex=current?steps.findIndex(step=>step.id===current.id):-1;
  $('#tunePathProgress').textContent=currentIndex>=0?`${currentIndex+1} / ${steps.length}`:`${state.workspace?.tunePath?.progress||0}%`;
  $('#tunePathSummary').textContent=current?`Current: ${current.title}`:steps.length?'Required setup complete. Review validation and flash preparation.':'Create or activate a project to begin.';
  $('#tunePathSteps').innerHTML=compact.length?compact.map(step=>`<button class="tune-step ${step.status}" ${step.status==='locked'?'disabled':''} data-tune-step="${safe(step.id)}"><span class="step-star">${step.status==='complete'?'✓':step.status==='locked'?'🔒':'★'}</span><span><strong>${safe(step.title)}</strong><small>${safe(step.description)}</small></span><em>${step.status==='current'?'DO NOW':step.status.toUpperCase()}</em></button>`).join(''):'<p class="muted">Workspace steps are loading…</p>';
  $$('[data-tune-step]').forEach(button=>button.onclick=()=>{const step=compact.find(item=>item.id===button.dataset.tuneStep);if(step&&step.status!=='locked')goToTuneStep(step)});
  $$('[data-guide-nav]').forEach(button=>button.classList.toggle('guide-current',button.dataset.guideNav===current?.id||((current?.id==='original'||current?.id==='definition')&&button.dataset.page==='files')));
  renderDashboard();
}
function goToTuneStep(step){showPage(step.page);setTimeout(()=>{const target=document.querySelector(step.target);if(target){target.scrollIntoView({behavior:'smooth',block:'center'});target.classList.remove('guided-target');void target.offsetWidth;target.classList.add('guided-target');setTimeout(()=>target.classList.remove('guided-target'),2400)}},180)}
function populateRevisionSelects(){
  const revisions=state.workspace?.files?.revisions||[];
  const options='<option value="">'+(revisions.length?'Select latest or choose a revision':'No revisions exported')+'</option>'+revisions.map(file=>`<option value="${safe(file.path)}">${safe(file.name)}</option>`).join('');
  for(const id of ['#flashRevision','#patchRevision']){const select=$(id);if(!select)continue;const previous=select.value;select.innerHTML=options;if(revisions.some(file=>file.path===previous))select.value=previous;else if(revisions[0])select.value=revisions[0].path;}
}
function flashCapabilityName(key){return {readProperties:'Read Properties',read:'Read',testWrite:'Test Write',writeCalibration:'Write Calibration',writeFull:'Write Full',recovery:'Recovery'}[key]||key}
function renderP01Commissioning(){
  const panel=$('#p01CommissionPanel'),p01=state.p01;
  if(!panel)return;
  panel.classList.toggle('hidden',!p01?.applicable);
  if(!p01?.applicable)return;
  const badge=$('#p01CommissionBadge');
  badge.className=p01.readyForWrite?'ready':p01.readMismatch?'blocked':'';
  badge.textContent=p01.readyForWrite?'WRITE PROOF COMPLETE':p01.readyForAi?'AI READY · WRITE NOT PROVEN':p01.readMismatch?'READS DO NOT MATCH':'COMMISSIONING REQUIRED';
  const blockers=p01.readyForAi?[]:(p01.aiBlockers||p01.blockers||[]);
  $('#p01CommissionSummary').innerHTML=p01.readyForWrite?`<b>This exact P01 and revision passed every commissioning gate.</b><br>OS ${safe(p01.identity?.os||'unknown')} · Service ${safe(p01.identity?.serviceNumber||'unknown')} · protected original ${safe((p01.canonicalReadSha256||'').slice(0,16))}… · Test Write verified.`:p01.readyForAi?`<b>Full AI is unlocked for this exact P01 read and confirmed OS-bound XDF.</b><br>${p01.parameterMap?'Requested parameters are commissioned.':'Build an action sheet, confirm its exact P01 parameters, then rebuild it.'} Validate the revision and pass Test Write before Calibration Write.`:`<b>TunIQ will not tune or write this P01 yet.</b><br>${blockers.map(item=>safe(item)).join('<br>')}`;
  $('#p01CommissionSteps').innerHTML=(p01.steps||[]).map((step,index)=>`<article class="p01-step ${step.complete?'complete':''} ${step.error?'error':''}"><i>${step.complete?'✓':step.error?'!':index+1}</i><div><b>${safe(step.title)}</b><small>${safe(step.detail||'Waiting')}</small></div></article>`).join('');
}

function p01AutoConfirmations(){return {valvetrainVerified:Boolean($('#p01AutoValvetrain')?.checked),tireRatingMph:Number($('#p01AutoTireRating')?.value)||null,drivelineVerified:Boolean($('#p01AutoDriveline')?.checked),brakesVerified:Boolean($('#p01AutoBrakes')?.checked),closedCourse:Boolean($('#p01AutoClosedCourse')?.checked),ghostCamRisksAccepted:Boolean($('#p01AutoGhostRisks')?.checked)}}
function p01AutoPayload(){return {request:$('#p01AutoRequest')?.value.trim()||'',confirmations:p01AutoConfirmations(),device:$('#flashInterface')?.value.trim()||'',voltage:$('#flashVoltage')?.value?Number($('#flashVoltage').value):undefined,benchPowerConfirmed:Boolean($('#flashBenchPower')?.checked),exactXdfAuthorization:Boolean($('#p01AutoExactXdf')?.checked),autoMapAuthorized:Boolean($('#p01AutoMap')?.checked),autoRevisionAuthorized:Boolean($('#p01AutoRevision')?.checked),testWriteAuthorized:Boolean($('#p01AutoTestWrite')?.checked)}}
function p01AutoPhaseLabel(phase){return ({idle:'Waiting to start',preflight:'Checking PCM Hammer, power, and permissions','read-properties':'Preparing Read Properties','waiting-read-properties':'Reading P01 properties','assisted-readProperties':'Assisted Read Properties — save/import Results','read-1':'Preparing full read 1 of 2','waiting-read-1':'Running full read 1 of 2','read-2':'Preparing full read 2 of 2','waiting-read-2':'Running full read 2 of 2','assisted-read':'Assisted full read — save/import BIN',definition:'Finding and binding the exact OS XDF','goal-map':'Mapping requested calibration cells','create-revision':'Creating protected AI revision','test-write':'Preparing Test Write','waiting-test-write':'Running PCM Hammer Test Write','assisted-testWrite':'Assisted Test Write — save/import Results','ready-to-write':'Guided setup complete','waiting-write':'Writing calibration — do not disconnect','write-complete':'Calibration write complete',failed:'Guided setup stopped on an error',cancelled:'Guided setup stopped'})[phase]||String(phase||'Waiting').replace(/-/g,' ')}
function renderP01Auto(auto=state.p01Auto){const box=$('#p01AutoBadge');if(!box)return;auto=auto||{status:'idle',phase:'idle',progress:0,messages:[]};state.p01Auto=auto;if(auto.p01){state.p01=auto.p01;if(state.workspace)state.workspace.p01=auto.p01}const phase=auto.phase||'idle',progress=Math.max(0,Math.min(100,Number(auto.progress)||0)),running=auto.status==='running',ready=phase==='ready-to-write',done=phase==='write-complete',blocked=auto.status==='paused'||['failed','cancelled'].includes(phase);box.textContent=done?'WRITE COMPLETE':ready?'READY TO WRITE':running?'RUNNING':blocked?'PAUSED':'IDLE';box.className=ready||done?'ready':blocked?'blocked':'';$('#p01AutoPhase').textContent=p01AutoPhaseLabel(phase);$('#p01AutoPercent').textContent=`${progress}%`;$('#p01AutoProgressBar').style.width=`${progress}%`;const revision=auto.revision?.name||auto.revision?.path?.split(/[\\/]/).pop()||'';const blocker=auto.blocker?`<br><b>Stopped:</b> ${safe(auto.blocker)}`:'';$('#p01AutoSummary').innerHTML=`<b>${safe(p01AutoPhaseLabel(phase))}</b>${revision?`<br>Revision: ${safe(revision)}`:''}${auto.appliedCells?`<br>Applied mapped cells: ${safe(auto.appliedCells)}`:''}${blocker}`;const messages=Array.isArray(auto.messages)?auto.messages.slice(-12):[];$('#p01AutoMessages').innerHTML=messages.length?messages.map(item=>`<article class="${safe(item.level||'info')}"><b>${safe(new Date(item.at||Date.now()).toLocaleTimeString())}</b><span>${safe(item.text||item.message||'')}</span></article>`).join(''):'<p class="muted">No automation activity yet.</p>';$('#p01AutoStart').disabled=running||ready;$('#p01AutoResume').disabled=running||ready||done||phase==='idle';$('#p01AutoCancel').disabled=!running;$('#p01AutoChooseXdf').classList.toggle('hidden',!(auto.stop?.code==='needs-xdf'||auto.stop?.code==='xdf-warnings'));$('#p01AutoWriteBox').classList.toggle('hidden',!ready);if(ready){const project=auto.activeProject?.name||state.activeProject?.name||'Project';$('#p01AutoWriteSummary').textContent=`The exact revision passed validation and Test Write. Type WRITE ${project} to authorize the separate real Calibration Write.`;$('#p01AutoWriteConfirmation').placeholder=`WRITE ${project}`}renderP01Commissioning()}
async function startP01Auto(){if(!confirm('TunIQ will run Read Properties on the connected P01, perform two full reads, compare and protect the original, bind an exact-OS XDF, create the requested revision, validate it, and run Test Write. It will stop rather than guess, and it will not perform the final real write without another confirmation. Continue?'))return;try{state.p01Auto=await window.tuniq.startP01Auto(p01AutoPayload());renderP01Auto()}catch(error){alert(error.message)}}
async function resumeP01Auto(){try{state.p01Auto=await window.tuniq.resumeP01Auto(p01AutoPayload());renderP01Auto()}catch(error){alert(error.message)}}
async function chooseP01AutoXdf(){try{const result=await window.tuniq.chooseP01AutoXdf();if(result){state.p01Auto=result;renderP01Auto()}}catch(error){alert(error.message)}}
async function cancelP01Auto(){if(!confirm('Stop Guided Automatic P01 Setup? A critical erase/write phase cannot be cancelled safely.'))return;try{state.p01Auto=await window.tuniq.cancelP01Auto();renderP01Auto()}catch(error){alert(error.message)}}
async function writeP01Auto(){const project=state.p01Auto?.activeProject?.name||state.activeProject?.name||'Project';if(!confirm(`This starts a real Calibration Write to the connected P01. Keep regulated power and the interface connected. Continue only after Test Write passed for this exact revision.`))return;try{state.p01Auto=await window.tuniq.writeP01Auto({confirmation:$('#p01AutoWriteConfirmation').value.trim(),device:$('#flashInterface').value.trim(),voltage:$('#flashVoltage').value?Number($('#flashVoltage').value):undefined,benchPowerConfirmed:$('#flashBenchPower').checked});renderP01Auto()}catch(error){alert(error.message||`Type exactly WRITE ${project}.`)}}

async function refreshP01ForSelectedRevision(){
  if(!state.p01?.applicable)return;
  try{state.p01=await window.tuniq.getP01Commissioning($('#flashRevision')?.value||null);if(state.workspace)state.workspace.p01=state.p01;renderP01Commissioning();renderFlashWorkspace()}catch(error){$('#p01CommissionSummary').textContent=error.message}
}
function renderFlashWorkspace(){
  const workspace=state.workspace||{},active=workspace.activeProject,flash=workspace.flash||workspace.integrations?.pcmHammer||state.flash||{},caps=flash.capabilities||{},validation=workspace.validation;
  state.flash=flash;state.validation=validation;state.p01=workspace.p01||state.p01;
  const betaSupport=state.beta?.support?.flashing||{status:'unsupported',note:'Support not evaluated'};const betaPrefs=state.beta?.preferences||{};const betaAccepted=Boolean(state.beta?.agreementAccepted);const experimentalWriteAllowed=betaSupport.status==='experimental'&&betaPrefs.allowExperimentalHardware&&(state.settings.detailLevel||'beginner')==='advanced';const genericWriteAllowed=betaSupport.status==='verified'||experimentalWriteAllowed;
  $('#flashProjectState').textContent=active?'Ready':'Missing';$('#flashProjectDot').className=active?'green':'amber';
  $('#flashBinState').textContent=active?.binInfo?.name||'Missing';$('#flashBinDot').className=active?.bin?'green':'amber';
  $('#flashAdapterState').textContent=flash.configured?`CLI ready${flash.probedAt?' / probed':''}`:flash.assistedAvailable?'Assisted app ready':'Not configured';$('#flashToolDot').className=flash.configured?'green':'amber';
  $('#flashToolState').textContent=flash.configured?(flash.executable?.split(/[\\/]/).pop()||'PCM Hammer CLI configured'):'PCM Hammer CLI needs setup';
  const valid=validation&&validation.compatible!==false&&['valid','valid-external'].includes(validation.checksumStatus);
  $('#flashValidationState').textContent=valid?`${validation.checksumStatus} / ${validation.targetFileName}`:'Not validated';$('#flashValidationDot').className=valid?'green':'amber';
  $('#flashSafetyBadge').textContent=flash.session?'OPERATION RUNNING':!betaAccepted?'BETA AGREEMENT REQUIRED':state.p01?.readyForWrite?'P01 COMMISSIONED · WRITE CONFIRMATION REQUIRED':state.p01?.readyForTestWrite?'P01 READY FOR TEST WRITE':betaSupport.status==='unsupported'?'UNSUPPORTED CONTROLLER':betaSupport.status==='experimental'&&!experimentalWriteAllowed?'EXPERIMENTAL · COMMISSION FIRST':valid?'VALIDATED · CONFIRMATION REQUIRED':flash.configured?'READ/PROPERTIES READY':'CAPABILITY CHECK REQUIRED';
  $('#flashInterface').value=flash.device||state.device?.connection?.port||$('#flashInterface').value||'';
  if(state.device?.connection?.voltage&&!$('#flashVoltage').value)$('#flashVoltage').value=Number(state.device.connection.voltage).toFixed(2);
  $('#flashCapabilities').innerHTML=Object.keys(caps).length?Object.entries(caps).map(([key,value])=>`<span class="${value?'ready':'missing'}">${value?'✓':'×'} ${safe(flashCapabilityName(key))}</span>`).join(''):'<span>Probe the CLI to discover supported commands.</span>';
  const templates=flash.templates||{};const templateFields={readProperties:'#flashTemplateIdentify',read:'#flashTemplateRead',testWrite:'#flashTemplateTest',writeCalibration:'#flashTemplateWriteCal',writeFull:'#flashTemplateWriteFull',recovery:'#flashTemplateRecovery'};for(const [key,selector] of Object.entries(templateFields)){const element=$(selector);if(element&&document.activeElement!==element)element.value=Array.isArray(templates[key])?templates[key].join(' '):(templates[key]||'')}
  populateRevisionSelects();renderP01Commissioning();
  const running=Boolean(flash.session);
  for(const [id,key] of [['#flashIdentify','readProperties'],['#flashRead','read'],['#flashTestWrite','testWrite'],['#flashWriteCalibration','writeCalibration'],['#flashWriteFull','writeFull'],['#flashRecovery','recovery']]){const button=$(id);if(button){const isWrite=['testWrite','writeCalibration','writeFull','recovery'].includes(key);let p01Locked=false;let locallyCommissioned=false;if(state.p01?.applicable){if(key==='testWrite'){p01Locked=!state.p01.readyForTestWrite;locallyCommissioned=state.p01.readyForTestWrite}else if(key==='writeCalibration'){p01Locked=!state.p01.readyForWrite;locallyCommissioned=state.p01.readyForWrite}else if(key==='writeFull')p01Locked=!state.p01.readyForWrite;}const operationAllowed=genericWriteAllowed||locallyCommissioned;const needsRevision=['testWrite','writeCalibration','writeFull','recovery'].includes(key);button.disabled=running||!active||!flash.configured||!caps[key]||!betaAccepted||(isWrite&&((needsRevision&&!(state.workspace?.files?.revisions||[]).length)||!operationAllowed||p01Locked));button.title=p01Locked?(state.p01?.writeBlockers||[]).join('\n'):isWrite&&!operationAllowed?betaSupport.note||'This combination is not enabled for public-beta writing.':'';}}
  $('#flashCancel').disabled=!running;
  if(flash.session)renderFlashProgress(flash.session);
  else if(!active)$('#flashConsole').textContent='Create or activate a project first.';
  else if(!flash.configured)$('#flashConsole').textContent='Configure PCM Hammer or PcmHammerCLI.exe in Tool Connections, then probe capabilities.';
}
function renderFlashProgress(session){
  state.flash={...(state.flash||{}),session};
  $('#flashSessionState').textContent=String(session.state||'running').toUpperCase();
  $('#flashPhase').textContent=[session.phase,Number.isFinite(Number(session.voltage))?`${Number(session.voltage).toFixed(2)} V`:null,session.voltageWarning].filter(Boolean).join(' · ');
  $('#flashProgressBar').style.width=`${Math.max(0,Math.min(100,Number(session.progress)||0))}%`;
  const lines=(session.log||[]).slice(-120).map(item=>`[${new Date(item.at).toLocaleTimeString()}] ${item.stream}: ${item.text}`);
  if(session.identity)lines.push('',`Identity: ${JSON.stringify(session.identity,null,2)}`);
  if(session.outputInfo)lines.push('',`Protected read: ${session.outputInfo.name}`,`SHA-256: ${session.outputInfo.sha256}`);
  if(session.verified)lines.push('Verification reported successful by PCM Hammer.');if(session.verificationWarning)lines.push(`SAFETY: ${session.verificationWarning}`);
  $('#flashConsole').textContent=lines.join('\n')||`${session.operation} started…`;
  $('#flashConsole').scrollTop=$('#flashConsole').scrollHeight;
  if(['complete','complete-unverified','failed','cancelled'].includes(session.state))refreshWorkspace(true).catch(()=>{});
}
function renderPatchWorkspace(){
  const workspace=state.workspace||{},active=workspace.activeProject,tool=workspace.integrations?.universalPatcher,validation=workspace.validation;
  $('#patchProjectBadge').textContent=active?.name||'NO PROJECT';
  $('#patchBinState').textContent=active?.binInfo?.sha256?'Fingerprint ready':'Missing';$('#patchBinDot').className=active?.bin?'green':'amber';
  $('#patchToolState').textContent=tool?.configured?'Configured':'Optional / report import works without launch';$('#patchToolDot').className=tool?.configured?'green':'amber';
  $('#patchFileSummary').innerHTML=active?.binInfo?`<b>${safe(active.binInfo.name)}</b><br>${formatBytes(active.binInfo.size)}<br>SHA-256: ${safe(active.binInfo.sha256)}<br>XDF checksums: ${Number(workspace.calibration?.mappingSummary?.checksumCount||0)}`:'Import an original BIN to begin.';
  $('#patchAnalyze').disabled=!active?.binInfo;$('#patchCompare').disabled=!active?.binInfo||!(workspace.files?.revisions||[]).length;$('#patchPreviewBin').disabled=!active?.binInfo;$('#patchImportBin').disabled=!state.patchPreview?.compatible;$('#patchCorrect').disabled=!(workspace.calibration?.mappingSummary?.checksumCount>0)||(workspace.files?.revisions||[]).length===0;
  populateRevisionSelects();
  const checksum=validation?.checksumStatus||'not analyzed',compatible=validation?.compatible;
  $('#patchChecksumState').textContent=checksum;$('#patchChecksumDot').className=['valid','valid-external'].includes(checksum)?'green':checksum==='invalid'?'red':'amber';
  $('#patchLayoutState').textContent=compatible===true?'Compatible':compatible===false?'Mismatch':'Unknown';$('#patchLayoutDot').className=compatible===true?'green':compatible===false?'red':'amber';
  $('#patchReportState').textContent=validation?new Date(validation.validatedAt).toLocaleString():'WAITING';
}
function activityLabel(item){const labels={'project-created':'Project created','project-updated':'Project updated','project-activated':'Project activated','bin-imported':'Original BIN imported','xdf-imported':'XDF imported','xdf-mapping-loaded':'Calibration mapping loaded','bin-exported':'Revision BIN exported','workspace-action-prepared':'Integrated action prepared','calibration-revision':'Calibration snapshot saved','tool-launched':'Compatibility tool launched','device-connected':'Vehicle interface connected','device-disconnected':'Vehicle interface disconnected','live-log-started':'Live log started','live-log-stopped':'Live log analyzed'};return labels[item.type]||String(item.type||'Activity').replace(/-/g,' ')}
function renderRevisionWorkspace(){
  const workspace=state.workspace||{},files=workspace.files?.revisions||[],activity=workspace.activity||[];
  $('#revisionCount').textContent=`${files.length} file${files.length===1?'':'s'}`;
  $('#revisionList').innerHTML=files.length?files.map(file=>`<article><div><b>${safe(file.name)}</b><small>${formatBytes(file.size)} · ${new Date(file.modifiedAt).toLocaleString()}</small></div><span>${safe((file.extension||'file').replace('.','').toUpperCase())}</span></article>`).join(''):'<p class="muted">No exported revisions yet.</p>';
  $('#workspaceActivity').innerHTML=activity.length?activity.slice(0,30).map(item=>`<article><div><b>${safe(activityLabel(item))}</b><small>${new Date(item.at).toLocaleString()}</small></div><span>${safe(item.details?.name||item.details?.projectName||'')}</span></article>`).join(''):'<p class="muted">No project activity recorded.</p>';
}
function renderAiContext(){const workspace=state.workspace||{},active=workspace.activeProject,device=state.device?.connection;$('#aiContext').innerHTML=active?[`Project: ${active.name}`,`Vehicle: ${active.vehicle||'Unassigned'}`,`Controller: ${active.controller||'Unknown'}`,`OS: ${active.os||'Auto-detect pending'}`,`BIN: ${active.binInfo?.name||'Missing'}`,`XDF: ${active.xdfInfo?.name||'Missing'}`,`Adapter: ${device?.adapter||'Disconnected'}`,`Logs: ${(state.liveLogs||[]).length}`,`Revisions: ${workspace.files?.revisions?.length||0}`].map(text=>`<span>${safe(text)}</span>`).join(''):'<span>No active project context.</span>'}
async function refreshWorkspace(silent=false){
  try{
    const workspace=await window.tuniq.getWorkspaceSummary();
    state.workspace=workspace;state.activeProject=workspace.activeProject||null;state.tools=workspace.tools||state.tools;state.device=workspace.device||state.device;state.liveLogs=Array.isArray(workspace.liveLogs)?workspace.liveLogs:state.liveLogs;state.sensorProfiles=workspace.sensorProfiles||state.sensorProfiles;state.flash=workspace.flash||state.flash;state.validation=workspace.validation||null;state.aiProposals=workspace.aiProposals||[];state.beta=workspace.beta||state.beta;state.updates=workspace.updates||state.updates;state.p01=workspace.p01||null;state.p01Auto=workspace.p01Auto||state.p01Auto;
    if(workspace.ai){state.aiIntake=workspace.ai.intake||null;state.aiPlan=workspace.ai.plan||null;}
    renderWorkspaceStrip();renderTunePath();renderP01Auto();renderP01Commissioning();renderFlashWorkspace();renderPatchWorkspace();renderRevisionWorkspace();renderDeviceStatus();renderLiveLogHistory();renderAiContext();renderAiPlan();renderAiProposalWorkspace();renderAiGoalRequest();renderBetaCenter();updateActiveProject();renderTools();
    return workspace;
  }catch(error){if(!silent)status(error.message,true);throw error}
}
async function prepareWorkspaceAction(action){
  const messages={
    'identify-controller':'Controller identification preflight prepared. Confirm ignition state, interface selection, battery support, and controller family before native communication is enabled.',
    'read-original':'Original-read plan prepared. TunIQ will place the result in the protected Originals folder and fingerprint it before any edits are allowed.',
    'analyze-bin':'BIN analysis prepared. TunIQ compares every changed byte and segment, verifies supported XDF checksums, and accepts a Universal Patcher report only when it is bound to this exact BIN fingerprint.'
  };
  const result=await window.tuniq.planWorkspaceAction({action});
  await refreshWorkspace(true);
  return {result,message:messages[action]||'Action prepared.'};
}
function renderVehicles(){const c=$('#garageContent');$('#projectVehicle').innerHTML='<option value="">Choose a Garage vehicle</option>'+state.vehicles.map(v=>`<option value="${safe(v.name)}">${safe(v.name)}${v.engine?` — ${safe(v.engine)}`:''}</option>`).join('');if(!state.vehicles.length){c.innerHTML='<div class="empty-card"><div class="empty-icon">▣</div><h2>No vehicles saved yet</h2><p>Add the Tahoe, OBS, or any LS-powered project. Vehicle profiles carry into future versions and can be selected in Tune Workflow.</p><button id="garageAdd">Create First Vehicle</button></div>';$('#garageAdd').onclick=()=>openVehicleModal();return}c.innerHTML=`<div class="vehicle-grid">${state.vehicles.map(v=>`<article class="vehicle-card"><div class="vehicle-icon">🚘</div><div><p class="eyebrow">${safe(v.controller||'CONTROLLER UNKNOWN')}</p><h3>${safe(v.name)}</h3><p>${safe([v.year,v.make,v.model].filter(Boolean).join(' ')||'Vehicle details not entered')}</p><div class="vehicle-tags"><span>${safe(v.engine||'Engine unknown')}</span>${v.vin?`<span>VIN saved</span>`:''}</div></div><div class="vehicle-actions"><button class="ghost" data-edit-vehicle="${v.id}">Edit</button><button class="danger-btn" data-delete-vehicle="${v.id}">Delete</button></div></article>`).join('')}</div>`;$$('[data-edit-vehicle]').forEach(b=>b.onclick=()=>openVehicleModal(state.vehicles.find(v=>v.id===b.dataset.editVehicle)));$$('[data-delete-vehicle]').forEach(b=>b.onclick=async()=>{const v=state.vehicles.find(x=>x.id===b.dataset.deleteVehicle);if(confirm(`Delete ${v?.name||'this vehicle'}?`)){await window.tuniq.deleteVehicle(b.dataset.deleteVehicle);state.vehicles=await window.tuniq.listVehicles();renderVehicles()}})}
function openVehicleModal(v=null){$('#vehicleForm').reset();$('#vehicleId').value=v?.id||'';$('#vehicleModalTitle').textContent=v?'Edit Vehicle':'Add Vehicle';for(const [id,key] of [['vehicleYear','year'],['vehicleMake','make'],['vehicleName','name'],['vehicleModel','model'],['vehicleEngine','engine'],['vehicleController','controller'],['vehicleVin','vin'],['vehicleNotes','notes']])$('#'+id).value=v?.[key]||'';$('#vehicleError').textContent='';$('#vehicleModal').classList.remove('hidden')}
function closeVehicleModal(){$('#vehicleModal').classList.add('hidden')}
function offlineAnswer(q){
  const lower=q.toLowerCase();
  const workspace=state.workspace||{};
  const active=workspace.activeProject||state.activeProject;
  const current=workspace.tunePath?.steps?.find(step=>step.status==='current');
  const context=active?` Active TunIQ project: ${active.name}, vehicle ${active.vehicle||'unspecified'}, controller ${active.controller||'unspecified'}${active.os?`, OS ${active.os}`:', OS auto-detect pending'}.`:'';
  if(lower.includes('next')||lower.includes('what should i do'))return current?`Your current Tune Path step is <b>${safe(current.title)}</b>. ${safe(current.description)} Open the glowing star beside that step and TunIQ will take you to the correct control.${context}`:`Your required project steps are complete up to the current validation and confirmation gates. Review Patches & Checksums before preparing a flash.${context}`;
  if(lower.includes('file')||lower.includes('loaded')){const bin=active?.binInfo?.name||'no original BIN';const xdf=active?.xdfInfo?.name||'no XDF';return `The shared workspace currently has <b>${safe(bin)}</b> and <b>${safe(xdf)}</b>. Calibration, Patches, Revisions, Flash preparation, and AI context all use this same pair.${context}`}
  if(lower.includes('what')&&lower.includes('tool'))return `TunIQ has recorded ${state.activity.filter(x=>x.type==='tool-launched').length} compatibility-mode legacy tool launches. Standard PCM Hammer, TunerPro/XDF, and Universal Patcher work now routes to native TunIQ tabs without opening separate windows.${context}`;
  if(lower.includes('fuel trim'))return 'Positive fuel trims mean the PCM is adding fuel. Before editing VE or MAF tables, check vacuum leaks, exhaust leaks ahead of the O₂ sensors, fuel pressure, injector data, and MAF cleanliness. Compare both banks: one-bank-only trim usually points to a bank-specific issue.'+context;
  if(lower.includes('fan'))return 'Verify coolant-temperature accuracy first. Use enough separation between fan-on and fan-off temperatures to prevent rapid cycling, confirm thermostat temperature, and verify relay and wiring current capacity.'+context;
  if(lower.includes('knock'))return 'Do not desensitize knock protection first. Verify fuel octane, commanded spark, AFR, coolant temperature, mechanical noise, sensor torque, and harness condition. Log RPM, load, spark, AFR, and knock retard together.'+context;
  if(lower.includes('injector'))return 'Injector tuning needs flow rate versus pressure, offset versus voltage, short-pulse adder, and minimum pulse data. A single lb/hr value is not enough for accurate idle and transient fueling.'+context;
  if(lower.includes('p01')||lower.includes('p59'))return 'P01 and P59 are common Gen III GM PCMs. Support depends on the exact operating system and hardware ID. Preserve a verified original BIN before editing, and match the XDF to the operating system—not just the vehicle year.'+context;
  if(lower.includes('log')||lower.includes('live data')){const latest=(state.liveLogs||[])[0],analysis=state.logAnalysis||latest?.analysis;if(!latest)return `No saved live log is attached to the active project yet. Connect the vehicle interface, open Live Log, choose a profile, and record the exact problem area.${context}`;if(!analysis)return `The latest log is <b>${safe(latest.name||'unnamed')}</b> with ${Number(latest.samples||0)} samples. Open Live Log and analyze it before changing calibration tables.${context}`;const top=(analysis.findings||[])[0];return `The latest AI log review has <b>${safe(analysis.confidence||'limited')}</b> confidence from ${Number(analysis.sampleCount||0)} samples. ${top?`Top finding: <b>${safe(top.title)}</b>. ${safe(top.detail)} ${safe(top.action)}`:'No repeatable problem was identified.'}${context}`;}
  if(lower.includes('full ai')||lower.includes('build plan'))return state.aiPlan?`Your Full AI plan is for <b>${safe(state.aiPlan.goal)}</b> and contains ${state.aiPlan.steps.length} steps. Open Full AI Tuner to review the build intake, safety blocks, and exact sequence.${context}`:`Open Full AI Tuner and enter the engine, transmission, modifications, symptoms, and tune goal. TunIQ will ask for cam specifications when a cam or ghost-cam goal is selected.${context}`;
  if(lower.includes('saved tune')||lower.includes('library'))return `Your local Tune Library currently contains ${(state.tuneLibrary||[]).length} tune package(s). Controller and OS mismatches are blocked before a tune can be copied into an active project's Revisions folder.${context}`;
  if(lower.includes('forum')||lower.includes('community'))return `The Community Hub currently has ${(state.communityPosts||[]).length} local guide or draft post(s). Filters are available for engine, transmission, controller, category, and search terms. Online accounts and cloud moderation are not enabled in this development build.${context}`;
  return `Offline AI now follows TunIQ's active project, controller, OS, BIN, XDF, Tune Path, revision files, and recent project actions.${context} Live vehicle values and direct flashing actions are still being connected behind controlled native adapters.`
}
function resetProjectForm(){
  state.editingProjectId=null;
  $('#projectForm').reset();
  $('#projectId').value='';
  $('#projectFormTitle').textContent='New Project';
  $('#projectFormMode').textContent='CREATE';
  $('#projectSubmit').textContent='＋ Create Protected Project';
  $('#projectCancelEdit').classList.add('hidden');
  $('#projectFormStatus').textContent='New projects receive protected Originals, Definitions, Revisions, Logs, and Backups folders.';
}
function beginProjectEdit(project){
  if(!project)return;
  state.editingProjectId=project.id;
  $('#projectId').value=project.id||'';
  $('#projectName').value=project.name||'';
  $('#projectVehicle').value=project.vehicle||'';
  $('#projectController').value=project.controller||'';
  $('#projectOs').value=project.os||'';
  $('#projectNotes').value=project.notes||'';
  $('#projectFormTitle').textContent='Edit Project';
  $('#projectFormMode').textContent='EDITING';
  $('#projectSubmit').textContent='Save Project Changes';
  $('#projectCancelEdit').classList.remove('hidden');
  $('#projectFormStatus').textContent='Saving updates changes the project manifest only. Existing BINs, XDFs, logs, backups, and revisions stay in place.';
  showPage('workflow');
  $('#projectName').focus();
}
async function loadProjects(){
  const items=await window.tuniq.listProjects();
  state.projects=Array.isArray(items)?items:[];
  $('#projects').innerHTML=state.projects.length?state.projects.map(project=>`<article class="project-card"><div class="project-card-main"><b>⚙ ${safe(project.name)}</b><p>${safe(project.vehicle||'No vehicle')} • ${safe(project.controller||'Controller unknown')}${project.os?` • OS ${safe(project.os)}`:''}</p>${project.notes?`<small class="project-notes">${safe(project.notes)}</small>`:''}<small>${project.updatedAt?`Updated ${new Date(project.updatedAt).toLocaleString()}`:project.createdAt?new Date(project.createdAt).toLocaleString():'Date unavailable'}</small></div><div class="project-card-actions"><button class="edit-project ghost" data-project-id="${safe(project.id)}">Edit</button><button class="activate-project ghost" data-project-id="${safe(project.id)}">${state.activeProject?.id===project.id?'✓ Active':'Set Active'}</button></div></article>`).join(''):'<div class="empty-card compact"><div class="empty-icon">⚙</div><h3>No projects yet</h3><p>Create one on the left. TunIQ will build protected Originals, Definitions, Revisions, Logs, and Backups folders.</p></div>';
  $$('.edit-project').forEach(button=>button.onclick=()=>beginProjectEdit(state.projects.find(project=>project.id===button.dataset.projectId)));
  $$('.activate-project').forEach(button=>button.onclick=async()=>{
    try{
      state.activeProject=await window.tuniq.setActiveProject(button.dataset.projectId);
      updateActiveProject();
      await loadProjects();
      await refreshProjectFiles();
      invalidateCalibration('The active project changed. Load its BIN and XDF before editing or exporting.');
      status(`Active project set to ${state.activeProject.name}. Every tuning workspace tab now uses this project.`);
      await refreshWorkspace(true);
    }catch(error){status(error.message,true)}
  });
}



let calSelection=new Set(),calAnchor=null,calUndo=[],calRedo=[],calClipboard=[];
let calibrationInitialized=false,calibrationInitializing=null,calibrationControlsBound=false;
function clone(v){return JSON.parse(JSON.stringify(v))}
function calKey(r,c){return `${r}:${c}`}
function currentCal(){return state.calibration?.tables?.[state.calibration.activeTable]||null}
function normalizeCalibration(workspace){
  if(!workspace||typeof workspace!=='object'||!workspace.tables||typeof workspace.tables!=='object')throw new Error('Calibration workspace is missing or invalid.');
  const keys=Object.keys(workspace.tables);
  if(!keys.length)throw new Error('Calibration workspace does not contain any tables.');
  if(!workspace.activeTable||!workspace.tables[workspace.activeTable])workspace.activeTable=keys[0];
  workspace.modified=workspace.modified&&typeof workspace.modified==='object'?workspace.modified:{};
  workspace.stock=workspace.stock&&typeof workspace.stock==='object'?workspace.stock:clone(workspace.tables);
  for(const key of keys){
    const table=workspace.tables[key];
    if(!table||!Array.isArray(table.values)||!table.values.length)throw new Error(`Calibration item ${key} does not contain a readable value grid.`);
    if(table.values.length>256)throw new Error(`Calibration item ${key} exceeds the supported 256-row display limit.`);
    const columns=Array.isArray(table.values[0])?table.values[0].length:0;
    if(!columns||columns>256)throw new Error(`Calibration item ${key} has an unsupported column count.`);
    table.values=table.values.map(row=>{
      if(!Array.isArray(row)||row.length!==columns)throw new Error(`Calibration item ${key} contains a non-rectangular value grid.`);
      return row.map(value=>{const numeric=Number(value);if(!Number.isFinite(numeric))throw new Error(`Calibration item ${key} contains a non-numeric value.`);return numeric});
    });
    table.rowHeaders=Array.isArray(table.rowHeaders)&&table.rowHeaders.length===table.values.length?table.rowHeaders:table.values.map((_,i)=>String(i));
    table.colHeaders=Array.isArray(table.colHeaders)&&table.colHeaders.length===columns?table.colHeaders:Array.from({length:columns},(_,i)=>String(i));
  }
  return workspace;
}
function pushCalUndo(){if(!state.calibration)return;calUndo.push(clone(state.calibration));if(calUndo.length>30)calUndo.shift();calRedo=[]}
function markModified(tableKey,r,c){const table=state.calibration?.tables?.[tableKey];if(!table)return;const stock=state.calibration.stock?.[tableKey]?.values?.[r]?.[c];const value=table.values?.[r]?.[c];const key=`${tableKey}:${r}:${c}`;if(Number(value)===Number(stock))delete state.calibration.modified[key];else state.calibration.modified[key]=true}
function validateCalibration(){const table=currentCal(),el=$('#labValidation');if(!table){el.textContent='⚠ No table loaded';el.className='validation-bad';return false}if(table.unsupportedReason){el.textContent=`READ ONLY · ${table.unsupportedReason}`;el.className='validation-bad';return true}let invalid=0;const min=Number(table.min),max=Number(table.max),hasMin=table.min!==null&&table.min!==undefined&&table.min!==''&&Number.isFinite(min),hasMax=table.max!==null&&table.max!==undefined&&table.max!==''&&Number.isFinite(max);for(const row of table.values)for(const value of row){const numeric=Number(value);if(!Number.isFinite(numeric)||(hasMin&&numeric<min)||(hasMax&&numeric>max))invalid++}const range=hasMin||hasMax?` (${hasMin?min:'−∞'}–${hasMax?max:'∞'})`:'';el.textContent=invalid?`⚠ ${invalid} invalid value${invalid===1?'':'s'}${range}`:'✓ Values within defined range';el.className=invalid?'validation-bad':'validation-ok';return invalid===0}
async function persistCalibration(){if(!state.calibration)return;state.calibration=normalizeCalibration(await window.tuniq.saveCalibration(state.calibration));$('#labSaveState').textContent=`Saved ${new Date().toLocaleTimeString()}`}
function renderCalTables(){
  const list=$('#calTableList');if(!state.calibration){list.innerHTML='<p class="muted">Open the Calibration Lab to load tables.</p>';return}
  const active=state.calibration.activeTable,query=String($('#calTableSearch')?.value||'').trim().toLowerCase();
  const entries=Object.entries(state.calibration.tables).filter(([key,t])=>!query||[key,t.name,t.category,t.description,t.unit].some(value=>String(value||'').toLowerCase().includes(query))).slice(0,800);
  const groups=new Map();for(const entry of entries){const category=entry[1].category||'Uncategorized';if(!groups.has(category))groups.set(category,[]);groups.get(category).push(entry)}
  list.innerHTML=entries.length?[...groups.entries()].map(([category,items])=>`<div class="cal-category"><b>${safe(category)}</b>${items.map(([key,t])=>{const rows=Array.isArray(t.values)?t.values.length:0,cols=rows&&Array.isArray(t.values[0])?t.values[0].length:0;return `<button class="cal-table-btn ${key===active?'active':''}" data-cal-table="${safe(key)}"><span>${safe(t.name||key)}</span><small>${rows} × ${cols}${t.unit?` · ${safe(t.unit)}`:''}</small></button>`}).join('')}</div>`).join(''):'<p class="muted">No mapped parameters match this search.</p>';
  $$('[data-cal-table]').forEach(b=>b.onclick=()=>{state.calibration.activeTable=b.dataset.calTable;calSelection.clear();calAnchor=null;renderCalibration()})
}
function renderCalGrid(){
  const table=currentCal(),grid=$('#calGrid');
  if(!table){grid.innerHTML='<tbody><tr><td style="padding:24px">No calibration table is loaded.</td></tr></tbody>';return}
  $('#labTableTitle').textContent=table.name||'Calibration Table';
  $('#labUnit').textContent=table.unit||'TABLE';
  let html='<thead><tr><th class="corner">Row / Axis</th>'+table.colHeaders.map(value=>`<th>${safe(value)}</th>`).join('')+'</tr></thead><tbody>';
  table.values.forEach((row,r)=>{
    html+=`<tr><th>${safe(table.rowHeaders[r]??r)}</th>`+row.map((value,c)=>{
      const selected=calSelection.has(calKey(r,c));
      const modified=state.calibration.modified[`${state.calibration.activeTable}:${r}:${c}`];
      return `<td><input class="cal-cell ${selected?'selected':''} ${modified?'modified':''}" data-r="${r}" data-c="${c}" type="number" step="0.01" value="${safe(value)}" ${table.unsupportedReason?'disabled title="Read-only unsupported XDF definition"':''}></td>`;
    }).join('')+'</tr>';
  });
  grid.innerHTML=html+'</tbody>';
  $$('.cal-cell').forEach(cell=>{
    cell.onmousedown=event=>selectCalCell(event.target,event.shiftKey);
    cell.onfocus=event=>{
      const key=calKey(+event.target.dataset.r,+event.target.dataset.c);
      if(!calSelection.has(key))selectCalCell(event.target,false);
    };
    cell.onchange=async event=>{
      const value=Number(event.target.value);
      if(!Number.isFinite(value)){event.target.value=currentCal().values[+event.target.dataset.r][+event.target.dataset.c];return}
      pushCalUndo();
      const r=+event.target.dataset.r,c=+event.target.dataset.c;
      currentCal().values[r][c]=value;
      markModified(state.calibration.activeTable,r,c);
      validateCalibration();
      renderCalGrid();
      updateCalCount();
      try{await persistCalibration()}catch(error){showCalibrationFailure(error)}
    };
  });
  validateCalibration();
}
function selectCalCell(cell,extend=false){const r=+cell.dataset.r,c=+cell.dataset.c;if(!extend||!calAnchor){calSelection.clear();calAnchor={r,c};calSelection.add(calKey(r,c))}else{calSelection.clear();for(let rr=Math.min(r,calAnchor.r);rr<=Math.max(r,calAnchor.r);rr++)for(let cc=Math.min(c,calAnchor.c);cc<=Math.max(c,calAnchor.c);cc++)calSelection.add(calKey(rr,cc))}$$('.cal-cell').forEach(x=>x.classList.toggle('selected',calSelection.has(calKey(+x.dataset.r,+x.dataset.c))))}
function updateCalCount(){const count=Object.keys(state.calibration?.modified||{}).length;$('#labModifiedCount').textContent=`${count} modified`}
function renderCalHistory(){const items=state.calHistory||[];$('#calHistory').innerHTML=items.length?items.slice(0,8).map(x=>`<article><b>${safe(x.name)}</b><small>${new Date(x.at).toLocaleString()}</small></article>`).join(''):'<p class="muted">No saved revisions yet.</p>'}
function renderCalibration(){
  if(!state.calibration)return;
  normalizeCalibration(state.calibration);
  renderCalTables();
  renderCalGrid();
  updateCalCount();
  renderCalHistory();
  const isXdf=state.calibration.mode==='xdf';
  const sameProject=!isXdf||!state.calibration.projectId||state.calibration.projectId===state.activeProject?.id;
  $('#labSourceBadge').textContent=isXdf?(sameProject?'XDF MAPPED':'OTHER PROJECT WORKSPACE'):'LOCAL WORKSPACE';
  $('#labSourceBadge').classList.toggle('source-warning',!sameProject);
  $('#labExportBin').disabled=!isXdf||!sameProject;
  const summary=state.calibration.mappingSummary;
  if(!sameProject)$('#labSaveState').textContent='Reload BIN + XDF for the active project before exporting';
  else if(summary&&summary.skipped)$('#labSaveState').textContent=`Loaded ${summary.loaded}; ${summary.skipped} oversized mappings skipped for stability`;
}
function invalidateCalibration(message='Reload the active project BIN and XDF to continue.'){
  calibrationInitialized=false;
  calibrationInitializing=null;
  state.calibration=null;
  calSelection.clear();calAnchor=null;calUndo.length=0;calRedo.length=0;
  $('#labSourceBadge').textContent='RELOAD REQUIRED';
  $('#labSourceBadge').classList.add('source-warning');
  $('#labExportBin').disabled=true;
  $('#labTableTitle').textContent='Calibration workspace needs reloading';
  $('#labUnit').textContent='PROJECT CHANGED';
  $('#labValidation').textContent='⚠ Reload BIN + XDF';
  $('#labValidation').className='validation-bad';
  $('#calTableList').innerHTML='<p class="muted">No active mapping loaded.</p>';
  $('#calGrid').innerHTML=`<tbody><tr><td style="padding:24px;white-space:normal">${safe(message)}</td></tr></tbody>`;
  $('#labModifiedCount').textContent='0 modified';
}
function showCalibrationFailure(error){console.error(error);$('#labTableTitle').textContent='Calibration recovery mode';$('#labUnit').textContent='STARTUP PROTECTED';$('#labValidation').textContent='⚠ Workspace could not be loaded';$('#labValidation').className='validation-bad';$('#calGrid').innerHTML=`<tbody><tr><td style="padding:24px;white-space:normal"><b>TunIQ stayed open.</b><br>${safe(error?.message||error)}<br><br>The original workspace is preserved in AppData if recovery was required.</td></tr></tbody>`}
async function applyCalOperation(){if(!calSelection.size)return alert('Select one or more cells first.');const table=currentCal();if(!table)return;const amount=Number($('#labAmount').value);if(!Number.isFinite(amount))return;pushCalUndo();const op=$('#labOperation').value;for(const key of calSelection){const [r,c]=key.split(':').map(Number);let v=Number(table.values[r][c]);if(op==='add')v+=amount;if(op==='subtract')v-=amount;if(op==='multiply')v*=amount;if(op==='percent')v*=1+amount/100;table.values[r][c]=Number(v.toFixed(3));markModified(state.calibration.activeTable,r,c)}renderCalibration();await persistCalibration()}
function bindCalibrationControls(){
  if(calibrationControlsBound)return;
  calibrationControlsBound=true;
  $('#calTableSearch').oninput=renderCalTables;
  $('#labApply').onclick=()=>applyCalOperation().catch(error=>alert(error.message));
  $('#labUndo').onclick=async()=>{try{if(!calUndo.length)return;calRedo.push(clone(state.calibration));state.calibration=calUndo.pop();renderCalibration();await persistCalibration()}catch(error){alert(error.message)}};
  $('#labRedo').onclick=async()=>{try{if(!calRedo.length)return;calUndo.push(clone(state.calibration));state.calibration=calRedo.pop();renderCalibration();await persistCalibration()}catch(error){alert(error.message)}};
  $('#labCopy').onclick=()=>{
    const table=currentCal();if(!table||!calSelection.size)return;
    calClipboard=[...calSelection].map(key=>{const [r,c]=key.split(':').map(Number);return table.values[r][c]});
    navigator.clipboard?.writeText(calClipboard.join('\t')).catch(()=>{});
  };
  $('#labPaste').onclick=async()=>{try{
    const table=currentCal();if(!table||!calSelection.size||!calClipboard.length)return;
    pushCalUndo();let index=0;
    for(const key of calSelection){const [r,c]=key.split(':').map(Number);table.values[r][c]=Number(calClipboard[index%calClipboard.length]);markModified(state.calibration.activeTable,r,c);index++}
    renderCalibration();await persistCalibration();
  }catch(error){alert(error.message)}};
  $('#labSaveRevision').onclick=async()=>{try{
    if(!state.calibration)return;
    const name=prompt('Revision name',`Revision ${(state.calHistory||[]).length+1}`);if(!name)return;
    await persistCalibration();await window.tuniq.createCalibrationRevision({name});state.calHistory=await window.tuniq.listCalibrationHistory();renderCalHistory();
  }catch(error){alert(error.message)}};
  $('#labReset').onclick=async()=>{try{
    if(!state.calibration)return;
    const label=state.calibration.mode==='xdf'?'original imported BIN values':'stock practice values';
    if(!confirm(`Reset every calibration table to the ${label}?`))return;
    pushCalUndo();
    if(state.calibration.mode==='xdf'){
      state.calibration.tables=clone(state.calibration.stock);
      state.calibration.modified={};
      state.calibration.activeTable=Object.keys(state.calibration.tables)[0];
      await persistCalibration();
    }else{
      state.calibration=normalizeCalibration(await window.tuniq.resetCalibration());
    }
    calSelection.clear();calAnchor=null;renderCalibration();
  }catch(error){alert(error.message)}};
}
async function initCalibration(){bindCalibrationControls();state.calibration=normalizeCalibration(await window.tuniq.loadCalibration());state.calHistory=await window.tuniq.listCalibrationHistory();state.calHistory=Array.isArray(state.calHistory)?state.calHistory:[];renderCalibration();calibrationInitialized=true}
async function ensureCalibrationInitialized(){if(calibrationInitialized)return state.calibration;if(calibrationInitializing)return calibrationInitializing;$('#labTableTitle').textContent='Loading calibration workspace…';calibrationInitializing=initCalibration().finally(()=>{calibrationInitializing=null});return calibrationInitializing}

async function refreshProjectFiles(){
  const card=$('#projectFilesCard');
  if(!card)return;
  try{
    const files=await window.tuniq.getProjectFiles();
    state.activeProject=files.active||null;
    updateActiveProject();
    if(!files.active){
      card.className='empty-card compact';
      card.innerHTML='<div class="empty-icon">▤</div><h2>No active project</h2><p>Create or activate a project before importing a BIN or XDF.</p><button id="filesGoWorkflow">Go to Tune Workflow</button>';
      $('#filesGoWorkflow').onclick=()=>showPage('workflow');
      return;
    }
    const binHash=files.bin?.sha256?`${safe(files.bin.sha256.slice(0,16))}…`:'Unavailable';
    const xdfDetail=files.xdf?.error?`Definition warning: ${safe(files.xdf.error)}`:`${Number(files.xdf?.tableCount||0).toLocaleString()} mapped items · ${safe(files.xdf?.title||'')}`;
    card.className='panel project-files';
    card.innerHTML=`<div class="panel-title"><h3>${safe(files.active.name)}</h3><span>${safe(files.active.controller||'Controller unknown')}</span></div><div class="file-status-row"><div><b>Original BIN</b><span>${files.bin?safe(files.bin.name):'Not imported'}</span>${files.bin?`<small>${Number(files.bin.size||0).toLocaleString()} bytes · SHA-256 ${binHash}</small>`:''}</div><i class="${files.bin?'green':'amber'}"></i></div><div class="file-status-row"><div><b>TunerPro XDF</b><span>${files.xdf?safe(files.xdf.name):'Not imported'}</span>${files.xdf?`<small>${xdfDetail}</small>`:''}</div><i class="${files.xdf&&!files.xdf.error?'green':'amber'}"></i></div>${files.bin&&files.xdf&&!files.xdf.error?'<button id="filesLoadLab">Open Mapping in Calibration Lab</button>':''}`;
    const openButton=$('#filesLoadLab');
    if(openButton)openButton.onclick=loadRealCalibration;
  }catch(error){
    card.className='empty-card compact';
    card.innerHTML=`<div class="empty-icon">⚠</div><h2>Project files unavailable</h2><p>${safe(error.message)}</p>`;
  }
}
async function loadRealCalibration(){
  try{
    bindCalibrationControls();
    $('#labTableTitle').textContent='Loading BIN + XDF mapping…';
    state.calibration=normalizeCalibration(await window.tuniq.loadXdfCalibration());
    state.calHistory=await window.tuniq.listCalibrationHistory();
    state.calHistory=Array.isArray(state.calHistory)?state.calHistory:[];
    calibrationInitialized=true;
    calUndo.length=0;calRedo.length=0;calSelection.clear();calAnchor=null;
    renderCalibration();
    await refreshWorkspace(true);
    showPage('sandbox');
    const summary=state.calibration.mappingSummary;
    status(`Loaded ${Object.keys(state.calibration.tables).length} XDF items from ${state.activeProject?.name||'the active project'}.${summary?.skipped?` ${summary.skipped} oversized items were skipped for stability.`:''}`);
  }catch(error){
    showCalibrationFailure(error);
    alert(error.message);
  }
}



// TunIQ AI/community surfaces plus 1.6 controlled tuning and connected diagnostics rendering.
function selectedAiMods(){return $$('.ai-mod:checked').map(input=>input.value)}
function needsCamDetails(){const goal=($('#aiTuneGoal')?.value||'').toLowerCase();return selectedAiMods().includes('Aftermarket camshaft')||goal.includes('camshaft')}
function updateAiCamVisibility(){const card=$('#aiCamFields');if(card)card.classList.toggle('hidden',!needsCamDetails())}
const engineCatalogApi=window.TunIQEngineCatalog||null;
function engineOption(value,label=value){const option=document.createElement('option');option.value=value;option.textContent=label;return option}
function engineSelectionFromControls(){return {family:$('#aiEngineFamily')?.value||'',displacement:$('#aiEngineDisplacement')?.value||'',code:$('#aiEngineCode')?.value||'',custom:$('#aiEngineCustom')?.value||''}}
function syncEngineSelection(){
  const selection=engineSelectionFromControls();
  const label=engineCatalogApi?.composeEngineLabel(selection)||selection.custom||[selection.family,selection.displacement,selection.code].filter(Boolean).join(' / ');
  setValue('#aiEngine',label);
  const summary=$('#aiEngineSummary');
  if(summary){
    const complete=selection.family==='Custom / Other'?Boolean(selection.custom.trim()):Boolean(selection.family&&selection.displacement&&selection.code);
    summary.classList.toggle('ready',complete);
    summary.textContent=complete?`Selected engine: ${label}`:'Choose the family, displacement, and engine code. Example: LS → 5.3L → LM7.';
  }
  return {...selection,label};
}
function populateEngineCodes(family,displacement,selected=''){
  const code=$('#aiEngineCode');if(!code)return;
  code.innerHTML='';code.append(engineOption('','Choose engine code'));
  const group=engineCatalogApi?.groupEntry(family,displacement);
  (group?.codes||[]).forEach(item=>code.append(engineOption(item)));
  code.disabled=!(group?.codes?.length);
  if(selected&&[...code.options].some(option=>option.value===selected))code.value=selected;
  else if(group?.codes?.length===1)code.value=group.codes[0];
}
function populateEngineDisplacements(family,selectedDisplacement='',selectedCode=''){
  const displacement=$('#aiEngineDisplacement');if(!displacement)return;
  displacement.innerHTML='';displacement.append(engineOption('','Choose displacement'));
  const entry=engineCatalogApi?.familyEntry(family);
  (entry?.groups||[]).forEach(group=>displacement.append(engineOption(group.displacement)));
  displacement.disabled=!(entry?.groups?.length);
  if(selectedDisplacement&&[...displacement.options].some(option=>option.value===selectedDisplacement))displacement.value=selectedDisplacement;
  else if(entry?.groups?.length===1)displacement.value=entry.groups[0].displacement;
  populateEngineCodes(family,displacement.value,selectedCode);
}
function applyEngineSelection(selection={}){
  const family=$('#aiEngineFamily');if(!family)return;
  const wantedFamily=selection.family||'';
  if(wantedFamily&&[...family.options].some(option=>option.value===wantedFamily))family.value=wantedFamily;else family.value='';
  populateEngineDisplacements(family.value,selection.displacement||'',selection.code||'');
  const customWrap=$('#aiEngineCustomWrap');
  const custom=family.value==='Custom / Other';
  customWrap?.classList.toggle('hidden',!custom);
  setValue('#aiEngineCustom',selection.custom||'');
  syncEngineSelection();
}
function initializeEngineSelector(){
  const family=$('#aiEngineFamily');if(!family||family.dataset.ready==='1')return;
  family.innerHTML='';family.append(engineOption('','Choose engine family'));
  (engineCatalogApi?.catalog||[]).forEach(item=>family.append(engineOption(item.family)));
  family.dataset.ready='1';
  family.onchange=()=>{populateEngineDisplacements(family.value);const custom=family.value==='Custom / Other';$('#aiEngineCustomWrap')?.classList.toggle('hidden',!custom);syncEngineSelection()};
  $('#aiEngineDisplacement').onchange=()=>{populateEngineCodes(family.value,$('#aiEngineDisplacement').value);syncEngineSelection()};
  $('#aiEngineCode').onchange=syncEngineSelection;
  $('#aiEngineCustom').oninput=syncEngineSelection;
}
function optionalSpecInputs(){return [['gearRatio','#aiGearRatio'],['tireSize','#aiTireSize'],['converterStall','#aiConverterStall'],['desiredIdle','#aiDesiredIdle']]}
function updateOptionalSpecState(){
  const values=optionalSpecInputs().filter(([,selector])=>$(selector)?.value.trim()).map(([key])=>key);
  const box=$('#aiOptionalSpecState');if(!box)return;
  box.classList.toggle('has-values',values.length>0);box.classList.toggle('blank-values',values.length===0);
  box.textContent=values.length?`Saved details available: ${values.map(key=>({gearRatio:'gear ratio',tireSize:'tire size',converterStall:'converter stall',desiredIdle:'desired idle'}[key])).join(', ')}. Blank items remain unknown.`:'Blank optional values remain unknown. TunIQ will not silently treat them as stock specifications.';
}
function knownVehicleContext(){
  const active=state.activeProject;
  return state.vehicles.find(vehicle=>vehicle.name===active?.vehicle)||state.vehicles.find(vehicle=>vehicle.name===($('#aiVehicle')?.value||''))||null;
}
function extractKnownOptionalSpecs(text=''){
  const value=String(text||'');
  const first=(regex)=>value.match(regex)?.[1]||'';
  return {
    gearRatio:first(/(?:gear(?:\s+ratio)?|rear\s+gear|axle)\s*(?:is|:|=|-)?\s*(\d\.\d{2})/i),
    tireSize:first(/\b(\d{3}\/\d{2}R\d{2}|\d{2,3}x\d{1,2}(?:\.\d+)?R?\d{2})\b/i),
    converterStall:first(/(?:converter\s+stall|stall)\s*(?:is|:|=|-)?\s*(\d{3,4})(?:\s*rpm)?/i),
    desiredIdle:first(/(?:desired\s+idle|idle)\s*(?:is|:|=|-)?\s*(\d{3,4})(?:\s*rpm)?/i)
  };
}
function useKnownOptionalSpecs(){
  const vehicle=knownVehicleContext();
  const active=state.activeProject;
  const found=extractKnownOptionalSpecs([vehicle?.notes,active?.notes].filter(Boolean).join(' | '));
  let filled=0;
  for(const [key,selector] of optionalSpecInputs())if(!$(selector).value.trim()&&found[key]){$(selector).value=found[key];filled++}
  updateOptionalSpecState();
  const box=$('#aiOptionalSpecState');
  if(filled)box.textContent=`Filled ${filled} confirmed value${filled===1?'':'s'} from saved Garage/project notes. Review them before generating the plan.`;
  else box.textContent='No confirmed gear, tire, converter, or idle values were found in the saved vehicle/project. They were left blank.';
}
function collectAiPayload(){
  const engine=syncEngineSelection();
  return {
    vehicle:$('#aiVehicle').value,engine:engine.label,engineFamily:engine.family,engineDisplacement:engine.displacement,engineCode:engine.code,engineCustom:engine.custom,transmission:$('#aiTransmission').value,fuel:$('#aiFuel').value,aspiration:$('#aiAspiration').value,tuneGoal:$('#aiTuneGoal').value,drivingUse:$('#aiDrivingUse').value,
    modifications:selectedAiMods(),injectorData:$('#aiInjectorData').value,gearRatio:$('#aiGearRatio').value,tireSize:$('#aiTireSize').value,converterStall:$('#aiConverterStall').value,desiredIdle:$('#aiDesiredIdle').value,symptoms:$('#aiSymptoms').value,notes:$('#aiBuildNotes').value,
    controller:state.activeProject?.controller||'',operatingSystem:state.activeProject?.os||'',cam:{brand:$('#aiCamBrand').value,partNumber:$('#aiCamPart').value,durationIntake:$('#aiCamDurationI').value,durationExhaust:$('#aiCamDurationE').value,liftIntake:$('#aiCamLiftI').value,liftExhaust:$('#aiCamLiftE').value,lsa:$('#aiCamLsa').value,icl:$('#aiCamIcl').value}
  }
}
function setValue(id,value){const el=$(id);if(el)el.value=value||''}
function fillAiForm(intake){
  const active=state.activeProject;
  initializeEngineSelector();
  setValue('#aiVehicle',intake?.vehicle||active?.vehicle||'');setValue('#aiTransmission',intake?.transmission||'');setValue('#aiFuel',intake?.fuel||'93 octane gasoline');setValue('#aiAspiration',intake?.aspiration||'Naturally aspirated');setValue('#aiTuneGoal',intake?.tuneGoal||'');setValue('#aiDrivingUse',intake?.drivingUse||'');
  const garageVehicle=knownVehicleContext();
  const legacyEngine=intake?.engine||garageVehicle?.engine||'';
  const parsed=intake?.engineFamily?{family:intake.engineFamily,displacement:intake.engineDisplacement||'',code:intake.engineCode||'',custom:intake.engineCustom||''}:(engineCatalogApi?.findEngineSelection(legacyEngine)||{family:'Custom / Other',displacement:'Custom',code:'Custom engine',custom:legacyEngine});
  applyEngineSelection(parsed);
  setValue('#aiInjectorData',intake?.injectorData||'');setValue('#aiGearRatio',intake?.gearRatio||'');setValue('#aiTireSize',intake?.tireSize||'');setValue('#aiConverterStall',intake?.converterStall||'');setValue('#aiDesiredIdle',intake?.desiredIdle||'');setValue('#aiSymptoms',intake?.symptoms||'');setValue('#aiBuildNotes',intake?.notes||'');
  setValue('#aiCamBrand',intake?.cam?.brand||'');setValue('#aiCamPart',intake?.cam?.partNumber||'');setValue('#aiCamDurationI',intake?.cam?.durationIntake||'');setValue('#aiCamDurationE',intake?.cam?.durationExhaust||'');setValue('#aiCamLiftI',intake?.cam?.liftIntake||'');setValue('#aiCamLiftE',intake?.cam?.liftExhaust||'');setValue('#aiCamLsa',intake?.cam?.lsa||'');setValue('#aiCamIcl',intake?.cam?.icl||'');
  const mods=new Set(intake?.modifications||[]);$$('.ai-mod').forEach(input=>input.checked=mods.has(input.value));updateAiCamVisibility();updateOptionalSpecState();
}
function showFullAiError(error){const box=$('#fullAiError');if(box){box.textContent=error.message||String(error);box.classList.add('bad')}}
function renderAiPlan(){
  const active=state.activeProject,plan=state.aiPlan,intake=state.aiIntake;
  $('#fullAiNoProject').classList.toggle('hidden',Boolean(active));$('#fullAiWorkspace').classList.toggle('hidden',!active);
  if(!active)return;
  $('#fullAiProjectContext').innerHTML=`<b>${safe(active.name)}</b><span>${safe(active.vehicle||'Vehicle not assigned')}</span><span>${safe(active.controller||'Controller pending')}${active.os?` · OS ${safe(active.os)}`:' · OS auto-detect pending'}</span>`;
  $('#fullAiSaveState').textContent=intake?.updatedAt?`Saved ${new Date(intake.updatedAt).toLocaleString()}`:'Not saved';
  $('#aiPlanCount').textContent=`${plan?.steps?.length||0} steps`;
  $('#aiPlanSummary').innerHTML=plan?`<b>${safe(plan.goal)}</b><br>${safe(intake?.engine||'Engine pending')} · ${safe(intake?.transmission||'Transmission pending')} · ${safe(intake?.fuel||'Fuel pending')}<br><small>Created ${new Date(plan.generatedAt).toLocaleString()}</small>`:'Complete the intake to generate a project-specific plan.';
  $('#aiPlanList').innerHTML=plan?.steps?.length?plan.steps.map((step,index)=>`<article class="ai-plan-step ${step.locked?'locked':''} ${step.complete?'complete':''}"><span>${step.complete?'✓':step.locked?'🔒':index+1}</span><div><b>${safe(step.title)}</b><p>${safe(step.reason)}</p><small>${safe(step.type.toUpperCase())}</small></div></article>`).join(''):'<div class="empty-card compact"><div class="empty-icon">✦</div><h3>No AI plan yet</h3><p>Enter the build and goal. Cam, boost, transmission, fuel, and diagnosis steps are added only when they apply.</p></div>';
}
async function loadAiWorkspace(){
  if(!state.activeProject){state.aiIntake=null;state.aiPlan=null;state.goalRequests=[];state.goalProposal=null;renderAiPlan();renderAiGoalRequest();return}
  const [bundle,goals]=await Promise.all([window.tuniq.getAiIntake(),window.tuniq.listAiGoalRequests()]);state.aiIntake=bundle?.intake||null;state.aiPlan=bundle?.plan||null;state.goalRequests=Array.isArray(goals)?goals.filter(item=>item.kind==='goal-request'):[];state.goalProposal=state.goalRequests[0]||null;fillAiForm(state.aiIntake);renderAiPlan();renderAiGoalRequest();
}
function tuneLibraryFilters(){return {q:$('#tuneSearch').value.toLowerCase(),engine:$('#tuneEngineFilter').value.toLowerCase(),transmission:$('#tuneTransmissionFilter').value.toLowerCase(),controller:$('#tuneControllerFilter').value.toLowerCase(),favorites:$('#tuneFavoritesOnly').checked}}
function renderTuneLibrary(){
  const filters=tuneLibraryFilters();
  const items=(state.tuneLibrary||[]).filter(item=>{const hay=[item.name,item.description,item.engine,item.transmission,item.controller,item.os,item.fuel,item.tuneGoal,...(item.modifications||[]),...(item.tags||[])].join(' ').toLowerCase();return (!filters.q||hay.includes(filters.q))&&(!filters.engine||String(item.engine||'').toLowerCase().includes(filters.engine))&&(!filters.transmission||String(item.transmission||'').toLowerCase().includes(filters.transmission))&&(!filters.controller||String(item.controller||'').toLowerCase().includes(filters.controller))&&(!filters.favorites||item.favorite)});
  const grid=$('#tuneLibraryGrid');
  grid.innerHTML=items.length?items.map(item=>`<article class="tune-card"><div class="tune-card-head"><div><p class="eyebrow">${safe(item.tuneGoal||'SAVED TUNE')}</p><h3>${safe(item.name)}</h3></div><button class="favorite-tune ghost" data-id="${safe(item.id)}">${item.favorite?'★':'☆'}</button></div><p>${safe(item.description||'No description added.')}</p><div class="tune-meta"><span>${safe(item.engine||'Engine unspecified')}</span><span>${safe(item.transmission||'Transmission unspecified')}</span><span>${safe(item.controller||'Controller unspecified')}${item.os?` / OS ${safe(item.os)}`:''}</span><span>${safe(item.fuel||'Fuel unspecified')}</span></div><div class="tune-tags">${[...(item.modifications||[]),...(item.tags||[])].slice(0,8).map(tag=>`<span>${safe(tag)}</span>`).join('')}</div><small>SHA-256 ${safe((item.sourceSha256||'').slice(0,16))}… · ${new Date(item.createdAt).toLocaleString()}</small><div class="tune-actions"><button class="apply-tune" data-id="${safe(item.id)}">Use as Revision</button><button class="export-tune ghost" data-id="${safe(item.id)}">Export</button><button class="delete-tune danger-btn" data-id="${safe(item.id)}">Delete</button></div></article>`).join(''):'<div class="empty-card"><div class="empty-icon">★</div><h2>No matching saved tunes</h2><p>Save the active project’s latest revision or import a .tuniqtune package.</p></div>';
  $$('.favorite-tune').forEach(button=>button.onclick=async()=>{await window.tuniq.favoriteTune(button.dataset.id);await loadTuneLibrary()});
  $$('.apply-tune').forEach(button=>button.onclick=async()=>{try{const result=await window.tuniq.applyTune(button.dataset.id);alert(`Tune imported as a new project revision:\n${result.path}\n\nSHA-256: ${result.sha256}`);await refreshWorkspace(true)}catch(error){alert(error.message)}});
  $$('.export-tune').forEach(button=>button.onclick=async()=>{try{const out=await window.tuniq.exportTune(button.dataset.id);if(out)alert(`Tune package exported:\n${out}`)}catch(error){alert(error.message)}});
  $$('.delete-tune').forEach(button=>button.onclick=async()=>{if(confirm('Delete this tune from the local library?')){await window.tuniq.deleteTune(button.dataset.id);await loadTuneLibrary()}});
}
async function loadTuneLibrary(){state.tuneLibrary=await window.tuniq.listTuneLibrary();state.tuneLibrary=Array.isArray(state.tuneLibrary)?state.tuneLibrary:[];renderTuneLibrary()}
function renderCommunityPosts(){
  const q=$('#communitySearch').value.toLowerCase(),category=$('#communityCategory').value.toLowerCase(),engine=$('#communityEngine').value.toLowerCase(),trans=$('#communityTransmission').value.toLowerCase(),controller=$('#communityController').value.toLowerCase();
  const posts=(state.communityPosts||[]).filter(post=>{const hay=[post.title,post.body,post.engine,post.transmission,post.controller,...(post.tags||[])].join(' ').toLowerCase();return (!q||hay.includes(q))&&(!category||String(post.category||'').toLowerCase()===category)&&(!engine||String(post.engine||'').toLowerCase().includes(engine))&&(!trans||String(post.transmission||'').toLowerCase().includes(trans))&&(!controller||String(post.controller||'').toLowerCase().includes(controller))});
  $('#communityPosts').innerHTML=posts.length?posts.map(post=>`<article class="community-post"><div class="community-post-head"><div><span class="status-badge">${safe(post.category||'POST')}</span><h3>${safe(post.title)}</h3></div>${post.official?'<b class="official-badge">TunIQ Official</b>':`<button class="delete-post danger-btn" data-id="${safe(post.id)}">Delete</button>`}</div><p>${safe(post.body)}</p><div class="tune-meta"><span>${safe(post.engine||'Engine unspecified')}</span><span>${safe(post.transmission||'Transmission unspecified')}</span><span>${safe(post.controller||'Controller unspecified')}</span></div>${post.projectContext?`<div class="attached-context"><b>Attached project:</b> ${safe(post.projectContext.projectName)} · ${safe(post.projectContext.controller||'Controller pending')}${post.projectContext.os?` · OS ${safe(post.projectContext.os)}`:''}</div>`:''}<div class="tune-tags">${(post.tags||[]).map(tag=>`<span>${safe(tag)}</span>`).join('')}</div><small>By ${safe(post.author||'Unknown')} · ${new Date(post.createdAt).toLocaleString()}</small></article>`).join(''):'<div class="empty-card compact"><h3>No matching posts</h3><p>Clear a filter or create a local draft post.</p></div>';
  $$('.delete-post').forEach(button=>button.onclick=async()=>{if(confirm('Delete this local post draft?')){await window.tuniq.deleteCommunityPost(button.dataset.id);await loadCommunityPosts()}})
}
async function loadCommunityPosts(){state.communityPosts=await window.tuniq.listCommunityPosts();state.communityPosts=Array.isArray(state.communityPosts)?state.communityPosts:[];state.beta=state.beta||null;state.updates=state.updates||null;state.devices=Array.isArray(state.devices)?state.devices:[];state.device=state.device||{connected:false,connection:null,preferred:{}};state.liveLogs=Array.isArray(state.liveLogs)?state.liveLogs:[];state.sensorProfiles=state.sensorProfiles||{};state.logSession=state.device.logging||null;state.flash=state.flash||null;state.validation=state.validation||null;state.aiProposals=Array.isArray(state.aiProposals)?state.aiProposals:[];state.currentProposal=state.aiProposals[0]||null;state.goalRequests=Array.isArray(state.goalRequests)?state.goalRequests:[];state.goalProposal=state.goalRequests[0]||null;state.p01Auto=state.p01Auto||null;state.p01Evidence=state.p01Evidence&&typeof state.p01Evidence==='object'?state.p01Evidence:null;renderCommunityPosts()}


function valueText(value,digits=1,fallback='--'){const number=Number(value);return Number.isFinite(number)?number.toFixed(digits).replace(/\.0$/,''):fallback}
function showDeviceMessage(message,bad=false){const box=$('#deviceHelp');if(box){box.textContent=message;box.classList.toggle('bad',bad)}}
function showLogMessage(message,bad=false){const box=$('#logSessionStatus');if(box){box.textContent=message;box.classList.toggle('bad',bad)}}
function renderDeviceList(){
  const container=$('#deviceList');if(!container)return;
  const preferred=state.device?.preferred?.port||'';
  const selected=$('#devicePort')?.value||preferred;
  const devices=Array.isArray(state.devices)?state.devices:[];
  $('#deviceScanState').textContent=`${devices.filter(item=>!item.demo).length} physical port(s)`;
  $('#devicePort').innerHTML='<option value="">Select a port</option>'+devices.map(item=>`<option value="${safe(item.port)}">${safe(item.name)}</option>`).join('');
  if(devices.some(item=>item.port===selected))$('#devicePort').value=selected;else if(devices.some(item=>item.port===preferred))$('#devicePort').value=preferred;
  container.innerHTML=devices.length?devices.map(item=>`<button class="device-row ${item.port===($('#devicePort').value||preferred)?'selected':''}" data-device-port="${safe(item.port)}"><span class="device-port-icon">${item.demo?'◉':item.transport.includes('Bluetooth')?'⌁':'⇄'}</span><span><b>${safe(item.name)}</b><small>${safe(item.port)} · ${safe(item.transport)}${item.manufacturer?` · ${safe(item.manufacturer)}`:''}</small></span><em>${item.recommended?'OBDLINK':'SELECT'}</em></button>`).join(''):'<p class="muted">No serial devices were found. Pair the MX+ in Windows Bluetooth settings, then scan again.</p>';
  $$('[data-device-port]').forEach(button=>button.onclick=()=>{$('#devicePort').value=button.dataset.devicePort;renderDeviceList();showDeviceMessage(`Selected ${button.dataset.devicePort}. Press Connect & Identify.`)});
}
function renderDeviceStatus(){
  const device=state.device||{},connection=device.connection,connected=Boolean(device.connected&&connection),preferred=device.preferred||{};
  const badge=$('#deviceStatusBadge');if(badge){badge.textContent=connected?'CONNECTED':'DISCONNECTED';badge.className=`device-badge ${connected?'online':'offline'}`}
  $('#deviceConnect').disabled=connected;$('#deviceDisconnect').disabled=!connected;
  $('#deviceAdapter').textContent=connection?.adapter||preferred.adapter||'Not connected';
  $('#deviceFirmware').textContent=connection?.firmware||preferred.firmware||'Firmware unavailable';
  $('#deviceTransport').textContent=connection?.transport||preferred.transport||'Bluetooth / serial';
  $('#devicePortInfo').textContent=connection?.port?`${connection.port}${connection.baud?` at ${connection.baud} baud`:''}`:preferred.port?`${preferred.port} saved`:'No port selected';
  $('#deviceProtocol').textContent=connection?.protocol||preferred.protocol||'Not detected';
  $('#deviceVoltage').textContent=Number.isFinite(Number(connection?.voltage))?`${Number(connection.voltage).toFixed(2)} V`:'-- V';
  $('#deviceVin').textContent=connection?.vin||preferred.vin||'Not read';
  $('#deviceCapabilities').textContent=(connection?.capabilities||['Diagnostics','Live logging']).join(' · ');
  $('#liveDeviceState').textContent=connection?.adapter||'None';$('#scanProtocol').textContent=connection?.protocol||'Unknown';
  $('#scanState').textContent=connected?(state.logSession?'RECORDING':'CONNECTED'):'DISCONNECTED';$('#scanDot').style.background=connected?'#62f1b1':'#71837b';
  const header=$('.header-actions .connection');if(header)header.innerHTML=`<i></i>${connected?safe(connection.adapter):'Unified Desktop Core'}`;
  const diag=$('#diagDeviceState');if(diag)diag.textContent=connected?`${connection.adapter} on ${connection.port}`:preferred.port?`${preferred.port} configured`:'Not connected';
  const dot=$('#diagDeviceDot');if(dot)dot.className=connected?'green':'amber';
  $('#logStart').disabled=!connected||!state.activeProject||Boolean(state.logSession);$('#logStop').disabled=!state.logSession;$('#logMarker').disabled=!state.logSession;
}
async function scanDevices(){const button=$('#deviceScan');button.disabled=true;$('#deviceScanState').textContent='Scanning Windows ports…';try{state.devices=await window.tuniq.listDevices();renderDeviceList();showDeviceMessage(state.devices.some(item=>!item.demo)?'Select the OBDLink or Bluetooth serial COM port, then connect.':'No physical ports were returned. Confirm the adapter is paired in Windows; the virtual adapter is available for testing.')}catch(error){showDeviceMessage(error.message,true)}finally{button.disabled=false}}
async function loadDeviceManager(){state.device=await window.tuniq.getDeviceStatus();if(!state.devices.length)await scanDevices();else{renderDeviceList();renderDeviceStatus()}}
async function connectSelectedDevice(portOverride=null){const port=portOverride||$('#devicePort').value;if(!port)return showDeviceMessage('Select a detected port first.',true);$('#deviceConnect').disabled=true;showDeviceMessage(`Connecting to ${port} and identifying the adapter…`);try{state.device=await window.tuniq.connectDevice({port,baud:Number($('#deviceBaud').value||0)});renderDeviceStatus();renderDeviceList();showDeviceMessage(`Connected to ${state.device.connection.adapter}. Protocol: ${state.device.connection.protocol||'automatic'}.`);await refreshWorkspace(true);if($('#scanner').classList.contains('active'))startLivePolling()}catch(error){showDeviceMessage(error.message,true);renderDeviceStatus()}finally{$('#deviceConnect').disabled=Boolean(state.device?.connected)}}
async function disconnectDevice(){try{stopLivePolling();state.device=await window.tuniq.disconnectDevice();state.logSession=null;renderDeviceStatus();showDeviceMessage('Adapter disconnected. Your preferred COM port remains saved.');await refreshWorkspace(true)}catch(error){showDeviceMessage(error.message,true)}}
function drawLiveChart(){const canvas=$('#liveChart');if(!canvas)return;const ctx=canvas.getContext('2d');const width=canvas.width,height=canvas.height;ctx.clearRect(0,0,width,height);ctx.strokeStyle='#1e362d';ctx.lineWidth=1;for(let y=0;y<=4;y++){ctx.beginPath();ctx.moveTo(0,y*height/4);ctx.lineTo(width,y*height/4);ctx.stroke()}for(let x=0;x<=10;x++){ctx.beginPath();ctx.moveTo(x*width/10,0);ctx.lineTo(x*width/10,height);ctx.stroke()}if(livePoints.length<2)return;const series=[{key:'rpm',max:6500,color:'#62f1b1'},{key:'tps',max:100,color:'#f4c85c'},{key:'trim',max:40,min:-40,color:'#78bdf2'}];for(const item of series){ctx.strokeStyle=item.color;ctx.lineWidth=2;ctx.beginPath();let started=false;livePoints.forEach((point,index)=>{const raw=item.key==='trim'?(Number(point.stft1)||0)+(Number(point.ltft1)||0):Number(point[item.key]);if(!Number.isFinite(raw))return;const min=item.min??0;const x=index/(Math.max(1,livePoints.length-1))*width;const y=height-(Math.max(0,Math.min(1,(raw-min)/(item.max-min)))*height);if(!started){ctx.moveTo(x,y);started=true}else ctx.lineTo(x,y)});ctx.stroke()}}
function renderSensorFrame(sample){const rows=[['RPM',sample.rpm,'rpm'],['Speed',sample.speed,'mph'],['Coolant',sample.ect,'°F'],['Intake air',sample.iat,'°F'],['Throttle',sample.tps,'%'],['MAP',sample.map,'kPa'],['MAF',sample.maf,'g/s'],['MAF frequency',sample.mafFrequency,'Hz'],['STFT Bank 1',sample.stft1,'%'],['LTFT Bank 1',sample.ltft1,'%'],['Commanded EQ',sample.commandedEqRatio,'EQ'],['Wideband AFR',sample.widebandAfr,'AFR'],['Spark advance',sample.spark,'°'],['Knock retard',sample.knockRetard,'°'],['Injector duty',sample.injectorDuty,'%'],['Desired idle',sample.desiredIdle,'rpm'],['Misfire total',sample.misfireTotal,''],['Commanded gear',sample.commandedGear,''],['Actual gear',sample.actualGear,''],['Input shaft',sample.inputShaftSpeed,'rpm'],['Output shaft',sample.outputShaftSpeed,'rpm'],['Transmission slip',sample.transSlip,'rpm'],['Shift time',sample.shiftTime,'ms'],['TCC slip',sample.tccSlip,'rpm'],['Torque management',sample.torqueManagement,'%'],['Calculated load',sample.load,'%'],['Voltage',sample.voltage,'V']].filter(([,value])=>value!=null);$('#liveSensorRows').innerHTML=rows.map(([name,value,unit])=>`<div class="sensor-row"><span>${name}</span><b>${valueText(value,1)} ${unit}</b></div>`).join('');$('#liveFrameTime').textContent=new Date(sample.timestamp).toLocaleTimeString()}
function updateLiveSample(sample,statusPayload){
  if(statusPayload)state.device=statusPayload;
  const set=(id,value,digits=1)=>{$(id).textContent=valueText(value,digits)};
  set('#rpm',sample.rpm,0);set('#speed',sample.speed,1);set('#ect',sample.ect,1);set('#tps',sample.tps,1);set('#map',sample.map,1);set('#maf',sample.maf,2);set('#stft',sample.stft1,1);set('#ltft',sample.ltft1,1);set('#spark',sample.spark,1);set('#kr',sample.knockRetard,1);set('#volt',sample.voltage,2);
  livePoints.push({...sample,trim:(Number(sample.stft1)||0)+(Number(sample.ltft1)||0)});while(livePoints.length>140)livePoints.shift();drawLiveChart();renderSensorFrame(sample);renderDeviceStatus();
  if(state.logSession){state.logSession.samples=(state.logSession.samples||0)+1;$('#scanSamples').textContent=state.logSession.samples;showLogMessage(`Recording ${state.logSession.profileName} · ${state.logSession.samples} samples · ${state.device?.connection?.adapter||'adapter'}`)}
}
async function pollLiveSample(){if(livePolling||!state.device?.connected)return;livePolling=true;try{const result=await window.tuniq.sampleDevice();updateLiveSample(result.sample,result.status)}catch(error){showLogMessage(error.message,true);if(/disconnect|COM port|use|access/i.test(error.message))stopLivePolling()}finally{livePolling=false}}
function startLivePolling(){if(livePollTimer||!state.device?.connected)return;pollLiveSample();livePollTimer=setInterval(pollLiveSample,state.device?.connection?.demo?500:state.device?.connection?.persistent?450:1200)}
function stopLivePolling(){if(livePollTimer){clearInterval(livePollTimer);livePollTimer=null}livePolling=false}
function renderLogAnalysis(analysis){state.logAnalysis=analysis||null;const box=$('#logAnalysis');if(!analysis){$('#logAnalysisConfidence').textContent='NO ANALYSIS';box.innerHTML='<p class="muted">Stop a recording or select Analyze on a saved log.</p>';return}$('#logAnalysisConfidence').textContent=`${String(analysis.confidence||'limited').toUpperCase()} · ${Number(analysis.sampleCount||0)} SAMPLES`;box.innerHTML=(analysis.findings||[]).map(item=>`<article class="analysis-finding ${safe(item.severity||'info')}"><b>${safe(item.title)}</b><p>${safe(item.detail)}</p><small>Next: ${safe(item.action)}</small></article>`).join('')||'<p class="muted">No findings were generated.</p>';renderAiContext()}
function renderLiveLogHistory(){
  const box=$('#liveLogHistory');if(!box)return;const logs=Array.isArray(state.liveLogs)?state.liveLogs:[];
  box.innerHTML=logs.length?logs.map((log,index)=>`<article class="live-log-item"><div><b>${safe(log.name||'Live log')}</b><small>${safe(log.profileName||'Profile')} · ${Number(log.samples||0)} samples · ${log.startedAt?new Date(log.startedAt).toLocaleString():'Unknown date'}</small></div><div><button class="ghost analyze-log" data-log-index="${index}">${log.analysis?'Review':'Analyze'}</button><button class="ghost outcome-log" data-log-index="${index}">Result</button></div></article>`).join(''):'<p class="muted">No project logs yet.</p>';
  $$('.analyze-log').forEach(button=>button.onclick=async()=>{const log=logs[Number(button.dataset.logIndex)];if(!log)return;try{const analysis=log.analysis||await window.tuniq.analyzeLiveLog(log.csvPath);log.analysis=analysis;renderLogAnalysis(analysis);renderLiveLogHistory()}catch(error){showLogMessage(error.message,true)}});
  $$('.outcome-log').forEach(button=>button.onclick=()=>{const log=logs[Number(button.dataset.logIndex)];if(log)openOutcomeForm(log)});
  updateProposalLogOptions();
}
function updateProposalLogOptions(){const select=$('#aiProposalLog');if(!select)return;const previous=select.value;const logs=Array.isArray(state.liveLogs)?state.liveLogs:[];select.innerHTML='<option value="">Choose a saved CSV log</option>'+logs.map(log=>`<option value="${safe(log.csvPath)}">${safe(log.name||'Live log')} · ${Number(log.samples||0)} samples</option>`).join('');if(logs.some(log=>log.csvPath===previous))select.value=previous;else if(logs[0])select.value=logs[0].csvPath;}
function renderAiProposalWorkspace(){
  const proposal=state.currentProposal||state.aiProposals?.[0]||null;state.currentProposal=proposal;
  updateProposalLogOptions();
  const stateEl=$('#aiProposalState'),summary=$('#aiProposalSummary'),list=$('#aiProposalList'),apply=$('#aiApplyProposal');if(!stateEl||!summary||!list||!apply)return;
  if(!proposal){stateEl.textContent='NO PROPOSAL';summary.textContent='Load a BIN/XDF mapping and select a saved log.';list.innerHTML='';apply.disabled=true;return;}
  stateEl.textContent=proposal.blocked?'BLOCKED':`${proposal.summary?.proposedCells||0} CELL${proposal.summary?.proposedCells===1?'':'S'}`;
  summary.innerHTML=`<b>AI calibration cycle ${Number(proposal.iteration||1)} · ${safe(proposal.sourceLogName)}</b><br>${Number(proposal.sampleCount||0)} samples · ${safe(proposal.summary?.tables?.join(', ')||'No mapped target table')}<br>${proposal.blocked?'Safety findings must be resolved before changes can be applied.':'Every cell below requires approval.'}`;
  const safety=(proposal.safetyFindings||[]).map(item=>`<article class="proposal-safety ${safe(item.severity)}"><b>${safe(item.title)}</b><small>${safe(item.detail)}</small></article>`).join('');
  const changes=(proposal.proposals||[]).map(item=>`<label class="ai-proposal-item ${item.blocked?'blocked':''}"><input type="checkbox" class="ai-proposal-approve" value="${safe(item.id)}" ${item.blocked?'disabled':''}><span><b>${safe(item.tableName)} · ${safe(item.rowLabel)} / ${safe(item.colLabel)}</b><small>${safe(item.current)} → ${safe(item.proposed)} (${Number(item.percent)>=0?'+':''}${safe(item.percent)}%)</small><small>${safe(item.reason)}</small><em>${safe(item.confidence)} confidence · ${safe(item.risk)} risk</em></span></label>`).join('');
  list.innerHTML=safety+(changes||'<p class="muted">No repeatable log regions could be mapped to supported calibration tables.</p>');
  $$('.ai-proposal-approve').forEach(box=>box.onchange=()=>{apply.disabled=proposal.blocked||!$$('.ai-proposal-approve:checked').length});
  apply.disabled=proposal.blocked||!$$('.ai-proposal-approve:checked').length;
}
function goalConfirmations(){return {valvetrainVerified:$('#aiGoalValvetrain').checked,tireRatingMph:Number($('#aiGoalTireRating').value)||null,drivelineVerified:$('#aiGoalDriveline').checked,brakesVerified:$('#aiGoalBrakes').checked,closedCourse:$('#aiGoalClosedCourse').checked,ghostCamRisksAccepted:$('#aiGoalGhostRisks').checked}}
function renderAiGoalRequest(){
  const proposal=state.goalProposal;const stateEl=$('#aiGoalState'),summary=$('#aiGoalSummary'),box=$('#aiGoalActions'),apply=$('#aiApplyGoalRequest'),mapButton=$('#aiConfirmGoalMap');if(!stateEl||!summary||!box||!apply)return;
  if(!proposal){stateEl.textContent='NO REQUEST';summary.textContent='Describe the exact outcome. TunIQ will identify supported actions, required hardware checks, and exact mapped cells.';box.innerHTML='';apply.disabled=true;if(mapButton)mapButton.disabled=true;return}
  stateEl.textContent=proposal.blocked?'BLOCKED':proposal.partiallyBlocked?'PARTIAL':`${proposal.summary?.readyActions||0} READY`;
  const p01NeedsMap=Boolean(state.p01?.applicable);
  summary.innerHTML=`<b>${safe(proposal.requestText)}</b><br>${Number(proposal.summary?.readyActions||0)} ready action(s) · ${Number(proposal.summary?.blockedActions||0)} blocked action(s) · ${Number(proposal.summary?.proposedCells||0)} mapped cell(s)<br><small>${p01NeedsMap?'P01 requires one exact parameter-map confirmation for this verified OS/XDF before applying. ':''}Applying creates a revision only. Flashing remains separate.</small>`;
  box.innerHTML=(proposal.actions||[]).map(action=>{const requirements=(action.requirements||[]).map(item=>`<li>${safe(item)}</li>`).join('');const warnings=(action.warnings||[]).map(item=>`<li>${safe(item)}</li>`).join('');const changes=(action.proposals||[]).map(item=>`<label class="ai-proposal-item ${item.blocked?'blocked':''}"><input type="checkbox" class="ai-goal-approve" value="${safe(item.id)}" ${item.blocked?'disabled':''}><span><b>${safe(item.tableName)} · ${safe(item.rowLabel)} / ${safe(item.colLabel)}</b><small>${safe(item.current)} → ${safe(item.proposed)}</small><small>${safe(item.reason)}</small><em>${safe(item.confidence)} confidence · ${safe(item.risk)} risk</em></span></label>`).join('');const mapChoice=p01NeedsMap&&changes?`<label class="inline-check p01-map-choice"><input type="checkbox" class="ai-goal-map-action" value="${safe(action.id)}">I verified these are the correct ${safe(action.label)} parameters for OS ${safe(state.p01?.identity?.os||'')}</label>`:'';return `<article class="ai-goal-action ${safe(action.status)}"><div class="panel-title"><h4>${safe(action.label)}</h4><span>${safe(action.status.toUpperCase())}</span></div>${requirements?`<div class="goal-requirements"><b>Needed before this can run</b><ul>${requirements}</ul></div>`:''}${warnings?`<div class="goal-warnings"><b>Important</b><ul>${warnings}</ul></div>`:''}${changes||'<p class="muted">No editable cells were produced for this action.</p>'}${mapChoice}</article>`}).join('');
  const updateButtons=()=>{apply.disabled=!$$('.ai-goal-approve:checked').length;if(mapButton)mapButton.disabled=!p01NeedsMap||!$$('.ai-goal-map-action:checked').length};
  $$('.ai-goal-approve').forEach(input=>input.onchange=updateButtons);$$('.ai-goal-map-action').forEach(input=>input.onchange=updateButtons);updateButtons();
}
async function confirmP01GoalMap(){const proposal=state.goalProposal;if(!proposal)return;const actionIds=$$('.ai-goal-map-action:checked').map(input=>input.value);if(!actionIds.length)return alert('Select the P01 actions whose exact cells you verified.');if(!confirm(`Bind the selected table cells to P01 OS ${state.p01?.identity?.os||'unknown'} and the current XDF?

This does not change or flash the BIN.`))return;const button=$('#aiConfirmGoalMap');button.disabled=true;try{state.p01=await window.tuniq.confirmP01GoalMap({proposalId:proposal.id,actionIds});if(state.workspace)state.workspace.p01=state.p01;renderP01Commissioning();alert('P01 parameter map saved. Rebuild the Safe Action Sheet so TunIQ uses only those commissioned cells.')}catch(error){alert(error.message)}finally{renderAiGoalRequest()}}
async function buildAiGoalRequest(){const request=$('#aiGoalRequest').value.trim();if(!request)return alert('Describe the tune changes you want first.');$('#aiBuildGoalRequest').disabled=true;try{state.goalProposal=await window.tuniq.buildAiGoalRequest({request,confirmations:goalConfirmations()});state.goalRequests=[state.goalProposal,...(state.goalRequests||[]).filter(item=>item.id!==state.goalProposal.id)];renderAiGoalRequest();await refreshWorkspace(true)}catch(error){$('#aiGoalSummary').textContent=error.message}finally{$('#aiBuildGoalRequest').disabled=false}}
async function applyAiGoalRequest(){const proposal=state.goalProposal;if(!proposal)return;const approvedIds=$$('.ai-goal-approve:checked').map(input=>input.value);if(!approvedIds.length)return alert('Approve at least one exact requested change.');if(!confirm(`Apply ${approvedIds.length} approved requested change(s) and create a new revision?

This does not flash the PCM.`))return;$('#aiApplyGoalRequest').disabled=true;try{const result=await window.tuniq.applyAiGoalRequest({proposalId:proposal.id,approvedIds});state.calibration=normalizeCalibration(result.workspace);calibrationInitialized=true;renderCalibration();alert(`Requested tune revision created:
${result.revision.path}

Applied cells: ${result.applied.length}
Checksum status: ${result.revision.checksumStatus}

Review validation, then use Flash Center separately.`);await refreshProjectFiles();await refreshWorkspace(true)}catch(error){alert(error.message)}finally{renderAiGoalRequest()}}


function evidenceConfidenceLabel(value){return ({'explicit-p01':'EXPLICIT P01','family-unverified':'P01/P59 FAMILY','community-tested':'COMMUNITY TESTED','community-reference':'REFERENCE','primary-source':'PRIMARY SOURCE','negative-validation':'CAUTION'}[value]||String(value||'REFERENCE').toUpperCase())}
function evidenceConfidenceClass(value){if(['explicit-p01','primary-source','community-tested'].includes(value))return value;if(['family-unverified','negative-validation'].includes(value))return value;return 'community-reference'}
function renderP01Evidence(){
  const data=state.p01Evidence;if(!data)return;const summary=data.summary||{};
  const status=$('#p01EvidenceStatus'),summaryBox=$('#p01EvidenceSummary'),registryBox=$('#p01EvidenceRegistry'),importedBox=$('#p01EvidenceImported');if(!status||!summaryBox||!registryBox||!importedBox)return;
  status.textContent=`${Number(summary.publicLogSessions||0)} LOGS · ${Number(summary.definitionReferences||0)} XDFS`;
  summaryBox.innerHTML=`<b>${Number(summary.publicLogSessions||0)} public log sessions found</b><br>${Number(summary.explicitP01Logs||0)} explicitly identified as P01 · ${Number(summary.familyFormatLogs||0)} P01/P59-family sessions needing identity · ${Number(summary.importedItems||0)} locally imported item(s)<br><small>${safe(data.warning||'Public evidence is not a trusted tune rule.')}</small>`;
  const groups=[['live-log','Live logs'],['definition','P01 XDF references'],['calibration-library','BIN/XDF libraries'],['calibration-research','Calibration research'],['tool-reference','Tools and validation'],['logger-reference','Logger definitions']];
  const cards=[];for(const [type,label] of groups){const items=(data.registry||[]).filter(item=>item.type===type);if(!items.length)continue;cards.push(`<div class="evidence-group-label">${safe(label)}</div>`);cards.push(...items.map(item=>`<article class="evidence-card ${evidenceConfidenceClass(item.confidence)}"><div class="evidence-card-head"><div><b>${safe(item.title)}</b><small>${safe(item.attachmentName||item.format||'Public source')}</small></div><span class="evidence-chip ${item.confidence==='family-unverified'||item.confidence==='negative-validation'?'warn':''}">${safe(evidenceConfidenceLabel(item.confidence))}</span></div><div class="evidence-meta"><span class="evidence-chip">${safe(item.controller||'Any')}</span>${item.os?`<span class="evidence-chip">OS ${safe(item.os)}</span>`:''}<span class="evidence-chip">${safe(item.redistribution||'reference')}</span></div><small>${safe(item.notes||item.controllerEvidence||'')}</small><div class="evidence-actions"><button class="ghost p01-evidence-open" data-source-id="${safe(item.id)}">Open Source</button>${['live-log','definition','calibration-library','calibration-research'].includes(item.type)?`<button class="ghost p01-evidence-import-source" data-source-id="${safe(item.id)}">Import Downloaded File</button>`:''}</div></article>`));}
  registryBox.innerHTML=cards.join('')||'<p class="muted">No public sources are registered.</p>';
  const imported=Array.isArray(data.imported)?data.imported:[];importedBox.innerHTML=imported.length?imported.map(item=>{const compatible=item.compatibility?.controllerMatch!==false&&item.compatibility?.osMatch!==false;const blockers=(item.trainingBlockers||[]).map(value=>`<li>${safe(value)}</li>`).join('');return `<article class="evidence-card ${compatible?'':'incompatible'}"><div class="evidence-card-head"><div><b>${safe(item.sourceTitle||item.sourceFileName)}</b><small>${safe(item.sourceFileName)} · ${item.rowCount?`${Number(item.rowCount)} rows · `:''}${item.os?`OS ${safe(item.os)}`:'OS unbound'}</small></div><span class="evidence-chip ${compatible?'':'bad'}">${compatible?'MATCH':'CHECK PROJECT'}</span></div><div class="evidence-meta"><span class="evidence-chip">SHA ${safe(String(item.sourceFileSha256||'').slice(0,10))}</span>${item.normalizedFingerprint?`<span class="evidence-chip">SESSION ${safe(item.normalizedFingerprint.slice(0,10))}</span>`:''}${item.duplicateOf?'<span class="evidence-chip warn">DUPLICATE</span>':''}</div>${blockers?`<ul class="evidence-blockers">${blockers}</ul>`:''}<div class="evidence-actions"><button class="ghost p01-evidence-delete" data-evidence-id="${safe(item.id)}">Remove Local Evidence</button></div></article>`}).join(''):'<p class="muted">Download a referenced file in your browser, then import it here. TunIQ stores a fingerprint and a sanitized normalized copy of logs.</p>';
  $$('.p01-evidence-open').forEach(button=>button.onclick=()=>window.tuniq.openP01EvidenceSource(button.dataset.sourceId).catch(error=>alert(error.message)));
  $$('.p01-evidence-import-source').forEach(button=>button.onclick=()=>importP01Evidence(button.dataset.sourceId));
  $$('.p01-evidence-delete').forEach(button=>button.onclick=async()=>{if(!confirm('Remove this locally imported evidence record and its sanitized copy?'))return;try{state.p01Evidence=await window.tuniq.deleteP01Evidence(button.dataset.evidenceId);renderP01Evidence()}catch(error){alert(error.message)}});
}
async function loadP01Evidence(){state.p01Evidence=await window.tuniq.getP01Evidence();renderP01Evidence();return state.p01Evidence}
async function importP01Evidence(sourceId=''){try{const item=await window.tuniq.importP01Evidence({sourceId,profile:$('#logProfile')?.value||'baseline'});if(!item)return;state.p01Evidence=await window.tuniq.getP01Evidence();renderP01Evidence();const message=item.duplicate?`That file was already imported (${item.duplicateReason}).`:`Imported and fingerprinted ${item.sourceFileName}.${item.rowCount?` ${item.rowCount} usable rows were sanitized.`:''}`;alert(message)}catch(error){alert(error.message)}}

async function loadLiveLogs(){state.liveLogs=await window.tuniq.listLiveLogs();state.liveLogs=Array.isArray(state.liveLogs)?state.liveLogs:[];renderLiveLogHistory();return state.liveLogs}
async function loadLiveWorkspace(){state.device=await window.tuniq.getDeviceStatus();state.logSession=state.device.logging||state.logSession;renderDeviceStatus();await Promise.all([loadLiveLogs(),loadP01Evidence()]);if(state.device.connected)startLivePolling();else showLogMessage('Connect the OBDLink MX+ or another serial adapter in Device Manager first.')}
function renderObdLinkImport(result){const status=$('#obdLinkImportStatus'),details=$('#obdLinkImportDetails');if(!result){status.textContent='No phone log imported yet.';details.textContent='Select the same logging profile you used for the drive so TunIQ can check whether the required channels were recorded.';return}const quality=result.importQuality||{};status.textContent=`Imported ${result.samples||0} samples · ${String(quality.status||'unknown').toUpperCase()} quality · ${result.privateColumnsRemoved?.length||0} private/location column(s) removed.`;details.innerHTML=`<b>${safe(result.name||result.sourceFileName||'OBDLink phone log')}</b><br>Mapped: ${safe((result.availableChannels||[]).join(', ')||'No channels')}<br>Missing for this profile: ${safe((result.missingRecommendedChannels||[]).join(', ')||'None')}<br>Sampling: ${quality.sampleRateHz||'unknown'} Hz · Duration: ${quality.durationSeconds||0} sec`;}
async function importObdLinkPhoneLog(){if(!state.activeProject)return alert('Create or activate a project before importing a phone log.');const button=$('#importObdLinkLog');if(button)button.disabled=true;try{const result=await window.tuniq.importObdLinkLog({profile:$('#logProfile').value,name:$('#logName').value});if(!result)return;renderObdLinkImport(result);renderLogAnalysis(result.analysis);await loadLiveLogs();await refreshWorkspace(true);state.lastCompletedLog=result;openOutcomeForm(result)}catch(error){$('#obdLinkImportStatus').textContent=error.message}finally{if(button)button.disabled=false}}
async function showObdLinkGuide(){try{const guide=await window.tuniq.getObdLinkImportGuide($('#logProfile').value);$('#obdLinkImportDetails').innerHTML=`<b>Recommended channels for ${safe(guide.profile)}</b><br>${safe(guide.recommendedFields.join(', '))}<br><br>${guide.instructions.map(item=>`• ${safe(item)}`).join('<br>')}`;$('#obdLinkImportStatus').textContent='Use this checklist before recording the drive in the OBDLink mobile app.'}catch(error){$('#obdLinkImportStatus').textContent=error.message}}
async function startLiveLog(){if(!state.activeProject)return showLogMessage('Create or activate a project before recording.',true);try{state.logSession=await window.tuniq.startLiveLog({profile:$('#logProfile').value,name:$('#logName').value});livePoints.length=0;$('#scanSamples').textContent='0';renderDeviceStatus();startLivePolling();showLogMessage(`Recording ${state.logSession.profileName}. Drive safely and add an event marker when the problem occurs.`);await refreshWorkspace(true)}catch(error){showLogMessage(error.message,true)}}
async function stopLiveLog(){try{const result=await window.tuniq.stopLiveLog();state.logSession=null;renderDeviceStatus();if(result?.analysis)renderLogAnalysis(result.analysis);await loadLiveLogs();await refreshWorkspace(true);if(result){state.lastCompletedLog=result;openOutcomeForm(result);}showLogMessage(result?`Saved ${result.name||result.csvPath?.split(/[\\/]/).pop()||'live log'} with ${result.samples} samples. AI review is ready.`:'No active recording.')}catch(error){showLogMessage(error.message,true)}}
async function markLiveLog(){const label=prompt('Event marker','Problem happened here');if(!label)return;try{await window.tuniq.markLiveLog(label);showLogMessage(`Marker queued: ${label}. It will be attached to the next sample.`)}catch(error){showLogMessage(error.message,true)}}
function toggleDriveMode(){document.body.classList.toggle('drive-mode');$('#logDriveMode').textContent=document.body.classList.contains('drive-mode')?'Exit Drive Mode':'Drive Mode'}


function openOutcomeForm(log){
  if(!log?.csvPath)return;state.lastCompletedLog=log;$('#outcomeLogPath').value=log.csvPath;$('#outcomeRating').value='';$('#outcomeDtcs').value='';$('#outcomeRepairs').value='';$('#outcomeNotes').value='';$('#outcomeWideband').checked=false;$('#outcomeProposalChanged').checked=false;$('#outcomeShare').checked=Boolean(state.beta?.preferences?.improvementOptIn);$('#outcomeStatus').textContent='VIN, email, raw BIN data, and exact file paths are never included.';$('#logOutcomeForm').classList.remove('hidden');$('#logOutcomeForm').scrollIntoView({behavior:'smooth',block:'center'});
}
function closeOutcomeForm(){$('#logOutcomeForm').classList.add('hidden')}
function showBetaMessage(message,bad=false){const el=$('#betaReportStatus');if(el){el.textContent=message;el.classList.toggle('bad',bad)}}
function renderUpdateState(update=state.updates){if(!update)return;state.updates=update;$('#updateState').textContent=String(update.state||'idle').toUpperCase();$('#updateMessage').textContent=update.message||'No update information.';$('#updateDownload').disabled=update.state!=='available';$('#updateInstall').disabled=!update.downloaded;}
function renderBetaCenter(){
  const beta=state.beta;if(!beta)return;const prefs=beta.preferences||{},flash=beta.support?.flashing||{},logging=beta.support?.logging||{};
  $('#betaBuildVersion').textContent=`v${state.version||'1.7.0-beta.7'}`;$('#betaQueueCount').textContent=`${Number(beta.queueCount||0)} item${Number(beta.queueCount||0)===1?'':'s'}`;
  $('#betaAgreementBadge').textContent=beta.agreementAccepted?'BETA AGREEMENT ACCEPTED':'AGREEMENT NOT ACCEPTED';$('#betaAgreementBadge').className=`status-badge ${beta.agreementAccepted?'beta-ok':'beta-warn'}`;
  $('#betaFlashSupport').textContent=supportLabel(flash.status);$('#betaFlashSupport').className=`support-${supportClass(flash.status)}`;$('#betaFlashSupportNote').textContent=flash.note||'';
  $('#betaLogSupport').textContent=supportLabel(logging.status);$('#betaLogSupport').className=`support-${supportClass(logging.status)}`;$('#betaLogSupportNote').textContent=logging.note||'';
  $('#betaImprove').checked=Boolean(prefs.improvementOptIn);$('#betaShareLogs').checked=Boolean(prefs.shareSanitizedLogs);$('#betaShareCrashes').checked=Boolean(prefs.shareCrashReports);$('#betaExperimental').checked=Boolean(prefs.allowExperimentalHardware);$('#betaUpdateChannel').value=prefs.updateChannel||'beta';$('#betaUpdateFeed').value=prefs.updateFeedUrl||'';
  $('#betaShareLogs').disabled=!prefs.improvementOptIn;$('#betaShareCrashes').disabled=!prefs.improvementOptIn;
  $('#betaMatrixVersion').textContent=`Matrix ${beta.supportMatrixVersion||'unknown'}`;
  $('#betaCompatibilityGrid').innerHTML=(beta.matrix||[]).map(item=>`<article class="compat-card"><span class="support-status ${supportClass(item.status)}">${supportLabel(item.status)}</span><b>${safe(item.label)}</b><small>${safe(item.note)}</small></article>`).join('')||'<p class="muted">No compatibility records loaded.</p>';
  renderUpdateState(state.updates);
}
async function loadBetaCenter(){state.beta=await window.tuniq.getBetaState();state.updates=await window.tuniq.getUpdateStatus();renderBetaCenter();renderWorkspaceStrip();renderFlashWorkspace();}


async function init(){
  if(!window.tuniq)throw new Error('TunIQ desktop bridge did not load. Run the startup recovery file and try again.');
  if(window.tuniq.onFlashProgress)window.tuniq.onFlashProgress(payload=>renderFlashProgress(payload));
  if(window.tuniq.onUpdateStatus)window.tuniq.onUpdateStatus(payload=>renderUpdateState(payload));
  if(window.tuniq.onP01AutoProgress)window.tuniq.onP01AutoProgress(payload=>{state.p01Auto=payload;if(payload?.p01){state.p01=payload.p01;if(state.workspace)state.workspace.p01=payload.p01}renderP01Auto(payload);renderFlashWorkspace()});
  state=await window.tuniq.getBootstrap();
  state.vehicles=Array.isArray(state.vehicles)?state.vehicles:[];
  state.activity=Array.isArray(state.activity)?state.activity:[];
  state.tools=state.tools&&typeof state.tools==='object'?state.tools:{};
  state.settings=state.settings&&typeof state.settings==='object'?state.settings:{};state.settings.detailLevel=state.settings.detailLevel||'beginner';
  state.activeProject=state.activeProject||null;
  state.aiIntake=state.ai?.intake||null;state.aiPlan=state.ai?.plan||null;
  state.tuneLibrary=Array.isArray(state.tuneLibrary)?state.tuneLibrary:[];
  state.communityPosts=Array.isArray(state.communityPosts)?state.communityPosts:[];state.devices=Array.isArray(state.devices)?state.devices:[];state.device=state.device||{connected:false,connection:null,preferred:{}};state.liveLogs=Array.isArray(state.liveLogs)?state.liveLogs:[];state.sensorProfiles=state.sensorProfiles||{};state.logSession=state.device.logging||null;state.flash=state.flash||null;state.validation=state.validation||null;state.aiProposals=Array.isArray(state.aiProposals)?state.aiProposals:[];state.currentProposal=state.aiProposals[0]||null;state.goalRequests=Array.isArray(state.goalRequests)?state.goalRequests:[];state.goalProposal=state.goalRequests[0]||null;state.p01Evidence=state.p01Evidence&&typeof state.p01Evidence==='object'?state.p01Evidence:null;
  $('#version').textContent=`v${state.version}`;
  populateControllerCatalog();initializeEngineSelector();renderTools();renderVehicles();updateHeader();bindCalibrationControls();
  await loadProjects();
  await refreshProjectFiles();
  await refreshWorkspace(true);
  fillAiForm(state.aiIntake);renderAiPlan();renderP01Auto();renderTuneLibrary();renderCommunityPosts();renderDeviceStatus();renderLiveLogHistory();renderP01Evidence();renderAiProposalWorkspace();renderAiGoalRequest();renderBetaCenter();
  setTimeout(()=>{
    $('#splash').classList.add('hidden');
    $('#app').classList.remove('hidden');
    if(!state.beta?.agreementAccepted)$('#betaAgreementModal').classList.remove('hidden');else if(!state.profile||!state.settings.aiMode)$('#wizard').classList.remove('hidden');
  },300);
}
$$('.app-sidebar button').forEach(b=>b.onclick=()=>showPage(b.dataset.page));$$('[data-jump]').forEach(b=>b.onclick=()=>showPage(b.dataset.jump));$('#modeBtn').onclick=()=>showPage('settings');
$('#wizardForm').onsubmit=async e=>{e.preventDefault();try{const aiMode=$('input[name="aiMode"]:checked').value;const result=await window.tuniq.saveProfile({name:$('#name').value,email:$('#email').value,units:$('#units').value,aiMode});state.profile=result.profile;state.settings=result.settings;updateHeader();await refreshWorkspace(true);$('#wizard').classList.add('hidden')}catch(err){$('#wizardError').textContent=err.message}};
$('#resetWizard').onclick=()=>{$('#name').value=state.profile?.name||'';$('#email').value=state.profile?.email||'';$('#units').value=state.settings.units||'US';const r=$(`input[name="aiMode"][value="${state.settings.aiMode||'guided'}"]`);if(r)r.checked=true;$('#wizard').classList.remove('hidden')};
$('#modeSelect').onchange=async()=>{state.settings=await window.tuniq.setAiMode($('#modeSelect').value);updateHeader();await refreshWorkspace(true)};
$('#detailSelect').onchange=async()=>{state.settings=await window.tuniq.setDetailLevel($('#detailSelect').value);updateHeader()};
$('#scanTools').onclick=async event=>{const button=event.currentTarget;button.disabled=true;status('Scanning common install folders, LocalAppData, Desktop, and Downloads...');try{state.tools=await window.tuniq.scanTools();renderTools();await refreshWorkspace(true);const found=Object.values(state.tools).filter(Boolean).length;status(`Scan complete: ${found} of 3 tools ready. Use Browse for any portable copy TunIQ did not find.`)}catch(e){status(e.message,true)}finally{button.disabled=false}};
async function exportDiag(){try{const p=await window.tuniq.exportDiagnostics({description:$('#betaReportDescription')?.value||'',steps:$('#betaReportSteps')?.value||''});status(`Diagnostics saved to:\n${p}`);$('#diagText').textContent=`Latest report:\n${p}`}catch(e){status(e.message,true)}}$('#exportDiag').onclick=exportDiag;$('#diagExport2').onclick=exportDiag;
$('#projectForm').onsubmit=async e=>{
  e.preventDefault();
  const payload={id:$('#projectId').value||null,name:$('#projectName').value,vehicle:$('#projectVehicle').value,controller:$('#projectController').value,os:$('#projectOs').value,notes:$('#projectNotes').value};
  $('#projectSubmit').disabled=true;
  try{
    if(payload.id){
      const updated=await window.tuniq.updateProject(payload);
      if(updated.active)state.activeProject=updated.active;
      await loadProjects();
      updateActiveProject();
      await refreshProjectFiles();
      await refreshWorkspace(true);
      $('#projectFormStatus').textContent=`Saved ${updated.name}. Project files and revision history were preserved.`;
      status(`Updated project ${updated.name}.`);
      beginProjectEdit(updated.active||updated);
    }else{
      const created=await window.tuniq.createProject(payload);
      state.activeProject=created.active||await window.tuniq.setActiveProject(created.id);
      resetProjectForm();
      await loadProjects();
      updateActiveProject();
      await refreshProjectFiles();
      await refreshWorkspace(true);
      invalidateCalibration('A new project is active. Import and load its BIN and XDF before editing.');
      status(`Created and activated ${state.activeProject.name}. Import its original BIN and matching XDF next.`);
      showPage('files');
    }
  }catch(err){
    $('#projectFormStatus').textContent=err.message;
    alert(err.message);
  }finally{$('#projectSubmit').disabled=false}
};
$('#projectCancelEdit').onclick=resetProjectForm;
$('#newProjectTop').onclick=resetProjectForm;
$('#projectVehicle').onchange=()=>{const vehicle=state.vehicles.find(item=>item.name===$('#projectVehicle').value);if(vehicle?.controller&&!$('#projectController').value.trim())$('#projectController').value=vehicle.controller};
$('#detectProjectOs').onclick=async()=>{try{
  const result=await window.tuniq.detectProjectOs();
  if(result.detected){
    $('#projectOs').value=result.os;
    $('#projectOsHelp').textContent=`Detected ${result.os} from ${result.source}. TunIQ saved it to the active project.`;
    $('#projectFormStatus').textContent=result.message;
    if(result.active){state.activeProject=result.active;await loadProjects();await refreshWorkspace(true)}
  }else{
    $('#projectOsHelp').textContent=result.message;
    $('#projectFormStatus').textContent=result.message;
  }
}catch(error){$('#projectOsHelp').textContent=error.message;$('#projectFormStatus').textContent=error.message}};
$('#vehicleForm').onsubmit=async e=>{e.preventDefault();try{await window.tuniq.saveVehicle({id:$('#vehicleId').value||null,year:$('#vehicleYear').value,make:$('#vehicleMake').value,name:$('#vehicleName').value,model:$('#vehicleModel').value,engine:$('#vehicleEngine').value,controller:$('#vehicleController').value,vin:$('#vehicleVin').value,notes:$('#vehicleNotes').value});state.vehicles=await window.tuniq.listVehicles();renderVehicles();closeVehicleModal()}catch(err){$('#vehicleError').textContent=err.message}};$('#addVehicleBtn').onclick=()=>openVehicleModal();$('#cancelVehicle').onclick=closeVehicleModal;
$('#deviceScan').onclick=scanDevices;
$('#deviceImportPids').onclick=async()=>{try{const library=await window.tuniq.importPidLibrary();if(library){const count=(library.profiles||[]).reduce((total,profile)=>total+(profile.channels||[]).length,0);$('#pidProfileState').textContent=`Loaded ${library.profiles.length} controller profile(s) with ${count} enhanced PID channel(s). Reconnect the adapter to activate them.`}}catch(error){$('#pidProfileState').textContent=error.message}};
$('#devicePort').onchange=renderDeviceList;
$('#deviceConnect').onclick=()=>connectSelectedDevice();
$('#deviceDisconnect').onclick=disconnectDevice;
$('#deviceUseDemo').onclick=async()=>{if(!state.devices.some(item=>item.port==='virtual-demo'))state.devices.push({port:'virtual-demo',name:'TunIQ Virtual OBD-II Adapter',transport:'Simulation',demo:true});renderDeviceList();$('#devicePort').value='virtual-demo';await connectSelectedDevice('virtual-demo')};
$('#openDeviceManager').onclick=()=>showPage('devices');
$('#logStart').onclick=startLiveLog;
$('#logStop').onclick=stopLiveLog;
$('#logMarker').onclick=markLiveLog;
$('#logDriveMode').onclick=toggleDriveMode;
$('#refreshLiveLogs').onclick=loadLiveLogs;$('#p01EvidenceRefresh').onclick=loadP01Evidence;$('#p01EvidenceImport').onclick=()=>importP01Evidence('');$('#importObdLinkLog').onclick=importObdLinkPhoneLog;$('#importObdLinkLog2').onclick=importObdLinkPhoneLog;$('#showObdLinkGuide').onclick=showObdLinkGuide;
function ask(q){if(!q)return;$('#messages').insertAdjacentHTML('beforeend',`<div class="msg user">${safe(q)}</div>`);setTimeout(()=>{$('#messages').insertAdjacentHTML('beforeend',`<div class="msg ai"><b>✦ TunIQ Coach</b><br>${offlineAnswer(q)}</div>`);$('#messages').scrollTop=$('#messages').scrollHeight},state.settings.aiMode==='manual'?250:650)}
$('#aiForm').onsubmit=e=>{e.preventDefault();const q=$('#aiInput').value.trim();$('#aiInput').value='';ask(q)};$$('[data-question]').forEach(b=>b.onclick=()=>ask(b.dataset.question));
$('#importBin').onclick=async()=>{try{
  const result=await window.tuniq.importBin();
  if(result){if(result.active)state.activeProject=result.active;invalidateCalibration('The original BIN changed. Load the active BIN and XDF mapping again before editing or exporting.');await refreshProjectFiles();await refreshWorkspace(true);status(`Imported protected original ${result.name}.${result.detectedOs?` TunIQ detected OS ${result.detectedOs} from ${result.osSource}.`:''} Load BIN + XDF again before exporting.`)}
}catch(error){alert(error.message)}};
$('#importXdf').onclick=async()=>{try{
  const result=await window.tuniq.importXdf();
  if(result){if(result.active)state.activeProject=result.active;invalidateCalibration('The XDF changed. Load the active BIN and XDF mapping again before editing or exporting.');await refreshProjectFiles();await refreshWorkspace(true);status(`Imported ${result.name} with ${result.tableCount} mapped items.${result.detectedOs?` TunIQ detected OS ${result.detectedOs} from ${result.osSource}.`:''} Open the mapping in Calibration Lab to verify it.`)}
}catch(error){alert(error.message)}};
$('#openProjectFolder').onclick=async()=>{try{await window.tuniq.openProjectFolder()}catch(error){alert(error.message)}};
$('#workspaceRefresh').onclick=()=>refreshWorkspace().catch(error=>alert(error.message));
$('#tunePathToggle').onclick=()=>$('#tunePathPanel').classList.toggle('collapsed');
$('#flashGoTools').onclick=()=>showPage('bridge');
async function openAssistedPcmHammer(operation='readProperties'){try{const input=$('#flashRevision')?.value||null;const result=await window.tuniq.startAssistedPcmHammer({operation,input,device:$('#flashInterface')?.value.trim()||''});state.flash={...(state.flash||{}),assisted:result};$('#flashConsole').textContent=[result.reason,...(result.instructions||[])].join('\n');await refreshWorkspace(true)}catch(error){$('#flashConsole').textContent=error.message}}
async function importAssistedPcmHammer(){try{const result=await window.tuniq.importAssistedPcmHammer({operation:state.flash?.assisted?.operation||'readProperties',input:$('#flashRevision')?.value||null});if(result){$('#flashConsole').textContent=`Assisted evidence import:\n${(result.imported||[]).map(item=>`${item.accepted?'✓':'×'} ${item.type}: ${item.file}${item.message?` — ${item.message}`:''}`).join('\n')||'No files selected.'}`;await refreshWorkspace(true)}}catch(error){$('#flashConsole').textContent=error.message}}
async function probeFlashCli(){try{$('#flashProbe').disabled=true;$('#flashConsole').textContent='Probing PCM Hammer CLI help and operation capabilities…';const result=await window.tuniq.probeFlashCli({});state.flash={...(state.flash||{}),...result,configured:true};$('#flashConsole').textContent=`PCM Hammer CLI: ${result.executable}\nProbed: ${new Date(result.probedAt).toLocaleString()}\n\nCapabilities:\n${Object.entries(result.capabilities).map(([key,value])=>`${value?'✓':'×'} ${flashCapabilityName(key)}`).join('\n')}\n\n${result.help||''}`;await refreshWorkspace(true)}catch(error){$('#flashConsole').textContent=error.message}finally{$('#flashProbe').disabled=false}}
function flashPayload(operation){return {operation,device:$('#flashInterface').value.trim(),voltage:$('#flashVoltage').value?Number($('#flashVoltage').value):undefined,benchPowerConfirmed:$('#flashBenchPower').checked,input:$('#flashRevision').value,confirmation:$('#flashConfirmation').value.trim()}}
async function startFlash(operation){try{const labels={readProperties:'Reading controller properties',read:'Reading protected original',testWrite:'Running test write',writeCalibration:'Writing calibration',writeFull:'Writing full PCM',recovery:'Starting recovery operation'};$('#flashConsole').textContent=`${labels[operation]||operation}…\nDo not disconnect the interface or power.`;const result=await window.tuniq.startFlashOperation(flashPayload(operation));renderFlashProgress(result);await refreshWorkspace(true)}catch(error){$('#flashSessionState').textContent='BLOCKED';$('#flashConsole').textContent=error.message}}
$('#flashProbe').onclick=probeFlashCli;
$('#flashAssistedOpen').onclick=()=>openAssistedPcmHammer(state.p01Auto?.nextStep==='test-write'?'testWrite':state.p01Auto?.nextStep?.startsWith('read-')?'read':'readProperties');
$('#flashAssistedImport').onclick=importAssistedPcmHammer;
$('#flashInterface').onchange=()=>window.tuniq.saveFlashDevice($('#flashInterface').value.trim()).catch(()=>{});
$('#flashSaveTemplates').onclick=async()=>{try{const templates={readProperties:$('#flashTemplateIdentify').value.trim()||null,read:$('#flashTemplateRead').value.trim()||null,testWrite:$('#flashTemplateTest').value.trim()||null,writeCalibration:$('#flashTemplateWriteCal').value.trim()||null,writeFull:$('#flashTemplateWriteFull').value.trim()||null,recovery:$('#flashTemplateRecovery').value.trim()||null};await window.tuniq.saveFlashTemplates(templates);state.flash=await window.tuniq.getFlashStatus();renderFlashWorkspace();$('#flashConsole').textContent='Saved PCM Hammer CLI command templates. Run Read Properties or Read first before attempting a write.'}catch(error){$('#flashConsole').textContent=error.message}};
$('#flashIdentify').onclick=()=>startFlash('readProperties');
$('#flashRead').onclick=()=>startFlash('read');
$('#p01ImportIdentity').onclick=async()=>{try{const result=await window.tuniq.importP01IdentityProof();if(result){state.p01=result;await refreshWorkspace(true)}}catch(error){alert(error.message)}};
$('#p01ImportReads').onclick=async()=>{try{const result=await window.tuniq.importP01Reads();if(result){state.p01=result;await refreshProjectFiles();await refreshWorkspace(true)}}catch(error){alert(error.message)}};
$('#p01ConfirmDefinition').onclick=async()=>{const os=state.p01?.identity?.os;if(!os)return alert('Run Read Properties for the P01 first.');const typed=prompt(`Type the identified operating system to bind the loaded XDF:\n\n${os}`,'');if(typed===null)return;if(!confirm('Confirm that this XDF came from a trusted source for this exact P01 operating system and that the Calibration page shows no mapping warnings.'))return;try{state.p01=await window.tuniq.confirmP01Definition({typedOs:typed,acknowledged:true});await refreshWorkspace(true)}catch(error){alert(error.message)}};
$('#p01ImportTestWrite').onclick=async()=>{const input=$('#flashRevision')?.value;if(!input)return alert('Select the exact revision used in PCM Hammer Test Write first.');try{state.p01=await window.tuniq.importP01TestWriteProof(input);await refreshWorkspace(true)}catch(error){alert(error.message)}};
$('#p01IdentifyNow').onclick=()=>startFlash('readProperties');
$('#p01ReadNow').onclick=()=>startFlash('read');
$('#p01OpenCalibration').onclick=()=>showPage(state.activeProject?.bin&&state.activeProject?.xdf?'sandbox':'files');
$('#p01Reset').onclick=async()=>{if(!confirm('Reset the saved P01 commissioning proof for this project? Existing BIN and revision files will not be deleted.'))return;try{state.p01=await window.tuniq.resetP01Commissioning();if(state.workspace)state.workspace.p01=state.p01;renderP01Commissioning();renderFlashWorkspace()}catch(error){alert(error.message)}};
$('#flashRevision').onchange=()=>refreshP01ForSelectedRevision();
$('#flashTestWrite').onclick=()=>{if(confirm('Run PCM Hammer Test Write with the selected exact validated revision and stable power? This should be completed before the first real write.'))startFlash('testWrite')};
$('#flashWriteCalibration').onclick=()=>{const active=state.activeProject;if(!active)return;const expected=`WRITE ${active.name}`;if($('#flashConfirmation').value.trim()!==expected)return alert(`Type exactly ${expected} before writing.`);if(confirm(`Write the selected calibration to ${active.name}?\n\nKeep stable 12.5–14 V power and do not disconnect the interface.`))startFlash('writeCalibration')};
$('#flashWriteFull').onclick=()=>{const active=state.activeProject;if(!active)return;const expected=`FULL WRITE ${active.name}`;if($('#flashConfirmation').value.trim()!==expected)return alert(`Type exactly ${expected} before a full write.`);if(confirm(`FULL PCM WRITE for ${active.name}. This is higher risk than calibration-only writing. Continue only with a recovery plan and stable bench power.`))startFlash('writeFull')};
$('#flashRecovery').onclick=()=>{const active=state.activeProject;if(!active)return;const expected=`FULL WRITE ${active.name}`;if($('#flashConfirmation').value.trim()!==expected)return alert(`Type exactly ${expected} before recovery.`);if(confirm('Start the PCM Hammer recovery operation using the selected validated revision?'))startFlash('recovery')};
$('#flashCancel').onclick=async()=>{try{const result=await window.tuniq.cancelFlashOperation();if(result.session)renderFlashProgress(result.session)}catch(error){$('#flashConsole').textContent+=`\n${error.message}`}};

function patchTarget(){return $('#patchRevision').value||undefined}
function showValidation(result){state.validation=result;const analysis=result.analysis||result;const diff=analysis.comparison;$('#patchConsole').textContent=[`File: ${result.targetFileName||analysis.name}`,`SHA-256: ${result.targetFileSha256||analysis.sha256}`,`Size: ${analysis.size||diff?.revised?.size||0} bytes`,`Layout: ${result.compatible===false?'MISMATCH':'Compatible'}`,`Checksum: ${result.checksumStatus||analysis.nativeChecksumStatus}`,`Changed bytes: ${diff?.changedBytes??0} (${Number(diff?.changedPercent||0).toFixed(4)}%)`,`Changed segments: ${(diff?.segmentChanges||[]).filter(item=>item.changed).map(item=>item.index).join(', ')||'None'}`,`Native checksum definitions: ${(analysis.nativeChecksums||[]).length}`,...(result.warnings||[]).map(item=>`WARNING: ${item}`),'',JSON.stringify((analysis.nativeChecksums||[]),null,2)].join('\n');renderPatchWorkspace();renderFlashWorkspace()}
$('#patchAnalyze').onclick=async()=>{try{$('#patchConsole').textContent='Analyzing BIN, explicit XDF checksums, segment layout, and imported Universal Patcher reports…';const result=await window.tuniq.analyzeChecksum(patchTarget());showValidation(result);await refreshWorkspace(true)}catch(error){$('#patchConsole').textContent=error.message}};
$('#patchCompare').onclick=async()=>{try{const result=await window.tuniq.compareRevision(patchTarget());$('#patchConsole').textContent=`Original: ${result.original.name}\nRevision: ${result.revised.name}\nSame size: ${result.sameSize}\nChanged bytes: ${result.changedBytes}\nChanged: ${Number(result.changedPercent).toFixed(5)}%\n\nRanges:\n${result.ranges.slice(0,500).map(range=>`0x${range.start.toString(16).toUpperCase()}–0x${range.end.toString(16).toUpperCase()} (${range.length} bytes)`).join('\n')}${result.truncated?'\n…range list truncated':''}` }catch(error){$('#patchConsole').textContent=error.message}};
$('#patchPreviewBin').onclick=async()=>{try{const result=await window.tuniq.previewPatchedBin();if(!result)return;state.patchPreview=result;const diff=result.comparison;$('#patchConsole').textContent=`Patched BIN preview: ${result.sourceFileName}
SHA-256: ${result.sourceFileSha256}
Layout: ${result.compatible?'Compatible':'MISMATCH — import blocked'}
Changed bytes: ${diff.changedBytes} (${Number(diff.changedPercent||0).toFixed(5)}%)
Native checksum status: ${result.analysis.nativeChecksumStatus}
Changed segments: ${(diff.segmentChanges||[]).filter(item=>item.changed).map(item=>item.index).join(', ')||'None'}

Nothing has been copied or applied yet.`;renderPatchWorkspace()}catch(error){state.patchPreview=null;$('#patchConsole').textContent=error.message;renderPatchWorkspace()}};
$('#patchImportBin').onclick=async()=>{try{if(!state.patchPreview)return;if(!confirm(`Import ${state.patchPreview.sourceFileName} as a NEW project revision? The protected original will not be changed.`))return;const result=await window.tuniq.importPatchedBin(state.patchPreview);state.patchPreview=null;$('#patchConsole').textContent=`Imported ${result.name}
Changed bytes: ${result.comparison.changedBytes}
Checksum status: ${result.validation.checksumStatus}

Analyze this exact revision and import a matching Universal Patcher report if its checksum algorithm is not defined by the XDF.`;await refreshProjectFiles();await refreshWorkspace(true)}catch(error){$('#patchConsole').textContent=error.message}};
$('#patchImportReport').onclick=async()=>{try{const result=await window.tuniq.importUniversalPatcherReport(patchTarget());if(result){$('#patchConsole').textContent=`Imported ${result.report.name}\nValid: ${result.report.valid}\nErrors: ${result.report.errors}\nWarnings: ${result.report.warnings}\n\n${result.report.entries.map(item=>`${item.severity.toUpperCase()}: ${item.text}`).join('\n')}`;await refreshWorkspace(true)}}catch(error){$('#patchConsole').textContent=error.message}};
$('#patchCorrect').onclick=async()=>{try{if(!confirm('Create a NEW revision with the explicit XDF checksum fields corrected? The current revision and original remain unchanged.'))return;const result=await window.tuniq.correctExplicitChecksums(patchTarget());$('#patchConsole').textContent=`Created ${result.name}\nCorrected ${result.corrections.length} checksum field(s).\nStatus: ${result.analysis.checksumStatus}`;await refreshWorkspace(true)}catch(error){$('#patchConsole').textContent=error.message}};
$('#openRevisionsFolder').onclick=async()=>{try{await window.tuniq.openProjectSubfolder('revisions')}catch(error){alert(error.message)}};
$('#openLogsFolder').onclick=async()=>{try{await window.tuniq.openProjectSubfolder('logs')}catch(error){alert(error.message)}};
$('#labLoadXdf').onclick=loadRealCalibration;
$('#labExportBin').onclick=async()=>{try{
  if(state.calibration?.mode!=='xdf')throw new Error('Load a BIN and XDF mapping first.');
  if(state.calibration.projectId!==state.activeProject?.id)throw new Error('Reload the BIN and XDF for the active project before exporting.');
  if(!validateCalibration())throw new Error('Fix out-of-range values before exporting.');
  await persistCalibration();
  const result=await window.tuniq.exportBin(state.calibration);
  alert(`Revision BIN exported safely:\n${result.path}\n\nModified cells: ${result.modifiedCells}\nSHA-256: ${result.sha256}`);
  await refreshProjectFiles();
  await refreshWorkspace(true);
}catch(error){alert(error.message)}};

$$('.ai-mod').forEach(input=>input.onchange=updateAiCamVisibility);
$('#aiTuneGoal').onchange=updateAiCamVisibility;
optionalSpecInputs().forEach(([,selector])=>$(selector).oninput=updateOptionalSpecState);
$('#aiFindOptionalSpecs').onclick=useKnownOptionalSpecs;
$('#aiSaveIntake').onclick=async()=>{try{const intake=await window.tuniq.saveAiIntake(collectAiPayload());state.aiIntake=intake;$('#fullAiError').textContent='Build intake saved to the active project. Generate the plan when the hardware and goal are complete.';$('#fullAiError').classList.remove('bad');renderAiPlan();await refreshWorkspace(true)}catch(error){showFullAiError(error)}};
$('#fullAiForm').onsubmit=async event=>{event.preventDefault();$('#aiGeneratePlan').disabled=true;try{const result=await window.tuniq.generateAiPlan(collectAiPayload());state.aiIntake=result.intake;state.aiPlan=result.plan;$('#fullAiError').textContent=`Generated ${result.plan.steps.length} project-specific steps. No calibration bytes or controller data were changed.`;$('#fullAiError').classList.remove('bad');renderAiPlan();await refreshWorkspace(true)}catch(error){showFullAiError(error)}finally{$('#aiGeneratePlan').disabled=false}};
$('#aiBuildGoalRequest').onclick=buildAiGoalRequest;
$('#p01AutoStart').onclick=startP01Auto;$('#p01AutoResume').onclick=resumeP01Auto;$('#p01AutoChooseXdf').onclick=chooseP01AutoXdf;$('#p01AutoCancel').onclick=cancelP01Auto;$('#p01AutoWrite').onclick=writeP01Auto;
$('#aiConfirmGoalMap').onclick=confirmP01GoalMap;$('#aiApplyGoalRequest').onclick=applyAiGoalRequest;
$('#aiGenerateProposal').onclick=async()=>{const csvPath=$('#aiProposalLog').value;if(!csvPath)return alert('Choose a saved CSV log first.');$('#aiGenerateProposal').disabled=true;try{state.currentProposal=await window.tuniq.generateAiProposal(csvPath);state.aiProposals=[state.currentProposal,...(state.aiProposals||[]).filter(item=>item.id!==state.currentProposal.id)];renderAiProposalWorkspace();await refreshWorkspace(true)}catch(error){$('#aiProposalSummary').textContent=error.message}finally{$('#aiGenerateProposal').disabled=false}};
$('#aiApplyProposal').onclick=async()=>{const proposal=state.currentProposal;if(!proposal)return;const approvedIds=$$('.ai-proposal-approve:checked').map(box=>box.value);if(!approvedIds.length)return alert('Approve at least one proposed cell.');if(!confirm(`Apply ${approvedIds.length} approved cell change(s) and export a new revision? The protected original will not be changed.`))return;$('#aiApplyProposal').disabled=true;try{const result=await window.tuniq.applyAiProposal({proposalId:proposal.id,approvedIds});state.calibration=normalizeCalibration(result.workspace);calibrationInitialized=true;renderCalibration();alert(`AI-approved revision exported:
${result.revision.path}

Applied cells: ${result.applied.length}
Checksum status: ${result.revision.checksumStatus}`);await refreshProjectFiles();await refreshWorkspace(true)}catch(error){alert(error.message)}finally{renderAiProposalWorkspace()}};
$('#showTuneSave').onclick=()=>{const form=$('#tuneSaveForm');form.classList.remove('hidden');const active=state.activeProject,intake=state.aiIntake;setValue('#tuneName',active?`${active.name} Tune`:'');setValue('#tuneGoal',intake?.tuneGoal||'');setValue('#tuneEngine',intake?.engine||'');setValue('#tuneTransmission',intake?.transmission||'');setValue('#tuneFuel',intake?.fuel||'');setValue('#tuneTags',(intake?.modifications||[]).join(', '));form.scrollIntoView({behavior:'smooth',block:'start'})};
$('#cancelTuneSave').onclick=()=>$('#tuneSaveForm').classList.add('hidden');
$('#tuneSaveForm').onsubmit=async event=>{event.preventDefault();try{const entry=await window.tuniq.saveActiveTune({name:$('#tuneName').value,tuneGoal:$('#tuneGoal').value,engine:$('#tuneEngine').value,transmission:$('#tuneTransmission').value,fuel:$('#tuneFuel').value,tags:$('#tuneTags').value,description:$('#tuneDescription').value});$('#tuneSaveStatus').textContent=`Saved ${entry.name} with SHA-256 ${entry.sourceSha256.slice(0,16)}…`;$('#tuneSaveForm').classList.add('hidden');await loadTuneLibrary();await refreshWorkspace(true)}catch(error){$('#tuneSaveStatus').textContent=error.message}};
$('#importTunePackage').onclick=async()=>{try{const entry=await window.tuniq.importTune();if(entry){await loadTuneLibrary();alert(`Imported ${entry.name} into the local Tune Library.`)}}catch(error){alert(error.message)}};
['#tuneSearch','#tuneEngineFilter','#tuneTransmissionFilter','#tuneControllerFilter'].forEach(id=>$(id).oninput=renderTuneLibrary);$('#tuneFavoritesOnly').onchange=renderTuneLibrary;
['#communitySearch','#communityEngine','#communityTransmission','#communityController'].forEach(id=>$(id).oninput=renderCommunityPosts);$('#communityCategory').onchange=renderCommunityPosts;
$('#communityPostForm').onsubmit=async event=>{event.preventDefault();try{const post=await window.tuniq.createCommunityPost({category:$('#postCategory').value,title:$('#postTitle').value,engine:$('#postEngine').value,transmission:$('#postTransmission').value,controller:$('#postController').value,tags:$('#postTags').value,body:$('#postBody').value,attachProject:$('#postAttachProject').checked});$('#postStatus').textContent=`Saved local draft: ${post.title}`;$('#communityPostForm').reset();$('#postAttachProject').checked=true;await loadCommunityPosts()}catch(error){$('#postStatus').textContent=error.message}};


$('#betaAgreementForm').onsubmit=async event=>{event.preventDefault();if(!$('#betaAgreementCheck').checked)return;try{state.beta=await window.tuniq.acceptBetaAgreement(true);$('#betaAgreementModal').classList.add('hidden');renderBetaCenter();renderFlashWorkspace();if(!state.profile||!state.settings.aiMode)$('#wizard').classList.remove('hidden')}catch(error){$('#betaAgreementError').textContent=error.message}};
$('#betaAgreementRead').onclick=()=>window.tuniq.openBetaDocument('agreement').catch(error=>$('#betaAgreementError').textContent=error.message);
$('#logOutcomeForm').onsubmit=async event=>{event.preventDefault();try{const result=await window.tuniq.saveLogOutcome({csvPath:$('#outcomeLogPath').value,rating:$('#outcomeRating').value,newDtcs:$('#outcomeDtcs').value,repairsMade:$('#outcomeRepairs').value,notes:$('#outcomeNotes').value,widebandUsed:$('#outcomeWideband').checked,aiProposalChanged:$('#outcomeProposalChanged').checked,consentToImprove:$('#outcomeShare').checked,engine:state.aiIntake?.engine||'',tuneGoal:state.aiIntake?.tuneGoal||''});state.beta=result.state;$('#outcomeStatus').textContent='Result saved. Thank you for documenting the outcome.';renderBetaCenter();setTimeout(closeOutcomeForm,700)}catch(error){$('#outcomeStatus').textContent=error.message}};
$('#outcomeCancel').onclick=closeOutcomeForm;
$('#betaImprove').onchange=()=>{$('#betaShareLogs').disabled=!$('#betaImprove').checked;$('#betaShareCrashes').disabled=!$('#betaImprove').checked;if(!$('#betaImprove').checked){$('#betaShareLogs').checked=false;$('#betaShareCrashes').checked=false}};
$('#betaPreferencesForm').onsubmit=async event=>{event.preventDefault();try{state.beta=await window.tuniq.saveBetaPreferences({improvementOptIn:$('#betaImprove').checked,shareSanitizedLogs:$('#betaShareLogs').checked,shareCrashReports:$('#betaShareCrashes').checked,allowExperimentalHardware:$('#betaExperimental').checked,updateChannel:$('#betaUpdateChannel').value,updateFeedUrl:$('#betaUpdateFeed').value});state.updates=await window.tuniq.getUpdateStatus();$('#betaPreferenceStatus').textContent='Privacy and beta preferences saved locally.';renderBetaCenter();renderFlashWorkspace()}catch(error){$('#betaPreferenceStatus').textContent=error.message}};
$('#betaCreateReport').onclick=async()=>{try{const file=await window.tuniq.exportDiagnostics({description:$('#betaReportDescription').value,steps:$('#betaReportSteps').value});if(file)showBetaMessage(`Privacy-safe diagnostic package created:\n${file}`)}catch(error){showBetaMessage(error.message,true)}};
$('#betaExportQueue').onclick=async()=>{try{const file=await window.tuniq.exportImprovementQueue();if(file)showBetaMessage(`Improvement package exported:\n${file}`)}catch(error){showBetaMessage(error.message,true)}};
$('#betaSubmitQueue').onclick=async()=>{try{const result=await window.tuniq.submitImprovementQueue();state.beta=result.state;showBetaMessage(`Submitted ${result.submitted} queued item(s).`);renderBetaCenter()}catch(error){showBetaMessage(error.message,true)}};
$('#betaClearQueue').onclick=async()=>{if(!confirm('Delete all locally queued improvement data?'))return;state.beta=await window.tuniq.clearImprovementQueue();showBetaMessage('Queued improvement data deleted.');renderBetaCenter()};
$('#betaResetAgreement').onclick=async()=>{if(!confirm('Reset the Public Beta Agreement? Controller operations will be blocked until it is accepted again.'))return;state.beta=await window.tuniq.acceptBetaAgreement(false);renderBetaCenter();renderFlashWorkspace();$('#betaAgreementCheck').checked=false;$('#betaAgreementModal').classList.remove('hidden')};
$$('.beta-doc').forEach(button=>button.onclick=()=>window.tuniq.openBetaDocument(button.dataset.document).catch(error=>showBetaMessage(error.message,true)));
$('#updateCheck').onclick=async()=>{try{renderUpdateState({state:'checking',message:'Checking for updates…'});state.updates=await window.tuniq.checkForUpdates();renderUpdateState(state.updates)}catch(error){renderUpdateState({state:'error',message:error.message})}};
$('#updateDownload').onclick=async()=>{try{state.updates=await window.tuniq.downloadUpdate();renderUpdateState(state.updates)}catch(error){renderUpdateState({state:'error',message:error.message})}};
$('#updateInstall').onclick=async()=>{try{await window.tuniq.installUpdate()}catch(error){renderUpdateState({state:'error',message:error.message})}};

init().catch(e=>{document.body.innerHTML=`<pre style="padding:30px;color:#ffb18d">Startup error: ${safe(e.stack||e.message)}</pre>`});
