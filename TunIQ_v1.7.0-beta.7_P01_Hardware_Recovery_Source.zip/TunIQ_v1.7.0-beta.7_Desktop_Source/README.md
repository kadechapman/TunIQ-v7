# TunIQ v1.7.0-beta.7 — P01 Hardware Recovery

TunIQ is a Windows tuning workspace. This beta focuses on a recoverable, evidence-driven GM P01 setup path using PCM Hammer 2.x.

## Guided Automatic P01 Setup

Until physical hardware verification is completed, the workflow is named **Guided Automatic P01 Setup**. It:

- reads the installed PCM Hammer 2.x CLI help and uses only operations that build actually exposes;
- treats **Read Properties** as the identity operation and never requires a command literally named `identify`;
- releases TunIQ's serial session before PCM Hammer starts and detects a COM port held by another process;
- offers an assisted normal PCM Hammer Windows-app path when CLI automation is unavailable or unsupported;
- imports OSID, Hardware ID, service number, controller, VIN, voltage, full-read evidence, and Test Write results;
- accepts only two independent 524,288-byte P01 reads with identical SHA-256 hashes;
- rejects, quarantines, and explains failed, partial, oversized, missing, or mismatched reads;
- persists each completed step and resumes from the exact unfinished step after an app restart;
- stops once with an actionable reason rather than repeatedly retrying a failed operation.

## P01 sequence

1. Create or activate a P01 project.
2. Select the interface/COM port and confirm stable power.
3. Start **Guided Automatic P01 Setup**.
4. Complete Read Properties.
5. Complete exactly two independent full reads. Both must be exactly 524,288 bytes and have the same SHA-256 hash.
6. Bind a clean XDF that explicitly matches the detected OS.
7. Map and review the requested calibration cells.
8. Create and validate a protected revision.
9. Complete an explicit successful Test Write on that exact revision.
10. Review the separate write gate and typed authorization before any calibration write.

When CLI automation cannot safely perform a step, TunIQ opens or guides the normal PCM Hammer app, watches the assisted-import folder, and automatically imports supported `.txt`, `.log`, and `.bin` evidence.

## Important validation limit

This source was validated with automated tests and software simulations only. It does **not** claim real-adapter, real-COM4, bench-PCM, vehicle, voltage-under-load, or flash-write verification. Keep the first physical validation on a supported spare/bench P01 with stable power and preserve every PCM Hammer log.

## Install from source

1. Extract the source into a local folder outside OneDrive.
2. Run `INSTALL_AND_RUN_WINDOWS.bat`.
3. TunIQ stores application data under `%APPDATA%\TunIQ`.

## Verify the source

```bat
npm run check
npm test
npm run test:p01-sim
```

See `P01_HARDWARE_RECOVERY.md` and `TEST_REPORT_v1.7.0-beta.7.md`.

TunIQ remains `UNLICENSED` until its owner deliberately selects distribution terms.
