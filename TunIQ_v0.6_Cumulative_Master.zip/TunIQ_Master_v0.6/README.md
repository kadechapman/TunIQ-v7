# TunIQ v0.6 — Cumulative Master

This release contains everything implemented through Waves 1–5 and adds Wave 6 easy-launch improvements.

## Open TunIQ without installing anything

### Windows
1. Extract the ZIP first.
2. Open the extracted folder.
3. Double-click **`OPEN_TUNIQ_WINDOWS.bat`**.

The launcher only opens the self-contained offline app. It does not use Node.js and should not display a command window for normal use.

### Any computer
Open **`TunIQ_Open_Me.html`** directly in a modern browser.

## Why Node.js appeared before

`start-windows.bat` starts the optional AI backend. It is not the normal TunIQ launcher. The backend is only needed for connected AI features and keeps API credentials outside the browser.

## Wave 6 additions

- One-click Windows launcher
- No-install offline startup
- START_HERE instructions
- Clearer separation between the app, optional AI backend, and optional local bridge
- Cumulative preservation of Waves 1–5

## Optional services

- `start-windows.bat`: optional AI backend; requires Node.js
- `bridge/start-bridge-windows.bat`: optional local bridge foundation; requires Node.js

## Still locked

PCM Hammer control, BIN reading/writing, calibration editing, checksums, code clearing, flashing, recovery operations, and automatic tuning are not implemented.
