# Changelog

## 0.6.0
- Added one-click Windows offline launcher.
- Added START_HERE guide and no-install opening instructions.
- Clarified optional Node.js backend and bridge launchers.
- Preserved all cumulative features and write locks through Wave 5.


## 0.5.0
- Added cumulative Wave 5 bridge foundation.
- Added local-agent health endpoint with hard write lock.
- Added bridge UI, demo, preflight checklist, logs, and report export.
- Added one-file offline launcher.

# Changelog

## v0.4.0 — Wave 4 cumulative master

Contains all implemented functionality from Waves 1–4 in one project.

### Wave 4 additions
- Scanner workspace with simulated live data
- CSV replay and recording export
- DTC workspace and local explanations
- Experimental read-only ELM327 Web Serial path
- Session logging and scanner safety boundaries

### Included from Wave 3
- Multiple vehicle profiles and active-build memory
- Persistent AI conversations and answer modes
- Build planner, compatibility review, task and cost tracking
- Searchable knowledge base and data backup/restore

### Included from Wave 2
- Guided onboarding and vehicle profile editor
- CSV datalog analysis and sample log
- Optional secure Node.js AI backend
- Readiness and safety checks

### Included from Wave 1
- Dashboard and responsive navigation
- Garage, AI, Tune Studio, and Settings foundations
- TunIQ visual identity and GitHub-ready structure

### Locked for safety
- PCM Hammer control
- BIN reading or writing
- Calibration editing and checksums
- Code clearing and controller flashing
- Automatic tuning
