import fs from 'node:fs';
const mustExist=['OPEN_TUNIQ_WINDOWS.bat','START_HERE.txt','TunIQ_Open_Me.html','VERSION.json','docs/WAVE6_SCOPE.md'];
for(const file of mustExist){if(!fs.existsSync(file))throw new Error(`Missing ${file}`)}
const bat=fs.readFileSync('OPEN_TUNIQ_WINDOWS.bat','utf8');
if(!bat.includes('TunIQ_Open_Me.html'))throw new Error('Launcher does not open standalone app');
if(/node|npm/i.test(bat))throw new Error('Normal launcher must not require Node.js');
const v=JSON.parse(fs.readFileSync('VERSION.json','utf8'));
if(v.version!=='0.6.0'||v.wave!==6||!v.hardwareWritesLocked)throw new Error('Version or safety lock mismatch');
console.log('Wave 6 easy-launch audit passed');
