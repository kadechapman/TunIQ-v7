const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const SENSOR_PROFILES = {
  baseline: { name: 'Full Baseline', description: 'General drivability, temperatures, voltage, load, and fuel trims.', sensors: ['rpm','speed','ect','iat','tps','map','maf','stft1','ltft1','spark','voltage','load'] },
  fuelTrims: { name: 'Fuel Trim Review', description: 'Idle and cruise correction patterns before MAF or VE changes.', sensors: ['rpm','speed','ect','tps','map','maf','stft1','ltft1','voltage','load'] },
  camIdle: { name: 'Cam Idle Diagnosis', description: 'Idle stability, airflow/load, trims, spark, and temperature.', sensors: ['rpm','speed','ect','tps','map','maf','stft1','ltft1','spark','voltage','load'] },
  mafVe: { name: 'MAF / VE Review', description: 'Airflow and fuel correction across RPM and load.', sensors: ['rpm','speed','ect','iat','tps','map','maf','stft1','ltft1','spark','load'] },
  power: { name: 'Power & Knock Review', description: 'High-load data foundation. Wideband AFR and enhanced knock PIDs are required for final decisions.', sensors: ['rpm','speed','ect','iat','tps','map','maf','spark','voltage','load'] },
  transmission: { name: 'Transmission Driveability', description: 'Standard OBD data plus future enhanced transmission PIDs.', sensors: ['rpm','speed','ect','tps','map','spark','voltage','load'] }
};

function cleanText(value, max = 200) { return String(value ?? '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max); }
function safeFileName(value) { return cleanText(value, 100).replace(/[<>:"/\\|?*]+/g, '-').replace(/\s+/g, '-').replace(/^-+|-+$/g, '') || 'Live-Log'; }
function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function writeJson(file, value) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function csvValue(value) { const text = value == null ? '' : String(value); return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text; }
function mean(values) { const valid = values.filter(Number.isFinite); return valid.length ? valid.reduce((a,b)=>a+b,0) / valid.length : null; }
function stddev(values) { const valid = values.filter(Number.isFinite); if (valid.length < 2) return 0; const avg = mean(valid); return Math.sqrt(valid.reduce((sum,v)=>sum + Math.pow(v-avg,2),0) / valid.length); }
function round(value, digits = 2) { return Number.isFinite(value) ? Number(value.toFixed(digits)) : null; }

function parseVoltage(raw) {
  const match = String(raw || '').match(/(-?\d+(?:\.\d+)?)\s*V/i);
  return match ? Number(match[1]) : null;
}
function normalizeAdapterText(raw) {
  return String(raw || '').replace(/[>\r\n]+/g, ' ').replace(/\s+/g, ' ').replace(/^(ATI|AT@1|STDI)\s*/i, '').trim();
}
function extractPidBytes(raw, pid) {
  const target = String(pid).toUpperCase();
  const text = String(raw || '').toUpperCase().replace(/SEARCHING\.\.\./g, ' ');
  const pairs = text.match(/[0-9A-F]{2}/g) || [];
  for (let index = 0; index < pairs.length - 2; index += 1) {
    if (pairs[index] === '41' && pairs[index + 1] === target) return pairs.slice(index + 2).map(v => parseInt(v, 16));
  }
  return [];
}
function parseVin(raw) {
  const lines = String(raw || '').toUpperCase().split(/\r?\n/);
  const bytes = [];
  for (const line of lines) {
    const pairs = line.match(/[0-9A-F]{2}/g) || [];
    const start = pairs.findIndex((value, index) => value === '49' && pairs[index + 1] === '02');
    if (start >= 0) {
      const payload = pairs.slice(start + 3);
      for (const pair of payload) {
        const code = parseInt(pair, 16);
        if (code >= 32 && code <= 126) bytes.push(code);
      }
    }
  }
  const vin = Buffer.from(bytes).toString('ascii').replace(/[^A-HJ-NPR-Z0-9]/g, '');
  return vin.length >= 11 ? vin.slice(0, 17) : '';
}
function parsePidSample(responses = {}) {
  const get = command => extractPidBytes(responses[command], command.slice(2));
  const rpmBytes = get('010C');
  const speedBytes = get('010D');
  const ectBytes = get('0105');
  const iatBytes = get('010F');
  const tpsBytes = get('0111');
  const mapBytes = get('010B');
  const mafBytes = get('0110');
  const stftBytes = get('0106');
  const ltftBytes = get('0107');
  const sparkBytes = get('010E');
  const loadBytes = get('0104');
  const fuelBytes = get('0123');
  return {
    timestamp: new Date().toISOString(),
    rpm: rpmBytes.length >= 2 ? round(((rpmBytes[0] * 256) + rpmBytes[1]) / 4, 0) : null,
    speed: speedBytes.length ? round(speedBytes[0] * 0.621371, 1) : null,
    ect: ectBytes.length ? round((ectBytes[0] - 40) * 9 / 5 + 32, 1) : null,
    iat: iatBytes.length ? round((iatBytes[0] - 40) * 9 / 5 + 32, 1) : null,
    tps: tpsBytes.length ? round(tpsBytes[0] * 100 / 255, 1) : null,
    map: mapBytes.length ? mapBytes[0] : null,
    maf: mafBytes.length >= 2 ? round(((mafBytes[0] * 256) + mafBytes[1]) / 100, 2) : null,
    stft1: stftBytes.length ? round((stftBytes[0] - 128) * 100 / 128, 2) : null,
    ltft1: ltftBytes.length ? round((ltftBytes[0] - 128) * 100 / 128, 2) : null,
    spark: sparkBytes.length ? round(sparkBytes[0] / 2 - 64, 1) : null,
    load: loadBytes.length ? round(loadBytes[0] * 100 / 255, 1) : null,
    fuelPressure: fuelBytes.length >= 2 ? round(((fuelBytes[0] * 256) + fuelBytes[1]) * 10 / 6.89476, 1) : null,
    voltage: parseVoltage(responses.ATRV),
    protocol: normalizeAdapterText(responses.ATDP),
    knockRetard: null,
    source: 'vehicle'
  };
}

function parseCsvLine(line) {
  const values = [];
  let current = '';
  let quoted = false;
  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (char === '"') {
      if (quoted && line[i + 1] === '"') { current += '"'; i += 1; }
      else quoted = !quoted;
    } else if (char === ',' && !quoted) { values.push(current); current = ''; }
    else current += char;
  }
  values.push(current);
  return values;
}

class ObdManager {
  constructor(options) {
    this.dataRoot = options.dataRoot;
    this.getActiveProject = options.getActiveProject;
    this.appendActivity = options.appendActivity || (() => {});
    this.logStartup = options.logStartup || (() => {});
    this.bridgeScript = path.join(__dirname, 'obd-bridge.ps1');
    this.connection = null;
    this.logger = null;
    this.demoTick = 0;
  }

  devicesRoot() { return ensureDir(path.join(this.dataRoot(), 'Devices')); }
  configFile() { return path.join(this.devicesRoot(), 'adapter.json'); }
  getConfig() { return readJson(this.configFile(), { port: '', baud: 0, adapter: '', autoConnect: true }); }
  saveConfig(config) { const value = { ...this.getConfig(), ...config, updatedAt: new Date().toISOString() }; writeJson(this.configFile(), value); return value; }
  getStatus() {
    return {
      connected: Boolean(this.connection),
      connection: this.connection ? { ...this.connection } : null,
      preferred: this.getConfig(),
      logging: this.logger ? { ...this.logger, stream: undefined } : null,
      profiles: SENSOR_PROFILES
    };
  }

  runBridge(action, { port = '', baud = 0, timeout = 12000 } = {}) {
    if (process.platform !== 'win32') return Promise.reject(new Error('Physical serial adapters are available on the Windows build. Use the virtual adapter to test this development build.'));
    return new Promise((resolve, reject) => {
      const args = ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', this.bridgeScript, '-Action', action, '-PortName', String(port), '-Baud', String(baud || 0)];
      const child = spawn('powershell.exe', args, { windowsHide: true });
      let stdout = '';
      let stderr = '';
      const timer = setTimeout(() => {
        try { child.kill(); } catch {}
        reject(new Error(`The ${action.toLowerCase()} request timed out. Close other scanner apps and try again.`));
      }, timeout);
      child.stdout.on('data', chunk => { stdout += chunk.toString(); });
      child.stderr.on('data', chunk => { stderr += chunk.toString(); });
      child.on('error', error => { clearTimeout(timer); reject(error); });
      child.on('close', () => {
        clearTimeout(timer);
        const lines = stdout.trim().split(/\r?\n/).filter(Boolean);
        let result = null;
        for (let i = lines.length - 1; i >= 0; i -= 1) {
          try { result = JSON.parse(lines[i]); break; } catch {}
        }
        if (!result) return reject(new Error(stderr.trim() || `No response from the Windows serial bridge during ${action}.`));
        if (!result.success) {
          const message = cleanText(result.error || stderr || 'Adapter request failed.', 1000);
          const friendly = /access.*denied|unauthorized|in use|cannot open/i.test(message)
            ? 'The COM port is already in use or Windows denied access. Close OBDLink, OBDwiz, FORScan, PCM Hammer, and other scanner software, then reconnect.'
            : message;
          return reject(new Error(friendly));
        }
        resolve(result);
      });
    });
  }

  async listDevices() {
    let physical = [];
    if (process.platform === 'win32') {
      try {
        const result = await this.runBridge('List', { timeout: 9000 });
        physical = Array.isArray(result.devices) ? result.devices : result.devices ? [result.devices] : [];
      } catch (error) {
        this.logStartup('device-scan-warning', error.message);
      }
    }
    const normalized = physical.map(item => {
      const name = cleanText(item.name || `Serial Port (${item.port})`, 180);
      const search = `${name} ${item.manufacturer || ''} ${item.deviceId || ''}`.toLowerCase();
      return {
        id: item.port,
        port: item.port,
        name,
        manufacturer: cleanText(item.manufacturer, 100),
        hardwareId: cleanText(item.deviceId, 240),
        status: cleanText(item.status || 'Unknown', 40),
        transport: /bluetooth|bthenum|standard serial over bluetooth|spp/.test(search) ? 'Bluetooth Serial' : 'USB / Serial',
        recognized: /obdlink|scantool|elm327|stn11|stn21|obdx|j2534/.test(search),
        recommended: /obdlink|stn11|stn21/.test(search)
      };
    });
    normalized.sort((a,b) => Number(b.recommended) - Number(a.recommended) || a.port.localeCompare(b.port, undefined, { numeric: true }));
    normalized.push({ id: 'virtual-demo', port: 'virtual-demo', name: 'TunIQ Virtual OBD-II Adapter', manufacturer: 'TunIQ', hardwareId: 'VIRTUAL', status: 'Ready', transport: 'Simulation', recognized: true, recommended: false, demo: true });
    return normalized;
  }

  async connect(payload = {}) {
    const port = cleanText(payload.port || this.getConfig().port, 30);
    if (!port) throw new Error('Select a Bluetooth or USB serial port first. Pair the OBDLink MX+ in Windows Bluetooth settings before scanning.');
    if (port === 'virtual-demo') {
      this.connection = {
        port,
        baud: 0,
        adapter: 'TunIQ Virtual OBD-II Adapter',
        description: 'Safe simulated data source',
        firmware: '1.5 dev simulator',
        protocol: 'ISO 15765-4 CAN (11-bit / 500 kbaud)',
        voltage: 13.9,
        vin: '1TUNIQ15DEV000001',
        transport: 'Simulation',
        capabilities: ['Diagnostics', 'Live logging', 'AI log review', 'Project log storage'],
        connectedAt: new Date().toISOString(),
        demo: true
      };
      this.saveConfig({ port, baud: 0, adapter: this.connection.adapter, transport: 'Simulation' });
      this.appendActivity('device-connected', { port, adapter: this.connection.adapter, demo: true });
      return this.getStatus();
    }
    const requestedBaud = Number(payload.baud || this.getConfig().baud || 0);
    const result = await this.runBridge('Probe', { port, baud: requestedBaud, timeout: 17000 });
    const adapter = normalizeAdapterText(result.adapter) || 'ELM/STN-compatible adapter';
    const description = normalizeAdapterText(result.description);
    const deviceId = normalizeAdapterText(result.deviceId);
    const protocol = normalizeAdapterText(result.protocol) || 'Automatic protocol detection';
    const voltage = parseVoltage(result.voltageRaw);
    const vin = parseVin(result.vinRaw);
    const isObdLink = /obdlink|stn/i.test(`${adapter} ${description} ${deviceId}`);
    this.connection = {
      port,
      baud: Number(result.baud || requestedBaud || 115200),
      adapter,
      description,
      firmware: deviceId,
      protocol,
      voltage,
      vin,
      transport: 'Bluetooth / Serial',
      capabilities: ['Diagnostics', 'Live logging', 'AI log review', 'Project log storage', ...(isObdLink ? ['OBDLink/STN command set detected'] : [])],
      connectedAt: new Date().toISOString(),
      demo: false
    };
    this.saveConfig({ port, baud: this.connection.baud, adapter, description, firmware: deviceId, protocol, vin, transport: this.connection.transport });
    this.appendActivity('device-connected', { port, baud: this.connection.baud, adapter, protocol, vin: vin || null });
    return this.getStatus();
  }

  async disconnect() {
    const previous = this.connection;
    this.connection = null;
    if (this.logger) await this.stopLog('Adapter disconnected');
    if (previous) this.appendActivity('device-disconnected', { port: previous.port, adapter: previous.adapter });
    return this.getStatus();
  }

  virtualSample() {
    this.demoTick += 0.17;
    const t = this.demoTick;
    const throttleWave = Math.max(0, Math.sin(t * 0.55));
    const rpm = 760 + throttleWave * 3000 + Math.sin(t * 2.1) * 35;
    const speed = throttleWave > 0.18 ? throttleWave * 67 : 0;
    const leanWindow = Math.sin(t * 0.34) > 0.72;
    return {
      timestamp: new Date().toISOString(),
      rpm: round(rpm, 0),
      speed: round(speed, 1),
      ect: round(Math.min(203, 72 + t * 2.4), 1),
      iat: round(82 + Math.sin(t / 3) * 8, 1),
      tps: round(throttleWave * 78, 1),
      map: round(35 + throttleWave * 62, 1),
      maf: round(5.1 + throttleWave * 118, 2),
      stft1: round((leanWindow ? 8.5 : 0.8) + Math.sin(t * 1.5) * 2.6, 2),
      ltft1: round(leanWindow ? 5.8 : 2.1, 2),
      spark: round(18 + (1 - throttleWave) * 14 + Math.sin(t) * 2, 1),
      load: round(18 + throttleWave * 76, 1),
      fuelPressure: null,
      voltage: round(13.8 + Math.sin(t / 2) * 0.18, 2),
      protocol: this.connection?.protocol || 'SIMULATED CAN',
      knockRetard: Math.random() > 0.97 ? round(Math.random() * 2.4, 1) : 0,
      source: 'virtual'
    };
  }

  async sample() {
    if (!this.connection) throw new Error('Connect a vehicle interface in Device Manager first.');
    let sample;
    if (this.connection.demo) sample = this.virtualSample();
    else {
      const result = await this.runBridge('Sample', { port: this.connection.port, baud: this.connection.baud, timeout: 20000 });
      sample = parsePidSample(result.responses || {});
      if (sample.protocol) this.connection.protocol = sample.protocol;
      if (Number.isFinite(sample.voltage)) this.connection.voltage = sample.voltage;
    }
    if (this.logger) this.appendSample(sample);
    return { sample, status: this.getStatus() };
  }

  startLog(payload = {}) {
    if (!this.connection) throw new Error('Connect a vehicle interface before recording a log.');
    if (this.logger) throw new Error('A log is already recording. Stop it before starting another.');
    const active = this.getActiveProject();
    if (!active) throw new Error('Create or activate a project before recording. Logs must stay associated with a vehicle and calibration revision.');
    const profileKey = SENSOR_PROFILES[payload.profile] ? payload.profile : 'baseline';
    const profile = SENSOR_PROFILES[profileKey];
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const baseName = safeFileName(payload.name || `${profile.name}-${active.name}`);
    const logsFolder = ensureDir(path.join(active.folder, 'Logs'));
    const csvPath = path.join(logsFolder, `${baseName}-${stamp}.csv`);
    const metaPath = csvPath.replace(/\.csv$/i, '.meta.json');
    const columns = ['timestamp','rpm','speed','ect','iat','tps','map','maf','stft1','ltft1','spark','voltage','load','fuelPressure','knockRetard','marker'];
    fs.writeFileSync(csvPath, `${columns.join(',')}\n`, 'utf8');
    this.logger = {
      id: `${Date.now()}-log`,
      projectId: active.id,
      projectName: active.name,
      vehicle: active.vehicle || '',
      controller: active.controller || '',
      os: active.os || '',
      bin: active.binInfo?.name || '',
      profileKey,
      profileName: profile.name,
      sensors: profile.sensors,
      csvPath,
      metaPath,
      startedAt: new Date().toISOString(),
      samples: 0,
      pendingMarker: '',
      adapter: this.connection.adapter,
      port: this.connection.port,
      protocol: this.connection.protocol
    };
    writeJson(metaPath, { ...this.logger, status: 'recording' });
    this.appendActivity('live-log-started', { projectId: active.id, projectName: active.name, profile: profile.name, name: path.basename(csvPath), adapter: this.connection.adapter });
    return { ...this.logger };
  }

  appendSample(sample) {
    if (!this.logger) return;
    const columns = ['timestamp','rpm','speed','ect','iat','tps','map','maf','stft1','ltft1','spark','voltage','load','fuelPressure','knockRetard'];
    const marker = this.logger.pendingMarker || '';
    this.logger.pendingMarker = '';
    const values = columns.map(key => csvValue(sample[key]));
    values.push(csvValue(marker));
    fs.appendFileSync(this.logger.csvPath, `${values.join(',')}\n`, 'utf8');
    this.logger.samples += 1;
    this.logger.lastSampleAt = sample.timestamp;
    if (this.logger.samples % 10 === 0) writeJson(this.logger.metaPath, { ...this.logger, status: 'recording' });
  }

  markLog(label) {
    if (!this.logger) throw new Error('Start recording before adding an event marker.');
    this.logger.pendingMarker = cleanText(label || 'Driver marker', 160);
    return { marker: this.logger.pendingMarker, at: new Date().toISOString() };
  }

  async stopLog(reason = 'User stopped recording') {
    if (!this.logger) return null;
    const session = this.logger;
    this.logger = null;
    const stoppedAt = new Date().toISOString();
    const metadata = { ...session, status: 'complete', stoppedAt, stopReason: reason, durationSeconds: Math.max(0, (Date.parse(stoppedAt) - Date.parse(session.startedAt)) / 1000) };
    writeJson(session.metaPath, metadata);
    const analysis = this.analyzeCsv(session.csvPath, metadata);
    const analysisPath = session.csvPath.replace(/\.csv$/i, '.analysis.json');
    writeJson(analysisPath, analysis);
    this.appendActivity('live-log-stopped', { projectId: session.projectId, projectName: session.projectName, name: path.basename(session.csvPath), samples: session.samples, durationSeconds: metadata.durationSeconds, findings: analysis.findings.length });
    return { ...metadata, analysis, analysisPath };
  }

  listLogs() {
    const active = this.getActiveProject();
    if (!active) return [];
    const folder = path.join(active.folder, 'Logs');
    if (!fs.existsSync(folder)) return [];
    const entries = fs.readdirSync(folder, { withFileTypes: true })
      .filter(entry => entry.isFile() && entry.name.endsWith('.meta.json'))
      .map(entry => {
        const metaPath = path.join(folder, entry.name);
        const metadata = readJson(metaPath, {});
        const csvPath = metadata.csvPath || metaPath.replace(/\.meta\.json$/i, '.csv');
        const analysisPath = csvPath.replace(/\.csv$/i, '.analysis.json');
        return {
          ...metadata,
          metaPath,
          csvPath,
          name: path.basename(csvPath),
          exists: fs.existsSync(csvPath),
          analysis: readJson(analysisPath, null)
        };
      })
      .sort((a,b) => String(b.startedAt || '').localeCompare(String(a.startedAt || '')));
    return entries.slice(0, 100);
  }

  analyzeLog(csvPath) {
    const active = this.getActiveProject();
    if (!active) throw new Error('Select the project that owns this log first.');
    const resolved = path.resolve(csvPath || '');
    const logsRoot = path.resolve(path.join(active.folder, 'Logs'));
    if (!resolved.startsWith(logsRoot + path.sep) || !fs.existsSync(resolved)) throw new Error('The requested log is not inside the active project Logs folder.');
    const meta = readJson(resolved.replace(/\.csv$/i, '.meta.json'), {});
    const analysis = this.analyzeCsv(resolved, meta);
    writeJson(resolved.replace(/\.csv$/i, '.analysis.json'), analysis);
    return analysis;
  }

  analyzeCsv(csvPath, metadata = {}) {
    const text = fs.readFileSync(csvPath, 'utf8');
    const lines = text.split(/\r?\n/).filter(Boolean);
    if (lines.length < 2) return { generatedAt: new Date().toISOString(), log: path.basename(csvPath), sampleCount: 0, confidence: 'insufficient', findings: [{ severity: 'info', title: 'Not enough data', detail: 'Record at least 20–30 seconds in the problem area before asking the AI to recommend changes.', action: 'Repeat the log with the engine fully warmed and mark the exact event.' }] };
    const headers = parseCsvLine(lines[0]);
    const rows = lines.slice(1).map(line => {
      const values = parseCsvLine(line); const row = {};
      headers.forEach((header,index) => { const raw = values[index] ?? ''; row[header] = header === 'timestamp' || header === 'marker' ? raw : (raw === '' ? null : Number(raw)); });
      return row;
    });
    const findings = [];
    const trims = rows.map(row => Number.isFinite(row.stft1) && Number.isFinite(row.ltft1) ? row.stft1 + row.ltft1 : null).filter(Number.isFinite);
    const trimAvg = mean(trims);
    if (Number.isFinite(trimAvg) && trimAvg > 8) findings.push({ severity: trimAvg > 14 ? 'high' : 'warning', title: 'Repeatable positive fuel correction', detail: `Average combined Bank 1 correction was +${round(trimAvg,1)}%. The PCM is adding fuel in the logged areas.`, action: 'Check vacuum and exhaust leaks, fuel pressure, injector data, and MAF contamination before changing airflow tables. Then isolate the RPM/load region where the correction repeats.' });
    else if (Number.isFinite(trimAvg) && trimAvg < -8) findings.push({ severity: trimAvg < -14 ? 'high' : 'warning', title: 'Repeatable negative fuel correction', detail: `Average combined Bank 1 correction was ${round(trimAvg,1)}%. The PCM is removing fuel in the logged areas.`, action: 'Verify injector characterization, fuel pressure, purge flow, and MAF scaling before reducing VE or MAF values.' });
    else if (Number.isFinite(trimAvg)) findings.push({ severity: 'ok', title: 'Fuel correction is near target', detail: `Average combined Bank 1 correction was ${round(trimAvg,1)}%.`, action: 'Review separate idle, cruise, and acceleration segments before deciding that no changes are needed.' });

    const runningVoltage = rows.filter(row => Number(row.rpm) > 450).map(row => row.voltage).filter(Number.isFinite);
    const voltageAvg = mean(runningVoltage); const voltageMin = runningVoltage.length ? Math.min(...runningVoltage) : null;
    if (Number.isFinite(voltageAvg) && (voltageAvg < 13 || voltageMin < 12.4)) findings.push({ severity: 'high', title: 'Charging voltage needs attention', detail: `Running voltage averaged ${round(voltageAvg,2)} V and reached ${round(voltageMin,2)} V.`, action: 'Repair charging or connection issues before flashing or trusting sensor behavior.' });

    const ect = rows.map(row => row.ect).filter(Number.isFinite); const ectMax = ect.length ? Math.max(...ect) : null;
    if (Number.isFinite(ectMax) && ectMax > 230) findings.push({ severity: 'high', title: 'High coolant temperature recorded', detail: `Coolant temperature reached ${round(ectMax,1)} °F.`, action: 'Verify coolant level, fan operation, thermostat, airflow, and sensor accuracy before adding timing or leaning the calibration.' });

    const idleRows = rows.filter(row => Number(row.rpm) > 450 && Number(row.speed || 0) <= 1 && Number(row.tps || 0) <= 3);
    const idleDeviation = stddev(idleRows.map(row => row.rpm).filter(Number.isFinite));
    if (idleRows.length >= 10 && idleDeviation > 110) findings.push({ severity: 'warning', title: 'Idle speed is unstable', detail: `Idle RPM standard deviation was ${round(idleDeviation,0)} RPM across ${idleRows.length} samples.`, action: 'Check for mechanical problems first, then review desired idle, base running airflow, startup airflow, and idle spark together.' });

    const highThrottle = rows.filter(row => Number(row.tps) >= 70).length;
    if (highThrottle > 0) findings.push({ severity: 'info', title: 'High-load section detected', detail: `${highThrottle} high-throttle samples were recorded. Standard OBD data does not include a trustworthy wideband AFR or controller-specific knock channel by default.`, action: 'Do not make final power-enrichment or spark changes until a wideband and enhanced controller PIDs are logged.' });

    const markers = rows.filter(row => row.marker).map(row => ({ at: row.timestamp, label: row.marker }));
    if (!findings.length) findings.push({ severity: 'info', title: 'No strong repeatable fault found', detail: 'The available standard PIDs did not show a clear calibration pattern.', action: 'Record a longer log in the exact problem area and add an event marker when it happens.' });
    return {
      generatedAt: new Date().toISOString(),
      log: path.basename(csvPath),
      projectId: metadata.projectId || null,
      profile: metadata.profileName || '',
      sampleCount: rows.length,
      durationSeconds: metadata.durationSeconds || null,
      confidence: rows.length >= 120 ? 'good' : rows.length >= 30 ? 'limited' : 'insufficient',
      summary: { averageCombinedTrim: round(trimAvg,2), averageRunningVoltage: round(voltageAvg,2), minimumRunningVoltage: round(voltageMin,2), maxCoolantF: round(ectMax,1), idleRpmDeviation: round(idleDeviation,1), highThrottleSamples: highThrottle, markers },
      findings
    };
  }
}

module.exports = { ObdManager, SENSOR_PROFILES, parsePidSample, parseVin };
