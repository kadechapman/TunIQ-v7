# TunIQ v1.5.0-dev.1

Built directly on `v1.4.0-dev.1`. Existing profiles, Garage vehicles, projects, BINs, XDFs, revisions, Full AI plans, saved tunes, community drafts, tool paths, and settings remain in `%APPDATA%\TunIQ`.

## First TunIQ 1.5 milestone

### Bluetooth / serial Device Manager

- Added a dedicated Vehicle Interface page.
- Searches Windows COM devices created by paired Bluetooth adapters and USB serial adapters.
- Recognizes likely OBDLink, STN, ELM327, OBDX, and other serial interfaces from Windows device information.
- Includes a safe virtual OBD-II adapter for interface and logging tests without a vehicle.
- Tests common adapter baud rates: 115200, 38400, and 9600.
- Queries adapter identity, description, STN device information when supported, battery voltage, active OBD protocol, and VIN when standard Mode 09 is available.
- Remembers the preferred port and confirmed baud rate in `%APPDATA%\TunIQ\Devices\adapter.json`.
- Explains exclusive-port failures when OBDLink, OBDwiz, FORScan, PCM Hammer, or another application already owns the COM port.
- Labels the connection as diagnostics/logging capable. Flashing remains enabled only for separately verified adapter/controller combinations.

The OBDLink MX+ must be paired in Windows Bluetooth settings before TunIQ can see its Bluetooth serial COM port.

### Native Live Log workspace

- Replaced the old simulated Scanner page with a real Live Log workspace.
- Added Full Baseline, Fuel Trim Review, Cam Idle Diagnosis, MAF/VE Review, Power & Knock Review, and Transmission Driveability profiles.
- Polls standard OBD-II PIDs for RPM, vehicle speed, coolant temperature, intake-air temperature, throttle position, MAP, MAF, Bank 1 short/long fuel trims, spark advance, calculated load, system voltage, and supported fuel-pressure data.
- Displays live gauges, a scrolling trend chart, and the current sensor frame.
- Adds a simplified Drive Mode that hides calibration, flashing, community, and other distracting pages.
- Adds driver event markers so the exact stumble, shift, knock event, or stall can be found later.
- Saves CSV logs, metadata, and AI analysis files inside the active project's `Logs` folder.
- Associates each log with project, vehicle, controller, OS, BIN, adapter, protocol, profile, and timestamp.

Standard OBD-II does not provide every enhanced GM parameter. Knock retard, individual misfire counters, commanded gear, converter slip, wideband AFR, and controller-specific transmission data require enhanced PID definitions in later 1.5 builds.

### AI log-review foundation

- Automatically reviews a completed log.
- Looks for repeatable positive or negative fuel correction.
- Checks running voltage and minimum charging voltage.
- Flags excessive coolant temperature.
- Measures idle RPM instability during low-speed, closed-throttle samples.
- Identifies high-throttle sections and warns when wideband/enhanced knock data is missing.
- Saves findings with severity, evidence, and the recommended next diagnostic step.
- Adds the latest log and analysis to AI Coach project context.
- Adds adapter connection and baseline logging to the Guided Tune Path.
- Marks the Full AI baseline-diagnostics step complete when a project log exists.

The AI review proposes what to inspect next. It does not automatically alter calibration bytes or flash a controller in this build.

## Testing order

1. Extract into a new folder.
2. Run `INSTALL_AND_RUN_WINDOWS.bat`.
3. Pair the OBDLink MX+ in Windows Bluetooth settings.
4. Close other OBD applications.
5. Open **Device Manager** in TunIQ.
6. Press **Scan Bluetooth / USB**.
7. Select the Bluetooth COM port and press **Connect & Identify**.
8. Open **Live Log**, choose a profile, and record a short warm-idle test first.
9. Add an event marker while reproducing a symptom.
10. Stop the log and review the AI findings.

Use the **Virtual Adapter** first when testing the UI without the vehicle connected.

## Safety status

- Original BINs remain protected.
- Live logging never writes to the PCM.
- No calibration editing controls are shown in Drive Mode.
- Standard PID data is treated as diagnostic evidence, not enough by itself for final WOT fueling or spark changes.
- Controller writes remain locked and require explicit confirmation in future builds.
