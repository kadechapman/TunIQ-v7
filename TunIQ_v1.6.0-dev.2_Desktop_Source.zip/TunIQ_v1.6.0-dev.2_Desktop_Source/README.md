# TunIQ v1.6.0-dev.2

TunIQ is a development-stage Windows desktop tuning workspace built directly on `v1.5.0-dev.2`. Existing profiles, Garage vehicles, projects, protected originals, XDFs, revisions, logs, AI plans, tune packages, community drafts, and tool paths remain in `%APPDATA%\TunIQ`.

## What this build adds

### Managed PCM Hammer CLI workspace

The native Flash Center can now manage an installed PCM Hammer command-line executable without opening its normal desktop window.

- Probes CLI help and discovers available Identify, Read, Test Write, Calibration Write, Full Write, and Recovery commands.
- Includes editable advanced command templates when automatic command discovery does not match the installed CLI version.
- Identifies controller family, VIN, hardware ID, and operating system from CLI output when reported.
- Reads the PCM into the active project's protected `Originals` folder.
- Streams command output, progress, current phase, and reported voltage into TunIQ.
- Records persistent flash-session logs and history in `%APPDATA%\TunIQ\Logs\Flash`.
- Imports a successful read into the active project automatically.
- Requires an exact project revision, exact SHA-256 validation report, protected original, matching file size, selected interface, checksum approval, voltage/bench-power confirmation, browser confirmation, and typed authorization before writes.
- Uses different typed confirmations for calibration and full/recovery writes.
- Refuses to terminate PCM Hammer during erase, write, or verification.
- Blocks closing TunIQ while a managed write or recovery operation is active.
- Marks a successful CLI exit as **unverified** unless an explicit verification-pass message is detected.

Direct operations are available only when the installed PCM Hammer CLI advertises them or the user supplies a correct command template. TunIQ does not invent unsupported controller operations.

### Checksum, segment, and patched-BIN validation

- Calculates SHA-256 fingerprints and 64 KB segment maps.
- Compares every changed byte and groups changes into address ranges.
- Rejects size/layout mismatches before write authorization.
- Reads and verifies explicit supported checksum definitions from an XDF.
- Corrects supported explicit checksum fields into a **new revision**.
- Parses Universal Patcher JSON, text, log, XML, and HTML-style reports.
- Accepts an external checksum pass only when the report is bound to the exact target BIN SHA-256.
- Treats unknown or unsupported checksum messages as unvalidated, not as a pass.
- Previews a patched BIN byte-for-byte before import.
- Imports a compatible patched BIN as a new revision without changing the protected original.
- Stores validation, patch-preview, controller-identity, and checksum reports inside the project.

Controller-specific algorithms that are neither represented by a supported XDF checksum definition nor verified by a matching Universal Patcher report remain blocked from writing.

### Enhanced XDF mapping

The XDF parser now supports a broader set of common definition features:

- 8-, 16-, and 32-bit signed/unsigned integers
- 32- and 64-bit floating-point values
- Little- and big-endian storage
- Bit masks and individual flags with unrelated bits preserved on write
- Safer arithmetic conversion equations and inverse solving
- Dynamic X/Y axes
- Row-major and column-major layouts
- Unusual row and column strides
- Category membership and a searchable category browser
- Axis-link metadata
- Enumeration labels
- Explicit checksum definitions
- BIN-boundary and active-OS validation

Unsupported definitions are skipped or marked read-only instead of being silently written. XDF dialects vary, so every new controller/XDF combination still requires a known-good round-trip test before vehicle use.

### Persistent enhanced logging

- Keeps a Windows serial COM connection open through a persistent session instead of reopening it for every sample.
- Supports standard OBD-II data and controller-scoped imported PID profiles.
- Adds log columns for commanded equivalence ratio, wideband AFR, misfires, MAF frequency, injector duty, desired idle, commanded/actual gear, input/output speed, transmission slip, shift time, TCC slip, and torque-management state when verified PID definitions provide them.
- Uses faster UI polling with the persistent session and falls back safely when persistent mode is unavailable.
- Saves CSV, metadata, event markers, and AI analysis in the active project.
- Flags fuel-trim patterns, voltage, coolant temperature, idle instability, knock, misfires, injector duty, AFR error, transmission slip, and TCC slip when the necessary channels are present.

TunIQ does not guess enhanced GM PID commands. Import only definitions verified for the exact controller and operating system.

### Approval-gated AI calibration execution

- Converts repeatable log regions into exact proposed XDF cells for supported MAF, VE, and idle-airflow mappings.
- Shows current value, proposed value, percentage change, evidence, sample count, confidence, and risk.
- Caps automatic airflow correction proposals and requires approval for every cell.
- Blocks application for low voltage, excessive coolant temperature, or high-load data without required fueling channels.
- Never automatically adds spark from a single log.
- Applies only selected proposals to the current matching workspace.
- Exports the approved changes as a new revision with checksum/compatibility validation.
- Records numbered AI calibration cycles so the user can log, review, revise, and repeat.
- Keeps exporting and flashing as separate confirmation-gated actions.

## Important safety boundary

This is an integration development build, not a universal production flashing guarantee.

- Begin with **Identify**, **Read**, and **Test Write** on a spare or bench PCM.
- Verify the installed PCM Hammer CLI's actual command syntax in the Advanced CLI section.
- Use stable power and a supported interface.
- Do not perform a first write on the only controller needed to drive the vehicle.
- Do not authorize a write when the checksum state is `not-defined`, `unknown`, `invalid`, or when the BIN layout differs from the protected original.
- OBDLink MX+ remains classified as diagnostics/logging unless the exact PCM Hammer/interface/controller combination is separately verified.
- Full AI never silently flashes a controller.

## Recommended test order

1. Extract this ZIP into a new folder.
2. Run `INSTALL_AND_RUN_WINDOWS.bat`.
3. Open the existing project and confirm its protected original and XDF.
4. Open **Calibration**, reload BIN + XDF, and verify several known values against TunerPro.
5. Export a harmless test revision and inspect it in **Patches & Checksums**.
6. Import the Universal Patcher report for that exact revision when required.
7. Pair/connect the diagnostic adapter and record a baseline log.
8. Generate an AI proposal, review every cell, and approve only changes you understand.
9. Configure and probe `PcmHammerCLI.exe`.
10. Bench-test Identify, Read, and Test Write before enabling a calibration write.

## Development tests

Run:

```bat
npm run check
npm test
```

The included integration tests cover enhanced XDF round trips, bit-mask preservation, floating-point values, checksum correction, Universal Patcher report gating, AI cell proposals, managed mock PCM operations, live-log recording, and renderer/IPC contracts.
