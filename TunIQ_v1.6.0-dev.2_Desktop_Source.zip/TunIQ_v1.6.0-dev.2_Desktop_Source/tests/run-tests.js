const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { parseXdf, hydrate, applyTable } = require('../src/xdf');
const checksum = require('../src/checksum');
const { generateProposal, applyApproved } = require('../src/ai-tune');
const { FlashManager } = require('../src/flash');
const { ObdManager } = require('../src/obd');

const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-tests-'));
const pass = name => console.log(`✓ ${name}`);
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitFor(predicate, timeout = 6000) { const start = Date.now(); while (Date.now() - start < timeout) { const value = predicate(); if (value) return value; await sleep(20); } throw new Error('Timed out waiting for asynchronous test condition.'); }

function testXdfAndChecksums() {
  const folder = path.join(tempRoot, 'xdf'); fs.mkdirSync(folder, { recursive: true });
  const binFile = path.join(folder, 'test.bin'); const xdfFile = path.join(folder, 'test.xdf');
  const bin = Buffer.alloc(512, 0);
  bin.writeUInt16LE(100, 0x10);
  bin.writeUInt8(0b10101100, 0x20);
  bin.writeFloatLE(1.5, 0x30);
  [10,20,30,40].forEach((value,index) => bin.writeUInt8(value, 0x40 + [0,2,4,6][index]));
  fs.writeFileSync(binFile, bin);
  fs.writeFileSync(xdfFile, `<?xml version="1.0"?>
<XDFHEADER><deftitle>Test OS 12212156</deftitle><baseoffset>0</baseoffset></XDFHEADER>
<CATEGORY index="1" name="Fuel"/>
<XDFCONSTANT uniqueid="scaled" title="Scaled Constant"><CATEGORYMEM index="1"/><EMBEDDEDDATA mmedaddress="0x10" mmedelementsizebits="16" lsbfirst="1"/><MATH equation="X*0.5" units="unit"/></XDFCONSTANT>
<XDFCONSTANT uniqueid="flag" title="Masked Flag"><EMBEDDEDDATA mmedaddress="0x20" mmedelementsizebits="8" bitmask="0x0C"/><MATH equation="X"/></XDFCONSTANT>
<XDFCONSTANT uniqueid="float" title="Float Constant"><EMBEDDEDDATA mmedaddress="0x30" mmedelementsizebits="32" float="1"/><MATH equation="X"/></XDFCONSTANT>
<XDFTABLE uniqueid="stride" title="Stride Table"><XDFAXIS id="x"><indexcount>2</indexcount><LABEL index="0" value="A"/><LABEL index="1" value="B"/></XDFAXIS><XDFAXIS id="y"><indexcount>2</indexcount><LABEL index="0" value="1000"/><LABEL index="1" value="2000"/></XDFAXIS><XDFAXIS id="z"><EMBEDDEDDATA mmedaddress="0x40" mmedelementsizebits="8" mmedrowcount="2" mmedcolcount="2" mmedmajorstridebits="32" mmedminorstridebits="16"/><MATH equation="X" units="%"/></XDFAXIS></XDFTABLE>
<XDFCHECKSUM id="sum" title="Sum 8" algorithm="sum8"><EMBEDDEDDATA mmedaddress="0xF0" mmedelementsizebits="8"/><RANGE start="0x00" end="0xF0"/></XDFCHECKSUM>`);
  const parsed = parseXdf(xdfFile);
  assert.equal(parsed.tables.length, 4);
  assert.equal(parsed.categories['1'], 'Fuel');
  assert.equal(parsed.checksums.length, 1);
  const byId = Object.fromEntries(parsed.tables.map(item => [item.id, item]));
  assert.equal(hydrate(byId.scaled, bin).values[0][0], 50);
  assert.equal(hydrate(byId.flag, bin).values[0][0], 3);
  assert(Math.abs(hydrate(byId.float, bin).values[0][0] - 1.5) < 1e-6);
  assert.deepEqual(hydrate(byId.stride, bin).values, [[10,20],[30,40]]);
  const edited = Buffer.from(bin);
  const flag = hydrate(byId.flag, edited); flag.values[0][0] = 1; applyTable(edited, flag, new Set(['0:0']));
  assert.equal(edited.readUInt8(0x20), 0b10100100, 'bit-mask write must preserve unrelated bits');
  const float = hydrate(byId.float, edited); float.values[0][0] = 2.25; applyTable(edited, float, new Set(['0:0']));
  assert(Math.abs(edited.readFloatLE(0x30) - 2.25) < 1e-6);
  const corrected = checksum.correctDefinitions(edited, parsed.checksums);
  assert.equal(checksum.verifyDefinitions(corrected.buffer, parsed.checksums)[0].valid, true);
  pass('enhanced XDF parse/hydrate/write and explicit checksum correction');
}

function testChecksumReportsAndDiff() {
  const folder = path.join(tempRoot, 'reports'); fs.mkdirSync(folder, { recursive: true });
  const good = path.join(folder, 'good.txt'), unknown = path.join(folder, 'unknown.txt');
  fs.writeFileSync(good, 'Checksum 1: valid\nSegment layout: passed\n');
  fs.writeFileSync(unknown, 'Checksum 1: unknown or unsupported\n');
  assert.equal(checksum.parseUniversalPatcherReport(good).valid, true);
  assert.equal(checksum.parseUniversalPatcherReport(unknown).valid, false);
  const a = Buffer.alloc(128, 0), b = Buffer.from(a); b[5] = 1; b[6] = 2; b[50] = 3;
  const diff = checksum.diffBuffers(a,b); assert.equal(diff.changedBytes,3); assert.equal(diff.ranges.length,2);
  pass('Universal Patcher report gating and byte-range comparison');
}

function writeAiCsv(file) {
  const headers=['timestamp','rpm','speed','ect','iat','tps','map','maf','stft1','ltft1','spark','voltage','load','fuelPressure','knockRetard','commandedEqRatio','widebandAfr','misfireTotal','mafFrequency','injectorDuty','desiredIdle','commandedGear','actualGear','inputShaftSpeed','outputShaftSpeed','transSlip','shiftTime','tccSlip','torqueManagement','marker'];
  const rows=[headers.join(',')];
  for(let i=0;i<90;i++) rows.push([new Date(Date.now()+i*100).toISOString(),1500,35,190,85,25,40,20,3.2,2.4,24,13.9,35,'',0,1,14.7,0,4000,28,750,3,3,1450,1200,20,'',10,0,''].join(','));
  fs.writeFileSync(file, rows.join('\n')+'\n');
}
function testAiExecution() {
  const csv=path.join(tempRoot,'ai.csv'); writeAiCsv(csv);
  const workspace={mode:'xdf',projectId:'p1',tables:{maf:{name:'MAF Calibration',description:'MAF frequency',rowHeaders:['Value'],colHeaders:['2000','4000','6000'],values:[[10,20,30]]},ve:{name:'Main VE',rowHeaders:['1000','1500'],colHeaders:['30','40'],values:[[60,65],[70,75]]},idle:{name:'Base Running Airflow',rowHeaders:['160','190','220'],colHeaders:['P/N'],values:[[4],[5],[6]]}},stock:null,modified:{}};
  workspace.stock=JSON.parse(JSON.stringify(workspace.tables));
  const proposal=generateProposal({csvPath:csv,workspace,activeProject:{id:'p1',name:'Test'},analysis:{findings:[]}});
  assert.equal(proposal.blocked,false); assert(proposal.proposals.length>=2,'expected MAF/VE proposals');
  const picked=proposal.proposals[0]; const applied=applyApproved(JSON.parse(JSON.stringify(workspace)),proposal,[picked.id]);
  assert.equal(applied.applied.length,1); assert.notEqual(applied.workspace.tables[picked.tableKey].values[picked.row][picked.col],picked.current);
  assert.equal(applied.workspace.modified[`${picked.tableKey}:${picked.row}:${picked.col}`],true);
  pass('AI log-to-exact-cell proposal and explicit approval execution');
}

async function testFlashManager() {
  const folder=path.join(tempRoot,'flash-project'); fs.mkdirSync(path.join(folder,'Originals'),{recursive:true}); fs.mkdirSync(path.join(folder,'Revisions'),{recursive:true});
  const original=path.join(folder,'Originals','stock.bin'), revision=path.join(folder,'Revisions','rev.bin'); fs.writeFileSync(original,Buffer.alloc(512,1)); fs.writeFileSync(revision,Buffer.alloc(512,2));
  const data=path.join(tempRoot,'flash-data'); const events=[]; let identity=null; let readInfo=null;
  const active={id:'pflash',name:'Bench PCM',folder,controller:'P01',bin:original};
  const manager=new FlashManager({dataRoot:()=>data,getActiveProject:()=>active,getToolPath:()=>'',getDeviceStatus:()=>({connection:{port:'MOCK',voltage:13.5}}),appendActivity:(type,payload)=>events.push({type,payload}),emit:()=>{},onIdentifyComplete:async value=>{identity=value},onReadComplete:async(file,info)=>{readInfo={file,info}}});
  const mock=path.join(__dirname,'mock-pcmhammer-cli.js');
  const probe=await manager.probe({executable:process.execPath,prefixArgs:[mock]});
  assert(probe.capabilities.identify&&probe.capabilities.read&&probe.capabilities.writeCalibration);
  manager.saveDevice('MOCK');
  manager.start('identify',{}); await waitFor(()=>!manager.session); assert.equal(identity.controller,'P01'); assert.equal(identity.os,'12212156');
  manager.start('read',{}); await waitFor(()=>!manager.session); assert(readInfo&&fs.existsSync(readInfo.file));
  manager.start('writeCalibration',{input:revision,confirmation:'WRITE Bench PCM',checksumApproved:true,voltage:13.5}); await waitFor(()=>!manager.session); const write=manager.history.find(item=>item.operation==='writeCalibration'); assert.equal(write.state,'complete'); assert.equal(write.verified,true);
  assert(events.some(item=>item.type==='flash-writeCalibration-complete'));
  pass('managed PCM Hammer CLI probe, identify, read, progress, verify, and write gating');
}

async function testVirtualLogger() {
  const data=path.join(tempRoot,'obd-data'), project=path.join(tempRoot,'obd-project'); fs.mkdirSync(project,{recursive:true});
  const active={id:'pobd',name:'Virtual Vehicle',folder:project,vehicle:'Test',controller:'P01',os:'12212156',binInfo:{name:'stock.bin'}};
  const manager=new ObdManager({dataRoot:()=>data,getActiveProject:()=>active,appendActivity:()=>{},logStartup:()=>{}});
  await manager.connect({port:'virtual-demo'}); assert(manager.getStatus().connected);
  const session=manager.startLog({profile:'baseline',name:'Integration'}); manager.markLog('start test');
  for(let i=0;i<70;i++) await manager.sample();
  const stopped=await manager.stopLog(); assert(stopped.samples===70); assert(fs.existsSync(session.csvPath)); assert(stopped.analysis.sampleCount===70); assert(fs.readFileSync(session.csvPath,'utf8').includes('commandedEqRatio'));
  await manager.disconnect();
  pass('persistent log schema, virtual enhanced PIDs, markers, CSV, and AI analysis');
}

function testStaticContracts() {
  const html=fs.readFileSync(path.join(__dirname,'../src/renderer/index.html'),'utf8'); const app=fs.readFileSync(path.join(__dirname,'../src/renderer/app.js'),'utf8'); const preload=fs.readFileSync(path.join(__dirname,'../src/preload.js'),'utf8'); const main=fs.readFileSync(path.join(__dirname,'../src/main.js'),'utf8');
  const ids=new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(match=>match[1]));
  const used=[...app.matchAll(/\$\('#([^']+)'\)/g)].map(match=>match[1]);
  const missing=[...new Set(used.filter(id=>!ids.has(id)))].filter(id=>!['editActiveProject','filesGoWorkflow','filesLoadLab','garageAdd'].includes(id));
  assert.deepEqual(missing,[],`missing DOM IDs: ${missing.join(', ')}`);
  for(const match of preload.matchAll(/ipcRenderer\.invoke\('([^']+)'/g)) assert(main.includes(`ipcMain.handle('${match[1]}'`),`missing IPC handler ${match[1]}`);
  pass('renderer DOM and preload/main IPC contracts');
}

(async()=>{
  try { testXdfAndChecksums(); testChecksumReportsAndDiff(); testAiExecution(); await testFlashManager(); await testVirtualLogger(); testStaticContracts(); console.log('\nAll TunIQ 1.6 integration tests passed.'); }
  finally { fs.rmSync(tempRoot,{recursive:true,force:true}); }
})().catch(error=>{console.error('\nTEST FAILURE\n',error.stack||error);process.exit(1)});
