import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');const js=fs.readFileSync('js/app.js','utf8');const agent=fs.readFileSync('bridge/agent.mjs','utf8');
for(const token of ['id="bridge"','bridgeCheck','runPreflight'])if(!html.includes(token))throw new Error('Missing '+token);
for(const token of ['writeLocked','/api/bridge/health'])if(!agent.includes(token))throw new Error('Missing agent token '+token);
if(!js.includes('Wave 5: local bridge foundation'))throw new Error('Missing Wave 5 JS');
console.log('Wave 5 audit passed');
