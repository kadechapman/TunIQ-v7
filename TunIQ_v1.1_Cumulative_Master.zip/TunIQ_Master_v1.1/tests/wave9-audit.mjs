import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8'),js=fs.readFileSync('js/app.js','utf8'),ps=fs.readFileSync('bridge/TunIQ-Bridge.ps1','utf8');
const checks=[['three tools',/PCM Hammer/.test(html)&&/TunerPro/.test(html)&&/Universal Patcher/.test(html)],['launch endpoint',/\/launch/.test(js)&&/api\/bridge\/launch/.test(ps)],['COM inventory',/Win32_SerialPort/.test(ps)],['write lock',/writeLocked=\$true/.test(ps)],['no flash endpoint',!/["']\/api\/bridge\/(flash|write|read)["']/.test(ps)]];
let failed=0;for(const [n,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${n}`);if(!ok)failed++}process.exitCode=failed?1:0;
