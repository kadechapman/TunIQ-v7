import fs from 'node:fs';
const index=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');
const app=fs.readFileSync(new URL('../js/app.js',import.meta.url),'utf8');
const standalone=fs.readFileSync(new URL('../TunIQ_Open_Me.html',import.meta.url),'utf8');
const checks={
  continueButton:index.includes('Continue to Dashboard'),
  diagnosticPanel:index.includes('startupDiagnostics'),
  watchdog:index.includes("window.addEventListener('load'"),
  isolatedBoot:app.includes('safeBootStep'),
  cloneFallback:app.includes('safeClone'),
  standaloneInline:standalone.includes('safeBootStep')&&!standalone.includes('src="js/app.js"')
};
for(const [name,ok] of Object.entries(checks)){if(!ok)throw new Error(`v0.9.1 audit failed: ${name}`)}
console.log('Wave 9.1 audit passed',checks);
