import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const js=fs.readFileSync('js/app.js','utf8');
const required=['TUNE FILE MANAGER','primaryTuneFile','compareTuneFile','fileRegister'];
for(const x of required) if(!html.includes(x)) throw new Error('Missing '+x);
for(const x of ['SHA-256','crypto.subtle.digest','compareTuneFiles','tuniq-v08-file-register']) if(!js.includes(x)) throw new Error('Missing JS '+x);
if(/flash\s*\(/i.test(js)) throw new Error('Unexpected flash function');
console.log('Wave 8 audit passed');
