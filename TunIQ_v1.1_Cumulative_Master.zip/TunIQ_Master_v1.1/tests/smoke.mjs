import fs from 'node:fs';
const required=['index.html','css/style.css','js/app.js','backend/server.mjs','docs/WAVE4_SCOPE.md'];
for(const f of required){if(!fs.existsSync(new URL('../'+f,import.meta.url)))throw new Error('Missing '+f)}
const html=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');
for(const id of ['live','serialConnect','demoConnect','dtcList','liveChart'])if(!html.includes(`id="${id}"`))throw new Error('Missing UI id '+id);
console.log('Wave 4 smoke test passed');
