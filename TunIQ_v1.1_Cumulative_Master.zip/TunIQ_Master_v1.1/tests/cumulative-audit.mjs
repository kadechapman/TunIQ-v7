import fs from 'node:fs';
import assert from 'node:assert/strict';

const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const js = fs.readFileSync(new URL('../js/app.js', import.meta.url), 'utf8');
const requiredHtml = {
  'Wave 1 dashboard': 'id="dashboard"',
  'Wave 1 garage': 'id="garage"',
  'Wave 1 tune studio': 'id="studio"',
  'Wave 2 log analyzer': 'id="logs"',
  'Wave 2 vehicle form': 'id="vehicleForm"',
  'Wave 3 AI Brain': 'TunIQ AI Brain',
  'Wave 3 build planner': 'id="planner"',
  'Wave 3 project manager': 'id="projects"',
  'Wave 3 knowledge base': 'id="knowledge"',
  'Wave 4 scanner': 'id="live"',
  'Wave 4 DTC workspace': 'id="dtcList"',
  'Wave 4 recording': 'id="record"'
};
for (const [label, marker] of Object.entries(requiredHtml)) {
  assert.ok(html.includes(marker), `${label} marker missing: ${marker}`);
}
const requiredJs = ['localstorage', 'csv', 'conversation', 'serial', 'recording', 'dtc'];
for (const marker of requiredJs) assert.ok(js.toLowerCase().includes(marker), `JS capability marker missing: ${marker}`);
console.log(`Cumulative audit passed: ${Object.keys(requiredHtml).length} UI feature markers and ${requiredJs.length} JS capability markers.`);
