import http from 'node:http';
import os from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
const HOST='127.0.0.1', PORT=Number(process.env.TUNIQ_BRIDGE_PORT||8788);
function pcmHammerCandidates(){const homes=[process.env.ProgramFiles,process.env['ProgramFiles(x86)'],process.env.LOCALAPPDATA].filter(Boolean);const names=['PCM Hammer','PcmHammer','PCMhammer'];const found=[];for(const h of homes)for(const n of names){const p=path.join(h,n);if(fs.existsSync(p))found.push(p)}return found}
function interfaces(){return []}
const server=http.createServer((req,res)=>{
  res.setHeader('Access-Control-Allow-Origin','*');res.setHeader('Access-Control-Allow-Headers','content-type');res.setHeader('Content-Type','application/json');
  if(req.method==='OPTIONS'){res.statusCode=204;return res.end()}
  if(req.url==='/api/bridge/health')return res.end(JSON.stringify({ok:true,name:'TunIQ Local Bridge',version:'0.6.0',platform:os.platform(),arch:os.arch(),writeLocked:true,interfaces:interfaces(),pcmHammer:{installed:pcmHammerCandidates().length>0,paths:pcmHammerCandidates()},capabilities:{inventory:true,health:true,launch:false,readBin:false,writeBin:false,flash:false}}));
  res.statusCode=404;res.end(JSON.stringify({error:'Not found'}));
});
server.listen(PORT,HOST,()=>console.log(`TunIQ Bridge v0.6 listening on http://${HOST}:${PORT} (write commands locked)`));
