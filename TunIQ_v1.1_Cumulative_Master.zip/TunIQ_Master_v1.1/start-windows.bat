@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is required. Install Node.js 20 or newer, then run this file again.& pause & exit /b 1)
if not exist node_modules call npm install
if "%OPENAI_API_KEY%"=="" echo NOTE: OPENAI_API_KEY is not set. TunIQ will run with the limited offline AI.
call npm start
pause
