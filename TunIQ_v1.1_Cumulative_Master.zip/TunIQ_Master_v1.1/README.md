# TunIQ v1.1 Cumulative Master

Extract the ZIP and double-click `OPEN_TUNIQ_WINDOWS.bat`. The launcher waits for the local bridge before opening TunIQ. Opening `TunIQ_Open_Me.html` directly provides browser-only mode.

PCM read, write, recovery, and flash automation remain locked.
