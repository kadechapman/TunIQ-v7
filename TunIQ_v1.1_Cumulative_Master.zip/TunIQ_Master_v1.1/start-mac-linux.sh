#!/usr/bin/env sh
cd "$(dirname "$0")" || exit 1
command -v node >/dev/null 2>&1 || { echo "Node.js 20 or newer is required."; exit 1; }
[ -d node_modules ] || npm install
[ -n "$OPENAI_API_KEY" ] || echo "NOTE: OPENAI_API_KEY is not set. TunIQ will run with the limited offline AI."
npm start
