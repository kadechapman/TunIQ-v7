@echo off
setlocal
cd /d "%~dp0"
start "TunIQ Bridge" /min powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Minimized -File "%~dp0bridge\TunIQ-Bridge.ps1"
echo Starting TunIQ Windows Bridge...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$ok=$false; 1..20 | %% { try { $r=Invoke-RestMethod -Uri 'http://127.0.0.1:8788/api/bridge/health' -TimeoutSec 1; if($r.ok){$ok=$true;break} } catch {}; Start-Sleep -Milliseconds 250 }; if(-not $ok){Write-Host 'Bridge did not respond. TunIQ will open in browser-only mode.' -ForegroundColor Yellow; Start-Sleep 2}"
start "" "%~dp0TunIQ_Open_Me.html"
exit /b 0
