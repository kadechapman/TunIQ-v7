# Wave 10 / v1.0 Scope

- Guided, Manual, and Full AI modes.
- Three-way header and Settings controls.
- Mode-aware AI requests and 1–3 second thinking presentation.
- Polished 1–2 second boot sequence with fail-safe recovery.
- v0.9 external-tool discovery and launch foundation retained.
- PCM writing and flashing remain absent.
