# Wave 9.1 scope

Startup-recovery hotfix for the cumulative v0.9 integration build.

Included:
- fail-safe splash dismissal
- Continue to Dashboard button
- isolated startup steps
- browser compatibility fallback
- readable startup diagnostic panel
- standalone-build watchdog

No PCM write, flash, recovery, or automatic tune-edit command was added.
