# Wave 4 scope

Included: cumulative Waves 1–3 features, scanner demo mode, CSV replay/export, recording, DTC organization, live charts, session logs, and an experimental read-only Web Serial ELM327 path.

Excluded: guaranteed adapter compatibility, mobile Safari hardware access, code clearing, PCM Hammer control, calibration editing, BIN operations, checksums, flashing, and automatic tuning.
