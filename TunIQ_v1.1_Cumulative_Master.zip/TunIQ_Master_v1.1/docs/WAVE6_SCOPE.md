# Wave 6 Scope — Easy Launch and First-Run Clarity

- Added a one-click Windows launcher that opens the standalone application without Node.js.
- Added a prominent START_HERE guide.
- Preserved the one-file offline launcher for Windows, macOS, Linux, and mobile browsers.
- Clarified that Node.js scripts are optional developer/connected-feature services, not the normal app opener.
- Preserved all cumulative features through Wave 5 and all hardware-write safety locks.
