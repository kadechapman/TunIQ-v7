# TunIQ cumulative release model

TunIQ is maintained as one growing application. Each release starts from the previous complete release, adds the next wave, runs regression checks, and is packaged as a new ZIP.

- v0.1 / Wave 1: Foundation
- v0.2 / Wave 2: Smart Garage and log analysis
- v0.3 / Wave 3: AI Brain, project memory, and build planning
- v0.4 / Wave 4: Live diagnostics foundation

Users download only the newest ZIP. Older releases remain available as rollback copies and are not combined manually.
