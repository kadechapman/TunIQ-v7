# Wave 2 scope

Wave 2 focuses on guided onboarding, saved vehicle context, local log analysis, and an optional AI backend. Hardware communication remains out of scope.
