const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { TuneWorkspaceManager } = require('../src/tune-workspace');

function validate(workspace) {
  assert(workspace && workspace.tables && Object.keys(workspace.tables).length);
  for (const table of Object.values(workspace.tables)) assert(Array.isArray(table.values) && table.values.length);
  return true;
}
function workspace(active, value = 10, mode = 'xdf') {
  return {
    mode, projectId: active.id, activeTable: 'spark', modified: {},
    tables: { spark: { name: 'Spark', rowHeaders: ['1000'], colHeaders: ['0.50'], values: [[value]] } },
    stock: { spark: { name: 'Spark', rowHeaders: ['1000'], colHeaders: ['0.50'], values: [[10]] } }
  };
}
function setup(name) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), `tuniq-workspace-${name}-`));
  const activities = [];
  const manager = new TuneWorkspaceManager({ appendActivity: (type, details) => activities.push({ type, details }) });
  function project(id) {
    const folder = path.join(root, id); fs.mkdirSync(folder, { recursive: true });
    const bin = path.join(folder, 'original.bin'), xdf = path.join(folder, 'definition.xdf');
    fs.writeFileSync(bin, Buffer.alloc(64, id.charCodeAt(0))); fs.writeFileSync(xdf, `<XDFHEADER><deftitle>${id}</deftitle></XDFHEADER>`);
    return { id, name: id, folder, bin, binInfo: { sha256: require('crypto').createHash('sha256').update(fs.readFileSync(bin)).digest('hex') }, xdf, controller: 'P01', os: '12212156' };
  }
  return { root, manager, activities, project };
}

function scenarioIsolationAndRestart() {
  const ctx = setup('isolation');
  try {
    const a = ctx.project('project-a'), b = ctx.project('project-b');
    const wa = ctx.manager.bind(workspace(a, 11), a); const wb = ctx.manager.bind(workspace(b, 22), b);
    ctx.manager.save(a, wa, validate); ctx.manager.save(b, wb, validate);
    ctx.manager.createSnapshot(a, wa, { name: 'A baseline' }, validate);
    ctx.manager.createSnapshot(b, wb, { name: 'B baseline' }, validate);
    assert.equal(ctx.manager.load(a, () => workspace(a, 0, 'practice'), validate).tables.spark.values[0][0], 11);
    assert.equal(ctx.manager.load(b, () => workspace(b, 0, 'practice'), validate).tables.spark.values[0][0], 22);
    assert.equal(ctx.manager.history(a).length, 1); assert.equal(ctx.manager.history(b).length, 1);
    return { scenario: 'project-isolation-restart', passed: true, projectA: 11, projectB: 22 };
  } finally { fs.rmSync(ctx.root, { recursive: true, force: true }); }
}

function scenarioBackupRecovery() {
  const ctx = setup('recovery');
  try {
    const active = ctx.project('recovery-project');
    const first = ctx.manager.bind(workspace(active, 15), active); ctx.manager.save(active, first, validate);
    const second = ctx.manager.bind(workspace(active, 18), active); ctx.manager.save(active, second, validate);
    fs.writeFileSync(ctx.manager.workspaceFile(active), '{broken json', 'utf8');
    const recovered = ctx.manager.load(active, () => workspace(active, 0, 'practice'), validate);
    assert.equal(recovered.tables.spark.values[0][0], 15);
    assert(recovered.recovery?.restoredFromBackupAt);
    return { scenario: 'corrupt-workspace-backup-recovery', passed: true, recoveredValue: 15 };
  } finally { fs.rmSync(ctx.root, { recursive: true, force: true }); }
}

function scenarioCompareRestoreAndMismatch() {
  const ctx = setup('compare');
  try {
    const active = ctx.project('compare-project');
    const baseline = ctx.manager.bind(workspace(active, 10), active); ctx.manager.save(active, baseline, validate);
    const snapshot = ctx.manager.createSnapshot(active, baseline, { name: 'Known good' }, validate);
    const changed = ctx.manager.bind(workspace(active, 14), active); changed.modified['spark:0:0'] = true; ctx.manager.save(active, changed, validate);
    const comparison = ctx.manager.compare(active, changed, snapshot.id);
    assert.equal(comparison.changedCells, 1); assert.equal(comparison.details[0].delta, 4);
    const restored = ctx.manager.restore(active, snapshot.id, validate); assert.equal(restored.tables.spark.values[0][0], 10);
    fs.writeFileSync(active.bin, Buffer.alloc(64, 0x7f)); active.binInfo.sha256 = require('crypto').createHash('sha256').update(fs.readFileSync(active.bin)).digest('hex');
    let stop = ''; try { ctx.manager.restore(active, snapshot.id, validate); } catch (error) { stop = error.code; }
    assert.equal(stop, 'snapshot-binding-mismatch');
    const fresh = ctx.manager.load(active, () => workspace(active, 5, 'practice'), validate);
    assert.equal(fresh.mode, 'practice');
    assert(fs.readdirSync(ctx.manager.recoveryRoot(active)).some(name => name.startsWith('invalidated-')));
    return { scenario: 'compare-restore-fingerprint-stop', passed: true, changedCells: 1, restoreValue: 10, stop };
  } finally { fs.rmSync(ctx.root, { recursive: true, force: true }); }
}

const report = { type: 'tuniq-tune-workspace-simulations', version: '1.7.0-beta.15', generatedAt: new Date().toISOString(), scenarios: [scenarioIsolationAndRestart(), scenarioBackupRecovery(), scenarioCompareRestoreAndMismatch()] };
report.passed = report.scenarios.every(item => item.passed);
console.log(JSON.stringify(report, null, 2));
if (!report.passed) process.exit(1);
