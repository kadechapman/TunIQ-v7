# TunIQ v1.7.0-beta.15 Test Report

## Release

- Name: Hardware Validation Hotfix
- Base: TunIQ v1.7.0-beta.14 Closed-Loop Autonomous Tuning
- Development fixture: user-supplied beta.14 diagnostic report structure
- Real hardware verified: **No**

## Fix verification

- `workspace:get-summary` values are recursively converted to Electron structured-clone-safe plain data.
- Error objects preserve name, message, code, stack, and safe details.
- Buffers/typed arrays become size and SHA-256 metadata.
- BigInts become strings; functions/native handles are removed; circular references are contained.
- Summary failures return a minimal fallback rather than stopping the renderer action.
- PCM Hammer portable `Cli` layouts locate the sibling normal GUI executable.
- Unsupported CLI probes return assisted-mode status instead of causing a repeated Resume stop.
- A separately persisted normal PCM Hammer GUI path is supported.

## Test results

- Source syntax check: PASS
- Automated suite: **20/20 groups PASS**
- Retained focused simulations: **27/27 PASS**
- P01 clean, disconnect/restart, partial/mismatch/block-failure scenarios: PASS
- Exactly two 524,288-byte matching P01 reads rule: preserved
- Exact OS XDF and Test Write gates: preserved
- Final PCM write confirmation gate: preserved

## Diagnostic-state result

The supplied diagnostic represented an intact Customline P01 project with OS 9379910, service 9354896, a 524,288-byte protected original, imported reads, and an unsupported portable CLI probe. The raw private diagnostic and user paths are not included in this source package.

## Boundary

This release was tested through automated and software simulations. No physical OBDLink MX+, Windows Bluetooth COM session, vehicle, PCM read, Test Write, flash, or road/dyno validation is claimed.
