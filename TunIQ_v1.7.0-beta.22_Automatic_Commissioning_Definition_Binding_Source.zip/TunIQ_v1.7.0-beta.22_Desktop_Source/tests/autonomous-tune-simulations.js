const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { AutonomousTuneManager, deriveAutonomousTargets, executeAutonomousTune } = require('../src/autonomous-tune');
const { TuneEngineManager } = require('../src/tune-engine');
const { projectFixture, workspaceFixture, writeLog, targets, intake } = require('./tune-engine-simulations');

function sha(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function authorization(overrides = {}) {
  return {
    allowAutomaticCalibration: true,
    allowHighRiskMappedChanges: true,
    finalFlashSeparate: true,
    confirmedFacts: {
      protectedOriginal: true,
      mechanicalHealth: true,
      injectorData: true,
      fuelPressure: true,
      wideband: true,
      valvetrain: true,
      driveline: true,
      controlledTest: true
    },
    ...overrides
  };
}
function services(active, workspace, options = {}) {
  let current = JSON.parse(JSON.stringify(workspace));
  let revisionNumber = 0;
  const snapshots = [];
  return {
    callbacks: {
      validateWorkspace(value) { assert.equal(value.projectId, active.id); assert(value.tables); },
      saveWorkspace(value) { current = JSON.parse(JSON.stringify(value)); return current; },
      createSnapshot(value, payload) { snapshots.push({ name: payload.name, modified: Object.keys(value.modified || {}).length }); return snapshots.at(-1); },
      exportRevision(value, config) {
        revisionNumber += 1;
        const file = path.join(active.folder, 'Revisions', `${config.suffix}-${revisionNumber}.bin`);
        fs.mkdirSync(path.dirname(file), { recursive: true });
        fs.writeFileSync(file, Buffer.alloc(524288, 0x40 + revisionNumber));
        return { path: file, name: path.basename(file), sha256: sha(file), checksumStatus: 'valid', compatible: true, modifiedCells: Object.keys(value.modified || {}).length };
      },
      createHandoff(plan, value, revision) {
        if (options.failHandoffOnce && !options.failed) { options.failed = true; throw new Error('simulated handoff interruption'); }
        const folder = path.join(active.folder, 'Handoff', 'autonomous'); fs.mkdirSync(folder, { recursive: true });
        fs.writeFileSync(path.join(folder, 'handoff.json'), JSON.stringify({ planId: plan.id, revision: revision?.name, modified: Object.keys(value.modified || {}).length }));
        return { folder, manifest: path.join(folder, 'handoff.json') };
      }
    },
    get workspace() { return current; },
    snapshots
  };
}

async function completeAutonomousTune(root) {
  const active = projectFixture(root, 'auto-complete');
  const workspace = workspaceFixture(active);
  const log = path.join(active.folder, 'Logs', 'complete.csv'); writeLog(log, { knock: true });
  const events = [];
  const manager = new AutonomousTuneManager({ appendActivity: (type, details) => events.push({ type, details }) });
  const engine = new TuneEngineManager({ appendActivity: () => {} });
  const svc = services(active, workspace);
  const derived = deriveAutonomousTargets(intake(), targets(log), authorization());
  assert.equal(derived.profile, 'street'); assert.equal(derived.targetAfr, 12.6);
  const result = await executeAutonomousTune({ manager, engineManager: engine, active, intake: intake(), workspace, targets: derived, authorization: authorization(), callbacks: svc.callbacks });
  assert.equal(result.state.status, 'ready-for-flash-confirmation');
  assert(result.state.totalAppliedCells > 10);
  assert(result.state.completedStages.includes('drivability'));
  assert(result.state.completedStages.includes('airflow'));
  assert(result.state.completedStages.includes('fueling'));
  assert(result.state.completedStages.includes('spark'));
  assert(result.state.completedStages.includes('transmission'));
  assert(fs.existsSync(result.revision.path)); assert(fs.existsSync(result.handoff.manifest));
  assert.equal(result.state.authorization.finalFlashSeparate, true);
  assert(events.some(item => item.type === 'autonomous-tune-completed'));
}

async function restartResume(root) {
  const active = projectFixture(root, 'auto-resume');
  const workspace = workspaceFixture(active);
  const log = path.join(active.folder, 'Logs', 'resume.csv'); writeLog(log, { knock: true });
  const manager = new AutonomousTuneManager({ appendActivity: () => {} });
  const engine = new TuneEngineManager({ appendActivity: () => {} });
  const options = { failHandoffOnce: true, failed: false };
  const svc = services(active, workspace, options);
  const first = await executeAutonomousTune({ manager, engineManager: engine, active, intake: intake(), workspace, targets: targets(log), authorization: authorization(), callbacks: svc.callbacks });
  assert.equal(first.state.status, 'stopped'); assert.equal(first.state.phase, 'handoff');
  assert(first.state.completedStages.length >= 4);
  const restarted = new AutonomousTuneManager({ appendActivity: () => {} });
  const resumed = await executeAutonomousTune({ manager: restarted, engineManager: engine, active, intake: first.state.intake, workspace: first.workspace, targets: first.state.targets, authorization: first.state.authorization, mode: first.state.mode, resume: true, callbacks: svc.callbacks });
  assert.equal(resumed.state.status, 'ready-for-flash-confirmation');
  assert.equal(resumed.state.resumeCount, 1);
  assert(fs.existsSync(resumed.handoff.manifest));
}

async function safetyAndWaiting(root) {
  const active = projectFixture(root, 'auto-safety');
  const workspace = workspaceFixture(active);
  const manager = new AutonomousTuneManager({ appendActivity: () => {} });
  const engine = new TuneEngineManager({ appendActivity: () => {} });
  const svc = services(active, workspace);
  await assert.rejects(() => executeAutonomousTune({ manager, engineManager: engine, active, intake: intake(), workspace, targets: { ...targets(null), selectedLog: null }, authorization: { ...authorization(), allowAutomaticCalibration: false }, callbacks: svc.callbacks }), /authorization/i);
  const waiting = await executeAutonomousTune({ manager, engineManager: engine, active, intake: intake(), workspace, targets: { ...targets(null), selectedLog: null }, authorization: authorization(), callbacks: svc.callbacks });
  assert.equal(waiting.state.status, 'waiting-for-log');
  const changed = JSON.parse(JSON.stringify(workspace)); changed.binding.binSha256 = 'changed';
  await assert.rejects(() => executeAutonomousTune({ manager, engineManager: engine, active, intake: waiting.state.intake, workspace: changed, targets: waiting.state.targets, authorization: waiting.state.authorization, resume: true, callbacks: svc.callbacks }), /fingerprint changed/i);
}

async function runAll() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-autonomous-sim-'));
  try {
    await completeAutonomousTune(path.join(root, 'one'));
    await restartResume(path.join(root, 'two'));
    await safetyAndWaiting(path.join(root, 'three'));
    console.log('✓ Autonomous Tune simulation 1: complete tune automatically applied and packaged');
    console.log('✓ Autonomous Tune simulation 2: interruption and exact-stage restart/resume');
    console.log('✓ Autonomous Tune simulation 3: authorization, evidence, and fingerprint safety stops');
    console.log('All TunIQ beta.22 Autonomous Tune Agent simulations passed.');
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
}

if (require.main === module) runAll().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
module.exports = { runAll, authorization, services };
