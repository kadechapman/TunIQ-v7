const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const {
  TuneEngineManager,
  buildCoverageMap,
  buildTunePlan,
  buildStageProposal,
  applyStageProposal
} = require('../src/tune-engine');

function sha(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function projectFixture(root, id = 'street-project') {
  const folder = path.join(root, id);
  fs.mkdirSync(path.join(folder, 'Originals'), { recursive: true });
  fs.mkdirSync(path.join(folder, 'Definitions'), { recursive: true });
  fs.mkdirSync(path.join(folder, 'Logs'), { recursive: true });
  fs.mkdirSync(path.join(folder, 'Revisions'), { recursive: true });
  const bin = path.join(folder, 'Originals', 'stock.bin');
  const xdf = path.join(folder, 'Definitions', 'P01_12212156.xdf');
  fs.writeFileSync(bin, Buffer.alloc(524288, 0x51));
  fs.writeFileSync(xdf, '<XDFHEADER><deftitle>P01 OS 12212156</deftitle></XDFHEADER>');
  return { id, name: id, folder, controller: 'P01', os: '12212156', bin, binInfo: { sha256: sha(bin) }, xdf };
}
function table(name, rows, columns, values, extra = {}) {
  return { name, rowHeaders: rows, colHeaders: columns, values, address: extra.address ?? 0x100, equationSupported: true, min: extra.min ?? null, max: extra.max ?? null, unit: extra.unit || '', ...extra };
}
function workspaceFixture(active) {
  const workspace = {
    schemaVersion: 2, mode: 'xdf', projectId: active.id, sourceBin: active.bin, sourceXdf: active.xdf,
    sourceBinSha256: sha(active.bin), sourceXdfSha256: sha(active.xdf), mappingSummary: { loaded: 10, warnings: [] }, activeTable: 'idle', modified: {},
    binding: { projectId: active.id, binSha256: sha(active.bin), xdfSha256: sha(active.xdf) },
    tables: {
      idle: table('Desired Idle Speed', ['160', '200'], ['P/N', 'Drive'], [[650, 625], [650, 625]], { min: 500, max: 1400 }),
      airflow: table('Base Running Airflow', ['160', '200'], ['P/N'], [[4.5], [4.2]], { unit: 'g/s', min: 0, max: 30 }),
      fans: table('Cooling Fan Temperatures', ['Fan 1 On', 'Fan 1 Off', 'Fan 2 On', 'Fan 2 Off'], ['Value'], [[205], [198], [215], [208]], { unit: 'F', min: 120, max: 245 }),
      limits: table('Engine & Vehicle Speed Limits', ['Rev limiter fuel cut', 'Rev limiter resume', 'Vehicle speed limiter MPH'], ['Value'], [[5600], [5400], [98]], { min: 0, max: 8500 }),
      maf: table('MAF Calibration', ['Value'], ['2000', '4000', '6000'], [[10, 20, 30]], { min: 0, max: 100 }),
      ve: table('Main Volumetric Efficiency', ['1000', '1500', '2000'], ['30', '40', '50'], [[60, 65, 70], [70, 75, 80], [75, 80, 85]], { unit: '%', min: 20, max: 125 }),
      pe: table('Power Enrichment EQ Ratio', ['2000', '3000', '4000'], ['60', '80', '100'], [[1.05, 1.08, 1.1], [1.06, 1.1, 1.12], [1.08, 1.12, 1.14]], { unit: 'EQ', min: 0.7, max: 1.5 }),
      spark: table('High Octane Spark', ['1000', '2000', '3000', '4000'], ['0.30', '0.50', '0.70', '0.90'], [[20, 18, 16, 14], [24, 22, 20, 18], [28, 26, 24, 22], [30, 28, 26, 24]], { unit: 'deg', min: -10, max: 50 }),
      shifts: table('WOT Shift RPM', ['1-2', '2-3', '3-4'], ['Normal', 'Performance'], [[5200, 5400], [5150, 5350], [5000, 5250]], { unit: 'RPM', min: 2500, max: 7500 }),
      pressure: table('Shift Pressure', ['1-2', '2-3'], ['50', '100'], [[80, 95], [75, 90]], { min: 0, max: 150 })
    }
  };
  workspace.stock = JSON.parse(JSON.stringify(workspace.tables));
  return workspace;
}
function writeLog(file, options = {}) {
  const headers = ['timestamp','rpm','speed','ect','iat','tps','map','maf','stft1','ltft1','spark','voltage','load','fuelPressure','knockRetard','commandedEqRatio','widebandAfr','misfireTotal','mafFrequency','injectorDuty','desiredIdle','marker'];
  const rows = [headers.join(',')];
  for (let index = 0; index < 100; index += 1) {
    const wot = index >= 60;
    const knock = options.knock && index >= 70 && index < 82 ? 2.5 : 0;
    rows.push([
      new Date(1700000000000 + index * 100).toISOString(), wot ? 3000 : 1500, wot ? 70 : 30, 190, 85, wot ? 85 : 25,
      wot ? 85 : 40, wot ? 65 : 20, 3.2, 2.4, wot ? 22 : 24, options.lowVoltage ? 11.8 : 13.9,
      wot ? 0.7 : 0.4, 58, knock, wot ? 1.15 : 1, options.noWideband && wot ? '' : (wot ? 12.7 : 14.7), 0,
      wot ? 6000 : 4000, wot ? 70 : 28, 750, ''
    ].join(','));
  }
  fs.writeFileSync(file, `${rows.join('\n')}\n`);
}
function targets(log) {
  return {
    profile: 'street', aggressiveness: 2, selectedLog: log, desiredIdle: 750, revLimit: 6000, speedLimit: 120,
    fan1On: 195, fan1Off: 188, fan2On: 205, fan2Off: 198, targetAfr: 12.6, shiftRpm: 5500,
    confirmations: { protectedOriginal: true, mechanicalHealth: true, injectorData: true, fuelPressure: true, wideband: true, valvetrain: true, driveline: true, controlledTest: true }
  };
}
function intake() { return { engine: '5.3 LM7', transmission: '4L60E', fuel: '93 octane gasoline', aspiration: 'Naturally aspirated', tuneGoal: 'Street performance tune', modifications: ['Long-tube headers'], desiredIdle: '750' }; }

function cleanSuccessfulWorkflow(root) {
  const active = projectFixture(root, 'clean');
  const workspace = workspaceFixture(active);
  const log = path.join(active.folder, 'Logs', 'baseline.csv'); writeLog(log, { knock: true });
  const plan = buildTunePlan({ activeProject: active, intake: intake(), workspace, targets: targets(log) });
  assert(plan.readiness.score >= 85);
  assert.equal(plan.stages.find(stage => stage.id === 'drivability').status, 'ready');
  assert.equal(plan.stages.find(stage => stage.id === 'airflow').status, 'ready');
  assert.equal(plan.stages.find(stage => stage.id === 'fueling').status, 'ready');
  assert.equal(plan.stages.find(stage => stage.id === 'spark').status, 'ready');
  const coverage = buildCoverageMap(workspace);
  assert(coverage.roles['desired-idle'].available && coverage.roles.maf.available && coverage.roles['high-spark'].available);
  const drive = buildStageProposal({ plan, stageId: 'drivability', workspace, activeProject: active });
  assert.equal(drive.blocked, false); assert(drive.proposals.length >= 8);
  const applied = applyStageProposal(JSON.parse(JSON.stringify(workspace)), drive, drive.proposals.map(item => item.id));
  assert(applied.applied.length >= 8);
  assert.equal(applied.workspace.tables.idle.values[0][0], 750);
  assert.equal(applied.workspace.tables.limits.values[0][0], 6000);
  assert.equal(applied.workspace.tables.limits.values[2][0], 120);
  const airflow = buildStageProposal({ plan, stageId: 'airflow', workspace, activeProject: active, csvPath: log });
  assert.equal(airflow.blocked, false); assert(airflow.proposals.some(item => ['maf','ve','idle-airflow'].includes(item.role)));
  const spark = buildStageProposal({ plan, stageId: 'spark', workspace, activeProject: active, csvPath: log });
  assert.equal(spark.blocked, false); assert(spark.proposals.every(item => item.proposed <= item.current));
  return { active, workspace, plan, drive };
}
function restartResumeAndHandoff(root) {
  const { active, workspace, plan, drive } = cleanSuccessfulWorkflow(root);
  const events = [];
  const manager = new TuneEngineManager({ appendActivity: (type, details) => events.push({ type, details }) });
  manager.savePlan(active, plan); const saved = manager.saveProposal(active, drive);
  const restarted = new TuneEngineManager({ appendActivity: () => {} });
  const status = restarted.status(active, workspace);
  assert.equal(status.plan.id, plan.id); assert.equal(status.proposals[0].id, saved.id); assert.equal(status.stale, false);
  const revision = path.join(active.folder, 'Revisions', 'street-v1.bin'); fs.writeFileSync(revision, Buffer.alloc(524288, 0x52));
  const handoff = restarted.createHandoff(active, plan, workspace, { path: revision });
  assert(fs.existsSync(handoff.manifest)); assert(fs.existsSync(handoff.summary)); assert(fs.existsSync(path.join(handoff.folder, 'street-v1.bin')));
  const loaded = JSON.parse(fs.readFileSync(handoff.manifest, 'utf8'));
  assert.equal(loaded.project.id, active.id); assert.equal(loaded.revision.sha256, sha(revision));
}
function safetyStops(root) {
  const active = projectFixture(root, 'safety');
  const workspace = workspaceFixture(active);
  const unsafe = path.join(active.folder, 'Logs', 'unsafe.csv'); writeLog(unsafe, { lowVoltage: true, noWideband: true, knock: true });
  const boostedIntake = { ...intake(), aspiration: 'Turbocharged', tuneGoal: 'Forced-induction tune', modifications: ['Turbo', 'Larger injectors'] };
  const incomplete = targets(unsafe); incomplete.confirmations.wideband = false; incomplete.confirmations.fuelPressure = false; incomplete.confirmations.injectorData = false; incomplete.confirmations.controlledTest = false;
  const plan = buildTunePlan({ activeProject: active, intake: boostedIntake, workspace, targets: incomplete });
  assert.equal(plan.health.healthy, false);
  assert.equal(plan.stages.find(stage => stage.id === 'airflow').status, 'blocked');
  assert.equal(plan.stages.find(stage => stage.id === 'fueling').status, 'blocked');
  assert.throws(() => buildStageProposal({ plan, stageId: 'fueling', workspace, activeProject: active }), /blocked/i);
  const malicious = {
    id: 'malicious', kind: 'tune-engine-stage-proposal', planId: plan.id, projectId: active.id, binding: workspace.binding, stageId: 'spark', blocked: false,
    proposals: [{ id: 'spark-up', role: 'high-spark', tableKey: 'spark', tableName: 'High Octane Spark', row: 1, col: 1, current: 22, proposed: 24, risk: 'high' }]
  };
  assert.throws(() => applyStageProposal(JSON.parse(JSON.stringify(workspace)), malicious, ['spark-up']), /spark increase/i);
  const changed = JSON.parse(JSON.stringify(workspace)); changed.binding.binSha256 = 'different';
  assert.throws(() => buildStageProposal({ plan, stageId: 'drivability', workspace: changed, activeProject: active }), /fingerprint changed/i);
}

function runAll() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-engine-sim-'));
  try {
    cleanSuccessfulWorkflow(path.join(root, 'one'));
    restartResumeAndHandoff(path.join(root, 'two'));
    safetyStops(path.join(root, 'three'));
    console.log('✓ Tune Engine simulation 1: clean staged tuning workflow');
    console.log('✓ Tune Engine simulation 2: restart/resume, audit persistence, and handoff bundle');
    console.log('✓ Tune Engine simulation 3: health, instrumentation, fingerprint, and spark safety stops');
    console.log('All TunIQ beta.22 Unified Tune Engine simulations passed.');
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
}

if (require.main === module) runAll();
module.exports = { runAll, projectFixture, workspaceFixture, writeLog, targets, intake };
