#!/usr/bin/env node
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { parseXdf } = require('../src/xdf');
const {
  scanDefinitionSources, buildXdfFromUniversalTunerXml, parseUniversalTunerXml,
  createDefinitionJob, inspectDefinitionJob, universalPatcherLayout
} = require('../src/definition-pipeline');

const requested = process.argv[2] || 'all';
const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-beta20-definitions-'));
function folder(name) { const value = path.join(tempRoot, name); fs.mkdirSync(value, { recursive: true }); return value; }
function writeExactXdf(file, osid = '9379910') {
  fs.writeFileSync(file, `<?xml version="1.0"?><XDF><XDFHEADER><deftitle>P01 OS ${osid} exact definition</deftitle><baseoffset>0</baseoffset></XDFHEADER><XDFCONSTANT uniqueid="idle" title="Desired Idle"><EMBEDDEDDATA mmedaddress="0x20" mmedelementsizebits="16" lsbfirst="1"/><MATH equation="X" units="RPM"/></XDFCONSTANT></XDF>`);
}
function writeUpXml(file, osid = '9379910', options = {}) {
  const unsafe = options.unsafe ? '<Math>process.exit()</Math>' : '<Math>X*0.5</Math>';
  const address = options.missingAddress ? '' : '<Address>0x40</Address>';
  fs.writeFileSync(file, `<Tuner><OS>${osid}</OS><TableData><TableName>Main VE</TableName><Category>Fuel</Category><OS>${osid}</OS>${address}<DataType>UWORD</DataType><Rows>2</Rows><Columns>2</Columns><ByteOrder>PlatformOrder</ByteOrder><RowMajor>false</RowMajor>${unsafe}<Units>%</Units><RowHeaders>1000;2000</RowHeaders><ColumnHeaders>40;80</ColumnHeaders></TableData><TableData><TableName>Idle RPM</TableName><OS>${osid}</OS><Address>0x20</Address><DataType>SWORD</DataType><Rows>1</Rows><Columns>1</Columns><ByteOrder>PlatformOrder</ByteOrder><RowMajor>true</RowMajor><Math>X</Math><Units>RPM</Units></TableData></Tuner>`);
}

async function exactLocalXdf() {
  const root = folder('exact-local-xdf');
  const xdf = path.join(root, '9379910-stock.xdf'); writeExactXdf(xdf);
  const scan = scanDefinitionSources({ os: '9379910', roots: [root], parseXdf, controller: 'P01' });
  assert.equal(scan.xdfs.length, 1); assert.equal(scan.xdfs[0].tableCount, 1); assert.equal(scan.universalXml.length, 0);
  return { scenario: 'exact-local-xdf', passed: true, candidate: scan.xdfs[0].name, tableCount: scan.xdfs[0].tableCount };
}

async function universalPatcherXmlConversion() {
  const root = folder('up-xml-conversion');
  const upRoot = path.join(root, 'UniversalPatcher'); fs.mkdirSync(path.join(upRoot, 'XML'), { recursive: true }); fs.mkdirSync(path.join(upRoot, 'Tuner'), { recursive: true });
  const exe = path.join(upRoot, 'UniversalPatcher.exe'); fs.writeFileSync(exe, 'mock'); fs.writeFileSync(path.join(upRoot, 'XML', 'P01-P59.xml'), '<PCM/>');
  const xml = path.join(upRoot, 'Tuner', '9379910.xml'); writeUpXml(xml);
  const layout = universalPatcherLayout(exe); assert.equal(layout.complete, true);
  const parsed = parseUniversalTunerXml(xml, { controller: 'P01' }); assert.equal(parsed.usableTables.length, 2); assert.equal(parsed.usableTables[0].littleEndian, false); assert.equal(parsed.usableTables[0].rowMajor, false);
  const output = path.join(root, 'generated', 'TunIQ-UP-OS-9379910.xdf');
  const built = buildXdfFromUniversalTunerXml(xml, output, { os: '9379910', binSize: 524288, controller: 'P01' });
  const xdf = parseXdf(output); assert.equal(xdf.tables.length, 2); assert(xdf.title.includes('9379910')); assert.equal(xdf.tables[0].littleEndian, false); assert.equal(xdf.tables[0].columnMajor, true); assert(fs.existsSync(`${output}.provenance.json`));
  const scan = scanDefinitionSources({ os: '9379910', roots: [root], parseXdf, universalPatcherExe: exe, controller: 'P01' });
  assert(scan.xdfs.some(item => item.path === output)); assert(scan.universalXml.some(item => item.path === xml));
  return { scenario: 'universal-patcher-xml-conversion', passed: true, generated: path.basename(output), tableCount: xdf.tables.length, provenance: built.provenance.outputSha256 };
}

async function safeMissingDefinitionStop() {
  const root = folder('safe-missing-definition');
  const wrong = path.join(root, '12202088.xdf'); writeExactXdf(wrong, '12202088');
  const unsafe = path.join(root, '9379910.xml'); writeUpXml(unsafe, '9379910', { unsafe: true, missingAddress: true });
  const scan = scanDefinitionSources({ os: '9379910', roots: [root], parseXdf, controller: 'P01' });
  assert.equal(scan.xdfs.length, 0); assert.equal(scan.universalXml.length, 1); assert.equal(scan.universalXml[0].usableTables.length, 1, 'only the separately valid explicit-address table may remain usable');
  const bin = path.join(root, 'stock.bin'); fs.writeFileSync(bin, Buffer.alloc(524288, 0x55));
  const job = createDefinitionJob({ projectFolder: root, projectId: 'p1', projectName: 'Customline', os: '9379910', bin, tools: {} });
  const wrongOutput = path.join(job.output, 'wrong-os.xdf'); writeExactXdf(wrongOutput, '12202088');
  const inspected = inspectDefinitionJob(job.folder, { parseXdf, os: '9379910', binSize: 524288 });
  assert.equal(inspected.accepted.length, 0); assert.equal(inspected.rejected.length, 1); assert(fs.existsSync(path.join(job.folder, 'definition-job.json')));
  return { scenario: 'safe-missing-definition-stop', passed: true, accepted: inspected.accepted.length, rejected: inspected.rejected.length, job: path.basename(job.folder), guessedDefinitionGenerated: false };
}

const scenarios = {
  'exact-local-xdf': exactLocalXdf,
  'universal-patcher-xml-conversion': universalPatcherXmlConversion,
  'safe-missing-definition-stop': safeMissingDefinitionStop
};
async function runIntegratedDefinitionPipelineSimulations(selection = requested, options = {}) {
  try {
    const names = selection === 'all' ? Object.keys(scenarios) : [selection];
    const reports = [];
    for (const name of names) {
      if (!scenarios[name]) throw new Error(`Unknown scenario: ${name}`);
      reports.push(await scenarios[name]());
      if (!options.quiet) console.log(`✓ beta.22 definition pipeline simulation: ${name}`);
    }
    const result = { type: 'tuniq-integrated-definition-pipeline-simulations', version: '1.7.0-beta.22', generatedAt: new Date().toISOString(), softwareSimulationOnly: true, realHardwareVerified: false, reports };
    const out = path.join(__dirname, '..', 'test-results'); fs.mkdirSync(out, { recursive: true });
    fs.writeFileSync(path.join(out, 'integrated-definition-pipeline-simulations.json'), JSON.stringify(result, null, 2));
    return result;
  } finally { fs.rmSync(tempRoot, { recursive: true, force: true }); }
}
if (require.main === module) runIntegratedDefinitionPipelineSimulations().then(result => { console.log(JSON.stringify(result.reports, null, 2)); console.log('All TunIQ beta.22 Integrated Definition Pipeline simulations passed.'); }).catch(error => { console.error(error.stack || error); process.exit(1); });
module.exports = { runIntegratedDefinitionPipelineSimulations };
