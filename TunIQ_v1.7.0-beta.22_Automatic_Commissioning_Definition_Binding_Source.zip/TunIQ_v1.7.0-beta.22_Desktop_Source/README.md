# TunIQ v1.7.0-beta.22 — Automatic Commissioning Definition Binding

Beta.22 fixes the beta.21 P01 setup stop that incorrectly asked the user to load the protected BIN and TunIQ-generated commissioning XDF manually in Calibration.

## What changed

- Fingerprints the protected original directly from disk instead of trusting stale `binInfo` metadata from an older beta.
- Refreshes cached BIN/XDF metadata automatically when the files on disk are valid.
- Automatically loads and binds a TunIQ-generated commissioning-only XDF.
- Detects and rebuilds the stale beta.21 calibration workspace once when necessary.
- Continues automatically to the unchanged stock-clone revision and PCM Hammer Test Write.
- Never adds guessed tuning addresses. AI/manual tuning and PCM writing remain locked under a commissioning-only definition.

## Existing Customline project

Open the existing project and press **Resume Failed Step**. Do not delete the project or reimport the reads. Beta.22 should repair the stale workspace fingerprint, bind the displayed commissioning definition, and continue.

## Safety boundary

The commissioning definition is read-only and contains zero writable calibration tables. This release finishes hardware commissioning and Test Write only; it does not pretend the stock clone is a tunable calibration.

See `AUTOMATIC_COMMISSIONING_DEFINITION_BINDING.md` and `TEST_REPORT_v1.7.0-beta.22.md`.
