@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo TunIQ v1.7.0-beta.22 setup
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo Node.js is required. Install the current Node.js LTS version, then run this file again.
  pause
  exit /b 1
)

for /f "delims=" %%V in ('node -p "Number(process.versions.node.split('.')[0])"') do set "NODE_MAJOR=%%V"
if not defined NODE_MAJOR (
  echo Could not read the installed Node.js version.
  pause
  exit /b 1
)
if %NODE_MAJOR% LSS 18 (
  echo.
  echo Node.js 18 or newer is required. Installed major version: %NODE_MAJOR%
  pause
  exit /b 1
)

for %%D in ("%CD%") do set "INSTALL_DRIVE=%%~dD"
set "INSTALL_LETTER=%INSTALL_DRIVE:~0,1%"

if not exist node_modules\electron\dist\electron.exe (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$letters=@($env:SystemDrive.TrimEnd(':'),'%INSTALL_LETTER%') | Select-Object -Unique; $low=$false; foreach($letter in $letters){ $free=(Get-PSDrive -Name $letter).Free; Write-Host ('Free space on '+$letter+': drive: '+[math]::Round($free/1GB,2)+' GB'); if($free -lt 3GB){$low=$true} }; if($low){exit 2}"
  if errorlevel 2 (
    echo.
    echo TunIQ needs at least 3 GB free while Electron is being unpacked.
    echo Free more space, empty the Recycle Bin, then run this file again.
    pause
    exit /b 2
  )

  echo.
  echo Installing the Electron desktop runtime...
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo.
    echo Installation failed.
    echo If the error says ENOSPC, free more space and delete this folder's incomplete node_modules folder before retrying.
    echo Otherwise review the npm error shown above.
    pause
    exit /b 1
  )
)

call npm start
if errorlevel 1 (
  echo.
  echo TunIQ stopped with an error.
  echo Startup log: %APPDATA%\TunIQ\Logs\startup.log
  echo Crash log:   %APPDATA%\TunIQ\Logs\desktop-crash.log
  pause
  exit /b 1
)
endlocal
