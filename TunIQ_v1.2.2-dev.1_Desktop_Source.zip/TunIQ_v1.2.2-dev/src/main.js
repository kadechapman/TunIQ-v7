const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');

const APP_VERSION = '1.2.2-dev.1';
let mainWindow;

function dataRoot() {
  return path.join(app.getPath('documents'), 'TunIQ');
}
function ensureDataFolders() {
  const folders = ['Profile','Vehicles','Projects','Logs','AI','Settings','Backups','Tools'];
  fs.mkdirSync(dataRoot(), { recursive: true });
  for (const folder of folders) fs.mkdirSync(path.join(dataRoot(), folder), { recursive: true });
}
function readJson(file, fallback = null) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}
function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8');
}
function profileFile() { return path.join(dataRoot(), 'Profile', 'profile.json'); }
function settingsFile() { return path.join(dataRoot(), 'Settings', 'settings.json'); }
function toolsFile() { return path.join(dataRoot(), 'Tools', 'paths.json'); }

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1000,
    minHeight: 700,
    backgroundColor: '#111714',
    show: false,
    title: `TunIQ ${APP_VERSION}`,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  mainWindow.once('ready-to-show', () => mainWindow.show());
}

function findExecutable(candidates) {
  for (const candidate of candidates) {
    if (candidate && fs.existsSync(candidate)) return candidate;
  }
  return null;
}
function scanTools() {
  const configured = readJson(toolsFile(), {});
  const pf = process.env.ProgramFiles || 'C:\\Program Files';
  const pfx86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
  const local = process.env.LOCALAPPDATA || '';
  const results = {
    pcmHammer: findExecutable([configured.pcmHammer, path.join(pf, 'PCM Hammer', 'PcmHammer.exe'), path.join(pfx86, 'PCM Hammer', 'PcmHammer.exe')]),
    tunerPro: findExecutable([configured.tunerPro, path.join(pf, 'TunerPro', 'TunerPro.exe'), path.join(pfx86, 'TunerPro', 'TunerPro.exe')]),
    universalPatcher: findExecutable([configured.universalPatcher, path.join(pf, 'Universal Patcher', 'UniversalPatcher.exe'), path.join(local, 'UniversalPatcher', 'UniversalPatcher.exe')])
  };
  writeJson(toolsFile(), { ...configured, ...results });
  return results;
}

app.whenReady().then(() => {
  ensureDataFolders();
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('app:get-bootstrap', async () => ({
  version: APP_VERSION,
  dataRoot: dataRoot(),
  profile: readJson(profileFile(), null),
  settings: readJson(settingsFile(), { aiMode: null, units: 'US' }),
  tools: readJson(toolsFile(), {})
}));
ipcMain.handle('profile:save', async (_event, payload) => {
  const profile = { name: String(payload.name || '').trim(), email: String(payload.email || '').trim(), createdAt: new Date().toISOString() };
  const settings = { aiMode: payload.aiMode, units: payload.units || 'US', updatedAt: new Date().toISOString() };
  if (!profile.name || !profile.email || !['guided','manual','full-ai'].includes(settings.aiMode)) throw new Error('Name, email, and AI mode are required.');
  writeJson(profileFile(), profile);
  writeJson(settingsFile(), settings);
  return { profile, settings };
});
ipcMain.handle('settings:set-ai-mode', async (_event, aiMode) => {
  if (!['guided','manual','full-ai'].includes(aiMode)) throw new Error('Invalid AI mode.');
  const settings = { ...readJson(settingsFile(), {}), aiMode, updatedAt: new Date().toISOString() };
  writeJson(settingsFile(), settings);
  return settings;
});
ipcMain.handle('bridge:scan-tools', async () => scanTools());
ipcMain.handle('bridge:choose-tool', async (_event, key) => {
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'], filters: [{ name: 'Windows programs', extensions: ['exe'] }, { name: 'All files', extensions: ['*'] }] });
  if (result.canceled || !result.filePaths[0]) return null;
  const tools = readJson(toolsFile(), {});
  tools[key] = result.filePaths[0];
  writeJson(toolsFile(), tools);
  return tools[key];
});
ipcMain.handle('bridge:launch-tool', async (_event, key) => {
  const tools = readJson(toolsFile(), {});
  const exe = tools[key];
  if (!exe || !fs.existsSync(exe)) throw new Error('Tool path is not configured or no longer exists.');
  const child = spawn(exe, [], { detached: true, stdio: 'ignore' });
  child.unref();
  return true;
});
ipcMain.handle('system:open-data-folder', async () => shell.openPath(dataRoot()));
ipcMain.handle('project:create', async (_event, payload) => {
  const safeName = String(payload.name || '').trim().replace(/[<>:"/\\|?*]/g, '-');
  if (!safeName) throw new Error('Project name is required.');
  const id = `${Date.now()}-${safeName.toLowerCase().replace(/\s+/g,'-')}`;
  const folder = path.join(dataRoot(), 'Projects', id);
  fs.mkdirSync(path.join(folder, 'Originals'), { recursive: true });
  fs.mkdirSync(path.join(folder, 'Revisions'), { recursive: true });
  const manifest = { id, name: safeName, vehicle: payload.vehicle || '', notes: payload.notes || '', createdAt: new Date().toISOString(), revisions: [] };
  writeJson(path.join(folder, 'project.json'), manifest);
  return manifest;
});
ipcMain.handle('project:list', async () => {
  const base = path.join(dataRoot(), 'Projects');
  if (!fs.existsSync(base)) return [];
  return fs.readdirSync(base, { withFileTypes: true }).filter(x => x.isDirectory()).map(x => readJson(path.join(base, x.name, 'project.json'), null)).filter(Boolean).sort((a,b) => b.createdAt.localeCompare(a.createdAt));
});
ipcMain.handle('diagnostics:export', async () => {
  const report = { version: APP_VERSION, platform: process.platform, arch: process.arch, os: os.release(), dataRoot: dataRoot(), profileExists: fs.existsSync(profileFile()), settings: readJson(settingsFile(), {}), tools: scanTools(), generatedAt: new Date().toISOString() };
  const out = path.join(dataRoot(), 'Logs', `diagnostics-${Date.now()}.json`);
  writeJson(out, report);
  return out;
});
