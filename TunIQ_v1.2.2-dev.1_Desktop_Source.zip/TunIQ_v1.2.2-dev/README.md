# TunIQ v1.2.2-dev.1

This is the first real Electron desktop source build. It does not use the old PowerShell HTTP bridge.

## Windows
1. Extract the ZIP completely.
2. Double-click `INSTALL_AND_RUN_WINDOWS.bat` the first time.
3. After installation, use `START_TUNIQ_WINDOWS.bat`.

Node.js LTS and an internet connection are required only for the first Electron runtime installation.

## Implemented in this development build
- Mandatory first-run local profile wizard
- Email, name, units, and actual Guided / Manual / Full AI setting
- Persistent data in `Documents\TunIQ`
- Direct Windows tool scanning, browsing, and launching through Electron
- Scanner demo without a vehicle
- Local tune-project creation and persistent project list
- Offline LS assistant
- Diagnostic report export

## Safety
PCM reading, writing, and flashing are intentionally not implemented in this build.
