$ErrorActionPreference = 'Continue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$DataDir = Join-Path $Root 'Data'
New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
$LauncherLog = Join-Path $DataDir 'launcher.log'
$BridgeOutLog = Join-Path $DataDir 'bridge-console.log'
$BridgeErrLog = Join-Path $DataDir 'bridge-error.log'

function Write-LauncherLog([string]$Message) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff') $Message"
    Add-Content -LiteralPath $LauncherLog -Value $line -Encoding UTF8
    Write-Host $Message
}

Remove-Item -LiteralPath $LauncherLog,$BridgeOutLog,$BridgeErrLog -Force -ErrorAction SilentlyContinue
Clear-Host
Write-Host 'TunIQ v1.2.1' -ForegroundColor Green
Write-Host 'Starting the Windows Bridge...' -ForegroundColor Cyan
Write-LauncherLog "Root: $Root"

$BridgeScript = Join-Path $Root 'bridge\TunIQ-Bridge.ps1'
$OfflineApp = Join-Path $Root 'TunIQ_Open_Me.html'

if (-not (Test-Path -LiteralPath $BridgeScript -PathType Leaf)) {
    Write-LauncherLog 'ERROR: Bridge script is missing.'
    if (Test-Path -LiteralPath $OfflineApp) { Start-Process -FilePath $OfflineApp }
    Read-Host 'Press Enter to close'
    exit 1
}

$ChosenPort = $null
$BridgeProcess = $null

foreach ($Port in 8788..8797) {
    $Busy = $false
    try {
        $Busy = [bool](Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue)
    } catch {
        try {
            $Busy = [bool](netstat -ano | Select-String -SimpleMatch (':' + $Port + ' '))
        } catch { $Busy = $false }
    }

    if ($Busy) {
        Write-LauncherLog "Port $Port is already in use; trying the next port."
        continue
    }

    Write-LauncherLog "Trying local port $Port..."

    # IMPORTANT: Start-Process does not reliably quote array arguments that contain
    # spaces or parentheses. Build one escaped argument string so paths such as
    # 'Downloads\TunIQ-main (1)\...' work correctly.
    $EscapedBridge = $BridgeScript.Replace('"','\"')
    $ArgumentLine = "-NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$EscapedBridge`" -Port $Port"

    try {
        $BridgeProcess = Start-Process -FilePath 'powershell.exe' `
            -ArgumentList $ArgumentLine `
            -WindowStyle Hidden `
            -RedirectStandardOutput $BridgeOutLog `
            -RedirectStandardError $BridgeErrLog `
            -PassThru
    } catch {
        Write-LauncherLog "ERROR: Could not start PowerShell bridge: $($_.Exception.Message)"
        break
    }

    $Connected = $false
    foreach ($Attempt in 1..60) {
        Start-Sleep -Milliseconds 250
        $BridgeProcess.Refresh()

        if ($BridgeProcess.HasExited) {
            Write-LauncherLog "Bridge process exited early with code $($BridgeProcess.ExitCode)."
            if (Test-Path -LiteralPath $BridgeErrLog) {
                $ErrorText = Get-Content -LiteralPath $BridgeErrLog -Raw -ErrorAction SilentlyContinue
                if (-not [string]::IsNullOrWhiteSpace($ErrorText)) {
                    Write-LauncherLog ('Bridge error: ' + $ErrorText.Trim())
                }
            }
            break
        }

        try {
            $Response = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/bridge/health" -TimeoutSec 1
            if ($Response.ok) {
                $Connected = $true
                break
            }
        } catch { }
    }

    if ($Connected) {
        $ChosenPort = $Port
        break
    }

    if ($BridgeProcess -and -not $BridgeProcess.HasExited) {
        try { Stop-Process -Id $BridgeProcess.Id -Force -ErrorAction SilentlyContinue } catch { }
    }
}

if ($ChosenPort) {
    Write-LauncherLog "SUCCESS: Bridge connected on port $ChosenPort."
    Write-Host 'Opening TunIQ...' -ForegroundColor Green
    Start-Process "http://127.0.0.1:$ChosenPort/"
    Start-Sleep -Seconds 2
    exit 0
}

Write-LauncherLog 'ERROR: The local bridge could not start.'
Write-Host ''
Write-Host 'TunIQ can still open in offline mode, but PC scanning and tool launching will be unavailable.' -ForegroundColor Yellow
Write-Host '[1] Open Offline   [2] Open Logs Folder   [3] Retry   [4] Exit'
$Choice = Read-Host 'Choose 1, 2, 3, or 4'

switch ($Choice) {
    '1' {
        if (Test-Path -LiteralPath $OfflineApp) { Start-Process -FilePath $OfflineApp }
        else { Write-LauncherLog 'ERROR: Offline HTML file is missing.' }
    }
    '2' { Start-Process -FilePath 'explorer.exe' -ArgumentList ('"' + $DataDir + '"') }
    '3' {
        Start-Process -FilePath 'powershell.exe' -ArgumentList "-NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$($MyInvocation.MyCommand.Path)`""
    }
    default { }
}

Read-Host 'Press Enter to close'
exit 1
