# TunIQ v1.2.2

## Foundation reliability release

- Added a first-run local profile wizard with name, email, units, and Guided/Manual/Full AI selection.
- The assistance-mode choice now appears after the splash screen and can be changed from the header or Settings.
- Added a built-in Offline AI fallback for scanner, bridge, fuel-trim, cam/idle, injector, BIN/XDF, and PCM workflow questions.
- Added explicit Bridge action status so unavailable actions explain why instead of silently doing nothing.
- Improved scanner-demo discoverability for testing without a connected vehicle.
- Added local profile editing and cross-version local-storage migration foundations.
- Preserved v1.2 project, protected-original, revision, Tune File, Scanner, Garage, Planner, and diagnostic features.
- PCM read/write/flash automation remains locked.
