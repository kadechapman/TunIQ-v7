@echo off
setlocal
cd /d "%~dp0"
title TunIQ v1.2.2
start "TunIQ" "%~dp0TunIQ_Open_Me.html"
exit /b 0
