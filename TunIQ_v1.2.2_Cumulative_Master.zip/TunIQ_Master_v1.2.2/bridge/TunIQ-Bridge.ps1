param([int]$Port = 8788)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$DataDir = Join-Path $Root 'Data'
$ToolsDir = Join-Path $Root 'Tools'
$ProjectsDir = Join-Path $Root 'TuneProjects'
$ConfigPath = Join-Path $DataDir 'bridge-config.json'
$LogPath = Join-Path $DataDir 'bridge-startup.log'
$PortPath = Join-Path $DataDir 'bridge-port.txt'
New-Item -ItemType Directory -Force -Path $DataDir,$ToolsDir,$ProjectsDir | Out-Null

function Log([string]$Message) {
  $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff') $Message"
  Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8
}
function Read-Config { if(Test-Path $ConfigPath){ try { return Get-Content $ConfigPath -Raw | ConvertFrom-Json } catch { Log "Config read failed: $($_.Exception.Message)" } }; return [pscustomobject]@{} }
function Save-Config($cfg){ $cfg | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 $ConfigPath }
function First-Existing([string[]]$paths){ foreach($p in $paths){ if($p -and (Test-Path -LiteralPath $p -PathType Leaf)){ return (Resolve-Path -LiteralPath $p).Path } }; return '' }
function Tool-Inventory {
  $cfg=Read-Config
  $pf=$env:ProgramFiles; $pfx=${env:ProgramFiles(x86)}; $local=$env:LOCALAPPDATA
  $defs=@{
    pcmhammer=@('PCM Hammer', @($cfg.pcmhammer, "$pf\PCM Hammer\PcmHammer.exe", "$pfx\PCM Hammer\PcmHammer.exe", "$local\Programs\PCM Hammer\PcmHammer.exe", "$ToolsDir\PCM Hammer\PcmHammer.exe", "$ToolsDir\PcmHammer.exe"));
    tunerpro=@('TunerPro / TunerPro RT', @($cfg.tunerpro, "$pf\TunerPro RT\TunerPro.exe", "$pfx\TunerPro RT\TunerPro.exe", "$pf\TunerPro\TunerPro.exe", "$pfx\TunerPro\TunerPro.exe", "$local\Programs\TunerPro\TunerPro.exe", "$ToolsDir\TunerPro\TunerPro.exe", "$ToolsDir\TunerPro.exe"));
    universalpatcher=@('Universal Patcher', @($cfg.universalpatcher, "$pf\Universal Patcher\UniversalPatcher.exe", "$pfx\Universal Patcher\UniversalPatcher.exe", "$local\Programs\Universal Patcher\UniversalPatcher.exe", "$ToolsDir\Universal Patcher\UniversalPatcher.exe", "$ToolsDir\UniversalPatcher.exe"))
  }
  $out=[ordered]@{}
  foreach($k in $defs.Keys){ $path=First-Existing $defs[$k][1]; $out[$k]=[ordered]@{label=$defs[$k][0];installed=[bool]$path;path=$path} }
  return $out
}
function Com-Ports { try { @(Get-CimInstance Win32_SerialPort -ErrorAction Stop | ForEach-Object { [ordered]@{device=$_.DeviceID;description=$_.Name;manufacturer=$_.Manufacturer;pnpDeviceId=$_.PNPDeviceID} }) } catch { Log "COM inventory unavailable: $($_.Exception.Message)"; @() } }
function Snapshot { [ordered]@{ok=$true;name='TunIQ Local Windows Bridge';version='1.2.1';port=$Port;platform=[Environment]::OSVersion.VersionString;arch=$env:PROCESSOR_ARCHITECTURE;runtime=$PSVersionTable.PSVersion.ToString();writeLocked=$true;capabilities=[ordered]@{inventory=$true;configurePaths=$true;launchTools=$true;openFolders=$true;readPcm=$false;writePcm=$false;flashPcm=$false;automateTunerPro=$false};comPorts=Com-Ports;tools=Tool-Inventory} }
function Json($obj){ return ($obj | ConvertTo-Json -Depth 8 -Compress) }
function Mime([string]$Path){ switch -Regex ([IO.Path]::GetExtension($Path).ToLowerInvariant()) { '\.html?$' {'text/html; charset=utf-8'} '\.css$' {'text/css; charset=utf-8'} '\.js$' {'application/javascript; charset=utf-8'} '\.json$' {'application/json; charset=utf-8'} '\.svg$' {'image/svg+xml'} '\.png$' {'image/png'} default {'application/octet-stream'} } }
function Send-Response($stream,[int]$Status,[string]$ContentType,[byte[]]$Body,[hashtable]$ExtraHeaders=$null){
  $reason = @{200='OK';204='No Content';400='Bad Request';404='Not Found';500='Internal Server Error'}[$Status]
  if(-not $reason){$reason='OK'}
  $headers = "HTTP/1.1 $Status $reason`r`nContent-Type: $ContentType`r`nContent-Length: $($Body.Length)`r`nAccess-Control-Allow-Origin: *`r`nAccess-Control-Allow-Headers: content-type`r`nAccess-Control-Allow-Methods: GET, POST, OPTIONS`r`nConnection: close`r`n"
  if($ExtraHeaders){ foreach($k in $ExtraHeaders.Keys){$headers += "$k`: $($ExtraHeaders[$k])`r`n"} }
  $headers += "`r`n"
  $hb=[Text.Encoding]::ASCII.GetBytes($headers); $stream.Write($hb,0,$hb.Length); if($Body.Length){$stream.Write($Body,0,$Body.Length)}; $stream.Flush()
}
function Send-Json($stream,$obj,[int]$status=200){ $bytes=[Text.Encoding]::UTF8.GetBytes((Json $obj)); Send-Response $stream $status 'application/json; charset=utf-8' $bytes }
function Parse-Request($client){
  $stream=$client.GetStream(); $reader=New-Object IO.StreamReader($stream,[Text.Encoding]::UTF8,$false,1024,$true)
  $line=$reader.ReadLine(); if([string]::IsNullOrWhiteSpace($line)){return $null}
  $parts=$line.Split(' '); if($parts.Count -lt 2){throw 'Malformed request'}
  $method=$parts[0].ToUpperInvariant(); $target=$parts[1]; $headers=@{}
  while($true){$h=$reader.ReadLine(); if($null -eq $h -or $h -eq ''){break}; $idx=$h.IndexOf(':'); if($idx -gt 0){$headers[$h.Substring(0,$idx).Trim().ToLowerInvariant()]=$h.Substring($idx+1).Trim()}}
  $body=''; $len=0; if($headers.ContainsKey('content-length')){[int]::TryParse($headers['content-length'],[ref]$len)|Out-Null}; if($len -gt 0){$chars=New-Object char[] $len; $read=0; while($read -lt $len){$n=$reader.Read($chars,$read,$len-$read); if($n -le 0){break}; $read+=$n}; $body=-join $chars[0..([Math]::Max(0,$read-1))]}
  return [pscustomobject]@{Method=$method;Target=$target;Headers=$headers;Body=$body;Stream=$stream}
}
function Body-Json($req){ if([string]::IsNullOrWhiteSpace($req.Body)){return [pscustomobject]@{}}; return $req.Body | ConvertFrom-Json }
function Safe-FileFromTarget([string]$target){
  $path=($target.Split('?')[0]); if($path -eq '/' -or $path -eq '/index.html' -or $path -eq '/TunIQ_Open_Me.html'){return (Join-Path $Root 'TunIQ_Open_Me.html')}
  $relative=[Uri]::UnescapeDataString($path.TrimStart('/')).Replace('/','\')
  $candidate=[IO.Path]::GetFullPath((Join-Path $Root $relative)); $rootFull=[IO.Path]::GetFullPath($Root)
  if(-not $candidate.StartsWith($rootFull,[StringComparison]::OrdinalIgnoreCase)){return $null}; return $candidate
}

Remove-Item -LiteralPath $LogPath -Force -ErrorAction SilentlyContinue
Log "Starting TunIQ bridge v1.2.1 on requested port $Port"
$listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,$Port)
try { $listener.Start(); Set-Content -LiteralPath $PortPath -Value $Port -Encoding ASCII; Log "Bridge listening at http://127.0.0.1:$Port/" } catch { Log "FATAL: $($_.Exception.ToString())"; exit 2 }

try {
  while($true){
    $client=$listener.AcceptTcpClient()
    try {
      $req=Parse-Request $client; if($null -eq $req){continue}; $path=($req.Target.Split('?')[0]).ToLowerInvariant(); Log "$($req.Method) $path"
      if($req.Method -eq 'OPTIONS'){Send-Response $req.Stream 204 'text/plain' ([byte[]]@()); continue}
      if($path -eq '/api/bridge/health'){Send-Json $req.Stream (Snapshot); continue}
      if($path -eq '/api/bridge/config' -and $req.Method -eq 'POST'){
        $b=Body-Json $req; if($b.tool -notin @('pcmhammer','tunerpro','universalpatcher')){throw 'Unknown tool key'}; $cfg=Read-Config; $cfg|Add-Member -Force NoteProperty $b.tool ([string]$b.path); Save-Config $cfg; Send-Json $req.Stream (Snapshot); continue
      }
      if($path -eq '/api/bridge/launch' -and $req.Method -eq 'POST'){
        $b=Body-Json $req; if($b.tool -notin @('pcmhammer','tunerpro','universalpatcher')){throw 'Unknown tool key'}; $snap=Snapshot; $tool=$snap.tools.($b.tool); $candidate=[string]$b.path; if(-not $candidate){$candidate=$tool.path}; if(-not (Test-Path -LiteralPath $candidate -PathType Leaf)){throw 'Executable not found. Save or paste a valid full .exe path.'}; if([IO.Path]::GetExtension($candidate).ToLowerInvariant() -ne '.exe'){throw 'Only Windows .exe files can be launched.'}; $proc=Start-Process -FilePath $candidate -PassThru; Send-Json $req.Stream ([ordered]@{ok=$true;label=$tool.label;path=$candidate;pid=$proc.Id;writeLocked=$true}); continue
      }

      if($path -eq '/api/projects/create' -and $req.Method -eq 'POST'){
        $b=Body-Json $req; $name=([string]$b.project -replace '[^a-zA-Z0-9_-]','_'); if(-not $name){throw 'Project name is required'}
        $project=Join-Path $ProjectsDir $name; @('Original Reads','Working Tunes','Definitions','Logs','Reports','Recovery') | ForEach-Object { New-Item -ItemType Directory -Force -Path (Join-Path $project $_) | Out-Null }
        if($b.manifest){$b.manifest | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 (Join-Path $project 'project-manifest.json')}
        Send-Json $req.Stream ([ordered]@{ok=$true;path=$project;writeLocked=$true}); continue
      }
      if($path -eq '/api/projects/open' -and $req.Method -eq 'POST'){
        $b=Body-Json $req; $name=([string]$b.project -replace '[^a-zA-Z0-9_-]','_'); $project=Join-Path $ProjectsDir $name; if(-not (Test-Path $project)){throw 'Project folder not found'}; Start-Process explorer.exe -ArgumentList @($project); Send-Json $req.Stream ([ordered]@{ok=$true;path=$project}); continue
      }
      if($path -eq '/api/bridge/open-folder' -and $req.Method -eq 'POST'){
        $b=Body-Json $req; $target=if($b.kind -eq 'tools'){$ToolsDir}elseif($b.kind -eq 'logs'){$DataDir}else{$Root}; Start-Process explorer.exe -ArgumentList @($target); Send-Json $req.Stream ([ordered]@{ok=$true;path=$target}); continue
      }
      $file=Safe-FileFromTarget $req.Target
      if($file -and (Test-Path -LiteralPath $file -PathType Leaf)){ $bytes=[IO.File]::ReadAllBytes($file); Send-Response $req.Stream 200 (Mime $file) $bytes; continue }
      Send-Json $req.Stream ([ordered]@{error='Not found'}) 404
    } catch { try { Log "Request error: $($_.Exception.Message)"; Send-Json $req.Stream ([ordered]@{error=$_.Exception.Message;writeLocked=$true}) 400 } catch {} }
    finally { try {$client.Close()} catch {} }
  }
} finally { $listener.Stop(); Log 'Bridge stopped' }
