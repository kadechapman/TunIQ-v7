# TunIQ v1.2.2 Cumulative Master

Extract the complete folder and double-click `OPEN_TUNIQ_WINDOWS.bat`.

v1.2.2 adds a first-run profile and assistance-mode wizard, working Guided/Manual/Full AI switching, built-in Offline AI, clearer Bridge failures, local data migration foundations, and all earlier cumulative features.

No PCM write or flash automation is enabled.
