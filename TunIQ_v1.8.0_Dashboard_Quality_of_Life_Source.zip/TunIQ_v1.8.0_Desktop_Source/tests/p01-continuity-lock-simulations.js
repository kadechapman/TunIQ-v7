const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { P01CommissioningManager, P01_BIN_SIZE } = require('../src/p01-commissioning');

function sha(file){ return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function fixture(){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'tuniq-p01-continuity-'));
  const active={id:'p01-continuity',name:'Customline',controller:'P01',os:'9379910',folder:root};
  fs.mkdirSync(path.join(root,'Imports','PCM-Hammer'),{recursive:true});
  const first=path.join(root,'Imports','PCM-Hammer','P01-Read-session-a-p01_origin_read1.bin');
  const second=path.join(root,'Imports','PCM-Hammer','P01-Read-session-b-p01_origin_read2.bin');
  fs.writeFileSync(first,Buffer.alloc(P01_BIN_SIZE,0x5a));
  fs.writeFileSync(second,Buffer.alloc(P01_BIN_SIZE,0x5a));
  const manager=new P01CommissioningManager({getActiveProject:()=>active});
  manager.recordIdentity({controller:'P01',os:'9379910',hardwareId:'4294967295',serviceNumber:'9354896'});
  return {root,active,manager,first,second};
}
function run(){
  const mainSource=fs.readFileSync(path.join(__dirname,'..','src','main.js'),'utf8');
  assert(mainSource.includes('Start was treated as Continue'));
  assert(mainSource.includes('failed extra read continuity recovery'));
  assert(mainSource.includes('p01Manager.repairVerifiedReadPair(\'Start button continuity recovery\')'));
  const f=fixture();
  const identity=f.manager.load().identity;
  // Simulate the beta.25 failure: ledger wiped while the two good files remain on disk.
  const damaged=f.manager.load();
  damaged.reads=[]; damaged.readPair=null; delete damaged.canonicalReadSha256; delete damaged.canonicalReadPath; delete damaged.dualReadVerifiedAt;
  f.manager.save(damaged);
  const repaired=f.manager.repairVerifiedReadPair('continuity simulation');
  assert.equal(repaired.repaired,true);
  assert.equal(repaired.status.dualReadVerified,true);
  assert.equal(repaired.status.canonicalReadSha256,sha(f.first));
  assert.notEqual(repaired.status.readPair.first.path,repaired.status.readPair.second.path);

  // An unnecessary third read must not replace the verified pair.
  const before=f.manager.status();
  const third=path.join(f.root,'Imports','PCM-Hammer','P01-Read-accidental-restart.bin');
  fs.writeFileSync(third,Buffer.alloc(P01_BIN_SIZE,0x33));
  const extra=f.manager.recordRead(third,{proofSource:'accidental restart read'},{id:'third-session',device:'COM3'});
  const after=f.manager.status();
  assert.equal(extra.continuityLocked,true);
  assert.equal(after.dualReadVerified,true);
  assert.equal(after.canonicalReadSha256,before.canonicalReadSha256);
  assert.equal(after.readPair.first.path,before.readPair.first.path);
  assert.equal(after.readPair.second.path,before.readPair.second.path);

  // Protected originals and stock clones must never be mistaken for independent reads.
  const clone=path.join(f.root,'Customline-Commissioning-Stock-Clone.bin');
  fs.writeFileSync(clone,Buffer.alloc(P01_BIN_SIZE,0x5a));
  const state=f.manager.load(); state.reads=[]; state.readPair=null; delete state.canonicalReadSha256; delete state.canonicalReadPath; f.manager.save(state);
  const repairedAgain=f.manager.repairVerifiedReadPair('exclude clone simulation');
  assert.equal(repairedAgain.repaired,true);
  assert(![repairedAgain.pair.first.path,repairedAgain.pair.second.path].includes(clone));
  console.log('✓ P01 continuity lock simulations: disk recovery, accidental restart, clone exclusion');
  return {passed:true,scenarios:4};
}
if(require.main===module) run();
module.exports={runP01ContinuityLockSimulations:run};
