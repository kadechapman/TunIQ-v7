const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { FlashManager } = require('../src/flash');
const { P01AutoManager } = require('../src/p01-auto');
const { rankAlternatePorts } = require('../src/com-recovery');

function project(root, id) {
  const folder = path.join(root, id);
  fs.mkdirSync(path.join(folder, 'Reports'), { recursive: true });
  return { id, name: 'Customline', folder, controller: 'P01' };
}

async function directLeaseScenario(root) {
  const active = project(root, 'direct-lease'); const events = [];
  const manager = new FlashManager({
    dataRoot: () => path.join(root, 'data-one'), getActiveProject: () => active, getToolPath: () => null,
    releasePort: async ({ port, owner, leaseId }) => { events.push({ type: 'release', port, owner, leaseId }); return { released: true, port }; },
    probePortLock: async ({ port }) => { events.push({ type: 'probe', port }); return { available: true, port }; },
    abortBridgeRequests: reason => { events.push({ type: 'abort', reason }); return { aborted: 1 }; }
  });
  const lease = await manager.preparePort({ operation: 'readProperties', values: { device: 'COM4', port: 'COM4' } });
  assert.equal(lease.port, 'COM4'); assert.equal(lease.mode, 'direct-handoff'); assert.equal(lease.lockProbeSkipped, true);
  assert(events.some(item => item.type === 'release' && item.owner === 'pcmhammer'));
  assert(events.some(item => item.type === 'abort'));
  assert(!events.some(item => item.type === 'probe'));
  assert.equal(manager.status().portOwner.owner, 'pcmhammer');
  manager.clearTransientRecoveryState('simulation complete'); assert.equal(manager.status().portOwner.owner, 'idle');
  return { name: 'direct-com-lease-avoids-double-open', port: lease.port, lockProbeSkipped: true, ownerReturnedIdle: true, passed: true };
}

async function staleBridgeClearScenario(root) {
  const active = project(root, 'stale-bridge'); let aborted = 0; const releases = [];
  const manager = new FlashManager({
    dataRoot: () => path.join(root, 'data-two'), getActiveProject: () => active, getToolPath: () => null,
    releasePort: async ({ port }) => { releases.push(port); return { released: false, reason: 'already disconnected' }; },
    abortBridgeRequests: () => ({ aborted: ++aborted })
  });
  const lease = await manager.preparePort({ operation: 'read', values: { device: 'COM5', port: 'COM5' } });
  assert.equal(lease.port, 'COM5'); assert.equal(lease.released, false); assert.equal(aborted, 1);
  const cleared = manager.clearTransientRecoveryState('simulation'); assert.equal(cleared.bridge.aborted, 2); assert.equal(manager.status().portOwner.owner, 'idle');
  const ranked = rankAlternatePorts([{ port: 'COM5', name: 'OBDLink MX+ Outgoing', recognized: true, recommended: true }, { port: 'COM6', name: 'OBDLink Incoming', recognized: true }], 'COM4');
  assert.equal(ranked[0].port, 'COM5');
  return { name: 'stale-bridge-clears-without-probing-port', port: lease.port, abortedRequests: aborted, rankedFallback: ranked[0].port, passed: true };
}

function legacyStuckResumeScenario(root) {
  const active = project(root, 'legacy-stuck');
  const manager = new P01AutoManager({ getActiveProject: () => active, appendActivity: () => {}, processInstanceId: 'beta17-process' });
  const legacy = { ...manager.blank(active), version: 3, status: 'paused', phase: 'assisted-readProperties', nextStep: 'read-properties', resumePhase: 'read-properties', blocker: 'Open normal PCM Hammer.', stop: { code: 'unsupported-cli', priorPhase: 'waiting-read-properties' } };
  fs.writeFileSync(manager.file(active), JSON.stringify(legacy, null, 2));
  const loaded = manager.load(active); assert.equal(loaded.status, 'paused'); assert.equal(loaded.phase, 'stopped-integrated-migration'); assert.equal(manager.canResume(loaded), true);
  const resumed = manager.resume(); assert.equal(resumed.status, 'running'); assert.equal(resumed.phase, 'read-properties');
  return { name: 'beta16-assisted-state-migrates-to-integrated-resume', recoveryCount: resumed.recoveryCount, phase: resumed.phase, passed: true };
}

(async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-com-recovery-'));
  try {
    const scenarios = [await directLeaseScenario(root), await staleBridgeClearScenario(root), legacyStuckResumeScenario(root)];
    const report = { type: 'tuniq-com-recovery-simulations', version: '1.7.0-beta.23', generatedAt: new Date().toISOString(), softwareSimulationOnly: true, realHardwareVerified: false, scenarios };
    const output = path.join(__dirname, '..', 'test-results', 'com-recovery-simulations.json');
    fs.mkdirSync(path.dirname(output), { recursive: true }); fs.writeFileSync(output, JSON.stringify(report, null, 2));
    scenarios.forEach((item, index) => console.log(`✓ COM recovery simulation ${index + 1}: ${item.name}`));
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
})().catch(error => { console.error(error.stack || error); process.exit(1); });
