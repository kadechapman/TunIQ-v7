const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { P01CommissioningManager, P01_BIN_SIZE } = require('../src/p01-commissioning');

function runReleasePromotionSimulations() {
  const root = path.join(__dirname, '..');
  const version = JSON.parse(fs.readFileSync(path.join(root, 'VERSION.json'), 'utf8'));
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  const main = fs.readFileSync(path.join(root, 'src', 'main.js'), 'utf8');
  const html = fs.readFileSync(path.join(root, 'src', 'renderer', 'index.html'), 'utf8');
  const renderer = fs.readFileSync(path.join(root, 'src', 'renderer', 'app.js'), 'utf8');

  assert.equal(version.version, '1.8.0');
  assert.equal(version.channel, 'stable');
  assert.equal(version.name, 'Dashboard & Quality of Life');
  assert.equal(version.release, 'Dashboard & Quality of Life');
  assert.equal(pkg.version, '1.8.0');
  assert.equal(pkg.build.appId, 'com.tuniq.desktop', 'stable promotion must preserve the installed app identity');
  assert.equal(pkg.build.nsis.deleteAppDataOnUninstall, false, 'project data must remain protected during uninstall/update');
  assert(main.includes("const APP_VERSION = '1.8.0';"));
  assert(main.includes("path.join(app.getPath('appData'), 'TunIQ')"), '1.8 must reuse the existing AppData project root');
  assert(html.includes('Continue / Finish P01 Setup'));
  assert(!html.includes('Start Guided Automatic P01 Setup'));
  assert(html.includes('id="p01AutoResume" type="button" class="ghost hidden"'), 'legacy resume control must not be a normal-path action');
  assert(renderer.includes("primary.textContent=commissioned?'✓ P01 Hardware Setup Complete':'Continue / Finish P01 Setup'"));
  assert(renderer.includes('Verified reads recovered — continuing at Test Write.'));
  assert(renderer.includes('it will not perform an actual PCM write'));
  assert(renderer.includes("commissioned?'SETUP COMPLETE':written?'WRITE COMPLETE'"));

  // Prove a beta.26-era project with good files and a damaged ledger promotes without rereading.
  const projectRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-180-promotion-'));
  try {
    const active = { id: 'customline', name: 'Customline', controller: 'P01', os: '9379910', folder: projectRoot };
    const imports = path.join(projectRoot, 'Imports', 'PCM-Hammer');
    fs.mkdirSync(imports, { recursive: true });
    const first = path.join(imports, 'P01-Read-session-a-p01_origin_read1.bin');
    const second = path.join(imports, 'P01-Read-session-b-p01_origin_read2.bin');
    fs.writeFileSync(first, Buffer.alloc(P01_BIN_SIZE, 0x71));
    fs.writeFileSync(second, Buffer.alloc(P01_BIN_SIZE, 0x71));
    const manager = new P01CommissioningManager({ getActiveProject: () => active });
    manager.recordIdentity({ controller: 'P01', os: '9379910', hardwareId: '4294967295', serviceNumber: '9354896' });
    const damaged = manager.load();
    damaged.reads = [];
    damaged.readPair = null;
    delete damaged.canonicalReadSha256;
    delete damaged.canonicalReadPath;
    delete damaged.dualReadVerifiedAt;
    manager.save(damaged);
    const recovered = manager.repairVerifiedReadPair('1.8 release promotion simulation');
    assert.equal(recovered.repaired, true);
    assert.equal(recovered.status.dualReadVerified, true);
    assert.equal(recovered.status.identity.os, '9379910');
    const extra = path.join(imports, 'P01-Read-unnecessary-third.bin');
    fs.writeFileSync(extra, Buffer.alloc(P01_BIN_SIZE, 0x19));
    const result = manager.recordRead(extra, { proofSource: '1.8 repeated click simulation' }, { id: 'extra-session', device: 'COM3' });
    assert.equal(result.continuityLocked, true);
    assert.equal(manager.status().canonicalReadSha256, recovered.status.canonicalReadSha256);
  } finally {
    fs.rmSync(projectRoot, { recursive: true, force: true });
  }

  console.log('✓ TunIQ 1.8 stable promotion: QoL release identity, data-path compatibility, single continuation action, and beta.26 evidence recovery');
  return { passed: true, scenarios: 3 };
}

if (require.main === module) runReleasePromotionSimulations();
module.exports = { runReleasePromotionSimulations };
