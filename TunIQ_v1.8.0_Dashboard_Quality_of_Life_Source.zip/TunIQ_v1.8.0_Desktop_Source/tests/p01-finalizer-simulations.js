const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { P01CommissioningManager } = require('../src/p01-commissioning');
const { buildCommissioningOnlyXdf } = require('../src/definition-pipeline');
const {
  inspectVerifiedReadPair,
  ensureProtectedOriginal,
  createOrReuseStockClone,
  buildFinalizerAudit
} = require('../src/p01-finalizer');

function hash(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function makeFixture() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-beta24-finalizer-'));
  const first = path.join(root, 'read-1.bin');
  const second = path.join(root, 'read-2.bin');
  const bytes = Buffer.alloc(524288);
  for (let i = 0; i < bytes.length; i += 4096) bytes.writeUInt32LE((i ^ 0x9379910) >>> 0, i);
  fs.writeFileSync(first, bytes); fs.writeFileSync(second, bytes);
  const sha256 = hash(first);
  const state = { readPair: { status: 'verified', first: { path: first, sha256, size: 524288 }, second: { path: second, sha256, size: 524288 } }, canonicalReadPath: first, canonicalReadSha256: sha256 };
  return { root, first, second, sha256, state };
}

function runP01FinalizerSimulations() {
  const clean = makeFixture();
  const installed = ensureProtectedOriginal({ active: { bin: clean.first }, state: clean.state, originalsFolder: path.join(clean.root, 'Originals') });
  assert.equal(installed.installed.sha256, clean.sha256);
  const clone = createOrReuseStockClone({ originalFile: installed.installed.path, revisionsFolder: path.join(clean.root, 'Revisions'), projectName: 'Customline' });
  assert.equal(clone.changedBytes, 0); assert.equal(clone.revision.sha256, clean.sha256);
  const audit = buildFinalizerAudit({ active: { id: 'customline', name: 'Customline', controller: 'P01', os: '9379910' }, identity: { controller: 'P01', os: '9379910' }, pair: installed.pair, original: clone.original, definition: { exactOs: true, commissioningOnly: true, writableTables: 0 }, clone });
  assert.equal(audit.passed, true);

  const stale = makeFixture();
  const wrong = path.join(stale.root, 'wrong.bin'); fs.writeFileSync(wrong, Buffer.alloc(524288, 0xCC));
  const repaired = ensureProtectedOriginal({ active: { bin: wrong }, state: stale.state, originalsFolder: path.join(stale.root, 'Originals') });
  assert.equal(repaired.installed.sha256, stale.sha256, 'stale active BIN must be replaced from verified reads');


  const disk = makeFixture();
  const projectFolder = path.join(disk.root, 'Project'); fs.mkdirSync(path.join(projectFolder, 'Reports'), { recursive: true });
  let active = { id: 'customline-p01', name: 'Customline', folder: projectFolder, controller: 'P01', os: '9379910', bin: disk.first, binInfo: { path: disk.first, name: path.basename(disk.first), size: 524288, sha256: disk.sha256 } };
  const manager = new P01CommissioningManager({ getActiveProject: () => active, getCalibrationWorkspace: () => null, getFlashStatus: () => ({ configured: true, backend: { official: true, major: 2 } }), appendActivity: () => {} });
  manager.recordIdentity({ controller: 'P01', os: '9379910', hardwareId: '4294967295', serviceNumber: '9354896' }, { id: 'props', device: 'COM3' });
  manager.recordRead(disk.first, { controller: 'P01', os: '9379910' }, { id: 'read-one', proofSource: 'read-one' });
  manager.recordRead(disk.second, { controller: 'P01', os: '9379910' }, { id: 'read-two', proofSource: 'read-two' });
  const xdf = path.join(projectFolder, 'TunIQ-Commissioning-Only-OS-9379910.xdf');
  buildCommissioningOnlyXdf(xdf, { os: '9379910', binSize: 524288, controller: 'P01', originalSha256: disk.sha256 });
  active = { ...active, xdf, xdfInfo: { path: xdf, name: path.basename(xdf), title: 'TunIQ Commissioning Only OS 9379910', sha256: hash(xdf), tableCount: 1, commissioningOnly: true, writableTables: 0, warnings: [] } };
  const beforeBinding = manager.status(active);
  assert.equal(beforeBinding.definition.mappingLoaded, true, 'commissioning definition must bind from disk without a Calibration workspace');
  const afterBinding = manager.confirmCommissioningDefinitionFromDisk();
  assert.equal(afterBinding.definition.confirmedExact, true);

    const corrupt = makeFixture();
  fs.writeFileSync(corrupt.second, Buffer.alloc(131072, 0xAA));
  assert.throws(() => inspectVerifiedReadPair(corrupt.state), /524,288 bytes|no longer have matching/i);

  return {
    passed: true,
    scenarios: [
      { name: 'bound-workspace-bypass-stock-clone', passed: true, sha256: clean.sha256 },
      { name: 'stale-protected-original-repair', passed: true, sha256: stale.sha256 },
      { name: 'disk-binding-without-calibration-workspace', passed: true },
      { name: 'corrupt-read-hard-stop', passed: true }
    ]
  };
}

if (require.main === module) console.log(JSON.stringify(runP01FinalizerSimulations(), null, 2));
module.exports = { runP01FinalizerSimulations };
