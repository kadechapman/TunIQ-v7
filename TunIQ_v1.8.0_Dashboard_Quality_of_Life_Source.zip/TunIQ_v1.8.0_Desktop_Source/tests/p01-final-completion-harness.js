#!/usr/bin/env node
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { FlashManager } = require('../src/flash');
const { P01CommissioningManager } = require('../src/p01-commissioning');
const { buildCommissioningOnlyXdf } = require('../src/definition-pipeline');
const { ensureProtectedOriginal, createOrReuseStockClone, buildFinalizerAudit } = require('../src/p01-finalizer');

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitFor(predicate, timeout = 10000) { const start=Date.now(); while(Date.now()-start<timeout){if(predicate())return;await delay(20)} throw new Error('Timed out waiting for final completion harness.'); }
function hash(file){return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')}
function fixture(name){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),`tuniq-beta24-${name}-`));
  const folder=path.join(root,'Project'); for(const sub of ['Originals','Definitions','Revisions','Reports'])fs.mkdirSync(path.join(folder,sub),{recursive:true});
  const one=path.join(folder,'Originals','read-one.bin'), two=path.join(folder,'Originals','read-two.bin');
  const bytes=Buffer.alloc(524288); for(let i=0;i<bytes.length;i+=4096)bytes.writeUInt32LE((i^0x9379910)>>>0,i); fs.writeFileSync(one,bytes);fs.writeFileSync(two,bytes);
  let active={id:name,name:'Customline',folder,controller:'P01',os:'9379910',bin:one,binInfo:{path:one,name:path.basename(one),size:524288,sha256:hash(one)}};
  const manager=new P01CommissioningManager({getActiveProject:()=>active,getCalibrationWorkspace:()=>null,getFlashStatus:()=>({configured:true,backend:{official:true,major:2}}),appendActivity:()=>{}});
  manager.recordIdentity({controller:'P01',os:'9379910',hardwareId:'4294967295',serviceNumber:'9354896'},{id:'props',device:'COM3'});
  manager.recordRead(one,{controller:'P01',os:'9379910'},{id:'read-one',proofSource:'read-one'}); manager.recordRead(two,{controller:'P01',os:'9379910'},{id:'read-two',proofSource:'read-two'});
  const installed=ensureProtectedOriginal({active,state:manager.load(active),originalsFolder:path.join(folder,'Originals')}); active={...active,bin:installed.installed.path,binInfo:installed.installed};
  const xdf=path.join(folder,'Definitions','TunIQ-Commissioning-Only-OS-9379910.xdf'); buildCommissioningOnlyXdf(xdf,{os:'9379910',binSize:524288,controller:'P01',originalSha256:installed.pair.sha256});
  active={...active,xdf,xdfInfo:{path:xdf,name:path.basename(xdf),title:'TunIQ Commissioning Only OS 9379910',sha256:hash(xdf),tableCount:1,commissioningOnly:true,writableTables:0,warnings:[]}};
  const bound=manager.confirmCommissioningDefinitionFromDisk(); assert.equal(bound.definition.confirmedExact,true);
  const clone=createOrReuseStockClone({originalFile:active.bin,revisionsFolder:path.join(folder,'Revisions'),projectName:'Customline'});
  const audit=buildFinalizerAudit({active,identity:manager.load(active).identity,pair:installed.pair,original:clone.original,definition:bound.definition,clone}); assert.equal(audit.passed,true);
  manager.recordValidation({targetFile:clone.revision.path,targetFileName:clone.revision.name,targetFileSha256:clone.revision.sha256,compatible:true,checksumStatus:'valid-stock-clone'});
  const executable=path.join(root,'pcmhammer-cli'); try{fs.symlinkSync(process.execPath,executable)}catch{}
  const kernels=path.join(root,'Kernels'); fs.mkdirSync(kernels,{recursive:true}); fs.writeFileSync(path.join(kernels,'Kernel-P01.bin'),Buffer.alloc(64,1)); fs.writeFileSync(path.join(kernels,'Loader-P01.bin'),Buffer.alloc(64,2));
  const mock=path.join(__dirname,'mock-pcmhammer-cli.js');
  const flash=new FlashManager({dataRoot:()=>path.join(root,'Data'),getActiveProject:()=>active,getToolPath:()=>'',getDeviceStatus:()=>({connection:{port:'COM3',voltage:13.7}}),releasePort:async()=>({released:true}),probePortLock:async()=>({available:true}),abortBridgeRequests:()=>({aborted:0}),appendActivity:()=>{},emit:()=>{},onIdentifyComplete:async()=>{},onReadComplete:async()=>{},onSessionComplete:async session=>manager.recordFlashSession(session)});
  return {root,active,manager,clone,flash,executable,mock};
}
async function configure(f,scenario='success'){process.env.PCMHAMMER_MOCK_HELP_MODE='blank';process.env.PCMHAMMER_MOCK_PROFILE='long-device';process.env.PCMHAMMER_MOCK_SCENARIO='success';await f.flash.probe({executable:f.executable,prefixArgs:[f.mock]});f.flash.saveDevice('COM3');await f.flash.start('readProperties',{});await waitFor(()=>!f.flash.session);process.env.PCMHAMMER_MOCK_SCENARIO=scenario;}
async function completeFrom48(){const f=fixture('complete-from-48');await configure(f);await f.flash.start('testWrite',{input:f.clone.revision.path,voltage:13.7});await waitFor(()=>!f.flash.session);const status=f.manager.status(f.active,f.clone.revision.path);assert(status.testWrite);return{scenario:'complete-from-48-percent',passed:true,testWrite:true,sha256:f.clone.revision.sha256};}
async function disconnectRetry(){const f=fixture('disconnect-retry');await configure(f,'disconnect');await f.flash.start('testWrite',{input:f.clone.revision.path,voltage:13.7});await waitFor(()=>!f.flash.session);assert.equal(f.flash.getHistory()[0].stopCode,'adapter-disconnected');process.env.PCMHAMMER_MOCK_SCENARIO='success';await f.flash.start('testWrite',{input:f.clone.revision.path,voltage:13.7});await waitFor(()=>!f.flash.session);assert(f.manager.status(f.active,f.clone.revision.path).testWrite);return{scenario:'test-write-disconnect-retry',passed:true,firstStop:'adapter-disconnected',retryPassed:true};}
async function restartReuse(){const f=fixture('restart-reuse');const secondClone=createOrReuseStockClone({originalFile:f.active.bin,revisionsFolder:path.join(f.active.folder,'Revisions'),projectName:'Customline'});assert.equal(secondClone.revision.path,f.clone.revision.path);assert.equal(secondClone.revision.sha256,f.clone.revision.sha256);return{scenario:'restart-reuses-deterministic-clone',passed:true,duplicateRevisionsCreated:false};}
async function runP01FinalCompletionHarness(){const reports=[];try{reports.push(await completeFrom48(),await disconnectRetry(),await restartReuse());return{passed:true,softwareSimulationOnly:true,realHardwareVerified:false,reports};}finally{delete process.env.PCMHAMMER_MOCK_HELP_MODE;delete process.env.PCMHAMMER_MOCK_PROFILE;delete process.env.PCMHAMMER_MOCK_SCENARIO;}}
if(require.main===module)runP01FinalCompletionHarness().then(result=>console.log(JSON.stringify(result,null,2))).catch(e=>{console.error(e.stack||e);process.exit(1)});
module.exports={runP01FinalCompletionHarness};
