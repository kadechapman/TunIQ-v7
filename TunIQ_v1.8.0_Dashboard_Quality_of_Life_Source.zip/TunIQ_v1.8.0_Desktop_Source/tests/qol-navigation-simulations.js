const assert = require('assert');
const fs = require('fs');
const path = require('path');

function runQolNavigationSimulations() {
  const root = path.join(__dirname, '..');
  const html = fs.readFileSync(path.join(root, 'src', 'renderer', 'index.html'), 'utf8');
  const css = fs.readFileSync(path.join(root, 'src', 'renderer', 'styles.css'), 'utf8');
  const app = fs.readFileSync(path.join(root, 'src', 'renderer', 'app.js'), 'utf8');
  const main = fs.readFileSync(path.join(root, 'src', 'main.js'), 'utf8');
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

  const sidebar = html.match(/<aside class="app-sidebar">([\s\S]*?)<\/aside>/)?.[1] || '';
  const primaryPages = [...sidebar.matchAll(/data-page="([^"]+)"/g)].map(match => match[1]);
  assert.deepEqual(primaryPages, ['dashboard','garage','workflow','flash','scanner','fullai','tunes','settings']);
  assert.equal(primaryPages.length, 8, '1.8 must expose exactly eight main workspaces');
  for (const removed of ['files','sandbox','patches','devices','revisions','ai','community','bridge','beta','diagnostics']) {
    assert(!sidebar.includes(`data-page="${removed}"`), `${removed} must be contextual, not a permanent sidebar tab`);
  }

  assert(html.includes('class="tuniq-tach-logo"'), 'tachometer-Q logo missing');
  assert(html.includes('class="tach-needle"'), 'Q needle element missing');
  assert(!html.includes('class="loadbar"'), 'old loading bar must be removed');
  assert(css.includes('@keyframes tachAccelerate'), 'accelerating splash needle animation missing');
  assert(css.includes('#splash .tach-needle{animation:tachAccelerate'), 'splash must use tach acceleration');
  assert.equal(pkg.build.win.icon, 'build/icon.ico', 'Windows installer must use the new TunIQ logo');
  assert(fs.existsSync(path.join(root, 'build', 'icon.ico')), 'Windows icon file missing');
  assert(fs.existsSync(path.join(root, 'src', 'assets', 'tuniq-icon.png')), 'runtime icon file missing');
  assert(main.includes("icon: path.join(__dirname, 'assets', 'tuniq-icon.png')"), 'desktop window must use the new TunIQ logo');


  const sectionIds = new Set([...html.matchAll(/<section id="([^"]+)"/g)].map(match => match[1]));
  const expectedPages = ['dashboard','garage','workflow','files','revisions','flash','sandbox','patches','devices','scanner','fullai','ai','tunes','community','settings','bridge','diagnostics','beta'];
  for (const page of expectedPages) assert(sectionIds.has(page), `workspace section missing: ${page}`);
  const jumpTargets = [...html.matchAll(/data-jump="([^"]+)"/g)].map(match => match[1]);
  for (const target of jumpTargets) assert(sectionIds.has(target), `broken data-jump target: ${target}`);
  assert.equal(new Set([...primaryPages,'files','revisions','sandbox','patches','devices','ai','community','bridge','diagnostics','beta']).size, 18, 'all legacy modules must remain reachable exactly once through the consolidated shell');

  assert(html.includes('id="contextDock"'), 'contextual workspace dock missing');
  assert(app.includes("workflow:['workflow','files','revisions']"), 'Project context group incomplete');
  assert(app.includes("flash:['flash','sandbox','patches','devices']"), 'Tune context group incomplete');
  assert(app.includes("fullai:['fullai','ai']"), 'AI context group incomplete');
  assert(app.includes("tunes:['tunes','community']"), 'Library context group incomplete');
  assert(app.includes("settings:['settings','bridge','diagnostics','beta']"), 'System context group incomplete');
  assert(app.includes("const primaryPage=PRIMARY_NAV_PARENT[id]||id"), 'child pages must highlight their parent workspace');
  assert(app.includes('renderContextDock(id)'), 'context dock must update during navigation');

  assert(html.includes('TUNIQ 1.8 · QUALITY OF LIFE'), 'dashboard release identity missing');
  assert((html.match(/class="command-card"/g) || []).length === 6, 'dashboard must expose six consolidated command cards');
  assert(html.includes('Everything important is surfaced here without making you dig through a wall of tabs.'));

  console.log('✓ TunIQ 1.8 QoL navigation: tachometer-Q startup, eight main workspaces, contextual tools, and consolidated dashboard');
  return { passed: true, scenarios: 4 };
}

if (require.main === module) runQolNavigationSimulations();
module.exports = { runQolNavigationSimulations };
