#!/usr/bin/env node
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { FlashManager } = require('../src/flash');
const { inferTemplates } = require('../src/pcmhammer');
const { looksLikeCliUsageOnly, hasCommunicationActivity, safeToRetryProfile } = require('../src/pcmhammer-integrated');
const { P01CommissioningManager, P01_BIN_SIZE } = require('../src/p01-commissioning');
const { P01AutoManager } = require('../src/p01-auto');

const requested = process.argv[2] || 'all';
const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-beta19-real-cli-'));
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitFor(predicate, timeout = 10000) { const start = Date.now(); while (Date.now() - start < timeout) { if (predicate()) return; await delay(20); } throw new Error('Timed out waiting for beta.23 simulation.'); }
function sha(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function writeJson(file, value) { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, JSON.stringify(value, null, 2)); }
const REAL_HELP = `PCM Hammer CLI
Usage:  pcmhammer-cli.exe <operation> [--device <id>] [--kernel-dir <path>] [--debug]
Operations:
--read [file]             Read entire PCM to file (auto-names if omitted)
--test-read               Read entire PCM without saving
--write <file>            Write entire PCM from file
--test-write <file>       Test write (no permanent changes)
--verify <file>           CRC-compare file against PCM (no erase/write)
--get-properties          Read VIN, OSID, calibration, serial, voltage
--brute-force             Search the PCM security key (algo sweep, then numeric range)
--list-devices            List available serial and J2534 devices with index numbers
Device selection:
--device <number>         Select by index shown in --list-devices
--device COM3             Select a serial port by name
--device OBDX             Select a J2534 device by partial name (case-insensitive)
(omit --device)           Auto-selects when only one device is connected
Examples:
pcmhammer-cli.exe --read backup.bin --device COM3
pcmhammer-cli.exe --test-write newcal.bin --device Mongoose
pcmhammer-cli.exe --get-properties --device COM5`;
const REAL_USAGE_FAILURE = `Error: No operation specified.
${REAL_HELP}`;

function fixture(name) {
  const root = path.join(tempRoot, name); const folder = path.join(root, 'project');
  for (const sub of ['Originals','Revisions','Reports']) fs.mkdirSync(path.join(folder, sub), { recursive: true });
  const original = path.join(folder, 'Originals', 'stock.bin'); const revision = path.join(folder, 'Revisions', 'revision.bin');
  fs.writeFileSync(original, Buffer.alloc(P01_BIN_SIZE, 0x31)); fs.writeFileSync(revision, Buffer.alloc(P01_BIN_SIZE, 0x32));
  const mock = path.join(__dirname, 'mock-pcmhammer-cli.js'); const executable = path.join(root, 'pcmhammer-cli');
  try { fs.symlinkSync(process.execPath, executable); } catch { fs.copyFileSync(process.execPath, executable); }
  const kernels = path.join(root, 'Kernels'); fs.mkdirSync(kernels, { recursive: true }); fs.writeFileSync(path.join(kernels, 'Kernel-P01.bin'), Buffer.alloc(64, 1)); fs.writeFileSync(path.join(kernels, 'Loader-P01.bin'), Buffer.alloc(64, 2));
  return { root, folder, original, revision, mock, executable, active: { id: name, name, folder, controller: 'P01', os: '12212156', bin: original } };
}
function flashManager(f, hooks = {}) {
  return new FlashManager({
    dataRoot: () => path.join(f.root, 'data'), getActiveProject: () => f.active, getToolPath: () => '',
    getDeviceStatus: () => ({ connection: { port: 'COM3', voltage: 13.8 } }),
    releasePort: async () => ({ released: true }), abortBridgeRequests: () => ({ aborted: 0 }),
    appendActivity: () => {}, emit: () => {}, onIdentifyComplete: hooks.onIdentity || (async () => {}),
    onReadComplete: hooks.onRead || (async () => {}), onSessionComplete: hooks.onComplete || (async () => {})
  });
}

async function exactObservedCliPipeline() {
  const templates = inferTemplates(REAL_HELP);
  assert.deepEqual(templates.readProperties, ['--get-properties','--device','{device}']);
  assert.deepEqual(templates.read, ['--read','{output}','--device','{device}']);
  assert.deepEqual(templates.testWrite, ['--test-write','{input}','--device','{device}']);
  assert.equal(templates.writeCalibration, null);
  assert.deepEqual(templates.writeFull, ['--write','{input}','--device','{device}']);
  const f = fixture('exact-observed-cli'); const manager = flashManager(f);
  process.env.PCMHAMMER_MOCK_PROFILE = 'real-cli'; process.env.PCMHAMMER_MOCK_HELP_MODE = 'normal'; process.env.PCMHAMMER_MOCK_SCENARIO = 'success';
  const probe = await manager.probe({ executable: f.executable, prefixArgs: [f.mock] }); manager.saveDevice('COM3');
  assert.deepEqual(probe.templates.readProperties, templates.readProperties);
  await manager.start('readProperties', {}); await waitFor(() => !manager.session);
  const properties = manager.getHistory()[0]; assert.equal(properties.state, 'complete'); assert.deepEqual(properties.args.slice(-3), ['--get-properties','--device','COM3']);
  const output = path.join(f.folder, 'Originals', 'real-cli-read.bin');
  await manager.start('read', { output }); await waitFor(() => !manager.session);
  const read = manager.getHistory()[0]; assert.equal(read.state, 'complete'); assert.deepEqual(read.args.slice(1, 5), ['--read', output, '--device','COM3']); assert(read.args.includes('--kernel-dir')); assert.equal(fs.statSync(output).size, P01_BIN_SIZE);
  await manager.start('testWrite', { input: f.revision, voltage: 13.8 }); await waitFor(() => !manager.session);
  const test = manager.getHistory()[0]; assert.equal(test.testWritePassed, true); assert.deepEqual(test.args.slice(1, 5), ['--test-write', f.revision, '--device','COM3']); assert(test.args.includes('--kernel-dir'));
  const status = manager.status(); assert.equal(status.capabilities.writeCalibration, false); assert.equal(status.capabilities.writeFull, true);
  return { scenario: 'exact-observed-cli-pipeline', passed: true, readProperties: properties.args, read: read.args, testWrite: test.args, writeCalibration: false, writeFull: true };
}

async function diagnosticConfigMigration() {
  const f = fixture('diagnostic-config-migration'); const manager = flashManager(f);
  process.env.PCMHAMMER_MOCK_PROFILE = 'real-cli'; process.env.PCMHAMMER_MOCK_HELP_MODE = 'normal'; process.env.PCMHAMMER_MOCK_SCENARIO = 'success';
  writeJson(manager.configFile(), {
    executable: f.executable, prefixArgs: [f.mock], device: 'COM3', mode: 'auto', helpText: REAL_HELP,
    integrationMode: 'help-driven', integratedProfileId: '', commandSchemaVersion: 1,
    backend: { product: 'PCM Hammer', version: '', major: 0, official: false, recognizedExecutable: true, integrationReady: true },
    templates: { readProperties: ['read-properties','--port','{device}'], read: ['read','{output}'], testWrite: ['test','{input}'], writeCalibration: null, writeFull: null, recovery: null }
  });
  const repaired = manager.getConfig();
  assert.equal(repaired.commandSchemaVersion, 2); assert.deepEqual(repaired.templates.readProperties, ['--get-properties','--device','{device}']);
  assert.deepEqual(repaired.templates.read, ['--read','{output}','--device','{device}']);
  await manager.start('readProperties', {}); await waitFor(() => !manager.session);
  const result = manager.getHistory()[0]; assert.equal(result.state, 'complete'); assert.deepEqual(result.args.slice(-3), ['--get-properties','--device','COM3']);
  assert(result.technicalDetails?.commandLine.includes('--get-properties')); assert.equal(result.technicalDetails?.exitCode, 0);
  assert.equal(looksLikeCliUsageOnly(REAL_USAGE_FAILURE), true); assert.equal(hasCommunicationActivity(REAL_USAGE_FAILURE), false);
  assert.equal(safeToRetryProfile({ operation: 'readProperties', text: REAL_USAGE_FAILURE, exitCode: 1, output: null }), true);
  return { scenario: 'diagnostic-config-migration', passed: true, commandSchemaVersion: repaired.commandSchemaVersion, args: result.args, usageOnly: true, communicationStarted: false };
}

async function savedEvidenceLedgerRepair() {
  const f = fixture('saved-evidence-ledger-repair');
  const p01 = new P01CommissioningManager({ getActiveProject: () => f.active, getCalibrationWorkspace: () => null, getFlashStatus: () => ({ configured: true, backend: { official: true, major: 2 } }), appendActivity: () => {} });
  p01.recordIdentity({ controller: 'P01', os: '12212156', hardwareId: '9386530', serviceNumber: '12200411' }, { id: 'properties-session', device: 'COM3', proofSource: 'properties.txt' });
  const read1 = path.join(f.folder, 'Originals', 'read-one.bin'); const read2 = path.join(f.folder, 'Originals', 'read-two.bin');
  fs.writeFileSync(read1, Buffer.alloc(P01_BIN_SIZE, 0x66)); fs.writeFileSync(read2, Buffer.alloc(P01_BIN_SIZE, 0x66));
  p01.recordRead(read1, {}, { id: 'read-session-1', device: 'COM3', proofSource: 'physical-read-one.bin' });
  p01.recordRead(read2, {}, { id: 'read-session-2', device: 'COM3', proofSource: 'physical-read-two.bin' });
  const damaged = p01.load(); damaged.readPair = null; damaged.readResolution = '2 matching independent reads'; p01.save(damaged);
  const before = p01.status(); assert.equal(before.dualReadVerified, false);
  const repair = p01.repairVerifiedReadPair('diagnostic state regression'); assert.equal(repair.repaired, true); assert.equal(repair.status.dualReadVerified, true); assert.equal(repair.status.canonicalReadSha256, sha(read1));
  const auto = new P01AutoManager({ getActiveProject: () => f.active, appendActivity: () => {}, processInstanceId: 'beta19-test' });
  auto.save({ ...auto.blank(f.active), status: 'running', phase: 'read-properties', nextStep: 'read-properties', completedSteps: { preflight: { at: new Date().toISOString(), evidence: {} } } });
  const reconciled = auto.reconcileEvidence(repair.status, { repairedReadPair: true });
  assert.equal(reconciled.phase, 'definition'); assert(reconciled.completedSteps['read-properties']); assert(reconciled.completedSteps['read-1']); assert(reconciled.completedSteps['read-2']);
  return { scenario: 'saved-evidence-ledger-repair', passed: true, repaired: repair.repaired, phase: reconciled.phase, completedSteps: Object.keys(reconciled.completedSteps) };
}

const scenarios = {
  'exact-observed-cli-pipeline': exactObservedCliPipeline,
  'diagnostic-config-migration': diagnosticConfigMigration,
  'saved-evidence-ledger-repair': savedEvidenceLedgerRepair
};

async function runRealCliCommandRecoverySimulations(selection = requested, options = {}) {
  try {
    const names = selection === 'all' ? Object.keys(scenarios) : [selection];
    const reports = [];
    for (const name of names) {
      if (!scenarios[name]) throw new Error(`Unknown scenario: ${name}`);
      reports.push(await scenarios[name]());
      if (!options.quiet) console.log(`✓ beta.23 real CLI recovery simulation: ${name}`);
    }
    const result = { type: 'tuniq-real-cli-command-recovery-simulations', version: '1.7.0-beta.23', generatedAt: new Date().toISOString(), softwareSimulationOnly: true, realHardwareVerified: false, reports };
    const out = path.join(__dirname, '..', 'test-results');
    fs.mkdirSync(out, { recursive: true });
    fs.writeFileSync(path.join(out, 'real-cli-command-recovery-simulations.json'), JSON.stringify(result, null, 2));
    return result;
  } finally {
    delete process.env.PCMHAMMER_MOCK_PROFILE;
    delete process.env.PCMHAMMER_MOCK_HELP_MODE;
    delete process.env.PCMHAMMER_MOCK_SCENARIO;
    delete process.env.PCMHAMMER_MOCK_READ_BYTE;
    fs.rmSync(tempRoot, { recursive: true, force: true });
  }
}

if (require.main === module) {
  runRealCliCommandRecoverySimulations().then(result => {
    console.log(JSON.stringify(result.reports, null, 2));
    console.log('All TunIQ beta.23 Real CLI Command Recovery simulations passed.');
  }).catch(error => { console.error(error.stack || error); process.exit(1); });
}

module.exports = { runRealCliCommandRecoverySimulations, REAL_HELP, REAL_USAGE_FAILURE };
