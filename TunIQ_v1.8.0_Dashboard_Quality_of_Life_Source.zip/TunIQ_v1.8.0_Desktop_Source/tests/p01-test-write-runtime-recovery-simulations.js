#!/usr/bin/env node
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { FlashManager } = require('../src/flash');
const { P01_BIN_SIZE } = require('../src/p01-commissioning');

const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-beta25-testwrite-'));
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitFor(predicate, timeout = 12000) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    if (predicate()) return;
    await delay(20);
  }
  throw new Error('Timed out waiting for beta.25 Test Write recovery simulation.');
}

function fixture(name, withKernels = true) {
  const root = path.join(tempRoot, name);
  const project = path.join(root, 'project');
  const portable = path.join(root, 'PCMHammer');
  const cliFolder = path.join(portable, 'Cli');
  const kernelFolder = path.join(portable, 'Kernels');
  for (const folder of [path.join(project, 'Originals'), path.join(project, 'Revisions'), cliFolder, kernelFolder]) fs.mkdirSync(folder, { recursive: true });
  const original = path.join(project, 'Originals', 'stock.bin');
  const revision = path.join(project, 'Revisions', 'stock-clone.bin');
  fs.writeFileSync(original, Buffer.alloc(P01_BIN_SIZE, 0x31));
  fs.copyFileSync(original, revision);
  if (withKernels) {
    fs.writeFileSync(path.join(kernelFolder, 'Kernel-P01.bin'), Buffer.alloc(128, 1));
    fs.writeFileSync(path.join(kernelFolder, 'Loader-P01.bin'), Buffer.alloc(128, 2));
  }
  const executable = path.join(cliFolder, 'pcmhammer-cli');
  try { fs.symlinkSync(process.execPath, executable); } catch {}
  return {
    root, project, portable, cliFolder, kernelFolder, original, revision, executable,
    mock: path.join(__dirname, 'mock-pcmhammer-cli.js'),
    active: { id: name, name: 'Customline', folder: project, controller: 'P01', os: '9379910', bin: original }
  };
}

function managerFor(f, options = {}) {
  const ownership = options.ownership || [];
  return new FlashManager({
    dataRoot: () => path.join(f.root, 'data'),
    getActiveProject: () => f.active,
    getToolPath: () => f.portable,
    getDeviceStatus: () => ({ connection: { port: 'COM3', voltage: 13.8 } }),
    releasePort: async payload => { ownership.push({ type: 'release', port: payload.port }); return { released: true, port: payload.port, owner: 'TunIQ' }; },
    abortBridgeRequests: reason => { ownership.push({ type: 'abort', reason }); return { aborted: 1 }; },
    findAlternatePorts: async () => options.alternates || [],
    appendActivity: () => {}, emit: () => {}, onSessionComplete: options.onComplete || (async () => {})
  });
}

async function configure(manager, f) {
  process.env.PCMHAMMER_MOCK_PROFILE = 'real-cli';
  process.env.PCMHAMMER_MOCK_HELP_MODE = 'normal';
  process.env.PCMHAMMER_MOCK_REQUIRE_KERNEL = '1';
  process.env.PCMHAMMER_MOCK_SCENARIO = 'success';
  const probe = await manager.probe({ executable: f.executable, prefixArgs: [f.mock] });
  manager.saveDevice('COM3');
  return probe;
}

async function timeoutSwitchesToOutgoingPort() {
  const f = fixture('timeout-switches-to-outgoing');
  const ownership = [];
  const completed = [];
  const manager = managerFor(f, {
    ownership,
    alternates: [],
    onComplete: async session => completed.push(session)
  });
  const probe = await configure(manager, f);
  assert.equal(path.resolve(probe.kernel.folder), path.resolve(f.kernelFolder));
  process.env.PCMHAMMER_MOCK_SCENARIO = 'open-timeout';
  process.env.PCMHAMMER_MOCK_TIMEOUT_PORT = 'COM3';
  process.env.PCMHAMMER_MOCK_DEVICE_LIST = '0: OBDLink MX+ Incoming (COM3)\n1: OBDLink MX+ Outgoing (COM4)';
  await manager.start('testWrite', { input: f.revision, voltage: 13.8 });
  await waitFor(() => !manager.session);
  const result = manager.getHistory()[0];
  assert.equal(result.state, 'complete');
  assert.equal(result.testWritePassed, true);
  assert.equal(result.device, 'COM4');
  assert(result.args.includes('--kernel-dir'));
  assert.equal(path.resolve(result.args[result.args.indexOf('--kernel-dir') + 1]), path.resolve(f.kernelFolder));
  assert.deepEqual(result.deviceAttempts.map(item => item.device), ['COM3', 'COM3', 'COM4']);
  assert(ownership.filter(item => item.type === 'release').some(item => item.port === 'COM4'));
  assert.equal(manager.getConfig().device, 'COM4');
  return { scenario: 'timeout-switches-to-outgoing-port', passed: true, devices: result.deviceAttempts.map(item => item.device), kernelDir: result.kernelDir, testWrite: result.testWritePassed };
}

async function timeoutStopsWithExactCause() {
  const f = fixture('timeout-exact-cause');
  const manager = managerFor(f, { alternates: [] });
  await configure(manager, f);
  process.env.PCMHAMMER_MOCK_SCENARIO = 'open-timeout';
  process.env.PCMHAMMER_MOCK_TIMEOUT_PORT = 'COM3';
  process.env.PCMHAMMER_MOCK_DEVICE_LIST = '0: OBDLink MX+ Incoming (COM3)';
  await manager.start('testWrite', { input: f.revision, voltage: 13.8 });
  await waitFor(() => !manager.session);
  const result = manager.getHistory()[0];
  assert.equal(result.state, 'failed');
  assert.equal(result.stopCode, 'adapter-open-timeout');
  assert.match(result.error, /could not open COM3|openable outgoing OBDLink port/i);
  assert.equal(result.deviceAttempts.length, 2, 'same COM port must retry only once');
  assert(result.technicalDetails.kernelDir);
  return { scenario: 'timeout-stops-with-exact-cause', passed: true, stopCode: result.stopCode, attempts: result.deviceAttempts.length, error: result.error };
}

async function missingKernelsStopsBeforeLaunch() {
  const f = fixture('missing-kernels', false);
  const manager = managerFor(f, { alternates: [] });
  process.env.PCMHAMMER_MOCK_PROFILE = 'real-cli';
  process.env.PCMHAMMER_MOCK_HELP_MODE = 'normal';
  process.env.PCMHAMMER_MOCK_REQUIRE_KERNEL = '1';
  process.env.PCMHAMMER_MOCK_SCENARIO = 'success';
  await manager.probe({ executable: f.executable, prefixArgs: [f.mock] });
  manager.saveDevice('COM3');
  await assert.rejects(
    () => manager.start('testWrite', { input: f.revision, voltage: 13.8 }),
    error => error && error.code === 'kernel-files-missing' && /complete PCM Hammer package/i.test(error.message)
  );
  assert.equal(manager.getHistory().length, 0, 'PCM Hammer must not launch without required kernel files');
  return { scenario: 'missing-kernels-stops-before-launch', passed: true, stopCode: 'kernel-files-missing', launched: false };
}

async function runP01TestWriteRuntimeRecoverySimulations() {
  try {
    const reports = [];
    reports.push(await timeoutSwitchesToOutgoingPort());
    reports.push(await timeoutStopsWithExactCause());
    reports.push(await missingKernelsStopsBeforeLaunch());
    const out = path.join(__dirname, '..', 'test-results');
    fs.mkdirSync(out, { recursive: true });
    fs.writeFileSync(path.join(out, 'p01-test-write-runtime-recovery-simulations.json'), JSON.stringify({ generatedAt: new Date().toISOString(), reports }, null, 2));
    return reports;
  } finally {
    delete process.env.PCMHAMMER_MOCK_PROFILE;
    delete process.env.PCMHAMMER_MOCK_HELP_MODE;
    delete process.env.PCMHAMMER_MOCK_REQUIRE_KERNEL;
    delete process.env.PCMHAMMER_MOCK_SCENARIO;
    delete process.env.PCMHAMMER_MOCK_TIMEOUT_PORT;
    delete process.env.PCMHAMMER_MOCK_DEVICE_LIST;
    fs.rmSync(tempRoot, { recursive: true, force: true });
  }
}

module.exports = { runP01TestWriteRuntimeRecoverySimulations };

if (require.main === module) {
  runP01TestWriteRuntimeRecoverySimulations().then(reports => {
    for (const report of reports) console.log(`✓ beta.25 Test Write runtime recovery: ${report.scenario}`);
    console.log(JSON.stringify(reports, null, 2));
  }).catch(error => { console.error(error.stack || error); process.exit(1); });
}
