# Automatic Commissioning Definition Binding

## Reproduced beta.21 failure

Beta.21 generated and installed `TunIQ-Commissioning-Only-OS-9379910.xdf`, but the calibration workspace could be bound to a stale SHA-256 value cached in `active.binInfo`. P01 confirmation correctly compared the workspace against the two-read canonical SHA-256 and rejected the mismatch with a misleading request to load the files manually.

## Beta.22 recovery

1. Read the protected BIN and XDF fingerprints directly from disk.
2. Refresh stale project metadata.
3. Build a new project-scoped XDF workspace with the real fingerprints.
4. Confirm the exact OS automatically because TunIQ created the read-only definition itself.
5. If a beta.21 stale workspace survives, archive it and rebuild once.
6. Create a byte-for-byte stock clone and validate zero changed bytes.
7. Continue to integrated PCM Hammer Test Write.

No tuning address, equation, checksum definition, or writable table is invented.
