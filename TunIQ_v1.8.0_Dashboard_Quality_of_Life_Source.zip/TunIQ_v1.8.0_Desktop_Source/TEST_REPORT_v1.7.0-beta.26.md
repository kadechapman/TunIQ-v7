# TunIQ v1.7.0-beta.26 Test Report

## Purpose

Fix the observed failure where pressing **Start Guided Automatic P01 Setup** after completed P01 commissioning evidence restarted Read Properties and Full Read 1, then failed without a BIN and left the workflow regressed.

## Changes verified

- Start is treated as Continue whenever the active project already contains P01 identity, read, definition, revision, or Test Write evidence.
- Existing completion data is merged with current authorization/device input rather than replaced.
- Two matching 524,288-byte reads can be reconstructed from clearly named PCM Hammer read files even when an older JSON ledger was cleared.
- Protected originals, revisions, stock clones, exports, and tuned BINs are excluded from independent-read recovery.
- A verified read pair is continuity-locked. An accidental third read, whether successful or failed, cannot replace or erase it.
- A failed unnecessary read advances using the preserved verified pair instead of returning the workflow to Read 1.
- The finalizer and Test Write recovery from beta.24/beta.25 remain intact.

## Results

- Syntax validation: PASS
- Automated suite: 32/32 groups PASS
- P01 continuity-lock scenarios: 4/4 PASS
- Complete 48%-to-Test-Write harness: 3/3 PASS
- Test Write runtime recovery scenarios: 3/3 PASS
- P01 hardware recovery simulations: 3/3 PASS

## Hardware boundary

This release was tested in software simulations and clean archive extraction. A physical Windows Bluetooth stack, OBDLink MX+, COM port, vehicle, P01 PCM, and real Test Write cannot be proven in this build environment. The specific software regression reported by the user is covered by dedicated continuity tests.
