# Developer Notes — v1.7.0-beta.23

## Primary fix

- Added `P01CommissioningManager.verifiedOriginalBinding()`.
- Added `P01CommissioningManager.reconcileBoundCommissioningDefinition()`.
- Definition binding can use current workspace `binding` hashes when beta.21/beta.22 legacy `source*Sha256` fields are stale.
- Commissioning-only reconciliation requires zero writable tables and a protected BIN matching the verified read pair.
- Added `reconcileActiveCommissioningWorkspace()` in the main process.
- Reconciliation runs at startup, through `workspace:reconcile`, and before P01 Resume.
- Added preload and renderer contracts for working backend Refresh.
- Failed definition states are rebuilt at `create-revision`; completed read steps are preserved.

## Regression coverage

`tests/workspace-state-reconciliation-simulations.js` covers:

1. Stale canonical read hash with a valid verified pair and bound workspace.
2. Stale legacy workspace source fields with current binding fingerprints.
3. A beta.22 `unexpected-error` state repaired into a resumable `create-revision` step.
