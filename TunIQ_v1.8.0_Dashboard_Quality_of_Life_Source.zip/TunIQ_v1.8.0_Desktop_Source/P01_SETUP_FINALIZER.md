# P01 Setup Finalizer

The beta.24 finalizer intentionally bypasses the Calibration workspace for commissioning-only setup. A read-only commissioning XDF has zero writable addresses, so the safe proof is the exact XDF file, exact OS, two matching P01 reads, protected-original fingerprint, and unchanged stock clone.

## Automatic repair

- Rebuilds the verified read pair from saved evidence when necessary.
- Rejects missing, duplicate, partial, changed, or mismatched read files.
- Reinstalls the protected original from the verified pair when a stale project path or fingerprint exists.
- Regenerates the exact-OS commissioning definition when missing.
- Confirms the definition from disk without renderer or workspace-cache state.
- Reuses one deterministic stock clone instead of creating duplicate revisions on every retry.
- Produces a finalizer audit JSON before Test Write.

## Remaining physical boundary

The final software action is PCM Hammer Test Write. Hardware communication, ignition state, adapter stability, and vehicle voltage cannot be proven in a Linux simulation environment.
