# TunIQ v1.7.0-beta.26 — P01 Continuity Lock

This release fixes the accidental Guided Setup restart that returned a completed Customline project to Full Read 1 of 2. It preserves durable evidence and continues from the furthest verified step.
