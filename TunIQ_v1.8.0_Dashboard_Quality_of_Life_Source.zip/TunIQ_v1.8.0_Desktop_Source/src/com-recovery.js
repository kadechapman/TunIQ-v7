const RECOVERABLE_P01_CODES = new Set([
  'lock-probe-timeout', 'adapter-locked', 'adapter-disconnected', 'bridge-timeout',
  'pcmhammer-start-failed', 'operation-running', 'cli-launch-failed', 'cli-not-found',
  'cli-operation-unavailable', 'unsupported-cli', 'app-restarted-during-step',
  'adapter-open-timeout', 'kernel-files-missing'
]);

function clean(value, max = 1000) {
  return String(value ?? '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max);
}

function bridgeError(error, action = '', port = '') {
  const message = clean(error?.message || error || 'Windows serial bridge request failed.');
  const explicit = clean(error?.code || '', 120);
  let code = explicit || 'bridge-request-failed';
  if (/timed out/i.test(message)) code = String(action).toLowerCase() === 'lockprobe' ? 'lock-probe-timeout' : 'bridge-timeout';
  else if (/in use|access.*denied|unauthorized|cannot open|busy|locked/i.test(message)) code = 'adapter-locked';
  return {
    code,
    action: clean(action, 80),
    port: clean(port, 30),
    message,
    timedOut: code === 'lock-probe-timeout' || code === 'bridge-timeout',
    recoverable: ['lock-probe-timeout', 'bridge-timeout', 'adapter-locked'].includes(code)
  };
}

function isRecoverableP01Stop(code) { return RECOVERABLE_P01_CODES.has(clean(code, 120)); }

function normalizeP01RecoveryState(input = {}, processInstanceId = '') {
  const state = { ...input, completedSteps: { ...(input.completedSteps || {}) } };
  const stopCode = clean(state.stop?.code || '', 120);
  const stoppedPhase = /^stopped-|^assisted-/.test(String(state.phase || ''));
  const recoverable = isRecoverableP01Stop(stopCode) || stoppedPhase;
  if ((state.status === 'running' && state.stop) || (['failed', 'cancelled'].includes(state.status) && recoverable)) {
    state.status = 'paused';
  }
  if (state.status === 'paused' || recoverable) {
    state.resumePhase = state.resumePhase || state.nextStep || state.stop?.resumePhase || state.stop?.priorPhase || 'preflight';
    state.nextStep = state.resumePhase;
  }
  if (processInstanceId) state.runInstanceId = processInstanceId;
  return state;
}

function rankAlternatePorts(devices = [], currentPort = '') {
  const current = clean(currentPort, 30).toUpperCase();
  return (Array.isArray(devices) ? devices : [])
    .filter(item => item && item.port && String(item.port).toUpperCase() !== current && !item.demo)
    .map(item => {
      const text = `${item.name || ''} ${item.manufacturer || ''} ${item.hardwareId || ''} ${item.transport || ''}`.toLowerCase();
      let score = 0;
      if (/obdlink|scantool|stn11|stn21/.test(text)) score += 80;
      if (item.recommended) score += 35;
      if (item.recognized) score += 20;
      if (/bluetooth/.test(text)) score += 10;
      if (/outgoing|client/.test(text)) score += 20;
      if (/incoming|server/.test(text)) score -= 40;
      return { ...item, recoveryScore: score };
    })
    .filter(item => item.recoveryScore >= 20)
    .sort((a, b) => b.recoveryScore - a.recoveryScore || String(a.port).localeCompare(String(b.port), undefined, { numeric: true }));
}

module.exports = { RECOVERABLE_P01_CODES, bridgeError, isRecoverableP01Stop, normalizeP01RecoveryState, rankAlternatePorts };
