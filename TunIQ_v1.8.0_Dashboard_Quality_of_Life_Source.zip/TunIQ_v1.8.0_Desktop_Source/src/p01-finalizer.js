const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const P01_BIN_SIZE = 512 * 1024;

function sha256(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

function fileInfo(file) {
  if (!file || !fs.existsSync(file)) return null;
  const stat = fs.statSync(file);
  if (!stat.isFile()) return null;
  return { path: file, name: path.basename(file), size: stat.size, sha256: sha256(file), modifiedAt: stat.mtime.toISOString() };
}

function inspectVerifiedReadPair(state = {}) {
  const pair = state.readPair || null;
  const first = pair?.first || null;
  const second = pair?.second || null;
  if (pair?.status !== 'verified' || !first || !second) throw new Error('Two verified P01 reads are required.');
  const firstActual = fileInfo(first.path);
  const secondActual = fileInfo(second.path);
  if (!firstActual || !secondActual) throw new Error('One or both verified P01 read files are missing from disk.');
  if (path.resolve(firstActual.path).toLowerCase() === path.resolve(secondActual.path).toLowerCase()) throw new Error('The two P01 reads must be separate files.');
  if (firstActual.size !== P01_BIN_SIZE || secondActual.size !== P01_BIN_SIZE) throw new Error('Each verified P01 read must be exactly 524,288 bytes.');
  if (firstActual.sha256 !== secondActual.sha256) throw new Error('The two verified P01 reads no longer have matching SHA-256 hashes.');
  if (first.sha256 && first.sha256 !== firstActual.sha256) throw new Error('The first saved read fingerprint no longer matches the file on disk.');
  if (second.sha256 && second.sha256 !== secondActual.sha256) throw new Error('The second saved read fingerprint no longer matches the file on disk.');
  return { first: firstActual, second: secondActual, sha256: firstActual.sha256, size: P01_BIN_SIZE };
}

function selectVerifiedOriginal(active = {}, state = {}, pair = inspectVerifiedReadPair(state)) {
  const candidates = [active.bin, state.canonicalReadPath, pair.first.path, pair.second.path].filter(Boolean);
  for (const candidate of candidates) {
    const info = fileInfo(candidate);
    if (info && info.size === P01_BIN_SIZE && info.sha256 === pair.sha256) return info;
  }
  throw new Error('No protected-original file matches the two verified P01 reads.');
}

function sanitizeName(value) {
  return String(value || 'P01').replace(/[^a-zA-Z0-9_-]+/g, '-').replace(/^-+|-+$/g, '') || 'P01';
}

function ensureProtectedOriginal({ active, state, originalsFolder }) {
  const pair = inspectVerifiedReadPair(state);
  const selected = selectVerifiedOriginal(active, state, pair);
  fs.mkdirSync(originalsFolder, { recursive: true });
  const destination = path.join(originalsFolder, `P01-Verified-Original-${pair.sha256.slice(0, 16)}.bin`);
  const current = fileInfo(destination);
  if (!current) fs.copyFileSync(selected.path, destination);
  const installed = fileInfo(destination);
  if (!installed || installed.size !== P01_BIN_SIZE || installed.sha256 !== pair.sha256) throw new Error('TunIQ could not install a protected original matching the verified read pair.');
  return { pair, source: selected, installed };
}

function createOrReuseStockClone({ originalFile, revisionsFolder, projectName }) {
  const original = fileInfo(originalFile);
  if (!original || original.size !== P01_BIN_SIZE) throw new Error('A verified 524,288-byte original is required before creating the stock clone.');
  fs.mkdirSync(revisionsFolder, { recursive: true });
  const destination = path.join(revisionsFolder, `${sanitizeName(projectName)}-Commissioning-Stock-Clone-${original.sha256.slice(0, 16)}.bin`);
  const existing = fileInfo(destination);
  if (!existing) fs.copyFileSync(original.path, destination);
  const revision = fileInfo(destination);
  if (!revision || revision.size !== original.size || revision.sha256 !== original.sha256) {
    try { fs.unlinkSync(destination); } catch {}
    throw new Error('The commissioning stock clone did not match the verified original.');
  }
  const originalBytes = fs.readFileSync(original.path);
  const revisionBytes = fs.readFileSync(revision.path);
  if (!originalBytes.equals(revisionBytes)) throw new Error('The commissioning stock clone contains changed bytes.');
  return { original, revision, changedBytes: 0, compatibleLayout: true };
}

function buildFinalizerAudit({ active, identity, pair, original, definition, clone }) {
  const checks = {
    controllerP01: String(identity?.controller || active?.controller || '').toUpperCase() === 'P01',
    operatingSystemKnown: Boolean(identity?.os || active?.os),
    twoDistinctReads: Boolean(pair?.first?.path && pair?.second?.path && path.resolve(pair.first.path).toLowerCase() !== path.resolve(pair.second.path).toLowerCase()),
    readsExactly524288: pair?.first?.size === P01_BIN_SIZE && pair?.second?.size === P01_BIN_SIZE,
    readsMatchSha256: Boolean(pair?.sha256 && pair.first.sha256 === pair.second.sha256),
    protectedOriginalMatchesReads: Boolean(original?.sha256 && original.sha256 === pair?.sha256 && original.size === P01_BIN_SIZE),
    commissioningDefinitionExactOs: Boolean(definition?.exactOs && definition?.commissioningOnly),
    definitionReadOnly: Number(definition?.writableTables || 0) === 0,
    stockCloneUnchanged: Boolean(clone?.revision?.sha256 && clone.revision.sha256 === original?.sha256 && clone.changedBytes === 0),
    stockCloneExactly524288: clone?.revision?.size === P01_BIN_SIZE
  };
  const failures = Object.entries(checks).filter(([, passed]) => !passed).map(([name]) => name);
  return { type: 'p01-setup-finalizer-audit', version: 1, projectId: active?.id || null, projectName: active?.name || '', checks, passed: failures.length === 0, failures, at: new Date().toISOString() };
}

module.exports = {
  P01_BIN_SIZE,
  fileInfo,
  inspectVerifiedReadPair,
  selectVerifiedOriginal,
  ensureProtectedOriginal,
  createOrReuseStockClone,
  buildFinalizerAudit
};
