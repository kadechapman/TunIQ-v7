const fs = require('fs');
const path = require('path');

const INTEGRATED_PROFILES = Object.freeze([
  {
    id: 'official-2x-cli-flags-device', label: 'PCM Hammer 2.x CLI operation flags (--device)',
    templates: {
      readProperties: ['--get-properties', '--device', '{device}'],
      read: ['--read', '{output}', '--device', '{device}'],
      testWrite: ['--test-write', '{input}', '--device', '{device}'],
      writeCalibration: null,
      writeFull: ['--write', '{input}', '--device', '{device}'],
      recovery: null
    }
  },
  {
    id: 'official-2x-long-port', label: 'PCM Hammer 2.x long options (--port)',
    templates: {
      readProperties: ['read-properties', '--port', '{device}'],
      read: ['read-full', '--port', '{device}', '--output', '{output}'],
      testWrite: ['test-write', '--port', '{device}', '--input', '{input}'],
      writeCalibration: ['write-calibration', '--port', '{device}', '--input', '{input}'],
      writeFull: ['write-full', '--port', '{device}', '--input', '{input}'],
      recovery: ['recovery', '--port', '{device}', '--input', '{input}']
    }
  },
  {
    id: 'official-2x-long-device', label: 'PCM Hammer 2.x long options (--device)',
    templates: {
      readProperties: ['read-properties', '--device', '{device}'],
      read: ['read-full', '--device', '{device}', '--output', '{output}'],
      testWrite: ['test-write', '--device', '{device}', '--input', '{input}'],
      writeCalibration: ['write-calibration', '--device', '{device}', '--input', '{input}'],
      writeFull: ['write-full', '--device', '{device}', '--input', '{input}'],
      recovery: ['recovery', '--device', '{device}', '--input', '{input}']
    }
  },
  {
    id: 'official-2x-long-interface', label: 'PCM Hammer 2.x long options (--interface)',
    templates: {
      readProperties: ['read-properties', '--interface', '{device}'],
      read: ['read-full', '--interface', '{device}', '--output', '{output}'],
      testWrite: ['test-write', '--interface', '{device}', '--input', '{input}'],
      writeCalibration: ['write-calibration', '--interface', '{device}', '--input', '{input}'],
      writeFull: ['write-full', '--interface', '{device}', '--input', '{input}'],
      recovery: ['recovery', '--interface', '{device}', '--input', '{input}']
    }
  },
  {
    id: 'official-2x-short', label: 'PCM Hammer 2.x short options',
    templates: {
      readProperties: ['read-properties', '-p', '{device}'],
      read: ['read-full', '-p', '{device}', '-o', '{output}'],
      testWrite: ['test-write', '-p', '{device}', '-i', '{input}'],
      writeCalibration: ['write-calibration', '-p', '{device}', '-i', '{input}'],
      writeFull: ['write-full', '-p', '{device}', '-i', '{input}'],
      recovery: ['recovery', '-p', '{device}', '-i', '{input}']
    }
  },
  {
    id: 'official-2x-flags', label: 'PCM Hammer 2.x operation flags',
    templates: {
      readProperties: ['--read-properties', '--port', '{device}'],
      read: ['--read-full', '--port', '{device}', '--output', '{output}'],
      testWrite: ['--test-write', '--port', '{device}', '--input', '{input}'],
      writeCalibration: ['--write-calibration', '--port', '{device}', '--input', '{input}'],
      writeFull: ['--write-full', '--port', '{device}', '--input', '{input}'],
      recovery: ['--recovery', '--port', '{device}', '--input', '{input}']
    }
  },
  {
    id: 'official-2x-positional', label: 'PCM Hammer 2.x positional arguments',
    templates: {
      readProperties: ['read-properties', '{device}'],
      read: ['read-full', '{device}', '{output}'],
      testWrite: ['test-write', '{device}', '{input}'],
      writeCalibration: ['write-calibration', '{device}', '{input}'],
      writeFull: ['write-full', '{device}', '{input}'],
      recovery: ['recovery', '{device}', '{input}']
    }
  }
]);

function profileById(id) { return INTEGRATED_PROFILES.find(profile => profile.id === id) || null; }
function profileMatchingTemplate(operation, template) {
  const encoded = JSON.stringify(Array.isArray(template) ? template : []);
  return INTEGRATED_PROFILES.find(profile => JSON.stringify(profile.templates?.[operation] || null) === encoded) || null;
}
function isRecognizedPcmHammerExecutable(executable = '', backend = null) {
  const name = path.basename(String(executable || '')).toLowerCase();
  return /pcm\s*hammer|pcmhammer/.test(String(backend?.product || '')) || /pcmhammer.*(?:cli|console)|(?:cli|console).*pcmhammer/.test(name);
}
function looksLikeCliUsageOnly(text = '') {
  const source = String(text || '');
  const hasUsage = /\bUsage\s*:/i.test(source) && /\bOperations\s*:/i.test(source);
  const explicitSyntaxStop = /(?:No operation specified|unknown|invalid|unrecognized|unsupported)\s+(?:command|option|argument|verb)?/i.test(source)
    || /(?:required|missing)\s+(?:option|argument|operation)/i.test(source);
  const runtimeProof = /(?:Opening\s+(?:serial\s+)?port\s+COM\d+|Connected\s+to\s+(?:PCM|ECM|device)|Using\s+(?:device|interface)\s*[:=]|Battery\s+Voltage\s+(?:is\s*)?:|Voltage\s*:\s*\d+(?:\.\d+)?\s*V|Reading\s+block\s+\d+|Uploading\s+kernel|Unlock(?:ed|ing)\s+(?:PCM|ECM)|Erasing\s+flash|Writing\s+flash)/i.test(source);
  return hasUsage && (explicitSyntaxStop || !runtimeProof) && !runtimeProof;
}
function isSyntaxFailure(text = '', exitCode = null) {
  const source = String(text || '');
  if (looksLikeCliUsageOnly(source)) return true;
  if (/(?:no\s+operation\s+specified|unknown|invalid|unrecognized|unsupported)\s+(?:command|option|argument|verb)|no\s+such\s+(?:command|option)|unexpected\s+(?:argument|option)|required\s+(?:option|argument|operation).*missing|usage\s*:/i.test(source)) return true;
  return Number(exitCode) !== 0 && /(?:help|usage|command line|arguments?|options?)/i.test(source) && !hasCommunicationActivity(source);
}
function hasCommunicationActivity(text = '') {
  const source = String(text || '');
  if (looksLikeCliUsageOnly(source)) return false;
  if (/(?:could\s+not\s+open\s+the\s+selected\s+device[^\n]*timed\s+out|timed\s+out\s+trying\s+to\s+open\s+(?:serial\s+)?port|access\s+(?:to\s+the\s+port\s+)?is\s+denied[^\n]*another\s+program)/i.test(source)) return false;
  return /(?:Opening\s+(?:serial\s+)?port\s+COM\d+|Opened\s+(?:serial\s+)?port\s+COM\d+|Connecting\s+to\s+(?:PCM|ECM|device)|Connected\s+to\s+(?:PCM|ECM|device)|Using\s+(?:device|interface)\s*[:=]|Selected\s+(?:device|interface)\s*[:=]|Battery\s+Voltage\s+(?:is\s*)?:|Voltage\s*:\s*\d+(?:\.\d+)?\s*V|VIN\s*:\s*[A-HJ-NPR-Z0-9]{17}|OSID\s*:\s*\d+|Hardware\s+ID\s*:|Service\s+(?:No|Number)\s*:|Controller\s*:\s*(?:P\d+|E\d+)|Reading\s+block\s+\d+|Reading\s+(?:entire\s+)?PCM|Uploading\s+kernel|Kernel\s+(?:uploaded|running)|Unlock(?:ed|ing)\s+(?:PCM|ECM)|Security\s+key\s+(?:accepted|unlocked)|Erasing\s+flash|Writing\s+flash|Programming\s+flash|Verification\s+(?:passed|started))/i.test(source);
}
function outputWasCreated(file) {
  try { return Boolean(file && fs.statSync(file).isFile() && fs.statSync(file).size > 0); } catch { return false; }
}
function safeToRetryProfile({ operation, text, exitCode, output }) {
  if (!['readProperties', 'read'].includes(String(operation || ''))) return false;
  if (!isSyntaxFailure(text, exitCode)) return false;
  if (hasCommunicationActivity(text)) return false;
  if (outputWasCreated(output)) return false;
  return true;
}
function profilesForOperation(operation, cachedProfileId = '', customTemplate = null) {
  const configured = customTemplate ? [{ id: 'configured-template', label: 'Configured command template', templates: { [operation]: customTemplate } }] : [];
  const cached = profileById(cachedProfileId);
  if (cached?.templates?.[operation]) return [...configured, ...(configured.some(item => JSON.stringify(item.templates[operation]) === JSON.stringify(cached.templates[operation])) ? [] : [cached])];
  const discovered = INTEGRATED_PROFILES.filter(profile => profile.templates?.[operation]);
  if (!configured.length) return discovered;
  if (!['readProperties', 'read'].includes(String(operation || ''))) return configured;
  return [...configured, ...discovered.filter(profile => JSON.stringify(profile.templates[operation]) !== JSON.stringify(customTemplate))];
}
function profileCapabilities(profileId) {
  const profile = profileById(profileId);
  return Object.fromEntries(['readProperties','read','testWrite','writeCalibration','writeFull','recovery'].map(operation => [operation, Boolean(profile?.templates?.[operation])]));
}

module.exports = {
  INTEGRATED_PROFILES,
  profileById,
  profileMatchingTemplate,
  profilesForOperation,
  profileCapabilities,
  isRecognizedPcmHammerExecutable,
  isSyntaxFailure,
  hasCommunicationActivity,
  looksLikeCliUsageOnly,
  safeToRetryProfile,
  outputWasCreated
};
