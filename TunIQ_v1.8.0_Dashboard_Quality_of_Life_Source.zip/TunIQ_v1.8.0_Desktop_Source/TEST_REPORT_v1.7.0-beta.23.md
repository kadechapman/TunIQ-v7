# TunIQ v1.7.0-beta.23 Test Report

## Release

- Version: `1.7.0-beta.23`
- Name: **Workspace State Reconciliation**
- Base: TunIQ v1.7.0-beta.22 Automatic Commissioning Definition Binding
- Verification environment: Linux source/test environment with software mocks and simulations
- Real hardware verified: **No**

## User-observed regression reproduced

The active Calibration page showed the protected original and TunIQ commissioning-only OS 9379910 definition as **BOUND**, but Guided Automatic P01 Setup stopped with:

`Load the protected original and XDF in Calibration before confirming the definition.`

The header Refresh button also failed to repair the state because it only repainted the renderer from cached backend information.

## Implemented repair

- Added verified-original reconciliation using the two saved 524,288-byte matching reads and the protected BIN bytes on disk.
- Accepts current workspace `binding` fingerprints when beta.21/beta.22 legacy `sourceBinSha256` or `sourceXdfSha256` fields are stale.
- Repairs a stale P01 canonical read hash from the verified read pair.
- Automatically confirms only TunIQ commissioning-only definitions with zero writable tables.
- Writable definitions remain strict and must match the project, BIN SHA-256, and XDF SHA-256.
- Added backend `workspace:reconcile` IPC and renderer/preload contracts.
- Refresh now rebuilds the workspace and P01 state from disk.
- Startup performs non-destructive reconciliation.
- Resume performs reconciliation before evaluating the old failed state.
- The old unrecoverable definition error is converted to `create-revision`, preserving all completed read steps.

## Final source verification

- `npm run check`: **PASS**
- `npm test`: **PASS — 28/28 groups**
- Dedicated Workspace State Reconciliation simulations: **PASS — 3/3**
- Complete focused/recovery simulations: **PASS — 49/49**

## Dedicated beta.23 scenarios

1. **Stale canonical hash**
   - Verified pair and protected BIN matched.
   - Bound commissioning workspace remained accepted.
   - P01 canonical hash was repaired and the definition confirmed.

2. **Stale legacy workspace source fields**
   - Legacy `source*Sha256` values were deliberately wrong.
   - Current workspace binding hashes matched the files on disk.
   - Commissioning definition confirmation succeeded.

3. **Failed workflow repair**
   - Reproduced beta.22 `unexpected-error` with no resumable next step.
   - Rebuilt state as resumable.
   - Resume phase became `create-revision`.

## Retained safety and regression coverage

The retained suite passed for:

- PCM Hammer observed CLI syntax and command-profile recovery
- Direct COM ownership and stale bridge recovery
- Two exact 524,288-byte reads and SHA-256 matching
- Partial, mismatched, disconnected, and repeated-block read failures
- Exact XDF and Universal Patcher definition handling
- Read-only commissioning fallback and stock-clone validation
- Integrated Test Write simulation
- Project-scoped calibration workspaces and snapshot recovery
- Autonomous and closed-loop tuning simulations
- Garage, Quality of Life, Connection Doctor, and Offline P01 Lab

## Hardware boundary

This release was **not** validated with the user’s Windows runtime, COM3, OBDLink MX+, vehicle, P01 PCM, battery support, or physical PCM Hammer Test Write. The software regression is covered, but the next run on the user’s computer remains the real hardware validation.

## Exact archive verification

The packaged ZIP was extracted into a separate clean directory.

- ZIP integrity: **PASS**
- Internal source manifest: **171/171 files matched**
- Extracted `npm run check`: **PASS**
- Extracted `npm test`: **PASS — 28/28 groups**
- Extracted Workspace State Reconciliation simulations: **PASS — 3/3**
- Extracted complete focused/recovery chain: **PASS — 49/49**
