# Developer Notes — v1.7.0-beta.22

## Root cause

`tune-workspace.bindingFor()` and `loadActiveXdfWorkspace()` could prefer cached `active.binInfo.sha256` instead of hashing the protected BIN bytes. A migrated project could therefore save an XDF workspace whose source BIN fingerprint differed from the canonical two-read proof.

## Fix

- `bindingFor()` always hashes the current BIN bytes.
- `loadActiveXdfWorkspace()` refreshes stale BIN/XDF metadata and stores the actual hashes.
- Guided P01 definition binding performs a one-time commissioning-only workspace rebuild when it detects the beta.21 stale-binding error.
- Regression coverage uses a deliberately incorrect cached BIN SHA-256 and proves automatic confirmation succeeds without manual Calibration loading.
