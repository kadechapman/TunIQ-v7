# TunIQ v1.7.0-beta.25 Test Report

## Release

- Version: `1.7.0-beta.25`
- Name: **P01 Test Write Runtime Recovery**
- Base: `v1.7.0-beta.24 P01 Setup Finalizer`

## Real diagnostic reproduced

The uploaded beta.24 diagnostic showed two Test Write attempts using the correct installed-CLI command form:

```text
--test-write <verified stock clone> --device COM3
```

Both attempts exited with code 1 before PCM communication. The useful output was:

```text
Warning: no .bin kernel files found in the TunIQ project directory.
Error: could not open the selected device: Timed out trying to open serial port COM3.
```

The diagnostic also showed that the stock clone and commissioning steps were already complete. Beta.25 therefore changes only the runtime launch and COM recovery layer; it does not redo or weaken the verified read/clone safeguards.

## Implemented fixes

- Searches the configured PCM Hammer portable installation for `Kernel-*.bin` and `Loader-*.bin` files.
- Passes the verified folder using `--kernel-dir` for Read, Test Write, and write-related operations.
- Uses the kernel/tool directory as the PCM Hammer process working directory instead of the TunIQ project directory.
- Runs PCM Hammer `--list-devices` and combines those results with TunIQ's Windows OBDLink port ranking.
- On a pre-communication serial-open timeout, releases TunIQ's serial ownership and retries the selected port once.
- If that still fails, switches once to a recognized outgoing alternate OBDLink COM port for non-destructive operations.
- Stops after a bounded number of attempts; no retry loop is possible.
- Reports `adapter-open-timeout` or `kernel-files-missing` instead of generic `pcmhammer-failed`.
- Records exact kernel provenance, command line, attempted ports, exit code, and output in diagnostics.
- Does not automatically switch devices during Calibration Write, Full Write, or Recovery.

## Automated verification

- Source syntax check: **passed**
- Automated test groups: **31/31 passed**
- Focused simulations: **59/59 passed**
- New Test Write runtime recovery scenarios: **3/3 passed**

### New diagnostic-driven scenarios

1. **COM3 timeout → outgoing COM4 recovery**
   - Kernel folder discovered from a portable `PCMHammer/Kernels` layout.
   - `--kernel-dir` added to Test Write.
   - COM3 retried once after clearing TunIQ bridge ownership.
   - PCM Hammer `--list-devices` identified COM4 as the outgoing OBDLink port.
   - Test Write completed successfully on COM4.

2. **No usable alternate port**
   - COM3 was attempted exactly twice total.
   - Operation stopped with `adapter-open-timeout`.
   - The error named the real Windows/Bluetooth open failure.
   - No infinite retry occurred.

3. **Incomplete PCM Hammer package**
   - No valid kernel files were available.
   - TunIQ stopped before launching Test Write with `kernel-files-missing`.
   - No false hardware result was accepted.

## Retained regression coverage

All retained P01 finalizer, definition binding, workspace reconciliation, real CLI command recovery, integrated PCM Hammer, COM recovery, read mismatch, partial read, repeated block failure, disconnect/restart recovery, Connection Doctor, Garage, project workspace, autonomous tuning, closed-loop tuning, and quality-of-life simulations passed.

## Hardware boundary

This release was not physically run against the user's Windows Bluetooth stack, OBDLink MX+, COM ports, vehicle, or P01 PCM in the build environment. The software now handles the exact diagnostic causes, but a successful physical Test Write can only be confirmed on that PC and vehicle.

## Final source archive verification

The final source archive was sealed with a file-by-file SHA-256 manifest and then extracted into a separate clean directory. Verification covered:

- ZIP integrity
- **184/184** manifested source and test files
- `npm run check`
- `npm test` — **31/31 groups**
- the three diagnostic-driven Test Write runtime recovery scenarios
- the complete 48%-to-Test-Write completion harness
- clean, disconnect/restart, and failed-read P01 recovery scenarios

The extracted archive passed these checks. No physical hardware result is claimed.
