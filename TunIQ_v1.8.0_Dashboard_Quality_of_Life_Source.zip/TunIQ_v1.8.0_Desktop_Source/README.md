# TunIQ v1.8.0 — Dashboard & Quality of Life

TunIQ 1.8.0 is the interface and workflow cleanup release.

The permanent sidebar is reduced from eighteen entries to eight focused workspaces: **Dashboard, Garage, Projects, Tune Center, Live Data, AI Studio, Library, and Settings**. Related modules remain fully available through a small contextual tool bar inside their parent workspace, so Project Files, History, Calibration, Patches, Device Manager, AI Coach, Community, Tool Setup, Diagnostics, and Release Center are no longer competing for permanent navigation space.

The release also introduces the tachometer-Q identity requested for TunIQ. The Q ring forms the logo, its tail becomes the tach needle, the dial is marked from 0–160, and startup accelerates the needle instead of displaying a separate loading bar.

The Dashboard is rebuilt as a command center with the active project, guided next action, six consolidated workspace cards, readiness details, system status, and recent work in one view.

All v1.7.0-beta.26 P01 continuity protections remain included. For the Customline OS 9379910 commissioning path, tuning and real PCM writing remain locked because the generated definition is read-only. The required final commissioning operation remains PCM Hammer **Test Write only**.

See `RELEASE_NOTES_v1.8.0.md` and `TEST_REPORT_v1.8.0.md`.
