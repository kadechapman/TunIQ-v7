# TunIQ v1.8.0 Test Report

## Release

- Version: `1.8.0`
- Channel: `stable`
- Name: **Dashboard & Quality of Life**
- Continuity base: `v1.7.0-beta.26 P01 Continuity Lock`
- Primary project target retained: Customline, GM P01, OS 9379910

## Quality-of-life changes verified

- Tachometer-Q logo exists on the splash screen, header, Dashboard, and first-run profile screen.
- Dial markings include 0–160 and the Q tail is represented by the needle/tail geometry.
- The old loading bar is absent.
- Startup uses the accelerating `tachAccelerate` needle animation.
- Exactly eight permanent sidebar workspaces are exposed.
- Project Files, History, Calibration, Patches, Device Manager, AI Coach, Community, Tool Setup, Diagnostics, and Release Center are contextual tools rather than permanent sidebar entries.
- Child tools highlight the correct parent workspace.
- Contextual navigation updates whenever the active page changes.
- Dashboard exposes six consolidated command cards while retaining all project/readiness IDs required by the renderer.
- Existing Quick Switch, recent work, project switching, Back/Forward, sidebar, density, motion, and restart-restoration behavior remains intact.

## P01 continuity retained

- Existing identity, matching reads, protected original, definition, unchanged commissioning clone, validation, and Test Write progress remain recoverable from project files.
- A beta.26 project with a missing or damaged JSON read ledger recovers two valid 524,288-byte reads from disk.
- Failed, partial, mismatched, and unnecessary third reads do not replace a continuity-locked pair.
- The UI continues at Test Write when earlier evidence is complete.
- Commissioning completion reports setup completion without implying an actual PCM write.
- Read-only commissioning definitions continue to lock AI tuning, manual calibration editing, Calibration Write, Full Write, and OS conversion.

## Automated verification

- Source syntax/static validation: **PASS**
- Full automated suite: **PASS — 34/34 groups**
- New 1.8 QoL/navigation simulations: **PASS — 4/4**
- Stable promotion and AppData migration simulations: **PASS — 3/3**
- P01 continuity-lock simulations: **PASS — 4/4**
- PCM Hammer Test Write runtime recovery: **PASS — 3/3**
- Final 48%-to-Test-Write completion harness: **PASS — 3/3**
- Retained Garage, workspace, tuning, AI, logging, Connection Doctor, startup, COM recovery, definition, and P01 recovery groups: **PASS**

## Hardware boundary

This source package has not performed a physical Test Write against the user's Windows Bluetooth stack, OBDLink MX+, COM3/COM4 ports, Customline, or P01 PCM. It does not claim that real hardware commissioning is complete.
