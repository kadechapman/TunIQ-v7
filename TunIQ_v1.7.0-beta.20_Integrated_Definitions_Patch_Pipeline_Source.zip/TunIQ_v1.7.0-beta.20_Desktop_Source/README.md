# TunIQ v1.7.0-beta.20 — Integrated Definitions & Patch Pipeline

Beta.20 connects the verified PCM read workflow to calibration-definition discovery, TunIQ's native editor, managed TunerPro compatibility work, and managed Universal Patcher validation.

## You do not need to begin with an XDF

After Read Properties and the two matching 524,288-byte reads are complete, **Definition Center** searches:

- The active project's Definitions and Compatibility folders
- TunIQ's managed definition library
- Configured TunerPro folders
- The complete configured Universal Patcher folder, including its XML and Tuner data
- Downloads, Desktop, and Documents during a deep scan

TunIQ accepts only a source declaring the exact project operating system. For the current Customline project that means OS **9379910**.

If an exact Universal Patcher Tuner XML file contains explicit safe table addresses, TunIQ can convert it into an XDF-compatible definition and save a SHA-256 provenance record. It will not infer addresses from a BIN or adapt an XDF for a different OS.

## Integrated workflow

1. PCM Hammer identifies the controller and creates two matching reads inside TunIQ.
2. Definition Center finds, imports, or safely converts an exact-OS definition.
3. TunIQ binds the definition to the protected BIN/XDF fingerprints.
4. Calibration Lab and the Autonomous Tune Agent can edit supported mapped tables natively.
5. A managed TunerPro roundtrip can open an isolated working BIN and exact XDF for compatibility review. TunIQ imports a saved change only as a new revision.
6. A managed Universal Patcher job can validate or correct a working copy. TunIQ imports only a same-layout changed BIN and any valid report, then re-runs its own validation.
7. Test Write and controlled flashing remain gated by the existing P01 safety workflow.

## Important definition boundary

An XDF is calibration metadata, not something that can be safely created from a BIN by guessing. If no exact OS 9379910 XDF or explicit Universal Patcher table XML exists locally, TunIQ creates a managed definition job and stops without modifying the original.

TunerPro and Universal Patcher remain separate installed applications. TunIQ controls their working folders, input hashes, outputs, and revision imports; it does not claim that their Windows interfaces are embedded or that every version supports unattended automation.

## Windows

Extract the ZIP into a new folder and run `INSTALL_AND_RUN_WINDOWS.bat`. Existing projects remain in TunIQ AppData.

## Verification boundary

Beta.20 was verified with automated software tests and simulations. Real TunerPro, Universal Patcher, Windows file dialogs, OS 9379910 definition availability, OBDLink hardware, vehicle, PCM, Test Write, and flashing still require validation on the user's PC.
